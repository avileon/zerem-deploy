#!/bin/bash
#
# הפיכת /opt/zerem לריפו git — פעם אחת בלבד.
#
#   שלב א:  /opt/zerem/setup-git.sh <git@github.com:user/repo.git>
#           מייצר מפתח פריסה ומדפיס אותו. אתה מדביק אותו ב-GitHub.
#
#   שלב ב:  /opt/zerem/setup-git.sh --push
#           דוחף את הקוד הנוכחי ל-GitHub. מכאן והלאה: update.sh בלבד.
#
# ⚠️ המפתח הפרטי נוצר על השרת ולא עוזב אותו. אף אחד — כולל מי שכתב
# את הסקריפט הזה — לא רואה אותו. זו הסיבה שזה עדיף על טוקן שמודבק בצ׳אט.
#
set -euo pipefail
cd /opt/zerem

KEY=/root/.ssh/zerem_deploy

print_key() {
  echo ""
  echo "════════════════════════════════════════════════════════════"
  echo "  העתק את המפתח הבא ל-GitHub:"
  echo "  Settings → Deploy keys → Add deploy key"
  echo "  ✓ סמן \"Allow write access\""
  echo "════════════════════════════════════════════════════════════"
  echo ""
  cat "${KEY}.pub"
  echo ""
  echo "════════════════════════════════════════════════════════════"
}

# ── מפתח פריסה ──
if [ ! -f "$KEY" ]; then
  echo "→ מייצר מפתח פריסה…"
  mkdir -p /root/.ssh && chmod 700 /root/.ssh
  ssh-keygen -t ed25519 -f "$KEY" -N "" -C "zerem-droplet-$(hostname)" -q
  cat >> /root/.ssh/config <<'EOF'

Host github.com
  IdentityFile /root/.ssh/zerem_deploy
  IdentitiesOnly yes
  StrictHostKeyChecking accept-new
EOF
  chmod 600 /root/.ssh/config
  echo "  ✓ נוצר"
fi

# ── שלב ב ──
if [ "${1:-}" = "--push" ]; then
  [ -d .git ] || { echo "✗ הריפו לא אותחל. הרץ קודם בלי --push."; exit 1; }
  echo "→ בודק גישה ל-GitHub…"
  if ! ssh -T git@github.com 2>&1 | grep -qi "successfully authenticated"; then
    echo "✗ GitHub עדיין לא מזהה את המפתח."
    print_key
    exit 1
  fi
  echo "  ✓ מאומת"
  git push -u origin main
  echo ""
  echo "✅ הקוד ב-GitHub. מכאן והלאה מעדכנים כך:"
  echo "   /opt/zerem/update.sh"
  exit 0
fi

# ── שלב א ──
REMOTE="${1:-}"
if [ -z "$REMOTE" ]; then
  echo "שימוש: $0 git@github.com:<user>/<repo>.git"
  echo "       $0 --push        (אחרי הוספת המפתח ב-GitHub)"
  exit 1
fi
case "$REMOTE" in
  git@github.com:*) ;;
  *) echo "✗ נדרשת כתובת SSH: git@github.com:user/repo.git"; exit 1 ;;
esac

# ── .gitignore ──
# ⚠️ .env מכיל את סוד ה-cron ואת מפתחות קארדקום. הוא לעולם לא נכנס לריפו.
cat > .gitignore <<'EOF'
node_modules/
.next/
.env
.env.*
!.env.example
*.log
*.tsbuildinfo
s.tgz
backups/
EOF

if [ ! -d .git ]; then
  echo "→ מאתחל ריפו…"
  git init -q
  git symbolic-ref HEAD refs/heads/main
  git config user.email "deploy@zerem.local"
  git config user.name "Zerem Droplet"
fi

git remote remove origin 2>/dev/null || true
git remote add origin "$REMOTE"

git add -A
if git diff --cached --quiet 2>/dev/null; then
  echo "  ✓ אין שינויים לקומיט"
else
  git commit -q -m "Zerem — baseline from droplet $(date +%Y-%m-%d)"
  echo "  ✓ קומיט ראשון נוצר"
fi

# ודא ש-.env לא נכנס בטעות
if git ls-files --error-unmatch .env >/dev/null 2>&1; then
  echo "✗ .env נכנס לריפו — מסיר"
  git rm --cached .env -q
  git commit -q -m "Remove .env from tracking"
fi

echo ""
echo "→ שלב הבא:"
print_key
echo "  ואז הרץ:  $0 --push"
