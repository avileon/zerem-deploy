#!/bin/bash
#
# חזרה לגרסה קודמת.
#
#   /opt/zerem/rollback.sh            — גרסה אחת אחורה
#   /opt/zerem/rollback.sh <commit>   — לגרסה מסוימת
#   /opt/zerem/rollback.sh --list     — מה זמין
#
# ⚠️ חזרה בקוד **אינה** מבטלת מיגרציות שכבר רצו.
# אם הגרסה החדשה שינתה סכמה, שחזר גם את בסיס הנתונים מהגיבוי.
# הסקריפט אומר לך מתי זה המצב.
#
set -euo pipefail
cd /opt/zerem

if [ "${1:-}" = "--list" ]; then
  echo "── גרסאות אחרונות ──"
  git log --oneline -15
  echo ""
  echo "── גיבויים ──"
  ls -1t /opt/backups/*.sql.gz 2>/dev/null | head -10 | while read -r f; do
    echo "  $(du -h "$f" | cut -f1)  $f"
  done
  exit 0
fi

CURRENT=$(git rev-parse HEAD)
TARGET="${1:-$(git rev-parse HEAD~1)}"

echo "מ:  $(git log -1 --format='%h %s' "$CURRENT" | head -c 70)"
echo "אל: $(git log -1 --format='%h %s' "$TARGET" | head -c 70)"

# האם היו שינויי סכמה בין הגרסאות?
CHANGED=$(git diff --name-only "$TARGET" "$CURRENT" -- drizzle/ | wc -l)
if [ "$CHANGED" -gt 0 ]; then
  echo ""
  echo "⚠️  היו $CHANGED שינויי מיגרציה בין הגרסאות."
  echo "   חזרה בקוד לא מבטלת אותן. אם המבנה השתנה, שחזר גם נתונים:"
  echo "   gunzip -c /opt/backups/<קובץ>.sql.gz | docker compose exec -T db psql -U postgres zerem"
  echo ""
  read -r -p "להמשיך בכל זאת? (yes/no) " a
  [ "$a" = "yes" ] || { echo "בוטל."; exit 1; }
fi

git reset --hard --quiet "$TARGET"
docker compose up -d --build

for i in $(seq 1 60); do
  if docker exec zerem-app node -e \
     'fetch("http://localhost:3000/login").then(r=>process.exit(r.status<400?0:1)).catch(()=>process.exit(1))' \
     >/dev/null 2>&1; then
    echo "✅ חזרה הושלמה — $(git log -1 --format='%h %s' | head -c 60)"
    exit 0
  fi
  sleep 3
done

echo "✗ האפליקציה לא עלתה גם אחרי החזרה. בדוק: docker compose logs app --tail 60"
exit 1
