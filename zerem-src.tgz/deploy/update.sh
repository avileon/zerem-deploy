#!/bin/bash
#
# עדכון גרסה של זרם — בטוח לנתונים.
#
#   בשרת:  /opt/zerem/update.sh
#
# מה הוא עושה, לפי הסדר:
#   1. גיבוי מלא של בסיס הנתונים (עוצר אם נכשל)
#   2. git pull — קוד בלבד, ה-.env והוולום של Postgres לא נגעים
#   3. בנייה מחדש והפעלה
#   4. מיגרציות סכמה (קבצי SQL מגורסאות, לא push)
#   5. בדיקת בריאות — ואם היא נכשלת, חזרה אוטומטית לגרסה הקודמת
#
# ⚠️ מה שהוא **לא** עושה: לא מריץ `drizzle-kit push`, לא מוחק ולומים,
# ולא זורע מחדש נתונים קיימים. שלושת אלה הם הדרכים המקובלות לאבד דאטה.
#
set -euo pipefail
cd /opt/zerem

STAMP=$(date +%Y%m%d-%H%M%S)
LOG=/var/log/zerem-update.log
exec > >(tee -a "$LOG") 2>&1

echo ""
echo "════════════════════════════════════════"
echo "  עדכון זרם · $(date '+%d/%m/%Y %H:%M')"
echo "════════════════════════════════════════"

# ── 0. בדיקות מקדימות ──
command -v git >/dev/null || { echo "✗ git לא מותקן"; exit 1; }
[ -d .git ] || { echo "✗ /opt/zerem אינו ריפו git. הרץ קודם את migrate-to-git.sh"; exit 1; }

FREE_MB=$(df -Pm /var/lib/docker | awk 'NR==2 {print $4}')
if [ "$FREE_MB" -lt 1500 ]; then
  echo "✗ נשארו ${FREE_MB}MB בלבד. בנייה תיכשל. נקה עם: docker system prune -af"
  exit 1
fi

# ── 1. גיבוי ──
echo ""
echo "→ [1/5] מגבה את בסיס הנתונים…"
mkdir -p /opt/backups
BACKUP="/opt/backups/zerem-${STAMP}.sql.gz"
if ! docker compose exec -T db pg_dump -U postgres zerem | gzip > "$BACKUP"; then
  echo "✗ הגיבוי נכשל — לא ממשיכים. עדכון בלי גיבוי הוא הימור."
  rm -f "$BACKUP"
  exit 1
fi
SIZE=$(du -h "$BACKUP" | cut -f1)
echo "  ✓ $BACKUP ($SIZE)"
ls -1t /opt/backups/*.sql.gz 2>/dev/null | tail -n +15 | xargs -r rm   # שומרים 14 אחרונים

# ── 2. קוד ──
echo ""
echo "→ [2/5] מושך קוד…"
PREV=$(git rev-parse HEAD)
git fetch --quiet origin
NEXT=$(git rev-parse origin/main)

if [ "$PREV" = "$NEXT" ]; then
  echo "  ✓ כבר על הגרסה האחרונה ($(git log -1 --format=%s | head -c 60))"
  echo "    שום דבר לעדכן. הגיבוי נשמר בכל זאת."
  exit 0
fi

echo "  מ:  $(git log -1 --format='%h %s' "$PREV" | head -c 70)"
echo "  אל: $(git log -1 --format='%h %s' "$NEXT" | head -c 70)"
git reset --hard --quiet origin/main
echo "  ✓ הקוד עודכן"

# ── 3. בנייה ──
echo ""
echo "→ [3/5] בונה ומפעיל…"
if ! docker compose up -d --build; then
  echo "✗ הבנייה נכשלה — חוזר לגרסה הקודמת"
  git reset --hard --quiet "$PREV"
  docker compose up -d --build || true
  exit 1
fi

# ── 4 + 5. מיגרציות ובריאות ──
# המיגרציות רצות בתוך ה-entrypoint של הקונטיינר, לכן מספיק להמתין לו.
echo ""
echo "→ [4/5] מיגרציות ואתחול…"
HEALTHY=0
for i in $(seq 1 80); do
  if docker exec zerem-app node -e \
     'fetch("http://localhost:3000/login").then(r=>process.exit(r.status<400?0:1)).catch(()=>process.exit(1))' \
     >/dev/null 2>&1; then HEALTHY=1; break; fi
  sleep 3
done

echo ""
docker compose logs app --tail 40 2>&1 | grep -E "מיגרצי|זורע|מסנכרן|✓|⚠|✗" | tail -12

echo ""
echo "→ [5/5] בדיקת בריאות…"
if [ "$HEALTHY" != "1" ]; then
  echo "✗ האפליקציה לא עלתה. חוזר לגרסה הקודמת."
  echo "  ⚠️ שים לב: מיגרציות שכבר רצו אינן מבוטלות אוטומטית."
  echo "     אם הסכמה השתנתה, שחזר מהגיבוי:"
  echo "     gunzip -c $BACKUP | docker compose exec -T db psql -U postgres zerem"
  git reset --hard --quiet "$PREV"
  docker compose up -d --build || true
  exit 1
fi

for p in /login /console/login /pricing; do
  CODE=$(docker exec -e P="$p" zerem-app node -e \
    'fetch("http://localhost:3000"+process.env.P).then(r=>console.log(r.status)).catch(()=>console.log("ERR"))' 2>/dev/null)
  printf "   %-16s %s\n" "$p" "$CODE"
done

ORGS=$(docker compose exec -T db psql -U postgres zerem -tAc "SELECT count(*) FROM organizations" 2>/dev/null | tr -d ' ')
LEADS=$(docker compose exec -T db psql -U postgres zerem -tAc "SELECT count(*) FROM leads" 2>/dev/null | tr -d ' ')

echo ""
echo "════════════════════════════════════════"
echo "  ✅ העדכון הושלם"
echo "  גרסה: $(git log -1 --format='%h — %s' | head -c 60)"
echo "  נתונים: $ORGS עסקים · $LEADS לידים"
echo "  גיבוי: $BACKUP"
echo "════════════════════════════════════════"
