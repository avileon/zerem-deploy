'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Avatar } from './ui';

const PRIMARY = [
  { href: '/', label: 'בית', icon: '◎' },
  { href: '/leads', label: 'לידים', icon: '👥' },
  { href: '/quotes/new', label: '', icon: '＋', fab: true },
  { href: '/tasks', label: 'משימות', icon: '✓', badge: 4 },
  { href: '/more', label: 'עוד', icon: '⋯' },
];

const DESKTOP_NAV: Array<{ group: string; manager?: boolean; items: Array<{ href: string; label: string; icon: string; badge?: number }> }> = [
  { group: 'עבודה', items: [
    { href: '/', label: 'דשבורד', icon: '◎' },
    { href: '/leads', label: 'לידים', icon: '👥' },
    { href: '/tasks', label: 'משימות', icon: '✓', badge: 4 },
  ]},
  { group: 'מכירות', items: [
    { href: '/quotes', label: 'הצעות מחיר', icon: '📄' },
    { href: '/payments', label: 'תשלומים', icon: '💳' },
    { href: '/catalog', label: 'קטלוג', icon: '🏷️' },
  ]},
  // ⚠️ קבוצת המנהל מוסתרת מעובד. ההסתרה היא נוחות —
  // האכיפה נמצאת ב-requireManager() בכל אחד מהדפים האלה.
  { group: 'ניהול', manager: true, items: [
    { href: '/reports', label: 'דוחות', icon: '📊' },
    { href: '/integrations', label: 'אינטגרציות', icon: '🔌' },
    { href: '/team', label: 'צוות', icon: '🧑‍💼' },
    { href: '/settings/billing', label: 'חיוב ומנוי', icon: '💠' },
  ]},
];

export interface ShellSession {
  role: 'MANAGER' | 'EMPLOYEE';
  userName: string;
  orgName: string;
  impersonatedBy: string | null;
}

/** מסכים שמתרנדרים בלי המעטפת — התחברות, קונסולה, חתימה ציבורית */
const BARE = ['/q/', '/login', '/signup', '/set-password', '/forgot-password', '/console', '/billing/return'];

export default function Shell({ children, session }: { children: React.ReactNode; session?: ShellSession | null }) {
  const path = usePathname();
  const [installable, setInstallable] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    const onPrompt = (e: Event) => { e.preventDefault(); setInstallable(true); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    return () => window.removeEventListener('beforeinstallprompt', onPrompt);
  }, []);

  if (BARE.some((p) => path === p || path.startsWith(p))) return <>{children}</>;
  // בלי סשן אין מעטפת — הדף עצמו יפנה להתחברות
  if (!session) return <>{children}</>;

  const isManager = session.role === 'MANAGER';
  const nav = DESKTOP_NAV.filter((g) => !g.manager || isManager);

  const active = (href: string) => (href === '/' ? path === '/' : path.startsWith(href));

  async function signOut() {
    await fetch('/api/auth/logout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'TENANT' }),
    });
    window.location.href = '/login';
  }

  return (
    <div className={`flex min-h-screen ${session.impersonatedBy ? 'pt-7' : ''}`}>
      {/* ⚠️ באנר התחזות — הלקוח חייב לדעת שמישהו מהפלטפורמה בחשבון שלו.
          "צפייה חשאית" בנתוני לקוח היא בעיה משפטית, לא רק אתית. */}
      {session.impersonatedBy && (
        <div className="fixed inset-x-0 top-0 z-50 flex items-center justify-center gap-3 px-4 py-1.5 text-[11px] font-bold text-white"
             style={{ background: 'linear-gradient(90deg,#f59e0b,#d97706)' }}>
          <span>👁️ {session.impersonatedBy} צופה בחשבון הזה מהקונסולה</span>
          <button onClick={signOut} className="rounded-md bg-black/20 px-2 py-0.5">יציאה</button>
        </div>
      )}
      {/* ── סרגל צד ── */}
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col lg:flex"
             style={{ background: 'linear-gradient(170deg,#0f172a 0%,#0d2b2a 55%,#0f3b38 100%)' }}>
        <div className="flex items-center gap-3 px-5 py-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl text-lg font-black text-white"
               style={{ background: 'linear-gradient(135deg,#14b8a6,#0f766e)', boxShadow: '0 6px 18px -4px rgb(20 184 166 / .5)' }}>
            ז
          </div>
          <div>
            <div className="text-[17px] font-extrabold leading-none text-white">זרם</div>
            <div className="mt-1 truncate text-[10px] text-teal-200/70">{session.orgName}</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          {nav.map((g) => (
            <div key={g.group} className="mb-5">
              <div className="px-3 pb-2 text-[10px] font-bold tracking-wider text-slate-500">{g.group}</div>
              {g.items.map((it) => {
                const on = active(it.href);
                return (
                  <Link key={it.href} href={it.href}
                    className={`group relative mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-all ${
                      on ? 'text-white' : 'text-slate-300/80 hover:bg-white/5 hover:text-white'}`}
                    style={on ? { background: 'linear-gradient(135deg,rgb(20 184 166 / .22),rgb(15 118 110 / .3))', boxShadow: 'inset 0 0 0 1px rgb(45 212 191 / .25)' } : undefined}>
                    {on && <span className="absolute right-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-l-full bg-teal-400" />}
                    <span className={`w-4 text-center text-[14px] transition-transform group-hover:scale-110 ${on ? 'opacity-100' : 'opacity-70'}`}>{it.icon}</span>
                    <span className="flex-1">{it.label}</span>
                    {it.badge ? (
                      <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-bold text-white shadow-sm">{it.badge}</span>
                    ) : null}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="mx-3 mb-3 rounded-2xl bg-white/5 p-3 backdrop-blur">
          <div className="flex items-center gap-2.5">
            <Avatar name={session.userName} size={34} ring />
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-bold text-white">{session.userName}</div>
              <div className="truncate text-[10px] text-teal-200/70">{isManager ? 'מנהל' : 'עובד'}</div>
            </div>
            <span className="h-2 w-2 rounded-full bg-green-400 pulse-dot" />
          </div>
          <button onClick={signOut}
            className="mt-2 w-full rounded-lg bg-white/10 py-1.5 text-[11px] font-bold text-teal-100 transition hover:bg-white/15">
            יציאה
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* ── כותרת מובייל ── */}
        <header className="safe-t card-glass sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200/60 px-4 py-3 lg:hidden">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl text-base font-black text-white"
               style={{ background: 'linear-gradient(135deg,#14b8a6,#0f766e)', boxShadow: '0 4px 12px -2px rgb(20 184 166 / .45)' }}>
            ז
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[15px] font-extrabold leading-tight text-slate-900">זרם</div>
            <div className="truncate text-[10px] text-slate-400">{session.orgName}</div>
          </div>
          <Link href="/notifications" className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-white text-base shadow-sm ring-1 ring-slate-200">
            🔔
            <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-rose-500 ring-2 ring-white" />
          </Link>
          <Avatar name={session.userName} size={34} />
        </header>

        {installable && (
          <div className="flex items-center gap-2 px-4 py-2.5 text-xs text-white lg:hidden"
               style={{ background: 'linear-gradient(135deg,#0d9488,#0f766e)' }}>
            <span className="text-base">📲</span>
            <span className="flex-1 font-medium">התקן את זרם על המסך הראשי</span>
            <button className="rounded-lg bg-white/25 px-2.5 py-1 font-bold backdrop-blur">התקן</button>
          </div>
        )}

        <main className="min-w-0 flex-1 pb-28 lg:pb-0">{children}</main>

        {/* ── בר תחתון עם FAB ── */}
        <nav className="safe-b card-glass fixed inset-x-0 bottom-0 z-30 flex border-t border-slate-200/60 lg:hidden">
          {PRIMARY.map((it) => {
            if (it.fab) {
              return (
                <Link key={it.href} href={it.href} className="relative flex flex-1 justify-center">
                  <span className="absolute -top-6 flex h-14 w-14 items-center justify-center rounded-2xl text-2xl font-light text-white"
                        style={{ background: 'linear-gradient(135deg,#14b8a6,#0f766e)', boxShadow: '0 10px 24px -6px rgb(13 148 136 / .55)' }}>
                    {it.icon}
                  </span>
                </Link>
              );
            }
            const on = active(it.href);
            return (
              <Link key={it.href} href={it.href}
                className={`relative flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[10px] font-bold transition-colors ${
                  on ? 'text-teal-700' : 'text-slate-400'}`}>
                <span className={`text-lg leading-none transition-transform ${on ? 'scale-110' : ''}`}>{it.icon}</span>
                {it.label}
                {it.badge ? (
                  <span className="absolute right-[20%] top-1 rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white ring-2 ring-white">{it.badge}</span>
                ) : null}
                {on && <span className="absolute inset-x-5 top-0 h-0.5 rounded-full bg-teal-600" />}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
