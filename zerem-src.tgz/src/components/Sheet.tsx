'use client';
import { useEffect, useState } from 'react';

/**
 * גיליון תחתון במובייל, מודאל בדסקטופ.
 * הרכיב היחיד שמשמש לכל טופסי היצירה — כדי שהתנהגות המקלדת,
 * ה-Escape וגלילה תהיה זהה בכל מקום.
 */
export function Sheet({
  title, subtitle, children, onClose,
}: { title: string; subtitle?: string; children: React.ReactNode; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/45 lg:items-center lg:justify-center"
         onClick={onClose}>
      <div
        className="safe-b max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 lg:max-w-md lg:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
        <h3 className="text-base font-black text-slate-900">{title}</h3>
        {subtitle && <p className="mt-1 text-[12px] leading-relaxed text-slate-500">{subtitle}</p>}
        <div className="mt-4">{children}</div>
      </div>
    </div>
  );
}

export function Field({
  label, hint, children, required,
}: { label: string; hint?: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-bold text-slate-500">
        {label}{required && <span className="text-rose-500"> *</span>}
      </span>
      {children}
      {hint && <span className="mt-0.5 block text-[10px] text-slate-400">{hint}</span>}
    </label>
  );
}

export function TextInput({
  value, onChange, ltr, type, placeholder, required, autoFocus,
}: {
  value: string; onChange: (v: string) => void;
  ltr?: boolean; type?: string; placeholder?: string; required?: boolean; autoFocus?: boolean;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      type={type ?? 'text'}
      dir={ltr ? 'ltr' : undefined}
      placeholder={placeholder}
      required={required}
      autoFocus={autoFocus}
      inputMode={type === 'number' ? 'decimal' : type === 'tel' ? 'tel' : undefined}
      className={`input ${ltr ? 'ltr' : ''}`}
    />
  );
}

export function Choice<T extends string>({
  value, onChange, options,
}: { value: T; onChange: (v: T) => void; options: Array<[T, string]> }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map(([k, label]) => (
        <button
          key={k} type="button" onClick={() => onChange(k)}
          className={`chip px-2.5 py-1.5 ${
            value === k ? 'bg-teal-700 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

export function FormError({ error }: { error: string | null }) {
  if (!error) return null;
  return (
    <div className="rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold leading-relaxed text-rose-700">
      {error}
    </div>
  );
}

export function Actions({
  onCancel, busy, submitLabel,
}: { onCancel: () => void; busy: boolean; submitLabel: string }) {
  return (
    <div className="flex gap-2 pt-1">
      <button type="button" onClick={onCancel} className="btn btn-ghost flex-1">ביטול</button>
      <button type="submit" disabled={busy} className="btn btn-primary flex-1">
        {busy ? 'שומר…' : submitLabel}
      </button>
    </div>
  );
}

/** שולח טופס ומחזיר שגיאה קריאה. מרכז את טיפול השגיאות במקום אחד. */
export function useSubmit() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send(url: string, method: string, body: unknown) {
    setBusy(true); setError(null);
    const r = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת — בדוק חיבור' }));
    setBusy(false);
    if (!r.ok) setError(r.error ?? 'הפעולה נכשלה');
    return r;
  }

  return { busy, error, setError, send };
}
