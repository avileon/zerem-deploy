'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

/**
 * מעטפת הקונסולה — עולם ויזואלי נפרד לחלוטין מאפליקציית הלקוח.
 * טורקיז = לקוח. אינדיגו = פלטפורמה. אתה אף פעם לא מבלבל ביניהם.
 */
const NAV = [
  { group: 'פלטפורמה', items: [
    { href: '/console', label: 'סקירה', icon: '◎', exact: true },
    { href: '/console/businesses', label: 'עסקים', icon: '🏢' },
    { href: '/console/revenue', label: 'הכנסות', icon: '📈' },
  ]},
  { group: 'מסחר', items: [
    { href: '/console/subscriptions', label: 'מנויים', icon: '📋' },
    { href: '/console/coupons', label: 'קופונים', icon: '🎟️' },
    { href: '/console/plans', label: 'חבילות', icon: '📦' },
  ]},
  { group: 'מערכת', items: [
    { href: '/console/admins', label: 'מנהלי מערכת', icon: '🛡️' },
    { href: '/console/audit', label: 'יומן פעולות', icon: '🧾' },
  ]},
];

export default function ConsoleShell({
  admin, children,
}: { admin: { name: string; email: string; isOwner: boolean }; children: React.ReactNode }) {
  const path = usePathname();
  const active = (href: string, exact?: boolean) =>
    exact ? path === href : path === href || path.startsWith(href + '/');

  async function signOut() {
    await fetch('/api/auth/logout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: 'CONSOLE' }),
    });
    window.location.href = '/console/login';
  }

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col lg:flex"
             style={{ background: 'linear-gradient(170deg,#0f172a 0%,#1e1b4b 55%,#312e81 100%)' }}>
        <div className="flex items-center gap-3 px-5 py-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl text-lg font-black text-white"
               style={{ background: 'linear-gradient(135deg,#818cf8,#4f46e5)',
                        boxShadow: '0 6px 18px -4px rgb(99 102 241 / .55)' }}>
            ז
          </div>
          <div className="min-w-0">
            <div className="text-[16px] font-extrabold leading-none text-white">קונסולה</div>
            <div className="mt-1 truncate text-[10px] text-indigo-200/70">זרם · פלטפורמה</div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          {NAV.map((g) => (
            <div key={g.group} className="mb-4">
              <div className="px-3 pb-2 text-[10px] font-bold tracking-wider text-indigo-300/50">
                {g.group}
              </div>
              {g.items.map((it) => {
                const on = active(it.href, it.exact);
                return (
                  <Link key={it.href} href={it.href}
                    className={`relative mb-0.5 flex items-center gap-2.5 rounded-xl px-3 py-2 text-[13px] font-semibold transition ${
                      on ? 'bg-white/10 text-white ring-1 ring-inset ring-white/15'
                         : 'text-indigo-100/70 hover:bg-white/5 hover:text-white'}`}>
                    <span className="w-4 text-center opacity-80">{it.icon}</span>
                    {it.label}
                    {on && <span className="absolute inset-y-2 right-0 w-[3px] rounded-full bg-indigo-400" />}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="border-t border-white/10 p-3">
          <div className="rounded-xl bg-white/5 p-3">
            <div className="truncate text-[12px] font-bold text-white">{admin.name}</div>
            <div className="ltr truncate text-[10px] text-indigo-200/60">{admin.email}</div>
            <button onClick={signOut}
              className="mt-2 w-full rounded-lg bg-white/10 py-1.5 text-[11px] font-bold text-indigo-100 transition hover:bg-white/15">
              יציאה
            </button>
          </div>
        </div>
      </aside>

      {/* ── מובייל ── */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl text-sm font-black text-white"
               style={{ background: 'linear-gradient(135deg,#818cf8,#4f46e5)' }}>ז</div>
          <div className="flex-1 text-sm font-extrabold text-slate-900">קונסולה</div>
          <button onClick={signOut} className="text-[11px] font-bold text-slate-400">יציאה</button>
        </header>

        <div className="flex gap-1 overflow-x-auto border-b border-slate-200 bg-white px-3 py-2 lg:hidden">
          {NAV.flatMap((g) => g.items).map((it) => (
            <Link key={it.href} href={it.href}
              className={`whitespace-nowrap rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition ${
                active(it.href, it.exact) ? 'bg-indigo-600 text-white' : 'text-slate-500'}`}>
              {it.label}
            </Link>
          ))}
        </div>

        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  );
}
