'use client';
import { useState } from 'react';

/**
 * טופס אימות משותף — התחברות ללקוח, לקונסולה, וקביעת סיסמה.
 * הבדל ויזואלי מכוון בין שני העולמות: כהה לקונסולה, בהיר ללקוח.
 * זה לא קישוט — זו הדרך שבה אתה יודע ברגע אם אתה בעולם הנכון.
 */
export default function AuthForm({
  mode, title, subtitle, endpoint, next, token, footer,
}: {
  mode: 'tenant' | 'console' | 'set-password';
  title: string;
  subtitle?: string;
  endpoint: string;
  next?: string;
  token?: string;
  footer?: React.ReactNode;
}) {
  const dark = mode === 'console';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isSetPassword = mode === 'set-password';

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (isSetPassword && password !== confirm) {
      setError('הסיסמאות אינן זהות');
      return;
    }

    setBusy(true);
    const body = isSetPassword ? { token, password } : { email, password, next };
    const r = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(false);

    if (r.ok) window.location.href = r.redirect ?? '/';
    else setError(r.error ?? 'משהו השתבש');
  }

  return (
    <div
      className="flex min-h-screen items-center justify-center p-5"
      style={dark
        ? { background: 'linear-gradient(160deg,#0f172a 0%,#0d2b2a 55%,#0f3b38 100%)' }
        : undefined}
    >
      <div className={`w-full max-w-sm rounded-3xl p-7 ${
        dark ? 'bg-white/5 ring-1 ring-white/10 backdrop-blur' : 'card'}`}>

        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl text-xl font-black text-white"
               style={{
                 background: dark
                   ? 'linear-gradient(135deg,#818cf8,#4f46e5)'
                   : 'linear-gradient(135deg,#14b8a6,#0f766e)',
                 boxShadow: dark
                   ? '0 6px 18px -4px rgb(99 102 241 / .55)'
                   : '0 6px 18px -4px rgb(20 184 166 / .5)',
               }}>
            ז
          </div>
          <div>
            <div className={`text-lg font-extrabold leading-none ${dark ? 'text-white' : 'text-slate-900'}`}>
              {title}
            </div>
            {subtitle && (
              <div className={`mt-1 text-[11px] ${dark ? 'text-indigo-200/70' : 'text-slate-400'}`}>
                {subtitle}
              </div>
            )}
          </div>
        </div>

        <form onSubmit={submit} className="space-y-3">
          {!isSetPassword && (
            <Field dark={dark} label="אימייל">
              <input
                type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                required autoComplete="username" dir="ltr"
                className={inputCls(dark)} placeholder="you@business.co.il"
              />
            </Field>
          )}

          <Field dark={dark} label={isSetPassword ? 'סיסמה חדשה' : 'סיסמה'}>
            <div className="relative">
              <input
                type={show ? 'text' : 'password'} value={password}
                onChange={(e) => setPassword(e.target.value)}
                required dir="ltr"
                autoComplete={isSetPassword ? 'new-password' : 'current-password'}
                className={inputCls(dark)}
              />
              <button type="button" onClick={() => setShow((v) => !v)}
                className={`absolute left-2 top-1/2 -translate-y-1/2 rounded-lg px-2 py-1 text-[11px] ${
                  dark ? 'text-indigo-200/70 hover:text-white' : 'text-slate-400 hover:text-slate-600'}`}>
                {show ? 'הסתר' : 'הצג'}
              </button>
            </div>
          </Field>

          {isSetPassword && (
            <>
              <Field dark={dark} label="אישור סיסמה">
                <input
                  type={show ? 'text' : 'password'} value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  required dir="ltr" autoComplete="new-password" className={inputCls(dark)}
                />
              </Field>
              <div className={`text-[10px] leading-relaxed ${dark ? 'text-indigo-200/50' : 'text-slate-400'}`}>
                לפחות 10 תווים. סיסמה ארוכה עדיפה על סיסמה מסובכת — צירוף של שלוש
                מילים שרק אתה זוכר חזק יותר מ-Ab3!x9.
              </div>
            </>
          )}

          {error && (
            <div className={`rounded-xl px-3 py-2 text-[12px] font-semibold ${
              dark ? 'bg-rose-500/15 text-rose-200' : 'bg-rose-50 text-rose-700'}`}>
              {error}
            </div>
          )}

          <button type="submit" disabled={busy}
            className="w-full rounded-xl py-2.5 text-sm font-bold text-white transition active:scale-[.98] disabled:opacity-60"
            style={{ background: dark
              ? 'linear-gradient(135deg,#6366f1,#4338ca)'
              : 'linear-gradient(135deg,#14b8a6,#0f766e)' }}>
            {busy ? 'רגע…' : isSetPassword ? 'שמירה וכניסה' : 'כניסה'}
          </button>
        </form>

        {footer && (
          <div className={`mt-5 border-t pt-4 text-center text-[11px] ${
            dark ? 'border-white/10 text-indigo-200/60' : 'border-slate-100 text-slate-400'}`}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ dark, label, children }: { dark: boolean; label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className={`mb-1 block text-[11px] font-bold ${dark ? 'text-indigo-200/70' : 'text-slate-500'}`}>
        {label}
      </span>
      {children}
    </label>
  );
}

const inputCls = (dark: boolean) =>
  `w-full rounded-xl px-3 py-2.5 text-sm outline-none transition ${
    dark
      ? 'bg-white/10 text-white ring-1 ring-white/15 placeholder:text-white/30 focus:ring-2 focus:ring-indigo-400'
      : 'border border-slate-200 bg-white text-slate-800 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20'
  }`;
