import Link from 'next/link';
import type { ReactNode } from 'react';

const TONES: Record<string, string> = {
  teal: 'bg-teal-50 text-teal-800 border-teal-200/70',
  green: 'bg-green-50 text-green-700 border-green-200/70',
  amber: 'bg-amber-50 text-amber-700 border-amber-200/70',
  rose: 'bg-rose-50 text-rose-700 border-rose-200/70',
  sky: 'bg-sky-50 text-sky-700 border-sky-200/70',
  violet: 'bg-violet-50 text-violet-700 border-violet-200/70',
  slate: 'bg-slate-100 text-slate-600 border-slate-200/70',
};

export function Chip({ tone = 'slate', children }: { tone?: string; children: ReactNode }) {
  return <span className={`chip border ${TONES[tone] ?? TONES.slate}`}>{children}</span>;
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="rise mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-extrabold tracking-tight text-slate-900 lg:text-[26px]">{title}</h1>
        {subtitle && <p className="mt-1 text-xs text-slate-500 lg:text-sm">{subtitle}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

const STAT_ACCENT: Record<string, string> = {
  teal: 'from-teal-500 to-teal-700',
  green: 'from-green-500 to-green-700',
  amber: 'from-amber-400 to-amber-600',
  rose: 'from-rose-400 to-rose-600',
  sky: 'from-sky-400 to-sky-600',
  violet: 'from-violet-400 to-violet-600',
};

export function Stat({
  label, value, hint, tone = 'teal', href, icon, delay,
}: { label: string; value: ReactNode; hint?: ReactNode; tone?: string; href?: string; icon?: string; delay?: number }) {
  const body = (
    <div className={`card card-hover relative overflow-hidden p-3.5 lg:p-4 rise ${delay ? `rise-${delay}` : ''}`}>
      {/* פס מבטא צבעוני */}
      <span className={`absolute inset-y-0 right-0 w-[3px] bg-gradient-to-b ${STAT_ACCENT[tone] ?? STAT_ACCENT.teal}`} />
      <div className="flex items-start justify-between gap-2">
        <div className="label">{label}</div>
        {icon && <span className="text-sm opacity-60">{icon}</span>}
      </div>
      <div className="num mt-1 text-lg font-extrabold tracking-tight text-slate-900 lg:text-[26px]">{value}</div>
      {hint && (
        <div className={`mt-0.5 text-[11px] font-medium ${
          tone === 'green' ? 'text-green-600' : tone === 'rose' ? 'text-rose-600' : 'text-slate-400'}`}>
          {hint}
        </div>
      )}
    </div>
  );
  return href ? <Link href={href} className="block">{body}</Link> : body;
}

export function Section({ title, action, children, pad, icon }: {
  title: string; action?: ReactNode; children: ReactNode; pad?: boolean; icon?: string;
}) {
  return (
    <section className="card rise overflow-hidden">
      <header className="t-head flex items-center justify-between border-b border-slate-200/70 px-4 py-3">
        <h2 className="flex items-center gap-2 text-sm font-bold text-slate-800">
          {icon && <span className="text-base">{icon}</span>}{title}
        </h2>
        {action}
      </header>
      <div className={pad ? 'p-4' : ''}>{children}</div>
    </section>
  );
}

/* ─────────── תוויות ─────────── */

export const LEAD_STATUS: Record<string, { label: string; tone: string; dot: string }> = {
  NEW: { label: 'חדש', tone: 'sky', dot: 'bg-sky-500' },
  CONTACTED: { label: 'נוצר קשר', tone: 'violet', dot: 'bg-violet-500' },
  QUALIFIED: { label: 'מוסמך', tone: 'teal', dot: 'bg-teal-500' },
  QUOTED: { label: 'נשלחה הצעה', tone: 'amber', dot: 'bg-amber-500' },
  NEGOTIATION: { label: 'משא ומתן', tone: 'amber', dot: 'bg-amber-600' },
  WON: { label: 'נסגר', tone: 'green', dot: 'bg-green-500' },
  LOST: { label: 'אבוד', tone: 'rose', dot: 'bg-rose-500' },
};
export const LEAD_STATUS_ORDER = ['NEW', 'CONTACTED', 'QUALIFIED', 'QUOTED', 'NEGOTIATION', 'WON', 'LOST'];

export const SOURCE_LABEL: Record<string, string> = {
  WORDPRESS: 'וורדפרס', META_LEAD_ADS: 'Meta Ads', MANUAL: 'ידני',
  WHATSAPP: 'וואטסאפ', PHONE: 'טלפון', REFERRAL: 'המלצה', API: 'API', IMPORT: 'ייבוא',
};
export const SOURCE_ICON: Record<string, string> = {
  WORDPRESS: '🌐', META_LEAD_ADS: '📣', MANUAL: '✍️',
  WHATSAPP: '💬', PHONE: '📞', REFERRAL: '🤝', API: '⚙️', IMPORT: '📥',
};

export const QUOTE_STATUS: Record<string, { label: string; tone: string }> = {
  DRAFT: { label: 'טיוטה', tone: 'slate' },
  SENT: { label: 'נשלחה', tone: 'sky' },
  VIEWED: { label: 'נצפתה', tone: 'violet' },
  SIGNED: { label: 'נחתמה', tone: 'teal' },
  REJECTED: { label: 'נדחתה', tone: 'rose' },
  EXPIRED: { label: 'פג תוקף', tone: 'slate' },
  PAID: { label: 'שולמה', tone: 'green' },
};

export const TASK_PRIORITY: Record<string, { label: string; tone: string; bar: string }> = {
  LOW: { label: 'נמוכה', tone: 'slate', bar: 'bg-slate-300' },
  NORMAL: { label: 'רגילה', tone: 'sky', bar: 'bg-sky-400' },
  HIGH: { label: 'גבוהה', tone: 'amber', bar: 'bg-amber-500' },
  URGENT: { label: 'דחוף', tone: 'rose', bar: 'bg-rose-500' },
};

export const ROLE_LABEL: Record<string, string> = {
  MANAGER: 'מנהל', EMPLOYEE: 'עובד',
};

export const PAYMENT_STATUS: Record<string, { label: string; tone: string }> = {
  PENDING: { label: 'ממתין', tone: 'amber' }, AUTHORIZED: { label: 'מאושר', tone: 'sky' },
  PAID: { label: 'שולם', tone: 'green' }, FAILED: { label: 'נכשל', tone: 'rose' },
  REFUNDED: { label: 'הוחזר', tone: 'slate' }, CHARGEBACK: { label: 'ביטול עסקה', tone: 'rose' },
};

export const DOC_KIND: Record<string, string> = {
  QUOTE: 'הצעת מחיר', PROFORMA: 'חשבון עסקה', TAX_INVOICE: 'חשבונית מס',
  RECEIPT: 'קבלה', TAX_INVOICE_RECEIPT: 'חשבונית מס/קבלה', CREDIT_NOTE: 'חשבונית זיכוי',
};

/* ─────────── זמן ─────────── */

export function timeAgo(d: Date | string | null): string {
  if (!d) return '—';
  const diff = Math.floor((Date.now() - new Date(d).getTime()) / 1000);
  if (diff < 0) {
    const s = -diff;
    if (s < 3600) return `בעוד ${Math.floor(s / 60)} דק׳`;
    if (s < 86400) return `בעוד ${Math.floor(s / 3600)} שע׳`;
    return `בעוד ${Math.floor(s / 86400)} ימים`;
  }
  if (diff < 60) return 'עכשיו';
  if (diff < 3600) return `לפני ${Math.floor(diff / 60)} דק׳`;
  if (diff < 86400) return `לפני ${Math.floor(diff / 3600)} שע׳`;
  if (diff < 2592000) return `לפני ${Math.floor(diff / 86400)} ימים`;
  return new Date(d).toLocaleDateString('he-IL');
}

export function dueLabel(d: Date | string | null): { text: string; tone: string } {
  if (!d) return { text: 'ללא תאריך', tone: 'slate' };
  const ms = new Date(d).getTime() - Date.now();
  const today = new Date().toDateString() === new Date(d).toDateString();
  if (ms < 0) return { text: `באיחור · ${timeAgo(d)}`, tone: 'rose' };
  if (today) return { text: `היום ${new Date(d).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}`, tone: 'amber' };
  return { text: new Date(d).toLocaleDateString('he-IL', { day: 'numeric', month: 'short' }), tone: 'slate' };
}

export function Avatar({ name, size = 32, ring }: { name: string; size?: number; ring?: boolean }) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('');
  const hue = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-bold text-white ${ring ? 'ring-2 ring-white' : ''}`}
      style={{
        width: size, height: size, fontSize: size * 0.36,
        background: `linear-gradient(135deg, hsl(${hue} 52% 52%), hsl(${(hue + 26) % 360} 48% 40%))`,
        boxShadow: '0 2px 6px rgb(15 23 42 / .14)',
      }}
    >
      {initials}
    </span>
  );
}

export function Empty({ icon = '📭', title, hint }: { icon?: string; title: string; hint?: string }) {
  return (
    <div className="px-4 py-12 text-center">
      <div className="text-3xl opacity-50">{icon}</div>
      <div className="mt-2 text-sm font-semibold text-slate-500">{title}</div>
      {hint && <div className="mt-0.5 text-xs text-slate-400">{hint}</div>}
    </div>
  );
}

export function Progress({ value, max, tone = 'teal', delay = 0 }: { value: number; max: number; tone?: string; delay?: number }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  const bg: Record<string, string> = {
    teal: 'from-teal-400 to-teal-600',
    green: 'from-green-400 to-green-600',
    amber: 'from-amber-400 to-amber-500',
    rose: 'from-rose-400 to-rose-500',
    sky: 'from-sky-400 to-sky-500',
    violet: 'from-violet-400 to-violet-500',
  };
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200/70">
      <div className={`bar-grow h-full rounded-full bg-gradient-to-l ${bg[tone] ?? bg.teal}`}
           style={{ width: `${pct}%`, animationDelay: `${delay}ms` }} />
    </div>
  );
}

/**
 * גרף עמודות — סדרה יחידה, גוון אחד.
 * סדרה אחת ⇒ אין מקרא (הכותרת מזהה אותה). תוויות ישירות סלקטיביות בלבד.
 * צירים recessive, קצה עגול 4px מעוגן לבסיס, רווח 2px בין עמודות.
 */
export function BarChart({
  data, height = 132, format,
}: { data: Array<{ label: string; value: number }>; height?: number; format: (n: number) => string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const peak = data.reduce((a, b) => (b.value > a.value ? b : a), data[0]);
  return (
    <div>
      <div dir="rtl" className="flex items-end gap-[2px]" style={{ height }}>
        {data.map((d, i) => {
          const h = Math.max(3, (d.value / max) * (height - 26));
          const isPeak = d.label === peak?.label && d.value > 0;
          return (
            <div key={d.label} className="group flex flex-1 flex-col items-center justify-end gap-1" title={`${d.label}: ${format(d.value)}`}>
              {/* תווית ישירה רק על השיא — לא מספר על כל עמודה */}
              {isPeak && <span className="num text-[9px] font-bold text-teal-700">{format(d.value)}</span>}
              <div
                className="w-full rounded-t-[4px] bg-gradient-to-t from-teal-600 to-teal-400 transition-all duration-200 group-hover:from-teal-700 group-hover:to-teal-500"
                style={{ height: h, animation: `growBar .5s cubic-bezier(.4,0,.2,1) ${i * 45}ms both`, transformOrigin: 'bottom' }}
              />
            </div>
          );
        })}
      </div>
      <div dir="rtl" className="mt-1.5 flex gap-[2px] border-t border-slate-200/70 pt-1.5">
        {data.map((d) => (
          <div key={d.label} className="flex-1 text-center text-[9px] font-medium text-slate-400">{d.label}</div>
        ))}
      </div>
    </div>
  );
}

/** טבעת התקדמות — למדד יחיד */
export function Ring({ value, max, size = 56, tone = '#0d9488', label, onDark }: {
  value: number; max: number; size?: number; tone?: string; label?: string; onDark?: boolean;
}) {
  const pct = max > 0 ? Math.min(1, value / max) : 0;
  const r = (size - 8) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={onDark ? "rgba(255,255,255,.22)" : "#e2e8f0"} strokeWidth="6" />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tone} strokeWidth="6"
                strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - pct)}
                style={{ transition: 'stroke-dashoffset .7s cubic-bezier(.4,0,.2,1)' }} />
      </svg>
      <span className={`num absolute text-[11px] font-extrabold ${onDark ? "text-white" : "text-slate-700"}`}>
        {label ?? `${Math.round(pct * 100)}%`}
      </span>
    </div>
  );
}
