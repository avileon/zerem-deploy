/**
 * פתיחת חשבונות — עסקים, מנהלים ועובדים.
 *
 * שני מסלולי כניסה למערכת, ושניהם נגמרים באותו מקום:
 *   1. אתה פותח עסק מהקונסולה  → createBusiness()
 *   2. עסק נרשם לבד מדף המחירים → selfSignup()
 *
 * בשני המקרים נוצרים: ארגון + משתמש MANAGER + מנוי + הזמנה לקביעת סיסמה.
 * ההבדל היחיד הוא מי קובע את החבילה ומי משלם.
 */
import { and, eq, sql } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { hashPassword, hashToken, newToken, checkPasswordStrength } from './password';
import { revokeAllUserSessions } from './session';
import { normalizePhone } from '../israel';
import { addInterval, anchorDayFrom } from '../billing/pricing';
import { TRIAL_DAYS, TRIAL_PLAN_ID, FREE_PLAN_ID } from '../billing/catalog';
import { getEntitlements, invalidateEntitlements } from '../billing/entitlements';

const INVITE_TTL_HOURS = 72;
const RESET_TTL_MINUTES = 60;

export type Result<T> = { ok: true; data: T } | { ok: false; error: string };

/* ═══════════ הזמנות ═══════════ */

export async function createInvitation(opts: {
  email: string;
  userId?: string;
  adminId?: string;
  kind?: 'SET_PASSWORD' | 'RESET_PASSWORD';
  invitedBy: string;
}) {
  const kind = opts.kind ?? 'SET_PASSWORD';
  const { raw, hash } = newToken();
  const ttlMs = kind === 'RESET_PASSWORD' ? RESET_TTL_MINUTES * 60_000 : INVITE_TTL_HOURS * 3_600_000;

  // הזמנה קודמת שלא נוצלה מתבטלת — אחרת קישור ישן שדלף נשאר תקף
  if (opts.userId) {
    await db.update(s.invitations).set({ usedAt: new Date() })
      .where(and(eq(s.invitations.userId, opts.userId), sql`used_at IS NULL`));
  }
  if (opts.adminId) {
    await db.update(s.invitations).set({ usedAt: new Date() })
      .where(and(eq(s.invitations.adminId, opts.adminId), sql`used_at IS NULL`));
  }

  await db.insert(s.invitations).values({
    kind, tokenHash: hash,
    userId: opts.userId ?? null,
    adminId: opts.adminId ?? null,
    email: opts.email.toLowerCase(),
    invitedBy: opts.invitedBy,
    expiresAt: new Date(Date.now() + ttlMs),
  });

  return { token: raw, expiresInHours: ttlMs / 3_600_000 };
}

export async function consumeInvitation(rawToken: string, newPassword: string): Promise<Result<{ redirect: string }>> {
  const strength = checkPasswordStrength(newPassword);
  if (!strength.ok) return { ok: false, error: strength.reason! };

  const [inv] = await db.select().from(s.invitations)
    .where(eq(s.invitations.tokenHash, hashToken(rawToken))).limit(1);

  if (!inv) return { ok: false, error: 'הקישור אינו תקף' };
  if (inv.usedAt) return { ok: false, error: 'הקישור כבר נוצל' };
  if (inv.expiresAt < new Date()) return { ok: false, error: 'תוקף הקישור פג — בקש קישור חדש' };

  const hash = await hashPassword(newPassword);

  if (inv.userId) {
    await db.update(s.users)
      .set({ passwordHash: hash, status: 'ACTIVE' })
      .where(eq(s.users.id, inv.userId));
    // סיסמה חדשה מנתקת מכשירים קיימים — זו הנקודה של איפוס סיסמה
    await revokeAllUserSessions(inv.userId);
  } else if (inv.adminId) {
    await db.update(s.platformAdmins)
      .set({ passwordHash: hash, status: 'ACTIVE' })
      .where(eq(s.platformAdmins.id, inv.adminId));
  } else {
    return { ok: false, error: 'ההזמנה פגומה' };
  }

  await db.update(s.invitations).set({ usedAt: new Date() })
    .where(eq(s.invitations.id, inv.id));

  return { ok: true, data: { redirect: inv.adminId ? '/console/login' : '/login' } };
}

/* ═══════════ פתיחת עסק ═══════════ */

export interface CreateBusinessInput {
  businessName: string;
  legalName?: string;
  vatId?: string;
  managerName: string;
  managerEmail: string;
  managerPhone?: string;
  planId: string;
  interval?: 'MONTHLY' | 'YEARLY';
  /** TRIAL = ימי ניסיון · ACTIVE = פעיל בלי לגבות (לקוח שמשלם בהעברה) · FREE */
  mode: 'TRIAL' | 'ACTIVE' | 'FREE';
  trialDays?: number;
  createdBy: string;
}

export async function createBusiness(i: CreateBusinessInput): Promise<Result<{
  orgId: string; userId: string; inviteToken: string; slug: string;
}>> {
  const email = i.managerEmail.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, error: 'כתובת אימייל לא תקינה' };

  const [existingUser] = await db.select().from(s.users).where(eq(s.users.email, email)).limit(1);
  if (existingUser) {
    return { ok: false, error: 'כתובת האימייל כבר רשומה במערכת' };
  }

  const phone = i.managerPhone ? normalizePhone(i.managerPhone) : null;
  const slug = await uniqueSlug(i.businessName);
  const now = new Date();

  const created = await db.transaction(async (tx): Promise<Result<{ orgId: string; userId: string; slug: string }>> => {
    const [org] = await tx.insert(s.organizations).values({
      name: i.businessName.trim(),
      slug,
      legalName: i.legalName?.trim() || i.businessName.trim(),
      vatId: i.vatId?.trim() || null,
      email,
      phone: phone?.e164 ?? null,
    }).returning();

    const [user] = await tx.insert(s.users).values({
      email,
      name: i.managerName.trim(),
      phone: phone?.e164 ?? null,
      status: 'PENDING',
    }).returning();

    await tx.insert(s.memberships).values({
      orgId: org.id, userId: user.id, role: 'MANAGER', active: true,
    });

    // ── המנוי
    const isTrial = i.mode === 'TRIAL';
    const isFree = i.mode === 'FREE';
    const planId = isFree ? FREE_PLAN_ID : (isTrial ? TRIAL_PLAN_ID : i.planId);
    const trialDays = i.trialDays ?? TRIAL_DAYS;
    const anchor = anchorDayFrom(now);
    const periodEnd = isTrial
      ? new Date(now.getTime() + trialDays * 86_400_000)
      : addInterval(now, i.interval ?? 'MONTHLY', anchor);

    await tx.insert(s.orgSubscriptions).values({
      orgId: org.id,
      planId,
      interval: i.interval ?? 'MONTHLY',
      status: isTrial ? 'TRIALING' : isFree ? 'FREE' : 'ACTIVE',
      currentPeriodStart: now,
      currentPeriodEnd: periodEnd,
      trialEndsAt: isTrial ? periodEnd : null,
      billingAnchorDay: anchor,
    });

    await tx.insert(s.billingEvents).values({
      orgId: org.id, type: 'business.created',
      payload: { planId, mode: i.mode, slug, managerEmail: email },
      actor: i.createdBy,
    });

    return { ok: true, data: { orgId: org.id, userId: user.id, slug } };
  });

  if (!created.ok) return created;

  // ⚠️ ההזמנה נוצרת **אחרי** ה-commit, לא בתוכו.
  // createInvitation משתמש בחיבור הרגיל ולא ב-tx, ולכן בתוך הטרנזקציה
  // הוא לא רואה את המשתמש שזה עתה נוצר ונופל על foreign key.
  const inv = await createInvitation({
    email, userId: created.data.userId, invitedBy: i.createdBy, kind: 'SET_PASSWORD',
  });
  return { ok: true, data: { ...created.data, inviteToken: inv.token } };
}

async function uniqueSlug(name: string): Promise<string> {
  const base = name.trim().toLowerCase()
    .replace(/[^a-z0-9֐-׿\s-]/g, '')
    .replace(/\s+/g, '-')
    .slice(0, 40) || 'business';
  for (let i = 0; i < 50; i++) {
    const candidate = i === 0 ? base : `${base}-${i + 1}`;
    const [hit] = await db.select({ id: s.organizations.id })
      .from(s.organizations).where(eq(s.organizations.slug, candidate)).limit(1);
    if (!hit) return candidate;
  }
  return `${base}-${Date.now().toString(36)}`;
}

/* ═══════════ הוספת עובד ═══════════ */

/**
 * ⚠️ המכסה נאכפת כאן, בשרת, ולא במסך.
 * מנהל שיקרא ישירות ל-API בלי לעבור במסך ייתקל באותה בדיקה.
 */
export async function addTeamMember(i: {
  orgId: string;
  name: string;
  email: string;
  phone?: string;
  role: 'MANAGER' | 'EMPLOYEE';
  createdBy: string;
}): Promise<Result<{ userId: string; inviteToken: string }>> {
  const email = i.email.trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, error: 'כתובת אימייל לא תקינה' };

  const ent = await getEntitlements(i.orgId, { fresh: true });
  const seats = ent.features['users'];
  if (seats?.limit !== null && seats && seats.used >= seats.limit) {
    return {
      ok: false,
      error: `הגעת למכסת המשתמשים בחבילה (${seats.limit}). שדרוג או תוספת "משתמש נוסף" פותחים מקום.`,
    };
  }

  const [existing] = await db.select().from(s.users).where(eq(s.users.email, email)).limit(1);
  if (existing) {
    const [member] = await db.select().from(s.memberships).where(and(
      eq(s.memberships.userId, existing.id), eq(s.memberships.orgId, i.orgId),
    )).limit(1);
    if (member) {
      if (member.active) return { ok: false, error: 'המשתמש כבר בצוות' };
      // חבר שהוסר בעבר — מחזירים אותו במקום ליצור כפילות
      await db.update(s.memberships).set({ active: true, role: i.role })
        .where(eq(s.memberships.id, member.id));
      invalidateEntitlements(i.orgId);
      const inv = await createInvitation({ email, userId: existing.id, invitedBy: i.createdBy });
      return { ok: true, data: { userId: existing.id, inviteToken: inv.token } };
    }
    return { ok: false, error: 'כתובת האימייל רשומה כבר במערכת אחרת' };
  }

  const phone = i.phone ? normalizePhone(i.phone) : null;
  const [user] = await db.insert(s.users).values({
    email, name: i.name.trim(), phone: phone?.e164 ?? null, status: 'PENDING',
  }).returning();

  await db.insert(s.memberships).values({
    orgId: i.orgId, userId: user.id, role: i.role, active: true,
  });

  invalidateEntitlements(i.orgId);
  const inv = await createInvitation({ email, userId: user.id, invitedBy: i.createdBy });

  await db.insert(s.auditLogs).values({
    orgId: i.orgId, action: 'team.member_added', entityType: 'user', entityId: user.id,
    diff: { email, role: i.role },
  }).catch(() => {});

  return { ok: true, data: { userId: user.id, inviteToken: inv.token } };
}

export async function removeTeamMember(orgId: string, userId: string, actorUserId: string): Promise<Result<null>> {
  if (userId === actorUserId) return { ok: false, error: 'אי אפשר להסיר את עצמך' };

  const [target] = await db.select().from(s.memberships).where(and(
    eq(s.memberships.orgId, orgId), eq(s.memberships.userId, userId),
  )).limit(1);
  if (!target) return { ok: false, error: 'המשתמש לא נמצא בצוות' };

  // עסק בלי מנהל הוא עסק נעול — לא מאפשרים להגיע למצב הזה
  if (target.role === 'MANAGER') {
    const [{ n }] = await db.execute<{ n: number }>(sql`
      SELECT COUNT(*)::int AS n FROM memberships
      WHERE org_id = ${orgId} AND role = 'MANAGER' AND active
    `);
    if (Number(n) <= 1) return { ok: false, error: 'חייב להישאר מנהל אחד לפחות' };
  }

  await db.update(s.memberships).set({ active: false })
    .where(eq(s.memberships.id, target.id));
  await revokeAllUserSessions(userId);     // מתנתק מיד מכל המכשירים
  invalidateEntitlements(orgId);

  await db.insert(s.auditLogs).values({
    orgId, actorId: actorUserId, action: 'team.member_removed',
    entityType: 'user', entityId: userId,
  }).catch(() => {});

  return { ok: true, data: null };
}

export async function changeMemberRole(
  orgId: string, userId: string, role: 'MANAGER' | 'EMPLOYEE', actorUserId: string,
): Promise<Result<null>> {
  const [target] = await db.select().from(s.memberships).where(and(
    eq(s.memberships.orgId, orgId), eq(s.memberships.userId, userId),
  )).limit(1);
  if (!target) return { ok: false, error: 'המשתמש לא נמצא' };

  if (target.role === 'MANAGER' && role === 'EMPLOYEE') {
    const [{ n }] = await db.execute<{ n: number }>(sql`
      SELECT COUNT(*)::int AS n FROM memberships
      WHERE org_id = ${orgId} AND role = 'MANAGER' AND active
    `);
    if (Number(n) <= 1) return { ok: false, error: 'חייב להישאר מנהל אחד לפחות' };
  }

  await db.update(s.memberships).set({ role }).where(eq(s.memberships.id, target.id));
  await db.insert(s.auditLogs).values({
    orgId, actorId: actorUserId, action: 'team.role_changed',
    entityType: 'user', entityId: userId, diff: { from: target.role, to: role },
  }).catch(() => {});
  return { ok: true, data: null };
}

/* ═══════════ הרשמה עצמית ═══════════ */

export async function selfSignup(i: {
  businessName: string; managerName: string; email: string; phone?: string;
}): Promise<Result<{ orgId: string; userId: string; inviteToken: string }>> {
  const r = await createBusiness({
    businessName: i.businessName,
    managerName: i.managerName,
    managerEmail: i.email,
    managerPhone: i.phone,
    planId: TRIAL_PLAN_ID,
    mode: 'TRIAL',
    createdBy: 'system:signup',
  });
  if (!r.ok) return r;
  return { ok: true, data: { orgId: r.data.orgId, userId: r.data.userId, inviteToken: r.data.inviteToken } };
}
