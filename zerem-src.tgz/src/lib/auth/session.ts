/**
 * סשנים ובקרת גישה.
 *
 * שלושה עקרונות:
 *  1. הסשן נשמר בשרת. ביטול מיידי הוא דרישה אמיתית (עובד שעזב) —
 *     JWT לא ניתן לביטול לפני שפג, ולכן לא מתאים כאן.
 *  2. שתי עוגיות נפרדות בשמות שונים. קונסולה ולקוח לא חולקים סשן,
 *     ולא ניתן להשתמש בעוגייה של אחד כדי להיכנס לשני.
 *  3. כל שאילתה עסקית מקבלת orgId מהסשן ולא מפרמטר. אין נתיב שבו
 *     לקוח יכול לבקש org_id של מישהו אחר.
 */
import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { and, eq, gt, isNull, sql } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { hashToken, newToken } from './password';

export const TENANT_COOKIE = 'zerem_session';
export const CONSOLE_COOKIE = 'zerem_console';

const TENANT_TTL_DAYS = 14;
const CONSOLE_TTL_HOURS = 12;   // קונסולה = הרשאות רחבות → סשן קצר יותר

export interface TenantSession {
  kind: 'TENANT';
  sessionId: string;
  userId: string;
  orgId: string;
  role: 'MANAGER' | 'EMPLOYEE';
  userName: string;
  userEmail: string;
  orgName: string;
  /** כשמנהל-על צופה בחשבון לקוח — מוצג באנר קבוע ונרשם ביומן */
  impersonatedBy: { adminId: string; adminName: string } | null;
}

export interface ConsoleSession {
  kind: 'CONSOLE';
  sessionId: string;
  adminId: string;
  name: string;
  email: string;
  isOwner: boolean;
}

/* ═══════════ יצירה ═══════════ */

async function clientMeta() {
  const h = await headers();
  return {
    ip: (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || null,
    userAgent: h.get('user-agent')?.slice(0, 400) ?? null,
  };
}

export async function createTenantSession(
  userId: string, orgId: string, impersonatedByAdminId?: string,
) {
  const { raw, hash } = newToken();
  const meta = await clientMeta();
  const expiresAt = new Date(Date.now() + TENANT_TTL_DAYS * 86_400_000);

  await db.insert(s.sessions).values({
    kind: 'TENANT', tokenHash: hash, userId, orgId,
    impersonatedByAdminId: impersonatedByAdminId ?? null,
    ip: meta.ip, userAgent: meta.userAgent, expiresAt,
  });

  const jar = await cookies();
  jar.set(TENANT_COOKIE, raw, {
    httpOnly: true, sameSite: 'lax', path: '/',
    secure: process.env.NODE_ENV === 'production',
    expires: expiresAt,
  });
  return { expiresAt };
}

export async function createConsoleSession(adminId: string) {
  const { raw, hash } = newToken();
  const meta = await clientMeta();
  const expiresAt = new Date(Date.now() + CONSOLE_TTL_HOURS * 3_600_000);

  await db.insert(s.sessions).values({
    kind: 'CONSOLE', tokenHash: hash, adminId,
    ip: meta.ip, userAgent: meta.userAgent, expiresAt,
  });

  const jar = await cookies();
  jar.set(CONSOLE_COOKIE, raw, {
    httpOnly: true, sameSite: 'lax', path: '/',
    secure: process.env.NODE_ENV === 'production',
    expires: expiresAt,
  });
  return { expiresAt };
}

/* ═══════════ קריאה ═══════════ */

export async function getTenantSession(): Promise<TenantSession | null> {
  const jar = await cookies();
  const raw = jar.get(TENANT_COOKIE)?.value;
  if (!raw) return null;

  const [row] = await db
    .select({
      sessionId: s.sessions.id,
      userId: s.sessions.userId,
      orgId: s.sessions.orgId,
      impersonatedByAdminId: s.sessions.impersonatedByAdminId,
      role: s.memberships.role,
      membershipActive: s.memberships.active,
      userName: s.users.name,
      userEmail: s.users.email,
      userStatus: s.users.status,
      orgName: s.organizations.name,
      adminName: s.platformAdmins.name,
    })
    .from(s.sessions)
    .innerJoin(s.users, eq(s.users.id, s.sessions.userId))
    .innerJoin(s.organizations, eq(s.organizations.id, s.sessions.orgId))
    .innerJoin(s.memberships, and(
      eq(s.memberships.userId, s.sessions.userId),
      eq(s.memberships.orgId, s.sessions.orgId),
    ))
    .leftJoin(s.platformAdmins, eq(s.platformAdmins.id, s.sessions.impersonatedByAdminId))
    .where(and(
      eq(s.sessions.tokenHash, hashToken(raw)),
      eq(s.sessions.kind, 'TENANT'),
      isNull(s.sessions.revokedAt),
      gt(s.sessions.expiresAt, new Date()),
    ))
    .limit(1);

  if (!row || !row.userId || !row.orgId) return null;
  // חברות שבוטלה או משתמש שהושבת — הסשן מת מיד, בלי לחכות לפקיעה
  if (!row.membershipActive || row.userStatus === 'DISABLED') return null;

  return {
    kind: 'TENANT',
    sessionId: row.sessionId,
    userId: row.userId,
    orgId: row.orgId,
    role: row.role,
    userName: row.userName,
    userEmail: row.userEmail,
    orgName: row.orgName,
    impersonatedBy: row.impersonatedByAdminId
      ? { adminId: row.impersonatedByAdminId, adminName: row.adminName ?? 'מנהל מערכת' }
      : null,
  };
}

export async function getConsoleSession(): Promise<ConsoleSession | null> {
  const jar = await cookies();
  const raw = jar.get(CONSOLE_COOKIE)?.value;
  if (!raw) return null;

  const [row] = await db
    .select({
      sessionId: s.sessions.id,
      adminId: s.platformAdmins.id,
      name: s.platformAdmins.name,
      email: s.platformAdmins.email,
      isOwner: s.platformAdmins.isOwner,
      status: s.platformAdmins.status,
    })
    .from(s.sessions)
    .innerJoin(s.platformAdmins, eq(s.platformAdmins.id, s.sessions.adminId))
    .where(and(
      eq(s.sessions.tokenHash, hashToken(raw)),
      eq(s.sessions.kind, 'CONSOLE'),
      isNull(s.sessions.revokedAt),
      gt(s.sessions.expiresAt, new Date()),
    ))
    .limit(1);

  if (!row || row.status === 'DISABLED') return null;
  return {
    kind: 'CONSOLE', sessionId: row.sessionId, adminId: row.adminId,
    name: row.name, email: row.email, isOwner: row.isOwner,
  };
}

/* ═══════════ שומרים ═══════════ */

/**
 * ⚠️ שתי משפחות של שומרים, בכוונה:
 *
 *   requireX()  — לדפים. מפנה עם redirect() של Next.
 *   apiX()      — למסלולי API. מחזיר תוצאה, לא זורק.
 *
 * הבדיקה תפסה למה זה חשוב: שומר שמפנה בתוך מסלול API מחזיר 307
 * עם HTML במקום 401 עם JSON, ואף לקוח לא יודע לטפל בזה. ולהפך —
 * שומר שזורק בתוך דף מפיל אותו ל-500 במקום להפנות להתחברות.
 */

export class AuthError extends Error {
  constructor(public code: 'NO_SESSION' | 'FORBIDDEN', public redirectTo: string) {
    super(code);
  }
}

/* ── לדפים ── */

export async function requireTenant(): Promise<TenantSession> {
  const sess = await getTenantSession();
  if (!sess) redirect('/login');
  return sess;
}

/**
 * פעולות שרק מנהל העסק רשאי לבצע: ניהול צוות, חיוב, אינטגרציות.
 * ⚠️ נקרא בשרת. הסתרת כפתור ב-UI אינה בקרת גישה.
 */
export async function requireManager(): Promise<TenantSession> {
  const sess = await getTenantSession();
  if (!sess) redirect('/login');
  if (sess.role !== 'MANAGER') redirect('/?denied=manager');
  return sess;
}

export async function requireConsole(): Promise<ConsoleSession> {
  const sess = await getConsoleSession();
  if (!sess) redirect('/console/login');
  return sess;
}

/* ── למסלולי API ── */

export type ApiGuard<T> =
  | { ok: true; session: T }
  | { ok: false; status: 401 | 403; error: string };

export async function apiTenant(): Promise<ApiGuard<TenantSession>> {
  const sess = await getTenantSession();
  if (!sess) return { ok: false, status: 401, error: 'נדרשת התחברות' };
  return { ok: true, session: sess };
}

export async function apiManager(): Promise<ApiGuard<TenantSession>> {
  const sess = await getTenantSession();
  if (!sess) return { ok: false, status: 401, error: 'נדרשת התחברות' };
  if (sess.role !== 'MANAGER') return { ok: false, status: 403, error: 'רק מנהל רשאי לבצע פעולה זו' };
  return { ok: true, session: sess };
}

export async function apiConsole(): Promise<ApiGuard<ConsoleSession>> {
  const sess = await getConsoleSession();
  if (!sess) return { ok: false, status: 401, error: 'נדרשת התחברות לקונסולה' };
  return { ok: true, session: sess };
}

/* ═══════════ ביטול ═══════════ */

export async function revokeSession(sessionId: string) {
  await db.update(s.sessions).set({ revokedAt: new Date() })
    .where(eq(s.sessions.id, sessionId));
}

/** כשעובד מוסר או סיסמה מתחלפת — כל המכשירים שלו מתנתקים */
export async function revokeAllUserSessions(userId: string) {
  await db.update(s.sessions).set({ revokedAt: new Date() })
    .where(and(eq(s.sessions.userId, userId), isNull(s.sessions.revokedAt)));
}

export async function logout(kind: 'TENANT' | 'CONSOLE') {
  const jar = await cookies();
  const name = kind === 'TENANT' ? TENANT_COOKIE : CONSOLE_COOKIE;
  const raw = jar.get(name)?.value;
  if (raw) {
    await db.update(s.sessions).set({ revokedAt: new Date() })
      .where(eq(s.sessions.tokenHash, hashToken(raw)));
  }
  jar.delete(name);
}

/* ═══════════ הגבלת קצב ═══════════ */

const WINDOW_MIN = 15;
const MAX_FAILS = 8;

export async function tooManyAttempts(identifier: string): Promise<boolean> {
  const [row] = await db.execute<{ n: number }>(sql`
    SELECT COUNT(*)::int AS n FROM login_attempts
    WHERE identifier = ${identifier.toLowerCase()}
      AND NOT succeeded
      AND created_at > now() - interval '${sql.raw(String(WINDOW_MIN))} minutes'
  `);
  return Number(row?.n ?? 0) >= MAX_FAILS;
}

export async function recordAttempt(identifier: string, succeeded: boolean) {
  const meta = await clientMeta();
  await db.insert(s.loginAttempts)
    .values({ identifier: identifier.toLowerCase().slice(0, 160), succeeded, ip: meta.ip })
    .catch(() => {});
  // התחברות מוצלחת מנקה את המונה — אחרת משתמש שטעה פעמיים
  // ואז הצליח, נחסם בפעם הבאה בלי סיבה
  if (succeeded) {
    await db.delete(s.loginAttempts)
      .where(and(
        eq(s.loginAttempts.identifier, identifier.toLowerCase()),
        eq(s.loginAttempts.succeeded, false),
      )).catch(() => {});
  }
}
