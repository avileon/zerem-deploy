/**
 * גיבוב סיסמאות — scrypt מהספרייה הסטנדרטית של Node.
 *
 * למה scrypt ולא bcrypt/argon2: שניהם דורשים קומפילציה נייטיבית,
 * שנשברת בתמונות alpine ובשדרוגי Node. scrypt מובנה, מאושר ב-RFC 7914,
 * ועמיד לחומרה ייעודית (memory-hard). התלות הכי טובה היא זו שאין.
 *
 * הפרמטרים מאוחסנים בתוך ה-hash עצמו, כך שאפשר להחמיר אותם בעתיד
 * בלי לשבור סיסמאות קיימות.
 */
import { randomBytes, scrypt, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const scryptAsync = promisify(scrypt) as (
  password: string | Buffer, salt: string | Buffer, keylen: number, options: object,
) => Promise<Buffer>;

const PARAMS = { N: 16384, r: 8, p: 1, keylen: 64 };

export async function hashPassword(plain: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scryptAsync(plain.normalize('NFKC'), salt, PARAMS.keylen, {
    N: PARAMS.N, r: PARAMS.r, p: PARAMS.p, maxmem: 64 * 1024 * 1024,
  });
  return `scrypt$${PARAMS.N}$${PARAMS.r}$${PARAMS.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

export async function verifyPassword(plain: string, stored: string | null): Promise<boolean> {
  // ⚠️ משתמש ללא סיסמה (עדיין PENDING) לא "מצליח להתחבר עם סיסמה ריקה".
  if (!stored) return false;
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, N, r, p, saltB64, keyB64] = parts;
  try {
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(keyB64, 'base64');
    const actual = await scryptAsync(plain.normalize('NFKC'), salt, expected.length, {
      N: Number(N), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024,
    });
    // השוואה בזמן קבוע — השוואה רגילה מדליפה מידע דרך זמן הריצה
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

/* ═══════════ טוקנים (סשן, הזמנה) ═══════════ */

/** הטוקן הגולמי נמסר פעם אחת בלבד. בבסיס הנתונים נשמר רק ה-hash. */
export function newToken(bytes = 32): { raw: string; hash: string } {
  const raw = randomBytes(bytes).toString('base64url');
  return { raw, hash: hashToken(raw) };
}

export function hashToken(raw: string): string {
  return createHash('sha256').update(raw).digest('hex');
}

/* ═══════════ חוזק סיסמה ═══════════ */

export interface PasswordCheck { ok: boolean; reason?: string; score: number }

/**
 * דרישות מכוונות-מציאות: אורך הוא מה שמגן, לא "תו מיוחד".
 * כלל של 8 תווים עם סימן קריאה מייצר Passw0rd! אצל כולם.
 */
export function checkPasswordStrength(pw: string): PasswordCheck {
  const len = pw.length;
  if (len < 10) return { ok: false, reason: 'הסיסמה חייבת להיות באורך 10 תווים לפחות', score: 0 };
  if (len > 200) return { ok: false, reason: 'הסיסמה ארוכה מדי', score: 0 };

  const lower = /[a-zא-ת]/.test(pw);
  const upper = /[A-Z]/.test(pw);
  const digit = /\d/.test(pw);
  const other = /[^a-zA-Z0-9א-ת]/.test(pw);
  const variety = [lower, upper, digit, other].filter(Boolean).length;

  if (COMMON.has(pw.toLowerCase())) {
    return { ok: false, reason: 'הסיסמה הזו נפוצה מדי', score: 0 };
  }
  if (/^(.)\1+$/.test(pw)) {
    return { ok: false, reason: 'הסיסמה חייבת להכיל יותר מתו אחד', score: 0 };
  }
  if (len < 14 && variety < 2) {
    return { ok: false, reason: 'הוסף ספרה או אות גדולה, או בחר סיסמה ארוכה יותר', score: 1 };
  }

  const score = Math.min(4, Math.floor(len / 6) + variety - 1);
  return { ok: true, score };
}

const COMMON = new Set([
  '1234567890', 'qwertyuiop', 'password12', 'password123', '12345678910',
  'aaaaaaaaaa', 'abcdefghij', 'iloveyou12', 'admin12345', 'welcome123',
  'qwerty12345', '123456789a', 'password1234',
]);
