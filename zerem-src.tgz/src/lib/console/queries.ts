/**
 * שאילתות הקונסולה — חוצות דיירים בכוונה.
 *
 * ⚠️ כל פונקציה כאן רואה את כל הלקוחות. אסור לייבא מהקובץ הזה
 * לתוך אפליקציית הלקוח. כל קריאה חייבת להיות מאחורי requireConsole().
 */
import { sql } from 'drizzle-orm';
import { db } from '@/db';

export interface BusinessRow extends Record<string, unknown> {
  org_id: string;
  org_name: string;
  slug: string;
  vat_id: string | null;
  created_at: string;
  plan_id: string;
  plan_name: string | null;
  interval: string;
  status: string;
  current_period_end: string;
  trial_ends_at: string | null;
  mrr: number;
  seats_used: number;
  seats_limit: number | null;
  leads: number;
  paid_total: number;
  last_activity: string | null;
  manager_name: string | null;
  manager_email: string | null;
  pending_users: number;
}

export async function listBusinesses(): Promise<BusinessRow[]> {
  return db.execute<BusinessRow>(sql`
    SELECT
      o.id AS org_id, o.name AS org_name, o.slug, o.vat_id, o.created_at,
      COALESCE(sub.plan_id, 'free')      AS plan_id,
      pl.name_he                          AS plan_name,
      COALESCE(sub.interval, 'MONTHLY')   AS interval,
      COALESCE(sub.status, 'FREE')        AS status,
      sub.current_period_end, sub.trial_ends_at,
      COALESCE(CASE WHEN sub.interval = 'YEARLY'
                    THEN pp.amount_ex_vat / 12.0 ELSE pp.amount_ex_vat END, 0)::float AS mrr,
      (SELECT COUNT(*)::int FROM memberships m WHERE m.org_id = o.id AND m.active) AS seats_used,
      pe.limit_value AS seats_limit,
      (SELECT COUNT(*)::int FROM leads l WHERE l.org_id = o.id) AS leads,
      COALESCE((SELECT SUM(bi.total_inc_vat) FROM billing_invoices bi
                WHERE bi.org_id = o.id AND bi.status = 'PAID'), 0)::float AS paid_total,
      (SELECT MAX(a.created_at) FROM activities a WHERE a.org_id = o.id) AS last_activity,
      mgr.name AS manager_name, mgr.email AS manager_email,
      (SELECT COUNT(*)::int FROM memberships m2
         JOIN users u2 ON u2.id = m2.user_id
        WHERE m2.org_id = o.id AND m2.active AND u2.status = 'PENDING') AS pending_users
    FROM organizations o
    LEFT JOIN org_subscriptions sub ON sub.org_id = o.id
    LEFT JOIN plans pl ON pl.id = sub.plan_id
    LEFT JOIN plan_prices pp ON pp.plan_id = sub.plan_id AND pp.interval = sub.interval
    LEFT JOIN plan_entitlements pe ON pe.plan_id = sub.plan_id AND pe.feature_key = 'users'
    LEFT JOIN LATERAL (
      SELECT u.name, u.email FROM memberships m
      JOIN users u ON u.id = m.user_id
      WHERE m.org_id = o.id AND m.role = 'MANAGER' AND m.active
      ORDER BY m.id LIMIT 1
    ) mgr ON true
    ORDER BY o.created_at DESC
  `);
}

export interface PlatformOverview {
  businesses: number;
  activePaying: number;
  trialing: number;
  freePlan: number;
  suspended: number;
  pastDue: number;
  mrr: number;
  totalCollected: number;
  newThisMonth: number;
  pendingActivation: number;
  totalUsers: number;
  totalLeads: number;
}

export async function platformOverview(): Promise<PlatformOverview> {
  const [row] = await db.execute<Record<string, number>>(sql`
    SELECT
      (SELECT COUNT(*)::int FROM organizations) AS businesses,
      (SELECT COUNT(*)::int FROM org_subscriptions WHERE status = 'ACTIVE')    AS active_paying,
      (SELECT COUNT(*)::int FROM org_subscriptions WHERE status = 'TRIALING')  AS trialing,
      (SELECT COUNT(*)::int FROM org_subscriptions WHERE status = 'FREE')      AS free_plan,
      (SELECT COUNT(*)::int FROM org_subscriptions WHERE status = 'SUSPENDED') AS suspended,
      (SELECT COUNT(*)::int FROM org_subscriptions WHERE status = 'PAST_DUE')  AS past_due,
      (SELECT COUNT(*)::int FROM organizations WHERE created_at >= date_trunc('month', now())) AS new_this_month,
      (SELECT COUNT(*)::int FROM users WHERE status = 'PENDING')  AS pending_activation,
      (SELECT COUNT(*)::int FROM users)                           AS total_users,
      (SELECT COUNT(*)::int FROM leads)                           AS total_leads,
      COALESCE((SELECT SUM(total_inc_vat) FROM billing_invoices WHERE status = 'PAID'), 0)::float AS total_collected,
      COALESCE((
        SELECT SUM(CASE WHEN s2.interval = 'YEARLY' THEN p.amount_ex_vat/12.0 ELSE p.amount_ex_vat END)
        FROM org_subscriptions s2
        JOIN plan_prices p ON p.plan_id = s2.plan_id AND p.interval = s2.interval
        WHERE s2.status IN ('ACTIVE','PAST_DUE','CANCELING')
      ), 0)::float AS mrr
  `);

  const n = (k: string) => Number(row?.[k] ?? 0);
  return {
    businesses: n('businesses'),
    activePaying: n('active_paying'),
    trialing: n('trialing'),
    freePlan: n('free_plan'),
    suspended: n('suspended'),
    pastDue: n('past_due'),
    mrr: Math.round(n('mrr') * 100) / 100,
    totalCollected: Math.round(n('total_collected') * 100) / 100,
    newThisMonth: n('new_this_month'),
    pendingActivation: n('pending_activation'),
    totalUsers: n('total_users'),
    totalLeads: n('total_leads'),
  };
}

export interface BusinessDetail extends Record<string, unknown> {
  org_id: string; org_name: string; slug: string; legal_name: string | null;
  vat_id: string | null; email: string | null; phone: string | null; created_at: string;
  plan_id: string; interval: string; status: string;
  current_period_start: string; current_period_end: string; trial_ends_at: string | null;
  cancel_at_period_end: boolean; dunning_attempt: number;
  coupon_code: string | null; last4: string | null;
}

export async function businessDetail(orgId: string) {
  const [detail] = await db.execute<BusinessDetail>(sql`
    SELECT o.id AS org_id, o.name AS org_name, o.slug, o.legal_name, o.vat_id,
           o.email, o.phone, o.created_at,
           COALESCE(s.plan_id,'free') AS plan_id, COALESCE(s.interval,'MONTHLY') AS interval,
           COALESCE(s.status,'FREE') AS status,
           s.current_period_start, s.current_period_end, s.trial_ends_at,
           COALESCE(s.cancel_at_period_end,false) AS cancel_at_period_end,
           COALESCE(s.dunning_attempt,0) AS dunning_attempt,
           c.code AS coupon_code, pm.last4
    FROM organizations o
    LEFT JOIN org_subscriptions s ON s.org_id = o.id
    LEFT JOIN coupons c ON c.id = s.coupon_id
    LEFT JOIN billing_payment_methods pm ON pm.id = s.payment_method_id
    WHERE o.id = ${orgId}
  `);
  if (!detail) return null;

  const members = await db.execute<{
    user_id: string; name: string; email: string; phone: string | null;
    role: string; active: boolean; status: string; last_login_at: string | null;
  }>(sql`
    SELECT u.id AS user_id, u.name, u.email, u.phone, m.role, m.active,
           u.status, u.last_login_at
    FROM memberships m JOIN users u ON u.id = m.user_id
    WHERE m.org_id = ${orgId}
    ORDER BY m.role, u.name
  `);

  const usage = await db.execute<{ leads: number; quotes: number; tasks: number; payments: number }>(sql`
    SELECT
      (SELECT COUNT(*)::int FROM leads    WHERE org_id = ${orgId}) AS leads,
      (SELECT COUNT(*)::int FROM quotes   WHERE org_id = ${orgId}) AS quotes,
      (SELECT COUNT(*)::int FROM tasks    WHERE org_id = ${orgId}) AS tasks,
      (SELECT COUNT(*)::int FROM payments WHERE org_id = ${orgId}) AS payments
  `);

  const invoices = await db.execute<{
    id: string; period_start: string; total_inc_vat: number; status: string; doc_url: string | null;
  }>(sql`
    SELECT id, period_start, total_inc_vat::float, status, cardcom_doc_url AS doc_url
    FROM billing_invoices WHERE org_id = ${orgId}
    ORDER BY created_at DESC LIMIT 12
  `);

  const events = await db.execute<{ type: string; actor: string | null; created_at: string; payload: unknown }>(sql`
    SELECT type, actor, created_at, payload FROM billing_events
    WHERE org_id = ${orgId} ORDER BY created_at DESC LIMIT 20
  `);

  return { detail, members, usage: usage[0], invoices, events };
}

export async function auditTrail(limit = 100) {
  return db.execute<{
    type: string; actor: string | null; created_at: string;
    org_name: string | null; payload: Record<string, unknown>;
  }>(sql`
    SELECT e.type, e.actor, e.created_at, o.name AS org_name, e.payload
    FROM billing_events e
    LEFT JOIN organizations o ON o.id = e.org_id
    ORDER BY e.created_at DESC
    LIMIT ${limit}
  `);
}
