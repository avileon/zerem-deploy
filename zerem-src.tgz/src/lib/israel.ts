/**
 * שכבת הידע הישראלי.
 * כל מה שכאן הוא תיקון או השלמה למה שה-PRD לא כיסה.
 */

/* ═══════════ 1. מע״מ ═══════════
 * ⚠️ ה-PRD כתב "VAT (Israeli tax rate)" כאילו זה קבוע. הוא לא.
 * 17% → 18% ב-01.01.2025. תקציב 2026 השאיר על 18% (הצעה ל-19% לא אושרה).
 * הצעת מחיר מדצמבר שהופכת לחשבונית בינואר חוצה שינוי שיעור — לכן
 * השיעור נשמר על המסמך, ונבחר לפי תאריך.
 */
export const VAT_HISTORY: Array<{ from: string; rate: number; note: string }> = [
  { from: '2015-10-01', rate: 0.17, note: 'הורדה מ-18% ל-17%' },
  { from: '2025-01-01', rate: 0.18, note: 'העלאה ל-18% במסגרת תקציב 2025' },
];

export function vatRateAt(date: Date = new Date()): number {
  const t = date.getTime();
  let rate = VAT_HISTORY[0].rate;
  for (const r of VAT_HISTORY) {
    if (new Date(r.from).getTime() <= t) rate = r.rate;
  }
  return rate;
}

export const CURRENT_VAT_RATE = vatRateAt();

/* ═══════════ 2. מספר הקצאה — מודל חשבוניות ישראל ═══════════
 * ⚠️ לא הופיע ב-PRD כלל, וזו חשיפה אמיתית.
 * חשבונית מס מעל הסף (לפני מע״מ) ללא מספר הקצאה תקף —
 * הקונה לא יכול לקזז מע״מ תשומות. זו בעיה מסחרית של הלקוח שלנו, לא רק לוג.
 * הסף יורד בשלבים:
 */
export const ALLOCATION_THRESHOLDS: Array<{ from: string; amount: number }> = [
  { from: '2024-05-05', amount: 25000 },
  { from: '2025-01-01', amount: 20000 },
  { from: '2025-07-01', amount: 10000 },
  { from: '2026-06-01', amount: 5000 },
];

export function allocationThresholdAt(date: Date = new Date()): number {
  const t = date.getTime();
  let amount = ALLOCATION_THRESHOLDS[0].amount;
  for (const a of ALLOCATION_THRESHOLDS) {
    if (new Date(a.from).getTime() <= t) amount = a.amount;
  }
  return amount;
}

/** האם החשבונית הזו חייבת מספר הקצאה. הסכום נבדק **לפני** מע״מ. */
export function requiresAllocationNumber(amountExVatIls: number, date: Date = new Date()): boolean {
  return amountExVatIls >= allocationThresholdAt(date);
}

/* ═══════════ 3. טלפונים ═══════════ */

/** קידומות ניידים תקפות בישראל */
const MOBILE_PREFIXES = ['50', '51', '52', '53', '54', '55', '58', '59'];
/** קידומות קו נייח גיאוגרפיות */
const LANDLINE_PREFIXES = ['2', '3', '4', '8', '9'];
/** VoIP לא-גיאוגרפי */
const VOIP_PREFIXES = ['72', '73', '76', '77'];

export type PhoneKind = 'MOBILE' | 'LANDLINE' | 'VOIP' | 'SERVICE' | 'INVALID';

export interface NormalizedPhone {
  ok: boolean;
  e164: string | null;      // +972501234567
  national: string | null;  // 0501234567
  display: string | null;   // 050-123-4567
  kind: PhoneKind;
  /** chatId ל-Green API: E.164 בלי ה-+ ועם @c.us */
  waChatId: string | null;
  error?: string;
}

/**
 * נרמול טלפון ישראלי ל-E.164.
 * זהו מפתח הדדופליקציה — 050-1234567 / 0501234567 / +972501234567 / 972-50-1234567
 * חייבים כולם להגיע לאותה מחרוזת, אחרת ייווצרו לידים כפולים.
 */
export function normalizePhone(input: string | null | undefined): NormalizedPhone {
  const fail = (error: string, kind: PhoneKind = 'INVALID'): NormalizedPhone =>
    ({ ok: false, e164: null, national: null, display: null, waChatId: null, kind, error });

  if (!input) return fail('מספר ריק');

  let d = String(input).replace(/[^\d+]/g, '');
  if (d.startsWith('+')) d = d.slice(1);
  d = d.replace(/\D/g, '');
  if (!d) return fail('אין ספרות');

  // 00972… → 972…
  if (d.startsWith('00972')) d = d.slice(2);
  // 972… כבר בינלאומי
  if (d.startsWith('972')) d = d.slice(3);
  // 0501234567 → 501234567
  else if (d.startsWith('0')) d = d.slice(1);

  // מספרי שירות — אין להם צורה בינלאומית, לא ניתן לשלוח אליהם וואטסאפ
  if (/^(1800|1700|1599|1900|1599)/.test(d) || d.startsWith('1')) {
    return fail('מספר שירות (1-800/1-700/1-599) — לא ניתן ליצירת קשר בוואטסאפ', 'SERVICE');
  }

  let kind: PhoneKind = 'INVALID';
  if (MOBILE_PREFIXES.includes(d.slice(0, 2)) && d.length === 9) kind = 'MOBILE';
  else if (VOIP_PREFIXES.includes(d.slice(0, 2)) && d.length === 9) kind = 'VOIP';
  else if (LANDLINE_PREFIXES.includes(d.slice(0, 1)) && d.length === 8) kind = 'LANDLINE';

  if (kind === 'INVALID') return fail(`מספר לא תקין: ${input}`);

  const e164 = `+972${d}`;
  const national = `0${d}`;
  const display =
    kind === 'MOBILE' || kind === 'VOIP'
      ? `${national.slice(0, 3)}-${national.slice(3, 6)}-${national.slice(6)}`
      : `${national.slice(0, 2)}-${national.slice(2, 5)}-${national.slice(5)}`;

  return { ok: true, e164, national, display, kind, waChatId: `972${d}@c.us` };
}

/** האם ניתן לשלוח וואטסאפ למספר הזה */
export function canWhatsApp(p: NormalizedPhone): boolean {
  return p.ok && (p.kind === 'MOBILE' || p.kind === 'VOIP');
}

/* ═══════════ 4. ח.פ. / ע.מ. / ת.ז. ═══════════ */

/** ביקורת ספרת ביקורת ישראלית (אלגוריתם לוהן משוקלל) */
export function isValidIsraeliId(id: string | null | undefined): boolean {
  if (!id) return false;
  const s = String(id).replace(/\D/g, '').padStart(9, '0');
  if (s.length !== 9) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    let n = Number(s[i]) * ((i % 2) + 1);
    if (n > 9) n -= 9;
    sum += n;
  }
  return sum % 10 === 0;
}

/* ═══════════ 5. חישוב מסמך ═══════════ */

export interface LineInput {
  quantity: number;
  unitPriceIls: number;
  discountPercent?: number;
  vatExempt?: boolean;
}

export interface DocTotals {
  subtotalIls: number;
  discountIls: number;
  taxableIls: number;
  exemptIls: number;
  vatIls: number;
  totalIls: number;
  vatRate: number;
  /** האם החשבונית שתיווצר מכאן תחייב מספר הקצאה */
  allocationRequired: boolean;
  allocationThreshold: number;
}

export function calcTotals(
  lines: LineInput[],
  opts: { discountType?: 'PERCENT' | 'AMOUNT'; discountValue?: number; at?: Date } = {},
): DocTotals {
  const at = opts.at ?? new Date();
  const vatRate = vatRateAt(at);
  const round2 = (n: number) => Math.round(n * 100) / 100;

  let taxable = 0;
  let exempt = 0;
  for (const l of lines) {
    const gross = l.quantity * l.unitPriceIls;
    const net = gross * (1 - (l.discountPercent ?? 0) / 100);
    if (l.vatExempt) exempt += net;
    else taxable += net;
  }
  const subtotal = round2(taxable + exempt);

  // הנחה כללית מתחלקת יחסית בין חייב לפטור
  const discount = round2(
    opts.discountType === 'AMOUNT'
      ? Math.min(opts.discountValue ?? 0, subtotal)
      : (subtotal * (opts.discountValue ?? 0)) / 100,
  );
  const ratio = subtotal > 0 ? 1 - discount / subtotal : 1;
  const taxableAfter = round2(taxable * ratio);
  const exemptAfter = round2(exempt * ratio);

  const vat = round2(taxableAfter * vatRate);
  const total = round2(taxableAfter + exemptAfter + vat);
  const exVat = round2(taxableAfter + exemptAfter);

  return {
    subtotalIls: subtotal,
    discountIls: discount,
    taxableIls: taxableAfter,
    exemptIls: exemptAfter,
    vatIls: vat,
    totalIls: total,
    vatRate,
    allocationRequired: requiresAllocationNumber(exVat, at),
    allocationThreshold: allocationThresholdAt(at),
  };
}

/* ═══════════ 6. פורמט ═══════════ */

export const ils = (n: number | string) =>
  new Intl.NumberFormat('he-IL', { style: 'currency', currency: 'ILS', maximumFractionDigits: 0 }).format(Number(n));

export const ils2 = (n: number | string) =>
  new Intl.NumberFormat('he-IL', { style: 'currency', currency: 'ILS', minimumFractionDigits: 2 }).format(Number(n));

export const num = (n: number | string) => new Intl.NumberFormat('he-IL').format(Number(n));

/* ═══════════ 7. חתימה אלקטרונית ═══════════
 * חוק חתימה אלקטרונית, תשס״א-2001:
 *   · חתימה רגילה   — כל סימן אלקטרוני
 *   · מאובטחת (§3)  — ייחודית לחותם · מזהה אותו · בשליטתו הבלעדית · מגלה שינוי
 *   · מאושרת        — מאובטחת + תעודה מגורם מאשר מורשה
 *
 * הצעת מחיר מסחרית אינה דורשת חתימה בכלל — דיני חוזים בישראל קונסנסואליים.
 * לכן חתימה רגילה מספיקה משפטית. השאלה האמיתית היא ראייתית.
 * הרכיבים כאן מביאים אותנו לרמת "מאובטחת" בלי עלות של תעודות.
 */
export const SIGNATURE_EVIDENCE_CHECKLIST = [
  { key: 'snapshot', label: 'העתק מוקפא של המסמך כפי שהוצג', satisfies: 'גילוי שינוי' },
  { key: 'hash', label: 'SHA-256 של ה-PDF החתום', satisfies: 'גילוי שינוי' },
  { key: 'otp', label: 'אימות OTP לטלפון החותם', satisfies: 'ייחודיות + שליטה בלעדית' },
  { key: 'identity', label: 'שם, טלפון ואימייל החותם', satisfies: 'זיהוי' },
  { key: 'audit', label: 'חותמת זמן שרת, IP, User-Agent', satisfies: 'ראיה נסיבתית' },
] as const;

/**
 * ⚠️ אין להציג במוצר "חתימה בעלת תוקף משפטי מלא" ללא בדיקת עו״ד.
 * הניסוח הבטוח: "חתימה אלקטרונית מתועדת".
 */
export const SIGNATURE_LEGAL_DISCLAIMER =
  'חתימה אלקטרונית מתועדת לפי חוק חתימה אלקטרונית, תשס״א-2001. ' +
  'המסמך נשמר בעותק מוקפא עם חתימת גיבוב (hash) ותיעוד מלא של מועד החתימה.';
