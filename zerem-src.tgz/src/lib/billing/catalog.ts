/**
 * קטלוג המוצר — מקור האמת לחבילות, מחירים ומגבלות.
 *
 * הקובץ הזה הוא ה-seed. אחרי ההרצה הראשונה, המחירים חיים ב-DB וניתנים
 * לעריכה מקונסולת הניהול ללא deploy. הקובץ נשאר כברירת מחדל ולתיעוד.
 *
 * מחירים לפני מע״מ. שנתי = 10 חודשים במחיר 12 (הנחה 16.7%).
 */

export type FeatureKey =
  | 'users' | 'leads' | 'quotes_per_month' | 'wa_channels' | 'forms'
  | 'e_signature' | 'payments' | 'invoicing' | 'automations'
  | 'advanced_reports' | 'api' | 'multi_branch' | 'white_label';

export interface FeatureMeta {
  key: FeatureKey;
  label: string;
  /** מגבלה מספרית (מוני שימוש) או יכולת בוליאנית */
  kind: 'quota' | 'flag';
  /** האם המונה מתאפס בכל מחזור חיוב, או נספר במצטבר */
  reset: 'cycle' | 'absolute';
  unit?: string;
}

export const FEATURES: FeatureMeta[] = [
  { key: 'users',            label: 'משתמשים',            kind: 'quota', reset: 'absolute', unit: 'משתמשים' },
  { key: 'leads',            label: 'לידים פעילים',        kind: 'quota', reset: 'absolute', unit: 'לידים' },
  { key: 'quotes_per_month', label: 'הצעות מחיר בחודש',    kind: 'quota', reset: 'cycle',    unit: 'הצעות' },
  { key: 'wa_channels',      label: 'חיבורי וואטסאפ',      kind: 'quota', reset: 'absolute', unit: 'חיבורים' },
  { key: 'forms',            label: 'טפסי קליטה',          kind: 'quota', reset: 'absolute', unit: 'טפסים' },
  { key: 'e_signature',      label: 'חתימה דיגיטלית',      kind: 'flag',  reset: 'absolute' },
  { key: 'payments',         label: 'סליקת אשראי',         kind: 'flag',  reset: 'absolute' },
  { key: 'invoicing',        label: 'הפקת חשבוניות',       kind: 'flag',  reset: 'absolute' },
  { key: 'automations',      label: 'אוטומציות',           kind: 'flag',  reset: 'absolute' },
  { key: 'advanced_reports', label: 'דוחות מתקדמים',       kind: 'flag',  reset: 'absolute' },
  { key: 'api',              label: 'API ו-Webhooks',      kind: 'flag',  reset: 'absolute' },
  { key: 'multi_branch',     label: 'ריבוי סניפים',        kind: 'flag',  reset: 'absolute' },
  { key: 'white_label',      label: 'הסרת מיתוג זרם',      kind: 'flag',  reset: 'absolute' },
];

export const FEATURE_LABEL: Record<string, string> =
  Object.fromEntries(FEATURES.map((f) => [f.key, f.label]));

export interface PlanDef {
  id: string;
  nameHe: string;
  tagline: string;
  sortOrder: number;
  monthly: number | null;      // null = חינם
  yearly: number | null;
  /** null = ללא הגבלה, false = נעול */
  entitlements: Record<FeatureKey, number | null | boolean>;
  highlights: string[];
}

export const PLANS: PlanDef[] = [
  {
    id: 'free',
    nameHe: 'חינם',
    tagline: 'להתחיל לנהל לידים בלי כרטיס אשראי',
    sortOrder: 0,
    monthly: 0,
    yearly: 0,
    entitlements: {
      users: 1, leads: 50, quotes_per_month: 20, wa_channels: false, forms: 1,
      e_signature: false, payments: false, invoicing: false, automations: false,
      advanced_reports: false, api: false, multi_branch: false, white_label: false,
    },
    highlights: ['משתמש אחד', '50 לידים', '20 הצעות בחודש', 'אפליקציה לנייד'],
  },
  {
    id: 'basic',
    nameHe: 'בסיס',
    tagline: 'לעסק קטן שרוצה להפסיק לאבד לידים',
    sortOrder: 1,
    monthly: 99,
    yearly: 990,
    entitlements: {
      users: 3, leads: 1000, quotes_per_month: null, wa_channels: 1, forms: 5,
      e_signature: true, payments: false, invoicing: false, automations: true,
      advanced_reports: false, api: false, multi_branch: false, white_label: false,
    },
    highlights: ['3 משתמשים', '1,000 לידים', 'חיבור וואטסאפ', 'חתימה דיגיטלית'],
  },
  {
    id: 'pro',
    nameHe: 'מקצועי',
    tagline: 'הצעה → חתימה → תשלום → חשבונית, הכול במקום אחד',
    sortOrder: 2,
    monthly: 249,
    yearly: 2490,
    entitlements: {
      users: 10, leads: null, quotes_per_month: null, wa_channels: 2, forms: null,
      e_signature: true, payments: true, invoicing: true, automations: true,
      advanced_reports: true, api: false, multi_branch: false, white_label: true,
    },
    highlights: ['10 משתמשים', 'לידים ללא הגבלה', 'סליקה + חשבוניות', 'דוחות מתקדמים'],
  },
  {
    id: 'business',
    nameHe: 'עסקי',
    tagline: 'לעסק עם כמה סניפים ומערכות נוספות',
    sortOrder: 3,
    monthly: 499,
    yearly: 4990,
    entitlements: {
      users: null, leads: null, quotes_per_month: null, wa_channels: 5, forms: null,
      e_signature: true, payments: true, invoicing: true, automations: true,
      advanced_reports: true, api: true, multi_branch: true, white_label: true,
    },
    highlights: ['משתמשים ללא הגבלה', 'API ו-Webhooks', 'ריבוי סניפים', 'תמיכה בעדיפות'],
  },
];

export const PLAN_BY_ID = Object.fromEntries(PLANS.map((p) => [p.id, p]));
export const FREE_PLAN_ID = 'free';
export const TRIAL_PLAN_ID = 'pro';
export const TRIAL_DAYS = 14;

/* ── תוספות ──────────────────────────────────────────────── */

export interface AddonDef {
  key: string;
  label: string;
  monthlyExVat: number;
  /** לאיזה מונה התוספת מוסיפה יחידות */
  grants?: { feature: FeatureKey; per: number };
  availableIn: string[];
}

export const ADDONS: AddonDef[] = [
  { key: 'extra_user',  label: 'משתמש נוסף',           monthlyExVat: 29, grants: { feature: 'users', per: 1 },        availableIn: ['basic', 'pro'] },
  { key: 'extra_wa',    label: 'חיבור וואטסאפ נוסף',    monthlyExVat: 49, grants: { feature: 'wa_channels', per: 1 },  availableIn: ['basic', 'pro', 'business'] },
  { key: 'storage_10gb', label: 'אחסון 10GB נוסף',      monthlyExVat: 19,                                             availableIn: ['basic', 'pro', 'business'] },
];

export const ADDON_BY_KEY = Object.fromEntries(ADDONS.map((a) => [a.key, a]));

/* ── לוח ה-Dunning ───────────────────────────────────────────
 * ימים מאז החידוש שנכשל. אחרי הניסיון האחרון → השהיה.
 * לקוח לא נחסם על כרטיס שפג תוקף ביום הראשון — הוא פשוט הולך למתחרה.
 */
export const DUNNING_SCHEDULE_DAYS = [0, 1, 3, 6, 10] as const;
export const SUSPEND_AFTER_ATTEMPT = DUNNING_SCHEDULE_DAYS.length; // 5
export const CLOSE_AFTER_SUSPENDED_DAYS = 30;
export const DATA_RETENTION_AFTER_CLOSE_DAYS = 90;

/** התראה על כרטיס שפג תוקף */
export const CARD_EXPIRY_WARN_DAYS = [30, 7] as const;
/** התראה לפני חידוש שנתי — גם חובה חוקית בעסקה מתמשכת */
export const YEARLY_RENEWAL_NOTICE_DAYS = 14;
