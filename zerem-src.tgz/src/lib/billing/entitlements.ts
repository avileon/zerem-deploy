/**
 * אכיפת מגבלות.
 *
 * כלל אחד שאסור לשבור: ה-UI מסתיר כפתורים, **השרת** אוכף.
 * מסך שמסתיר כפתור אינו אבטחה — הוא נוחות. כל מסלול API שיוצר
 * משאב מוגבל חייב לקרוא ל-requireQuota לפני הכתיבה.
 */
import { and, eq, sql } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { FEATURES, PLAN_BY_ID, ADDON_BY_KEY, type FeatureKey } from './catalog';

export interface Entitlement {
  key: string;
  label: string;
  enabled: boolean;
  limit: number | null;      // null = ללא הגבלה
  used: number;
  remaining: number | null;
  pct: number | null;        // 0–100, null אם ללא הגבלה
}

export interface OrgEntitlements {
  orgId: string;
  planId: string;
  planName: string;
  status: string;
  /** true = יש גישה מלאה. false = מסך חסימה בלבד. */
  hasAccess: boolean;
  /** true = יש חוב פתוח, מציגים באנר אבל לא חוסמים */
  needsAttention: boolean;
  currentPeriodEnd: Date | null;
  trialEndsAt: Date | null;
  cancelAtPeriodEnd: boolean;
  features: Record<string, Entitlement>;
}

const CACHE_MS = 60_000;
const cache = new Map<string, { at: number; value: OrgEntitlements }>();

export function invalidateEntitlements(orgId: string) {
  cache.delete(orgId);
}

/** תחילת חלון הספירה למונים מחזוריים */
function cyclePeriodKey(periodStart: Date | null): string {
  const d = periodStart ?? new Date();
  return d.toISOString().slice(0, 10);
}

export async function getEntitlements(orgId: string, opts?: { fresh?: boolean }): Promise<OrgEntitlements> {
  const hit = cache.get(orgId);
  if (!opts?.fresh && hit && Date.now() - hit.at < CACHE_MS) return hit.value;

  const [sub] = await db.select().from(s.orgSubscriptions).where(eq(s.orgSubscriptions.orgId, orgId)).limit(1);

  const planId = sub?.status === 'TRIALING' ? 'pro' : (sub?.planId ?? 'free');
  const plan = PLAN_BY_ID[planId] ?? PLAN_BY_ID['free'];

  // מגבלות מה-DB; נופלים לקטלוג אם השורות עוד לא נזרעו
  const rows = await db.select().from(s.planEntitlements).where(eq(s.planEntitlements.planId, planId));
  const dbEnt = new Map(rows.map((r) => [r.featureKey, r]));

  // תוספות שנרכשו מגדילות מכסות
  const bonus = new Map<string, number>();
  if (sub) {
    const items = await db.select().from(s.subscriptionItems)
      .where(and(eq(s.subscriptionItems.subscriptionId, sub.id), eq(s.subscriptionItems.kind, 'ADDON')));
    for (const it of items) {
      const def = it.addonKey ? ADDON_BY_KEY[it.addonKey] : undefined;
      if (def?.grants) bonus.set(def.grants.feature, (bonus.get(def.grants.feature) ?? 0) + def.grants.per * it.quantity);
    }
  }

  const usage = await currentUsage(orgId, cyclePeriodKey(sub?.currentPeriodStart ?? null));

  const features: Record<string, Entitlement> = {};
  for (const f of FEATURES) {
    const row = dbEnt.get(f.key);
    const fallback = plan.entitlements[f.key as FeatureKey];
    const enabled = row ? row.isEnabled : fallback !== false;
    let limit = row ? row.limitValue : (typeof fallback === 'number' ? fallback : null);
    if (limit !== null && bonus.has(f.key)) limit += bonus.get(f.key)!;
    if (!enabled) limit = 0;

    const used = usage[f.key] ?? 0;
    features[f.key] = {
      key: f.key,
      label: f.label,
      enabled,
      limit,
      used,
      remaining: limit === null ? null : Math.max(0, limit - used),
      pct: limit === null || limit === 0 ? null : Math.min(100, Math.round((used / limit) * 100)),
    };
  }

  const status = sub?.status ?? 'FREE';
  const value: OrgEntitlements = {
    orgId,
    planId,
    planName: plan.nameHe,
    status,
    hasAccess: status !== 'SUSPENDED' && status !== 'CLOSED',
    needsAttention: status === 'PAST_DUE',
    currentPeriodEnd: sub?.currentPeriodEnd ?? null,
    trialEndsAt: sub?.trialEndsAt ?? null,
    cancelAtPeriodEnd: sub?.cancelAtPeriodEnd ?? false,
    features,
  };

  cache.set(orgId, { at: Date.now(), value });
  return value;
}

/**
 * ספירת שימוש בפועל.
 * מונים מוחלטים (משתמשים, לידים) נספרים מהטבלאות עצמן — מונה נפרד
 * יוצא מסנכרון ברגע שמישהו מוחק שורה ישירות ב-DB.
 * מונים מחזוריים (הצעות בחודש) נשמרים ב-usage_counters.
 */
async function currentUsage(orgId: string, periodKey: string): Promise<Record<string, number>> {
  const [counts] = await db.execute<{
    users: number; leads: number; wa_channels: number; forms: number;
  }>(sql`
    SELECT
      (SELECT COUNT(*)::int FROM memberships       WHERE org_id = ${orgId}) AS users,
      (SELECT COUNT(*)::int FROM leads             WHERE org_id = ${orgId} AND status NOT IN ('LOST','WON')) AS leads,
      (SELECT COUNT(*)::int FROM integrations      WHERE org_id = ${orgId} AND provider = 'GREEN_API' AND enabled) AS wa_channels,
      (SELECT COUNT(*)::int FROM webhook_endpoints WHERE org_id = ${orgId} AND active) AS forms
  `);

  const cycleRows = await db.select().from(s.usageCounters)
    .where(and(eq(s.usageCounters.orgId, orgId), eq(s.usageCounters.periodStart, periodKey)));

  const out: Record<string, number> = {
    users: Number(counts?.users ?? 0),
    leads: Number(counts?.leads ?? 0),
    wa_channels: Number(counts?.wa_channels ?? 0),
    forms: Number(counts?.forms ?? 0),
  };
  for (const r of cycleRows) out[r.featureKey] = r.used;
  return out;
}

/* ═══════════ שומרים ═══════════ */

export class QuotaError extends Error {
  constructor(
    public feature: string,
    public label: string,
    public limit: number | null,
    public used: number,
    public planId: string,
  ) {
    super(`quota_exceeded:${feature}`);
  }
  toJSON() {
    return {
      error: 'QUOTA_EXCEEDED',
      feature: this.feature,
      message: `הגעת למכסת ${this.label} בחבילה הנוכחית`,
      limit: this.limit,
      used: this.used,
      upgradeUrl: '/settings/billing/change',
    };
  }
}

export class FeatureLockedError extends Error {
  constructor(public feature: string, public label: string, public planId: string) {
    super(`feature_locked:${feature}`);
  }
  toJSON() {
    return {
      error: 'FEATURE_LOCKED',
      feature: this.feature,
      message: `${this.label} אינו זמין בחבילה הנוכחית`,
      upgradeUrl: '/settings/billing/change',
    };
  }
}

export async function requireFeature(orgId: string, key: FeatureKey) {
  const ent = await getEntitlements(orgId);
  const f = ent.features[key];
  if (!f?.enabled) throw new FeatureLockedError(key, f?.label ?? key, ent.planId);
}

export async function requireQuota(orgId: string, key: FeatureKey, need = 1) {
  const ent = await getEntitlements(orgId, { fresh: true });
  const f = ent.features[key];
  if (!f?.enabled) throw new FeatureLockedError(key, f?.label ?? key, ent.planId);
  if (f.limit === null) return;
  if (f.used + need > f.limit) throw new QuotaError(key, f.label, f.limit, f.used, ent.planId);
}

/** מונה מחזורי — נקרא אחרי יצירה מוצלחת, לא לפניה */
export async function bumpUsage(orgId: string, key: FeatureKey, by = 1, periodStart?: Date) {
  const periodKey = cyclePeriodKey(periodStart ?? null);
  await db.insert(s.usageCounters)
    .values({ orgId, featureKey: key, periodStart: periodKey, used: by })
    .onConflictDoUpdate({
      target: [s.usageCounters.orgId, s.usageCounters.featureKey, s.usageCounters.periodStart],
      set: { used: sql`${s.usageCounters.used} + ${by}` },
    });
  invalidateEntitlements(orgId);
}
