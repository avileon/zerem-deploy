/**
 * שירות המנויים — הפעולות שהלקוח יוזם.
 * הפרדה מכוונת מ-engine.ts: שם הכול מונע cron, כאן הכול מונע משתמש.
 */
import { and, eq, sql, desc } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import {
  addInterval, anchorDayFrom, buildInvoice, couponDiscount, couponLabel,
  isBetterCoupon, prorate, round2, validateCoupon, withVat,
  COUPON_REJECTION_HE, type CouponLike, type Interval,
} from './pricing';
import {
  ADDON_BY_KEY, FREE_PLAN_ID, PLAN_BY_ID, TRIAL_DAYS, TRIAL_PLAN_ID,
} from './catalog';
import { createCheckoutLink, getLpResult, platformCardcom } from './cardcom-billing';
import { invalidateEntitlements } from './entitlements';
import { logEvent } from './engine';

/* ═══════════ קריאה ═══════════ */

export async function getSubscription(orgId: string) {
  const [sub] = await db.select().from(s.orgSubscriptions)
    .where(eq(s.orgSubscriptions.orgId, orgId)).limit(1);
  return sub ?? null;
}

export async function ensureSubscription(orgId: string) {
  const existing = await getSubscription(orgId);
  if (existing) return existing;
  const now = new Date();
  const trialEndsAt = new Date(now.getTime() + TRIAL_DAYS * 86_400_000);
  const [sub] = await db.insert(s.orgSubscriptions).values({
    orgId,
    planId: TRIAL_PLAN_ID,
    interval: 'MONTHLY',
    status: 'TRIALING',
    currentPeriodStart: now,
    currentPeriodEnd: trialEndsAt,
    trialEndsAt,
    billingAnchorDay: anchorDayFrom(now),
  }).returning();
  await logEvent(orgId, sub.id, 'trial.started', { days: TRIAL_DAYS }, 'system:signup');
  return sub;
}

export async function listInvoices(orgId: string, limit = 24) {
  return db.select().from(s.billingInvoices)
    .where(eq(s.billingInvoices.orgId, orgId))
    .orderBy(desc(s.billingInvoices.createdAt))
    .limit(limit);
}

export async function subscriptionAddons(subscriptionId: string) {
  return db.select().from(s.subscriptionItems).where(and(
    eq(s.subscriptionItems.subscriptionId, subscriptionId),
    eq(s.subscriptionItems.kind, 'ADDON'),
  ));
}

/* ═══════════ קופונים ═══════════ */

export async function findCoupon(code: string): Promise<CouponLike | null> {
  const [c] = await db.select().from(s.coupons)
    .where(sql`upper(${s.coupons.code}) = upper(${code.trim()})`).limit(1);
  if (!c) return null;
  return {
    id: c.id, code: c.code, type: c.type, value: Number(c.value),
    duration: c.duration, durationCycles: c.durationCycles,
    validFrom: c.validFrom, validUntil: c.validUntil,
    maxRedemptions: c.maxRedemptions, redemptionCount: c.redemptionCount,
    appliesToPlans: c.appliesToPlans ?? null, appliesToInterval: c.appliesToInterval ?? null,
    firstTimeOnly: c.firstTimeOnly,
    minAmountExVat: c.minAmountExVat ? Number(c.minAmountExVat) : null,
    isActive: c.isActive,
  };
}

export interface CouponPreview {
  ok: boolean;
  reason?: string;
  code?: string;
  label?: string;
  discountExVat?: number;
  netExVat?: number;
  totalIncVat?: number;
  betterThanCurrent?: boolean;
}

export async function previewCoupon(
  orgId: string, code: string, planId: string, interval: Interval,
): Promise<CouponPreview> {
  const plan = PLAN_BY_ID[planId];
  if (!plan) return { ok: false, reason: 'החבילה לא נמצאה' };
  const base = interval === 'YEARLY' ? (plan.yearly ?? 0) : (plan.monthly ?? 0);

  const c = await findCoupon(code);
  if (!c) return { ok: false, reason: COUPON_REJECTION_HE.NOT_FOUND };

  const [redeemed] = await db.select().from(s.couponRedemptions).where(and(
    eq(s.couponRedemptions.couponId, c.id), eq(s.couponRedemptions.orgId, orgId),
  )).limit(1);

  const [paidBefore] = await db.select({ n: sql<number>`count(*)::int` })
    .from(s.billingInvoices)
    .where(and(eq(s.billingInvoices.orgId, orgId), eq(s.billingInvoices.status, 'PAID')));

  const v = validateCoupon(c, {
    planId, interval, amountExVat: base,
    alreadyRedeemedByOrg: !!redeemed,
    orgEverPaid: Number(paidBefore?.n ?? 0) > 0,
  });
  if (!v.ok) return { ok: false, reason: COUPON_REJECTION_HE[v.reason] };

  const discountExVat = couponDiscount(c, base, c.durationCycles);
  const netExVat = round2(Math.max(0, base - discountExVat));
  const { totalIncVat } = withVat(netExVat);

  const sub = await getSubscription(orgId);
  const current = sub?.couponId ? await findCouponById(sub.couponId) : null;

  return {
    ok: true,
    code: c.code,
    label: couponLabel(c),
    discountExVat,
    netExVat,
    totalIncVat,
    betterThanCurrent: isBetterCoupon(c, current, base),
  };
}

async function findCouponById(id: string): Promise<CouponLike | null> {
  const [c] = await db.select().from(s.coupons).where(eq(s.coupons.id, id)).limit(1);
  if (!c) return null;
  return {
    id: c.id, code: c.code, type: c.type, value: Number(c.value),
    duration: c.duration, durationCycles: c.durationCycles,
    validFrom: c.validFrom, validUntil: c.validUntil,
    maxRedemptions: c.maxRedemptions, redemptionCount: c.redemptionCount,
    appliesToPlans: c.appliesToPlans ?? null, appliesToInterval: c.appliesToInterval ?? null,
    firstTimeOnly: c.firstTimeOnly,
    minAmountExVat: c.minAmountExVat ? Number(c.minAmountExVat) : null,
    isActive: c.isActive,
  };
}

/**
 * מימוש קופון — בתוך טרנזקציה עם נעילת שורה.
 * בלי FOR UPDATE, קמפיין עם 100 מימושים יכול להיפרע 200 פעם
 * ברגע שמאה אנשים לוחצים באותה שנייה.
 */
export async function redeemCoupon(orgId: string, subscriptionId: string, couponId: string) {
  return db.transaction(async (tx) => {
    const [locked] = await tx.execute<{ id: string; redemption_count: number; max_redemptions: number | null }>(
      sql`SELECT id, redemption_count, max_redemptions FROM coupons WHERE id = ${couponId} FOR UPDATE`,
    );
    if (!locked) return { ok: false as const, reason: COUPON_REJECTION_HE.NOT_FOUND };
    if (locked.max_redemptions !== null && locked.redemption_count >= locked.max_redemptions)
      return { ok: false as const, reason: COUPON_REJECTION_HE.EXHAUSTED };

    await tx.insert(s.couponRedemptions)
      .values({ couponId, orgId, subscriptionId })
      .onConflictDoNothing();

    await tx.update(s.coupons)
      .set({ redemptionCount: sql`${s.coupons.redemptionCount} + 1` })
      .where(eq(s.coupons.id, couponId));

    const c = await findCouponById(couponId);
    await tx.update(s.orgSubscriptions).set({
      couponId,
      couponCyclesLeft: c?.duration === 'REPEATING' ? (c.durationCycles ?? 1)
        : c?.type === 'FREE_PERIODS' ? Number(c.value) : null,
      updatedAt: new Date(),
    }).where(eq(s.orgSubscriptions.id, subscriptionId));

    return { ok: true as const };
  });
}

/* ═══════════ קופה ═══════════ */

export interface CheckoutInput {
  orgId: string;
  planId: string;
  interval: Interval;
  couponCode?: string;
  origin: string;
}

export async function startCheckout(i: CheckoutInput) {
  const plan = PLAN_BY_ID[i.planId];
  if (!plan) return { ok: false as const, error: 'החבילה לא נמצאה' };
  if (i.planId === FREE_PLAN_ID) return { ok: false as const, error: 'חבילת החינם אינה דורשת תשלום' };

  const sub = await ensureSubscription(i.orgId);
  const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, i.orgId)).limit(1);

  const base = i.interval === 'YEARLY' ? (plan.yearly ?? 0) : (plan.monthly ?? 0);

  let coupon: CouponLike | null = null;
  if (i.couponCode) {
    const preview = await previewCoupon(i.orgId, i.couponCode, i.planId, i.interval);
    if (preview.ok) coupon = await findCoupon(i.couponCode);
  }

  const now = new Date();
  const anchor = anchorDayFrom(now);
  const draft = buildInvoice({
    planName: plan.nameHe,
    planAmountExVat: base,
    interval: i.interval,
    periodStart: now,
    periodEnd: addInterval(now, i.interval, anchor),
    addons: [],
    coupon: coupon ? { c: coupon, cyclesLeft: coupon.durationCycles } : null,
    at: now,
  });

  // שומרים את הכוונה על המנוי — ה-webhook צריך לדעת מה נבחר
  await db.update(s.orgSubscriptions).set({
    planId: i.planId,
    interval: i.interval,
    billingAnchorDay: anchor,
    updatedAt: now,
  }).where(eq(s.orgSubscriptions.id, sub.id));

  if (coupon) await redeemCoupon(i.orgId, sub.id, coupon.id);

  const cfg = platformCardcom();
  const link = await createCheckoutLink({
    cfg,
    amountIncVat: draft.totalIncVat,
    returnValue: `sub_${sub.id}`,
    productName: `זרם · ${plan.nameHe} · ${i.interval === 'YEARLY' ? 'שנתי' : 'חודשי'}`,
    successUrl: `${i.origin}/billing/return?sub=${sub.id}&ok=1`,
    failedUrl: `${i.origin}/billing/return?sub=${sub.id}&ok=0`,
    webhookUrl: `${i.origin}/api/webhooks/cardcom/billing`,
    customer: {
      name: org?.legalName || org?.name || 'לקוח',
      email: org?.email ?? undefined,
      phone: org?.phone ?? undefined,
    },
    document: {
      name: org?.legalName || org?.name || 'לקוח',
      email: org?.email ?? undefined,
      phone: org?.phone ?? undefined,
      taxId: org?.vatId ?? undefined,
      sendByEmail: true,
      products: [{
        Description: `זרם · ${plan.nameHe} · ${i.interval === 'YEARLY' ? 'מנוי שנתי' : 'מנוי חודשי'}`,
        Quantity: 1,
        UnitCost: draft.totalIncVat,
      }],
    },
  });

  if (!link.ok) return { ok: false as const, error: link.error };

  await logEvent(i.orgId, sub.id, 'checkout.started',
    { planId: i.planId, interval: i.interval, amount: draft.totalIncVat, coupon: coupon?.code }, 'user');

  return {
    ok: true as const,
    url: link.url!,
    lowProfileId: link.lowProfileId,
    amountIncVat: draft.totalIncVat,
    zeroAuth: link.zeroAuth,
  };
}

/**
 * החלפת אמצעי תשלום — אימות ללא חיוב אם המסוף תומך.
 * אחרת ₪1 שנרשם ומזוכה מיד. מוצג ללקוח בשקיפות, לא מוסתר.
 */
export async function startPaymentMethodUpdate(orgId: string, origin: string) {
  const sub = await ensureSubscription(orgId);
  const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, orgId)).limit(1);
  const cfg = platformCardcom();

  const link = await createCheckoutLink({
    cfg,
    amountIncVat: 0,
    returnValue: `pm_${sub.id}`,
    productName: 'עדכון אמצעי תשלום · זרם',
    successUrl: `${origin}/billing/return?sub=${sub.id}&pm=1&ok=1`,
    failedUrl: `${origin}/billing/return?sub=${sub.id}&pm=1&ok=0`,
    webhookUrl: `${origin}/api/webhooks/cardcom/billing`,
    customer: { name: org?.legalName || org?.name || 'לקוח', email: org?.email ?? undefined },
  });

  if (!link.ok) return { ok: false as const, error: link.error };
  return { ok: true as const, url: link.url!, zeroAuth: link.zeroAuth };
}

/* ═══════════ עיבוד חזרה מקארדקום ═══════════ */

/**
 * נקרא מה-webhook ומדף החזרה כאחד — שניהם מגיעים, הסדר לא מובטח.
 * אידמפוטנטי: קריאה שנייה על אותו LowProfileId לא משנה כלום.
 */
export async function settleLowProfile(lowProfileId: string, actor: string) {
  const cfg = platformCardcom();
  const r = await getLpResult(cfg, lowProfileId);
  if (!r.ok) return { ok: false as const, error: r.error ?? 'GetLpResult נכשל' };

  const rv = r.returnValue ?? '';
  const isPmUpdate = rv.startsWith('pm_');
  const subId = rv.replace(/^(sub_|pm_)/, '');
  if (!subId) return { ok: false as const, error: 'ReturnValue חסר' };

  const [sub] = await db.select().from(s.orgSubscriptions)
    .where(eq(s.orgSubscriptions.id, subId)).limit(1);
  if (!sub) return { ok: false as const, error: 'מנוי לא נמצא' };

  // ── שמירת הטוקן
  let pmId = sub.paymentMethodId;
  if (r.token) {
    await db.update(s.billingPaymentMethods).set({ isDefault: false })
      .where(eq(s.billingPaymentMethods.orgId, sub.orgId));
    const [pm] = await db.insert(s.billingPaymentMethods).values({
      orgId: sub.orgId,
      token: r.token,
      last4: r.last4,
      brand: r.brand,
      expMonth: r.expMonth,
      expYear: r.expYear,
      holderName: r.holderName,
      isDefault: true,
      status: 'VALID',
    }).returning({ id: s.billingPaymentMethods.id });
    pmId = pm.id;
  }

  if (isPmUpdate) {
    await db.update(s.orgSubscriptions).set({
      paymentMethodId: pmId,
      // כרטיס חדש → מנסים מיד, לא מחכים למחזור הבא
      nextRetryAt: sub.status === 'PAST_DUE' || sub.status === 'SUSPENDED' ? new Date() : null,
      status: sub.status === 'SUSPENDED' ? 'PAST_DUE' : sub.status,
      updatedAt: new Date(),
    }).where(eq(s.orgSubscriptions.id, sub.id));
    await logEvent(sub.orgId, sub.id, 'payment_method.updated', { last4: r.last4 }, actor);
    invalidateEntitlements(sub.orgId);
    return { ok: true as const, kind: 'PM' as const, subscriptionId: sub.id };
  }

  // ── תשלום ראשון
  const now = new Date();
  const periodEnd = addInterval(now, sub.interval as Interval, sub.billingAnchorDay);
  const plan = PLAN_BY_ID[sub.planId];
  const base = sub.interval === 'YEARLY' ? (plan?.yearly ?? 0) : (plan?.monthly ?? 0);
  const amountIncVat = r.amount ?? withVat(base).totalIncVat;
  const { vatRate, vatAmount } = withVat(round2(amountIncVat / (1 + withVat(0).vatRate || 0.18)));

  const existing = await db.select().from(s.billingInvoices).where(and(
    eq(s.billingInvoices.subscriptionId, sub.id),
    eq(s.billingInvoices.periodStart, now),
  )).limit(1);

  if (!existing.length) {
    const netExVat = round2(amountIncVat / (1 + vatRate));
    const [inv] = await db.insert(s.billingInvoices).values({
      orgId: sub.orgId,
      subscriptionId: sub.id,
      periodStart: now,
      periodEnd,
      subtotalExVat: String(netExVat),
      discountExVat: '0',
      vatRate: String(vatRate),
      vatAmount: String(round2(amountIncVat - netExVat)),
      totalIncVat: String(amountIncVat),
      status: amountIncVat > 0 ? 'PAID' : 'ZERO_RATED',
      paidAt: now,
      cardcomTranId: r.transactionId,
      cardcomDocNumber: r.docNumber,
      cardcomDocUrl: r.docUrl,
    }).returning({ id: s.billingInvoices.id });

    await db.insert(s.billingInvoiceLines).values({
      invoiceId: inv.id,
      description: `${plan?.nameHe ?? sub.planId} · ${sub.interval === 'YEARLY' ? 'שנתי' : 'חודשי'}`,
      quantity: '1',
      unitExVat: String(netExVat),
      amountExVat: String(netExVat),
      kind: 'PLAN',
    });
    void vatAmount;
  }

  await db.update(s.orgSubscriptions).set({
    status: 'ACTIVE',
    paymentMethodId: pmId,
    currentPeriodStart: now,
    currentPeriodEnd: periodEnd,
    trialEndsAt: null,
    dunningAttempt: 0,
    nextRetryAt: null,
    updatedAt: now,
  }).where(eq(s.orgSubscriptions.id, sub.id));

  await logEvent(sub.orgId, sub.id, 'subscription.activated',
    { planId: sub.planId, amount: amountIncVat, tranId: r.transactionId }, actor);
  invalidateEntitlements(sub.orgId);

  return { ok: true as const, kind: 'PAID' as const, subscriptionId: sub.id };
}

/* ═══════════ שינוי חבילה ═══════════ */

export interface ChangePreview {
  direction: 'UPGRADE' | 'DOWNGRADE' | 'SAME';
  effective: 'NOW' | 'PERIOD_END';
  prorationExVat: number;
  prorationIncVat: number;
  daysLeft: number;
  newMonthlyExVat: number;
  effectiveDate: Date;
}

export async function previewChange(
  orgId: string, planId: string, interval: Interval,
): Promise<ChangePreview | { error: string }> {
  const sub = await getSubscription(orgId);
  if (!sub) return { error: 'אין מנוי' };
  const oldPlan = PLAN_BY_ID[sub.planId];
  const newPlan = PLAN_BY_ID[planId];
  if (!newPlan) return { error: 'החבילה לא נמצאה' };

  const oldMonthly = oldPlan ? (oldPlan.monthly ?? 0) : 0;
  const newMonthly = newPlan.monthly ?? 0;
  const direction = newMonthly > oldMonthly ? 'UPGRADE' : newMonthly < oldMonthly ? 'DOWNGRADE' : 'SAME';

  const p = prorate({
    oldMonthlyExVat: oldMonthly,
    newMonthlyExVat: newMonthly,
    periodStart: sub.currentPeriodStart,
    periodEnd: sub.currentPeriodEnd,
  });

  const { totalIncVat } = withVat(p.amountExVat);

  return {
    direction,
    effective: direction === 'UPGRADE' ? 'NOW' : 'PERIOD_END',
    prorationExVat: p.amountExVat,
    prorationIncVat: totalIncVat,
    daysLeft: p.daysLeft,
    newMonthlyExVat: interval === 'YEARLY' ? (newPlan.yearly ?? 0) : newMonthly,
    effectiveDate: direction === 'UPGRADE' ? new Date() : sub.currentPeriodEnd,
  };
}

export async function cancelSubscription(orgId: string, reason?: string) {
  const sub = await getSubscription(orgId);
  if (!sub) return { ok: false as const, error: 'אין מנוי' };
  await db.update(s.orgSubscriptions).set({
    cancelAtPeriodEnd: true,
    status: 'CANCELING',
    canceledAt: new Date(),
    cancelReason: reason ?? null,
    updatedAt: new Date(),
  }).where(eq(s.orgSubscriptions.id, sub.id));
  await logEvent(orgId, sub.id, 'subscription.cancel_scheduled', { reason }, 'user');
  invalidateEntitlements(orgId);
  return { ok: true as const, activeUntil: sub.currentPeriodEnd };
}

export async function resumeSubscription(orgId: string) {
  const sub = await getSubscription(orgId);
  if (!sub) return { ok: false as const, error: 'אין מנוי' };
  await db.update(s.orgSubscriptions).set({
    cancelAtPeriodEnd: false,
    status: 'ACTIVE',
    canceledAt: null,
    cancelReason: null,
    updatedAt: new Date(),
  }).where(eq(s.orgSubscriptions.id, sub.id));
  await logEvent(orgId, sub.id, 'subscription.resumed', {}, 'user');
  invalidateEntitlements(orgId);
  return { ok: true as const };
}

/* ═══════════ תוספות ═══════════ */

export async function addAddon(orgId: string, addonKey: string, quantity = 1) {
  const def = ADDON_BY_KEY[addonKey];
  if (!def) return { ok: false as const, error: 'התוספת לא נמצאה' };
  const sub = await getSubscription(orgId);
  if (!sub) return { ok: false as const, error: 'אין מנוי' };
  if (!def.availableIn.includes(sub.planId))
    return { ok: false as const, error: 'התוספת אינה זמינה בחבילה הנוכחית' };

  const [existing] = await db.select().from(s.subscriptionItems).where(and(
    eq(s.subscriptionItems.subscriptionId, sub.id),
    eq(s.subscriptionItems.addonKey, addonKey),
  )).limit(1);

  if (existing) {
    await db.update(s.subscriptionItems)
      .set({ quantity: existing.quantity + quantity })
      .where(eq(s.subscriptionItems.id, existing.id));
  } else {
    await db.insert(s.subscriptionItems).values({
      subscriptionId: sub.id, kind: 'ADDON', addonKey,
      quantity, unitExVat: String(def.monthlyExVat),
    });
  }

  const p = prorate({
    oldMonthlyExVat: 0,
    newMonthlyExVat: def.monthlyExVat * quantity,
    periodStart: sub.currentPeriodStart,
    periodEnd: sub.currentPeriodEnd,
  });

  await logEvent(orgId, sub.id, 'addon.added',
    { addonKey, quantity, prorationExVat: p.amountExVat }, 'user');
  invalidateEntitlements(orgId);
  return { ok: true as const, prorationExVat: p.amountExVat };
}
