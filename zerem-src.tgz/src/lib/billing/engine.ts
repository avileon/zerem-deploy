/**
 * מנוע הגבייה החוזרת.
 *
 * זה החלק שאם הוא לא רץ — לא נכנס כסף. לכן שלושה עקרונות:
 *  1. נעילה (advisory lock) — שתי ריצות במקביל לא יחייבו פעמיים
 *  2. כל מנוי בטרנזקציה משלו — כישלון של לקוח אחד לא מפיל 400 אחרים
 *  3. אידמפוטנטיות בשתי שכבות — UNIQUE אצלנו + ExternalUniqTranId בקארדקום
 *
 * התהליך מת אחרי שקארדקום חייב אבל לפני שכתבנו ל-DB? הריצה הבאה
 * תשלח את אותו מפתח, קארדקום יחזיר את העסקה הקיימת, ונרשום אותה.
 */
import { and, eq, inArray, isNotNull, lte, or, sql } from 'drizzle-orm';
import { db, schema as s, sql as pgConn } from '@/db';
import { vatRateAt } from '../israel';
import {
  addInterval, buildInvoice, idempotencyKey, round2,
  type CouponLike, type Interval,
} from './pricing';
import {
  chargeToken, createCheckoutLink, getLpResult, platformCardcom,
  declineMessageHe, type DocInput,
} from './cardcom-billing';
import {
  DUNNING_SCHEDULE_DAYS, SUSPEND_AFTER_ATTEMPT, CLOSE_AFTER_SUSPENDED_DAYS,
  PLAN_BY_ID, ADDON_BY_KEY, FREE_PLAN_ID, CARD_EXPIRY_WARN_DAYS,
} from './catalog';
import { invalidateEntitlements } from './entitlements';

const LOCK_KEY = 8_140_326; // מזהה שרירותי קבוע ל-advisory lock

/**
 * מנעול בתוך התהליך.
 *
 * ⚠️ למה זה נחוץ בנוסף ל-advisory lock: מנעולי advisory ב-Postgres הם
 * ברמת **סשן** ו**re-entrant**. שתי ריצות שקיבלו את אותו חיבור מה-pool
 * ישיגו שתיהן את המנעול, ושתיהן יחייבו. הבדיקה תפסה את זה בפועל.
 * לכן: מנעול בזיכרון חוסם כפילות באותו תהליך, ו-advisory lock על חיבור
 * ייעודי (reserve) חוסם כפילות בין תהליכים ובין מכונות.
 */
let inFlight = false;

export interface CycleReport {
  startedAt: string;
  finishedAt: string;
  skipped: boolean;
  examined: number;
  charged: number;
  chargedTotalIncVat: number;
  zeroRated: number;
  failed: number;
  suspended: number;
  closed: number;
  downgraded: number;
  errors: Array<{ subscriptionId: string; message: string }>;
}

/* ═══════════ נקודת הכניסה ═══════════ */

export async function runBillingCycle(opts?: { now?: Date; dryRun?: boolean }): Promise<CycleReport> {
  const now = opts?.now ?? new Date();
  const startedAt = new Date().toISOString();
  const report: CycleReport = {
    startedAt, finishedAt: startedAt, skipped: false,
    examined: 0, charged: 0, chargedTotalIncVat: 0, zeroRated: 0,
    failed: 0, suspended: 0, closed: 0, downgraded: 0, errors: [],
  };

  if (inFlight) {
    report.skipped = true;
    report.finishedAt = new Date().toISOString();
    return report;
  }
  inFlight = true;

  // חיבור ייעודי — המנעול והשחרור חייבים לרוץ על אותו סשן,
  // אחרת Postgres מזהיר "you don't own a lock" והמנעול נשאר תלוי.
  const conn = await pgConn.reserve();
  let holdsLock = false;
  try {
    const [lock] = await conn<{ locked: boolean }[]>`SELECT pg_try_advisory_lock(${LOCK_KEY}) AS locked`;
    if (!lock?.locked) {
      report.skipped = true;
      report.finishedAt = new Date().toISOString();
      return report;
    }
    holdsLock = true;

    await expireTrials(now, report);
    await closeAbandoned(now, report);

    const due = await db.select().from(s.orgSubscriptions).where(
      or(
        and(
          inArray(s.orgSubscriptions.status, ['ACTIVE', 'CANCELING']),
          lte(s.orgSubscriptions.currentPeriodEnd, now),
        ),
        and(
          eq(s.orgSubscriptions.status, 'PAST_DUE'),
          isNotNull(s.orgSubscriptions.nextRetryAt),
          lte(s.orgSubscriptions.nextRetryAt, now),
        ),
      ),
    );

    report.examined = due.length;

    for (const sub of due) {
      try {
        await processSubscription(sub, now, report, opts?.dryRun ?? false);
      } catch (e) {
        report.errors.push({ subscriptionId: sub.id, message: String(e) });
        await logEvent(sub.orgId, sub.id, 'cycle.error', { message: String(e) }, 'system:cron');
      }
    }

    await flagExpiringCards(now);
  } finally {
    if (holdsLock) await conn`SELECT pg_advisory_unlock(${LOCK_KEY})`.catch(() => {});
    conn.release();
    inFlight = false;
  }

  report.finishedAt = new Date().toISOString();
  return report;
}

/* ═══════════ מנוי בודד ═══════════ */

type Sub = typeof s.orgSubscriptions.$inferSelect;

async function processSubscription(sub: Sub, now: Date, report: CycleReport, dryRun: boolean) {
  // ביטול שהגיע לסוף התקופה → חבילת חינם, בלי חיוב
  if (sub.cancelAtPeriodEnd && sub.status !== 'PAST_DUE') {
    await downgradeToFree(sub, 'canceled_at_period_end');
    report.downgraded++;
    return;
  }

  const plan = PLAN_BY_ID[sub.planId];
  if (!plan) throw new Error(`unknown plan ${sub.planId}`);

  const interval = sub.interval as Interval;
  const periodStart = sub.status === 'PAST_DUE' ? sub.currentPeriodEnd : sub.currentPeriodEnd;
  const periodEnd = addInterval(periodStart, interval, sub.billingAnchorDay);

  const items = await db.select().from(s.subscriptionItems)
    .where(and(eq(s.subscriptionItems.subscriptionId, sub.id), eq(s.subscriptionItems.kind, 'ADDON')));

  const coupon = await loadCoupon(sub.couponId);

  const draft = buildInvoice({
    planName: plan.nameHe,
    planAmountExVat: interval === 'YEARLY' ? (plan.yearly ?? 0) : (plan.monthly ?? 0),
    interval,
    periodStart,
    periodEnd,
    addons: items.map((it) => ({
      label: it.addonKey ? (ADDON_BY_KEY[it.addonKey]?.label ?? it.addonKey) : 'תוספת',
      quantity: it.quantity,
      unitExVat: Number(it.unitExVat),
    })),
    coupon: coupon ? { c: coupon, cyclesLeft: sub.couponCyclesLeft } : null,
    at: now,
  });

  if (dryRun) return;

  // ── חשבונית: UNIQUE (subscription_id, period_start) היא ההגנה הראשונה
  const existing = await db.select().from(s.billingInvoices).where(and(
    eq(s.billingInvoices.subscriptionId, sub.id),
    eq(s.billingInvoices.periodStart, periodStart),
  )).limit(1);

  let invoiceId: string;
  if (existing.length) {
    if (existing[0].status === 'PAID' || existing[0].status === 'ZERO_RATED') {
      // כבר שולם — כנראה קריסה אחרי החיוב ולפני קידום התקופה. נקדם עכשיו.
      await advancePeriod(sub, periodStart, periodEnd, coupon);
      return;
    }
    invoiceId = existing[0].id;
  } else {
    const [inv] = await db.insert(s.billingInvoices).values({
      orgId: sub.orgId,
      subscriptionId: sub.id,
      periodStart, periodEnd,
      subtotalExVat: String(draft.subtotalExVat),
      discountExVat: String(draft.discountExVat),
      vatRate: String(draft.vatRate),
      vatAmount: String(draft.vatAmount),
      totalIncVat: String(draft.totalIncVat),
      status: draft.totalIncVat <= 0 ? 'ZERO_RATED' : 'OPEN',
    }).returning({ id: s.billingInvoices.id });
    invoiceId = inv.id;

    // חשבונית בלי שורות קורית כשמנוי בחבילת חינם מגיע לכאן.
    // insert עם מערך ריק זורק ב-Drizzle ומפיל את כל המחזור — לכן שומר.
    if (draft.lines.length) {
      await db.insert(s.billingInvoiceLines).values(draft.lines.map((l) => ({
        invoiceId,
        description: l.description,
        quantity: String(l.quantity),
        unitExVat: String(l.unitExVat),
        amountExVat: String(l.amountExVat),
        kind: l.kind,
      })));
    }
  }

  // ── סכום 0 (קופון "חודש חינם"): לא שולחים בקשת חיוב בכלל.
  //    חשבונית מס על ₪0 אינה מסמך מס — אין עסקה.
  if (draft.totalIncVat <= 0) {
    await db.update(s.billingInvoices)
      .set({ status: 'ZERO_RATED', paidAt: now })
      .where(eq(s.billingInvoices.id, invoiceId));
    await advancePeriod(sub, periodStart, periodEnd, coupon);
    await logEvent(sub.orgId, sub.id, 'invoice.zero_rated', { invoiceId, coupon: coupon?.code }, 'system:cron');
    report.zeroRated++;
    return;
  }

  // ── אמצעי תשלום
  const pm = await defaultPaymentMethod(sub.orgId);
  if (!pm) {
    await markFailed(sub, invoiceId, now, report, 'אין אמצעי תשלום שמור');
    return;
  }

  const attemptNo = sub.dunningAttempt + 1;
  const key = idempotencyKey(sub.id, periodStart);

  const org = await orgBillingProfile(sub.orgId);
  const doc: DocInput = {
    name: org.legalName || org.name,
    email: org.email ?? undefined,
    phone: org.phone ?? undefined,
    taxId: org.vatId ?? undefined,
    sendByEmail: true,
    products: draft.lines
      .filter((l) => l.amountExVat !== 0)
      .map((l) => ({
        Description: l.description,
        Quantity: l.quantity,
        UnitCost: round2(l.amountExVat * (1 + draft.vatRate) / (l.quantity || 1)),
      })),
  };

  const cfg = platformCardcom();
  const res = await chargeToken({
    cfg,
    token: pm.token,
    expiryMMYY: `${String(pm.expMonth ?? 12).padStart(2, '0')}${String(pm.expYear ?? 30).slice(-2)}`,
    amountIncVat: draft.totalIncVat,
    idempotencyKey: key,
    document: doc,
  });

  await db.insert(s.chargeAttempts).values({
    invoiceId, attemptNo, externalUniqId: key,
    responseCode: res.responseCode,
    responseText: res.description ?? res.error,
    cardcomTranId: res.transactionId,
    succeeded: res.ok || !!res.duplicate,
  }).onConflictDoNothing();

  if (res.ok || res.duplicate) {
    await db.update(s.billingInvoices).set({
      status: 'PAID',
      paidAt: now,
      cardcomTranId: res.transactionId,
      cardcomDocNumber: res.docNumber,
      cardcomDocUrl: res.docUrl,
    }).where(eq(s.billingInvoices.id, invoiceId));

    await advancePeriod(sub, periodStart, periodEnd, coupon);
    await logEvent(sub.orgId, sub.id, 'invoice.paid',
      { invoiceId, amount: draft.totalIncVat, tranId: res.transactionId, duplicate: res.duplicate }, 'system:cron');

    report.charged++;
    report.chargedTotalIncVat = round2(report.chargedTotalIncVat + draft.totalIncVat);
    return;
  }

  await markFailed(sub, invoiceId, now, report, declineMessageHe(res.responseCode, res.error));
}

/* ═══════════ מעברי מצב ═══════════ */

async function advancePeriod(sub: Sub, periodStart: Date, periodEnd: Date, coupon: CouponLike | null) {
  let cyclesLeft = sub.couponCyclesLeft;
  let couponId: string | null = sub.couponId;

  if (coupon) {
    if (coupon.duration === 'REPEATING' && cyclesLeft !== null) {
      cyclesLeft = Math.max(0, cyclesLeft - 1);
      if (cyclesLeft === 0) couponId = null;    // מוצה — לא נגרר למחזור הבא
    } else if (coupon.duration === 'ONCE') {
      couponId = null;
      cyclesLeft = null;
    }
  }

  await db.update(s.orgSubscriptions).set({
    status: sub.cancelAtPeriodEnd ? 'CANCELING' : 'ACTIVE',
    currentPeriodStart: periodStart,
    currentPeriodEnd: periodEnd,
    dunningAttempt: 0,
    nextRetryAt: null,
    couponId,
    couponCyclesLeft: cyclesLeft,
    updatedAt: new Date(),
  }).where(eq(s.orgSubscriptions.id, sub.id));

  invalidateEntitlements(sub.orgId);
}

async function markFailed(sub: Sub, invoiceId: string, now: Date, report: CycleReport, reason: string) {
  const attempt = sub.dunningAttempt + 1;

  await db.update(s.billingInvoices).set({ status: 'FAILED' }).where(eq(s.billingInvoices.id, invoiceId));

  if (attempt >= SUSPEND_AFTER_ATTEMPT) {
    await db.update(s.orgSubscriptions).set({
      status: 'SUSPENDED', dunningAttempt: attempt, nextRetryAt: null, updatedAt: now,
    }).where(eq(s.orgSubscriptions.id, sub.id));
    await notifyOrg(sub.orgId, 'החשבון הושהה', `לא הצלחנו לגבות את התשלום. ${reason}. הגישה תיפתח מיד עם עדכון אמצעי התשלום.`);
    await logEvent(sub.orgId, sub.id, 'subscription.suspended', { invoiceId, reason, attempt }, 'system:cron');
    report.suspended++;
    invalidateEntitlements(sub.orgId);
    return;
  }

  const nextDays = DUNNING_SCHEDULE_DAYS[attempt] ?? 3;
  const nextRetryAt = new Date(sub.currentPeriodEnd.getTime() + nextDays * 86_400_000);

  await db.update(s.orgSubscriptions).set({
    status: 'PAST_DUE', dunningAttempt: attempt, nextRetryAt, updatedAt: now,
  }).where(eq(s.orgSubscriptions.id, sub.id));

  // הנוסח לא מנוסח כאיום. רוב הכשלים הם כרטיס שהתחדש, לא לקוח שברח.
  if (attempt >= 2) {
    await notifyOrg(sub.orgId, 'החיוב לא עבר',
      `${reason}. כנראה שהכרטיס התחדש — עדכון לוקח 30 שניות. ננסה שוב ב-${nextRetryAt.toLocaleDateString('he-IL')}.`);
  }

  await logEvent(sub.orgId, sub.id, 'charge.failed', { invoiceId, reason, attempt, nextRetryAt }, 'system:cron');
  report.failed++;
}

async function downgradeToFree(sub: Sub, reason: string) {
  const now = new Date();
  await db.update(s.orgSubscriptions).set({
    planId: FREE_PLAN_ID,
    status: 'FREE',
    interval: 'MONTHLY',
    cancelAtPeriodEnd: false,
    canceledAt: now,
    cancelReason: sub.cancelReason ?? reason,
    couponId: null,
    couponCyclesLeft: null,
    dunningAttempt: 0,
    nextRetryAt: null,
    currentPeriodStart: now,
    currentPeriodEnd: addInterval(now, 'MONTHLY', sub.billingAnchorDay),
    updatedAt: now,
  }).where(eq(s.orgSubscriptions.id, sub.id));

  // ⚠️ לא מוחקים נתונים. לקוח שמגלה שאיבד 800 לידים לא חוזר.
  await db.delete(s.subscriptionItems).where(eq(s.subscriptionItems.subscriptionId, sub.id));
  await logEvent(sub.orgId, sub.id, 'subscription.downgraded', { reason }, 'system:cron');
  invalidateEntitlements(sub.orgId);
}

/** Trial שהסתיים ללא כרטיס → חבילת חינם. לא חוסמים. */
async function expireTrials(now: Date, report: CycleReport) {
  const expired = await db.select().from(s.orgSubscriptions).where(and(
    eq(s.orgSubscriptions.status, 'TRIALING'),
    isNotNull(s.orgSubscriptions.trialEndsAt),
    lte(s.orgSubscriptions.trialEndsAt, now),
  ));

  for (const sub of expired) {
    const pm = await defaultPaymentMethod(sub.orgId);
    if (pm) {
      // יש כרטיס — הופכים למנוי פעיל ומחייבים במחזור הזה
      await db.update(s.orgSubscriptions).set({
        status: 'ACTIVE',
        currentPeriodStart: now,
        currentPeriodEnd: now,          // ייגבה מיד בלולאה הראשית
        updatedAt: now,
      }).where(eq(s.orgSubscriptions.id, sub.id));
      await logEvent(sub.orgId, sub.id, 'trial.converted', {}, 'system:cron');
    } else {
      await downgradeToFree(sub, 'trial_expired');
      await notifyOrg(sub.orgId, 'תקופת הניסיון הסתיימה',
        'עברת לחבילת החינם. כל הנתונים שלך נשמרו — שדרוג מחזיר את כל היכולות.');
      report.downgraded++;
    }
  }
}

/** מנוי מושהה מעל 30 יום → סגירה */
async function closeAbandoned(now: Date, report: CycleReport) {
  const cutoff = new Date(now.getTime() - CLOSE_AFTER_SUSPENDED_DAYS * 86_400_000);
  const rows = await db.select().from(s.orgSubscriptions).where(and(
    eq(s.orgSubscriptions.status, 'SUSPENDED'),
    lte(s.orgSubscriptions.updatedAt, cutoff),
  ));
  for (const sub of rows) {
    await db.update(s.orgSubscriptions)
      .set({ status: 'CLOSED', updatedAt: now })
      .where(eq(s.orgSubscriptions.id, sub.id));
    await logEvent(sub.orgId, sub.id, 'subscription.closed', { after_days: CLOSE_AFTER_SUSPENDED_DAYS }, 'system:cron');
    report.closed++;
    invalidateEntitlements(sub.orgId);
  }
}

/**
 * כרטיס שפג תוקף הוא הסיבה מספר 1 לכשל חיוב.
 * התראה מוקדמת חוסכת כ-40% מהכשלים — זה זול בהרבה מ-dunning.
 */
async function flagExpiringCards(now: Date) {
  const pms = await db.select().from(s.billingPaymentMethods)
    .where(eq(s.billingPaymentMethods.status, 'VALID'));

  for (const pm of pms) {
    if (!pm.expMonth || !pm.expYear) continue;
    const exp = new Date(Date.UTC(pm.expYear, pm.expMonth, 0, 23, 59));
    const days = Math.ceil((exp.getTime() - now.getTime()) / 86_400_000);
    if (days < 0) {
      await db.update(s.billingPaymentMethods).set({ status: 'INVALID' })
        .where(eq(s.billingPaymentMethods.id, pm.id));
      await notifyOrg(pm.orgId, 'הכרטיס פג תוקף', 'עדכון אמצעי התשלום ימנע הפסקת שירות.');
    } else if (days <= CARD_EXPIRY_WARN_DAYS[0]) {
      await db.update(s.billingPaymentMethods).set({ status: 'EXPIRING' })
        .where(eq(s.billingPaymentMethods.id, pm.id));
      if (days <= CARD_EXPIRY_WARN_DAYS[1]) {
        await notifyOrg(pm.orgId, 'הכרטיס עומד לפוג',
          `הכרטיס המסתיים ב-${pm.last4} פג בעוד ${days} ימים.`);
      }
    }
  }
}

/* ═══════════ עזרים ═══════════ */

async function loadCoupon(couponId: string | null): Promise<CouponLike | null> {
  if (!couponId) return null;
  const [c] = await db.select().from(s.coupons).where(eq(s.coupons.id, couponId)).limit(1);
  if (!c) return null;
  return {
    id: c.id, code: c.code, type: c.type, value: Number(c.value),
    duration: c.duration, durationCycles: c.durationCycles,
    validFrom: c.validFrom, validUntil: c.validUntil,
    maxRedemptions: c.maxRedemptions, redemptionCount: c.redemptionCount,
    appliesToPlans: c.appliesToPlans ?? null, appliesToInterval: c.appliesToInterval ?? null,
    firstTimeOnly: c.firstTimeOnly, minAmountExVat: c.minAmountExVat ? Number(c.minAmountExVat) : null,
    isActive: c.isActive,
  };
}

export async function defaultPaymentMethod(orgId: string) {
  const [pm] = await db.select().from(s.billingPaymentMethods).where(and(
    eq(s.billingPaymentMethods.orgId, orgId),
    eq(s.billingPaymentMethods.isDefault, true),
  )).limit(1);
  return pm ?? null;
}

async function orgBillingProfile(orgId: string) {
  const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, orgId)).limit(1);
  return org;
}

export async function logEvent(
  orgId: string | null, subscriptionId: string | null,
  type: string, payload: Record<string, unknown>, actor: string,
) {
  await db.insert(s.billingEvents).values({ orgId, subscriptionId, type, payload, actor });
}

async function notifyOrg(orgId: string, title: string, body: string) {
  const owners = await db.select().from(s.memberships).where(and(
    eq(s.memberships.orgId, orgId),
    inArray(s.memberships.role, ['OWNER', 'ADMIN']),
  ));
  if (!owners.length) return;
  await db.insert(s.notifications).values(owners.map((o) => ({
    orgId, userId: o.userId, channel: 'IN_APP' as const,
    title, body, url: '/settings/billing',
  })));
}

export { createCheckoutLink, getLpResult, platformCardcom, vatRateAt };
