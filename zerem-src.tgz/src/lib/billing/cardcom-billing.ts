/**
 * שכבת קארדקום לגבייה החוזרת.
 *
 * שונה מ-`integrations/cardcom.ts` בשתי נקודות מהותיות:
 *  1. כאן **אנחנו** המוכר (זרם גובה מהלקוחות שלו), לא הלקוח שלנו.
 *     לכן ההגדרות מגיעות ממשתני סביבה של הפלטפורמה, לא מטבלת integrations.
 *  2. כאן קארדקום **כן** מפיק את חשבונית המס — זו הייתה החלטה מפורשת.
 *     במסלול של הלקוח, ריווחית היא המנפיק ולכן אין שם Document.
 *     ערבוב בין השניים = כפל הנפקה, וזו בעיית מס.
 */

const BASE = 'https://secure.cardcom.solutions/api/v11';

export interface PlatformCardcomConfig {
  terminalNumber: number;
  apiName: string;
  apiPassword?: string;
  /** האם המסוף תומך באימות כרטיס ללא חיוב (JValidateType 5) */
  supportsZeroAuth: boolean;
  /** אם לא — נחייב סכום סמלי ונבטל מיד */
  fallbackAuthAmount: number;
}

export function platformCardcom(): PlatformCardcomConfig {
  return {
    terminalNumber: Number(process.env.PLATFORM_CARDCOM_TERMINAL ?? 1000),
    apiName: process.env.PLATFORM_CARDCOM_API_NAME ?? 'Cardcomtest26',
    apiPassword: process.env.PLATFORM_CARDCOM_API_PASSWORD,
    supportsZeroAuth: process.env.PLATFORM_CARDCOM_ZERO_AUTH !== 'false',
    fallbackAuthAmount: Number(process.env.PLATFORM_CARDCOM_AUTH_AMOUNT ?? 1),
  };
}

export interface DocProduct {
  Description: string;
  Quantity: number;
  UnitCost: number;   // כולל מע״מ — קארדקום מחלץ לפי הגדרת המסוף
}

export interface DocInput {
  name: string;
  email?: string;
  phone?: string;
  taxId?: string;
  products: DocProduct[];
  /** ברירת מחדל: כן. חשבונית שלא נשלחת ללקוח מייצרת פניות לתמיכה. */
  sendByEmail?: boolean;
}

interface CardcomEnvelope {
  ResponseCode: number;
  Description?: string;
}

async function call<T extends CardcomEnvelope>(
  cfg: PlatformCardcomConfig, path: string, body: Record<string, unknown>,
): Promise<T | { __error: string }> {
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        TerminalNumber: cfg.terminalNumber,
        ApiName: cfg.apiName,
        ...(cfg.apiPassword ? { ApiPassword: cfg.apiPassword } : {}),
        ...body,
      }),
      signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok) return { __error: `HTTP ${res.status}: ${(await res.text()).slice(0, 300)}` };
    return (await res.json()) as T;
  } catch (e) {
    return { __error: String(e) };
  }
}

function buildDocument(d: DocInput) {
  return {
    Name: d.name,
    Email: d.email,
    Phone: d.phone,
    TaxId: d.taxId,
    IsSendByEmail: d.sendByEmail ?? true,
    Products: d.products.map((p) => ({
      Description: p.Description,
      Quantity: p.Quantity,
      UnitCost: p.UnitCost,
    })),
  };
}

/* ═══════════ 1. הרשמה — דף תשלום מתארח ═══════════ */

export interface CheckoutLinkInput {
  cfg: PlatformCardcomConfig;
  /** סכום כולל מע״מ. 0 = אימות כרטיס בלבד (קופון שמאפס). */
  amountIncVat: number;
  returnValue: string;              // "sub_<subscriptionId>"
  productName: string;
  successUrl: string;
  failedUrl: string;
  webhookUrl: string;
  customer: { name: string; email?: string; phone?: string };
  document?: DocInput;
}

export interface CheckoutLinkResult {
  ok: boolean;
  lowProfileId?: string;
  url?: string;
  /** true = לא נגבה כסף, רק נשמר טוקן */
  zeroAuth?: boolean;
  error?: string;
}

export async function createCheckoutLink(i: CheckoutLinkInput): Promise<CheckoutLinkResult> {
  const zeroAuth = i.amountIncVat <= 0;
  const amount = zeroAuth
    ? (i.cfg.supportsZeroAuth ? 0 : i.cfg.fallbackAuthAmount)
    : i.amountIncVat;

  const body: Record<string, unknown> = {
    ReturnValue: i.returnValue,
    Amount: amount,
    Operation: zeroAuth ? 'CreateTokenOnly' : 'ChargeAndCreateToken',
    SuccessRedirectUrl: i.successUrl,
    FailedRedirectUrl: i.failedUrl,
    WebHookUrl: i.webhookUrl,
    ISOCoinId: 1,
    Language: 'he',
    ProductName: i.productName,
    MaxNumOfPayments: 1,
    UIDefinition: {
      CardOwnerNameValue: i.customer.name,
      CardOwnerEmailValue: i.customer.email,
      CardOwnerPhoneValue: i.customer.phone,
      IsHideCardOwnerName: false,
    },
  };

  // אימות ללא חיוב — רק אם המסוף תומך
  if (zeroAuth && i.cfg.supportsZeroAuth) body.JValidateType = 5;

  // ⚠️ Document רק כשיש עסקה אמיתית. חשבונית על ₪0 אינה מסמך מס.
  if (!zeroAuth && i.document) body.Document = buildDocument(i.document);

  const r = await call<CardcomEnvelope & { LowProfileId?: string; Url?: string }>(
    i.cfg, '/LowProfile/Create', body,
  );
  if ('__error' in r) return { ok: false, error: r.__error };
  if (r.ResponseCode !== 0) return { ok: false, error: `${r.ResponseCode}: ${r.Description}` };
  return { ok: true, lowProfileId: r.LowProfileId, url: r.Url, zeroAuth };
}

/* ═══════════ 2. האמת היחידה ═══════════ */

export interface LpResult {
  ok: boolean;
  responseCode: number;
  description?: string;
  returnValue?: string;
  token?: string;
  tokenExpiryMMYY?: string;
  expMonth?: number;
  expYear?: number;
  last4?: string;
  brand?: string;
  holderName?: string;
  transactionId?: string;
  approvalNumber?: string;
  amount?: number;
  docNumber?: string;
  docUrl?: string;
  error?: string;
}

/**
 * ל-Cardcom אין חתימת HMAC על ה-Webhook — כל מי שמכיר את ה-URL
 * יכול לשלוח "שולם". לכן ה-Webhook הוא פינג בלבד, והפונקציה הזו
 * היא הדבר היחיד שמותר לו להזיז כסף במערכת.
 */
export async function getLpResult(cfg: PlatformCardcomConfig, lowProfileId: string): Promise<LpResult> {
  const r = await call<CardcomEnvelope & {
    ReturnValue?: string;
    TokenInfo?: { Token?: string; CardMonth?: number; CardYear?: number; CardOwnerName?: string };
    TranzactionInfo?: {
      TranzactionId?: number; ApprovalNumber?: string; Last4CardDigits?: number;
      Brand?: string; Amount?: number; CardOwnerName?: string;
      CardMonth?: number; CardYear?: number;
    };
    DocumentInfo?: { DocumentNumber?: number; DocumentUrl?: string };
  }>(cfg, '/LowProfile/GetLpResult', { LowProfileId: lowProfileId });

  if ('__error' in r) return { ok: false, responseCode: -1, error: r.__error };

  const t = r.TranzactionInfo;
  const tok = r.TokenInfo;
  const month = tok?.CardMonth ?? t?.CardMonth;
  const year = tok?.CardYear ?? t?.CardYear;

  return {
    ok: r.ResponseCode === 0,
    responseCode: r.ResponseCode,
    description: r.Description,
    returnValue: r.ReturnValue,
    token: tok?.Token,
    tokenExpiryMMYY: month && year
      ? `${String(month).padStart(2, '0')}${String(year).slice(-2)}`
      : undefined,
    expMonth: month,
    expYear: year ? (year < 100 ? 2000 + year : year) : undefined,
    last4: t?.Last4CardDigits != null ? String(t.Last4CardDigits).padStart(4, '0') : undefined,
    brand: t?.Brand,
    holderName: tok?.CardOwnerName ?? t?.CardOwnerName,
    transactionId: t?.TranzactionId ? String(t.TranzactionId) : undefined,
    approvalNumber: t?.ApprovalNumber,
    amount: t?.Amount,
    docNumber: r.DocumentInfo?.DocumentNumber ? String(r.DocumentInfo.DocumentNumber) : undefined,
    docUrl: r.DocumentInfo?.DocumentUrl,
    error: r.ResponseCode === 0 ? undefined : `${r.ResponseCode}: ${r.Description}`,
  };
}

/* ═══════════ 3. חיוב חוזר בטוקן ═══════════ */

export interface TokenChargeInput {
  cfg: PlatformCardcomConfig;
  token: string;
  expiryMMYY: string;
  amountIncVat: number;
  /** ExternalUniqTranId — דטרמיניסטי לפי (מנוי, תקופה). זה מה שמונע חיוב כפול. */
  idempotencyKey: string;
  document?: DocInput;
}

export interface TokenChargeResult {
  ok: boolean;
  responseCode: number;
  description?: string;
  transactionId?: string;
  approvalNumber?: string;
  docNumber?: string;
  docUrl?: string;
  /** true = קארדקום זיהה שהמפתח כבר שימש; העסקה הקיימת מוחזרת */
  duplicate?: boolean;
  error?: string;
}

export async function chargeToken(i: TokenChargeInput): Promise<TokenChargeResult> {
  const body: Record<string, unknown> = {
    Amount: i.amountIncVat,
    Token: i.token,
    CardExpirationMMYY: i.expiryMMYY,
    ExternalUniqTranId: i.idempotencyKey,
    ISOCoinId: 1,
    NumOfPayments: 1,
  };
  if (i.document) body.Document = buildDocument(i.document);

  const r = await call<CardcomEnvelope & {
    TranzactionId?: number; ApprovalNumber?: string;
    DocumentInfo?: { DocumentNumber?: number; DocumentUrl?: string };
  }>(i.cfg, '/Transactions/Transaction', body);

  if ('__error' in r) return { ok: false, responseCode: -1, error: r.__error };

  return {
    ok: r.ResponseCode === 0,
    responseCode: r.ResponseCode,
    description: r.Description,
    transactionId: r.TranzactionId ? String(r.TranzactionId) : undefined,
    approvalNumber: r.ApprovalNumber,
    docNumber: r.DocumentInfo?.DocumentNumber ? String(r.DocumentInfo.DocumentNumber) : undefined,
    docUrl: r.DocumentInfo?.DocumentUrl,
    duplicate: DUPLICATE_CODES.has(r.ResponseCode),
    error: r.ResponseCode === 0 ? undefined : `${r.ResponseCode}: ${r.Description}`,
  };
}

/** קודי תשובה שמשמעותם "המפתח הזה כבר שימש" — לא כישלון אמיתי */
const DUPLICATE_CODES = new Set([601, 682]);

/* ═══════════ 4. זיכוי ═══════════ */

export async function refund(
  cfg: PlatformCardcomConfig, transactionId: string, amountIncVat?: number,
): Promise<{ ok: boolean; error?: string; refundTranId?: string }> {
  const r = await call<CardcomEnvelope & { NewTranzactionId?: number }>(
    cfg, '/Transactions/RefundByTransactionId',
    { TranzactionId: Number(transactionId), ...(amountIncVat ? { PartialSum: amountIncVat } : {}) },
  );
  if ('__error' in r) return { ok: false, error: r.__error };
  return {
    ok: r.ResponseCode === 0,
    error: r.ResponseCode === 0 ? undefined : `${r.ResponseCode}: ${r.Description}`,
    refundTranId: r.NewTranzactionId ? String(r.NewTranzactionId) : undefined,
  };
}

/* ═══════════ קודי שגיאה נפוצים ═══════════
 * מיפוי לעברית — הודעת dunning טובה מסבירה ללקוח מה לעשות.
 * "שגיאה 33" לא גורם לאף אחד לעדכן כרטיס.
 */
export const DECLINE_REASONS: Record<number, string> = {
  1: 'הכרטיס נדחה על ידי חברת האשראי',
  2: 'הכרטיס חסום',
  3: 'הכרטיס גנוב או מוגבל',
  4: 'סירוב — יש ליצור קשר עם חברת האשראי',
  5: 'הכרטיס אינו תקף',
  6: 'פרטי הכרטיס שגויים',
  33: 'הכרטיס פג תוקף',
  36: 'הכרטיס מוגבל',
  39: 'חריגה ממסגרת האשראי',
};

export function declineMessageHe(code: number | null | undefined, fallback?: string): string {
  if (code != null && DECLINE_REASONS[code]) return DECLINE_REASONS[code];
  return fallback ?? 'החיוב לא עבר';
}

export const PLATFORM_CARDCOM_NOTES = [
  'ל-Cardcom אין חתימת HMAC על ה-Webhook — הגוף אינו מהימן. תמיד GetLpResult.',
  'ExternalUniqTranId חייב להיות דטרמיניסטי לפי (מנוי, תקופה), לא לפי זמן ריצה.',
  'Document נשלח רק כשיש עסקה בפועל. חשבונית על ₪0 אינה מסמך מס.',
  'סביבת בדיקות: terminal 1000, ApiName Cardcomtest26. סכום מעל 5,000 ₪ מדמה כישלון.',
] as const;
