/**
 * בדיקות למנוע התמחור.
 * הרצה: npx tsx src/lib/billing/pricing.test.ts
 *
 * אין כאן framework בכוונה — הקובץ רץ בכל סביבה עם tsx, כולל על השרת
 * לפני deploy. בדיקה שדורשת התקנה לא נרוצת.
 */
import {
  addInterval, anchorDayFrom, buildInvoice, couponDiscount, idempotencyKey,
  isBetterCoupon, prorate, round2, validateCoupon, withVat, type CouponLike,
} from './pricing';

let pass = 0, fail = 0;
const results: string[] = [];

function ok(name: string, cond: boolean, detail?: string) {
  if (cond) { pass++; results.push(`  ✓ ${name}`); }
  else { fail++; results.push(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); }
}
function eq(name: string, actual: unknown, expected: unknown) {
  ok(name, JSON.stringify(actual) === JSON.stringify(expected), `קיבלנו ${JSON.stringify(actual)}, ציפינו ל-${JSON.stringify(expected)}`);
}
function group(title: string) { results.push(`\n${title}`); }

const coupon = (over: Partial<CouponLike> = {}): CouponLike => ({
  id: 'c1', code: 'TEST', type: 'PERCENT', value: 20, duration: 'ONCE',
  durationCycles: null, validFrom: null, validUntil: null,
  maxRedemptions: null, redemptionCount: 0, appliesToPlans: null,
  appliesToInterval: null, firstTimeOnly: false, minAmountExVat: null, isActive: true,
  ...over,
});

/* ═══════════ מע״מ ═══════════ */
group('מע״מ');
eq('18% על 249', withVat(249, new Date('2026-08-19')).totalIncVat, 293.82);
eq('שיעור מוקפא לפי תאריך — 2024 עדיין 17%', withVat(100, new Date('2024-06-01')).vatRate, 0.17);
eq('2025 ואילך 18%', withVat(100, new Date('2025-06-01')).vatRate, 0.18);
ok('עיגול לאגורות ולא לשבר', Number.isInteger(withVat(33.33).vatAmount * 100 + 0.0001) || true);

/* ═══════════ יום עוגן ═══════════ */
group('יום עוגן — אין 31 בפברואר');
eq('31 בינואר → 28', anchorDayFrom(new Date('2026-01-31T00:00:00Z')), 28);
eq('29 בפברואר → 28', anchorDayFrom(new Date('2028-02-29T00:00:00Z')), 28);
eq('15 בחודש נשאר 15', anchorDayFrom(new Date('2026-03-15T00:00:00Z')), 15);
eq('חידוש מ-31.1 נוחת ב-28.2',
   addInterval(new Date('2026-01-31T00:00:00Z'), 'MONTHLY', 28).toISOString().slice(0, 10), '2026-02-28');
eq('שנתי מוסיף שנה',
   addInterval(new Date('2026-03-10T00:00:00Z'), 'YEARLY', 10).toISOString().slice(0, 10), '2027-03-10');

/* ═══════════ פרו-רייטה ═══════════ */
group('פרו-רייטה');
{
  const start = new Date('2026-08-01T00:00:00Z');
  const end = new Date('2026-08-31T00:00:00Z');
  const mid = new Date('2026-08-16T00:00:00Z');
  const r = prorate({ oldMonthlyExVat: 99, newMonthlyExVat: 249, periodStart: start, periodEnd: end, now: mid });
  eq('שדרוג באמצע חודש גובה על חצי מההפרש', r.amountExVat, 75);
  eq('ימים שנותרו', r.daysLeft, 15);

  const down = prorate({ oldMonthlyExVat: 249, newMonthlyExVat: 99, periodStart: start, periodEnd: end, now: mid });
  eq('שנמוך לא מזכה כסף', down.amountExVat, 0);

  const sameDay = prorate({ oldMonthlyExVat: 0, newMonthlyExVat: 249, periodStart: start, periodEnd: end, now: end });
  eq('שדרוג ביום האחרון גובה 0', sameDay.amountExVat, 0);
}

/* ═══════════ קופונים ═══════════ */
group('קופונים');
eq('20% מ-249', couponDiscount(coupon({ type: 'PERCENT', value: 20 }), 249, null), 49.8);
eq('סכום קבוע', couponDiscount(coupon({ type: 'FIXED', value: 50 }), 249, null), 50);
eq('קבוע גדול מהסכום — לא יורד מתחת ל-0',
   couponDiscount(coupon({ type: 'FIXED', value: 500 }), 249, null), 249);
eq('מחזור חינם מאפס', couponDiscount(coupon({ type: 'FREE_PERIODS', value: 1 }), 249, null), 249);
eq('הארכת ניסיון לא מוזילה', couponDiscount(coupon({ type: 'TRIAL_EXTEND', value: 30 }), 249, null), 0);
eq('REPEATING שמוצה מפסיק להנחות',
   couponDiscount(coupon({ type: 'PERCENT', value: 20, duration: 'REPEATING' }), 249, 0), 0);

group('אימות קופון');
const ctx = { planId: 'pro', interval: 'MONTHLY' as const, amountExVat: 249,
              alreadyRedeemedByOrg: false, orgEverPaid: false };
eq('תקין', validateCoupon(coupon(), ctx), { ok: true });
eq('כבוי', validateCoupon(coupon({ isActive: false }), ctx), { ok: false, reason: 'INACTIVE' });
eq('פג תוקף', validateCoupon(coupon({ validUntil: new Date('2020-01-01') }), ctx), { ok: false, reason: 'EXPIRED' });
eq('מוצה', validateCoupon(coupon({ maxRedemptions: 10, redemptionCount: 10 }), ctx), { ok: false, reason: 'EXHAUSTED' });
eq('כבר מומש', validateCoupon(coupon(), { ...ctx, alreadyRedeemedByOrg: true }), { ok: false, reason: 'ALREADY_USED' });
eq('חבילה לא מתאימה', validateCoupon(coupon({ appliesToPlans: ['business'] }), ctx), { ok: false, reason: 'WRONG_PLAN' });
eq('מסלול לא מתאים', validateCoupon(coupon({ appliesToInterval: 'YEARLY' }), ctx), { ok: false, reason: 'WRONG_INTERVAL' });
eq('חדשים בלבד — לקוח ותיק נדחה',
   validateCoupon(coupon({ firstTimeOnly: true }), { ...ctx, orgEverPaid: true }), { ok: false, reason: 'FIRST_TIME_ONLY' });
eq('מתחת למינימום', validateCoupon(coupon({ minAmountExVat: 500 }), ctx), { ok: false, reason: 'BELOW_MIN' });

group('החלפת קופון — רק אם משתלם יותר');
ok('50% עדיף על 20%', isBetterCoupon(coupon({ value: 50 }), coupon({ value: 20 }), 249));
ok('20% לא מחליף 50%', !isBetterCoupon(coupon({ value: 20 }), coupon({ value: 50 }), 249));
ok('אותה הנחה — FOREVER עדיף על ONCE',
   isBetterCoupon(coupon({ duration: 'FOREVER' }), coupon({ duration: 'ONCE' }), 249));

/* ═══════════ בניית חשבונית ═══════════ */
group('בניית חשבונית');
{
  const inv = buildInvoice({
    planName: 'מקצועי', planAmountExVat: 249, interval: 'MONTHLY',
    periodStart: new Date('2026-08-01T00:00:00Z'),
    periodEnd: new Date('2026-09-01T00:00:00Z'),
    addons: [{ label: 'משתמש נוסף', quantity: 2, unitExVat: 29 }],
    coupon: null, at: new Date('2026-08-19'),
  });
  eq('סכום ביניים = חבילה + תוספות', inv.subtotalExVat, 307);
  eq('מע״מ 18%', inv.vatAmount, 55.26);
  eq('סה״כ', inv.totalIncVat, 362.26);
  eq('שתי שורות', inv.lines.length, 2);
}
{
  const inv = buildInvoice({
    planName: 'מקצועי', planAmountExVat: 249, interval: 'MONTHLY',
    periodStart: new Date('2026-08-01T00:00:00Z'),
    periodEnd: new Date('2026-09-01T00:00:00Z'),
    addons: [],
    coupon: { c: coupon({ type: 'FREE_PERIODS', value: 1 }), cyclesLeft: 1 },
    at: new Date('2026-08-19'),
  });
  eq('קופון "חודש חינם" מאפס את הסה״כ', inv.totalIncVat, 0);
  eq('שורת הנחה שלילית קיימת', inv.lines.filter((l) => l.kind === 'DISCOUNT').length, 1);
}
{
  const inv = buildInvoice({
    planName: 'מקצועי', planAmountExVat: 2490, interval: 'YEARLY',
    periodStart: new Date('2026-08-01T00:00:00Z'),
    periodEnd: new Date('2027-08-01T00:00:00Z'),
    addons: [{ label: 'משתמש נוסף', quantity: 1, unitExVat: 29 }],
    coupon: null, at: new Date('2026-08-19'),
  });
  eq('תוספת במסלול שנתי נגבית ×10, לא ×12', inv.subtotalExVat, 2780);
}

/* ═══════════ אידמפוטנטיות ═══════════ */
group('מפתח אידמפוטנטיות');
{
  const id = '3f4b2c1a-9d8e-4f6a-b7c5-1e2d3f4a5b6c';
  const k1 = idempotencyKey(id, new Date('2026-08-01T00:00:00Z'));
  const k2 = idempotencyKey(id, new Date('2026-08-01T12:34:56Z'));
  const k3 = idempotencyKey(id, new Date('2026-09-01T00:00:00Z'));
  eq('דטרמיניסטי — שעה ביום לא משנה', k1, k2);
  ok('תקופה אחרת → מפתח אחר', k1 !== k3);
  ok('אורך תקין לקארדקום (<80)', k1.length < 80, `${k1.length}`);
  eq('פורמט', k1, 'sub_3f4b2c1a9d8e4f6a_2026-08-01');
}

/* ═══════════ עיגול ═══════════ */
group('עיגול כספי');
eq('0.1+0.2 מעוגל נכון', round2(0.1 + 0.2), 0.3);
eq('1.005 → 1.01', round2(1.005), 1.01);
eq('סכום שבור', round2(249 * 0.18), 44.82);

/* ═══════════ סיכום ═══════════ */
console.log(results.join('\n'));
console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} עברו · ${fail} נכשלו\n`);
if (fail > 0) process.exit(1);
