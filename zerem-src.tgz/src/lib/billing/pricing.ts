/**
 * מנוע התמחור — חישוב טהור, ללא גישה ל-DB.
 * כל פונקציה כאן ניתנת לבדיקה עם קלט קבוע. זה בכוונה:
 * לוגיקת כסף שדורשת מסד נתונים כדי להיבדק, לא נבדקת.
 */
import { vatRateAt } from '../israel';

export type Interval = 'MONTHLY' | 'YEARLY';
export type CouponType = 'PERCENT' | 'FIXED' | 'FREE_PERIODS' | 'TRIAL_EXTEND';
export type CouponDuration = 'ONCE' | 'REPEATING' | 'FOREVER';

export interface CouponLike {
  id: string;
  code: string;
  type: CouponType;
  value: number;
  duration: CouponDuration;
  durationCycles: number | null;
  validFrom: Date | null;
  validUntil: Date | null;
  maxRedemptions: number | null;
  redemptionCount: number;
  appliesToPlans: string[] | null;
  appliesToInterval: Interval | null;
  firstTimeOnly: boolean;
  minAmountExVat: number | null;
  isActive: boolean;
}

export interface LineDraft {
  description: string;
  quantity: number;
  unitExVat: number;
  amountExVat: number;
  kind: 'PLAN' | 'ADDON' | 'PRORATION' | 'DISCOUNT' | 'CREDIT';
}

export interface InvoiceDraft {
  lines: LineDraft[];
  subtotalExVat: number;
  discountExVat: number;
  netExVat: number;
  vatRate: number;
  vatAmount: number;
  totalIncVat: number;
}

/** עיגול לאגורות. float מצטבר סוטה — כל חישוב ביניים עובר כאן. */
export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/* ═══════════ מע״מ ═══════════ */

export function withVat(amountExVat: number, at: Date = new Date()) {
  const vatRate = vatRateAt(at);
  const vatAmount = round2(amountExVat * vatRate);
  return { vatRate, vatAmount, totalIncVat: round2(amountExVat + vatAmount) };
}

/* ═══════════ תקופות חיוב ═══════════ */

/**
 * יום העוגן מוגבל ל-1–28 בכוונה.
 * מנוי שנפתח ב-31 בינואר לא יכול להתחדש ב-31 בפברואר; לוגיקת
 * "היום האחרון בחודש" נשברת בשנה מעוברת ומייצרת חיובים כפולים.
 * מי שנרשם ב-29–31 מקבל 28, וזה לא מפריע לאף אחד.
 */
export function anchorDayFrom(date: Date): number {
  return Math.min(date.getUTCDate(), 28);
}

export function addInterval(from: Date, interval: Interval, anchorDay: number): Date {
  const d = new Date(from);
  // ⚠️ סדר הפעולות קריטי: קודם מאפסים ל-1 בחודש.
  // בלי זה, setUTCMonth על 31 בינואר גולש ל-3 במרץ (כי אין 31 בפברואר),
  // ואז setUTCDate(28) נוחת על 28 במרץ — חודש שלם קדימה, וחיוב שנעלם.
  d.setUTCDate(1);
  if (interval === 'YEARLY') d.setUTCFullYear(d.getUTCFullYear() + 1);
  else d.setUTCMonth(d.getUTCMonth() + 1);
  d.setUTCDate(Math.min(anchorDay, 28));
  return d;
}

export const DAY_MS = 86_400_000;

export function daysBetween(a: Date, b: Date): number {
  return Math.max(0, Math.ceil((b.getTime() - a.getTime()) / DAY_MS));
}

/* ═══════════ פרו-רייטה ═══════════ */

export interface ProrationInput {
  oldMonthlyExVat: number;
  newMonthlyExVat: number;
  periodStart: Date;
  periodEnd: Date;
  now?: Date;
}

/**
 * חיוב יחסי על ההפרש, לימים שנותרו במחזור.
 * שנמוך מחזיר 0 ולא זיכוי — אחרת אפשר לשדרג ליום, להשתמש, ולשנמך.
 * זה מוצג ללקוח בבירור לפני האישור, לא מוסתר.
 */
export function prorate(i: ProrationInput): { amountExVat: number; daysLeft: number; daysInCycle: number } {
  const now = i.now ?? new Date();
  const daysInCycle = Math.max(1, daysBetween(i.periodStart, i.periodEnd));
  const daysLeft = Math.max(0, daysBetween(now, i.periodEnd));
  const delta = i.newMonthlyExVat - i.oldMonthlyExVat;
  if (delta <= 0) return { amountExVat: 0, daysLeft, daysInCycle };
  return { amountExVat: round2((delta * daysLeft) / daysInCycle), daysLeft, daysInCycle };
}

/* ═══════════ קופונים ═══════════ */

export type CouponRejection =
  | 'NOT_FOUND' | 'INACTIVE' | 'NOT_STARTED' | 'EXPIRED' | 'EXHAUSTED'
  | 'ALREADY_USED' | 'WRONG_PLAN' | 'WRONG_INTERVAL' | 'FIRST_TIME_ONLY' | 'BELOW_MIN';

export const COUPON_REJECTION_HE: Record<CouponRejection, string> = {
  NOT_FOUND:       'הקוד לא נמצא',
  INACTIVE:        'הקוד אינו פעיל',
  NOT_STARTED:     'הקוד עדיין לא נכנס לתוקף',
  EXPIRED:         'תוקף הקוד פג',
  EXHAUSTED:       'הקוד מוצה — נגמרו המימושים',
  ALREADY_USED:    'כבר מימשת את הקוד הזה',
  WRONG_PLAN:      'הקוד לא תקף לחבילה שנבחרה',
  WRONG_INTERVAL:  'הקוד תקף רק למסלול אחר (חודשי/שנתי)',
  FIRST_TIME_ONLY: 'הקוד מיועד ללקוחות חדשים בלבד',
  BELOW_MIN:       'סכום העסקה נמוך מהמינימום לקוד הזה',
};

export interface CouponContext {
  planId: string;
  interval: Interval;
  amountExVat: number;
  alreadyRedeemedByOrg: boolean;
  orgEverPaid: boolean;
  now?: Date;
}

export function validateCoupon(c: CouponLike | null, ctx: CouponContext):
  { ok: true } | { ok: false; reason: CouponRejection } {
  const now = ctx.now ?? new Date();
  if (!c) return { ok: false, reason: 'NOT_FOUND' };
  if (!c.isActive) return { ok: false, reason: 'INACTIVE' };
  if (c.validFrom && now < c.validFrom) return { ok: false, reason: 'NOT_STARTED' };
  if (c.validUntil && now > c.validUntil) return { ok: false, reason: 'EXPIRED' };
  if (c.maxRedemptions !== null && c.redemptionCount >= c.maxRedemptions)
    return { ok: false, reason: 'EXHAUSTED' };
  if (ctx.alreadyRedeemedByOrg) return { ok: false, reason: 'ALREADY_USED' };
  if (c.appliesToPlans?.length && !c.appliesToPlans.includes(ctx.planId))
    return { ok: false, reason: 'WRONG_PLAN' };
  if (c.appliesToInterval && c.appliesToInterval !== ctx.interval)
    return { ok: false, reason: 'WRONG_INTERVAL' };
  if (c.firstTimeOnly && ctx.orgEverPaid) return { ok: false, reason: 'FIRST_TIME_ONLY' };
  if (c.minAmountExVat !== null && ctx.amountExVat < c.minAmountExVat)
    return { ok: false, reason: 'BELOW_MIN' };
  return { ok: true };
}

/** כמה הקופון מוריד מסכום נתון. לעולם לא יורד מתחת ל-0. */
export function couponDiscount(c: CouponLike, amountExVat: number, cyclesLeft: number | null): number {
  if (c.type === 'TRIAL_EXTEND') return 0;
  if (c.duration === 'REPEATING' && cyclesLeft !== null && cyclesLeft <= 0) return 0;
  switch (c.type) {
    case 'PERCENT':      return round2(Math.min(amountExVat, (amountExVat * c.value) / 100));
    case 'FIXED':        return round2(Math.min(amountExVat, c.value));
    case 'FREE_PERIODS': return round2(amountExVat);   // מחזור חינם מלא
    default:             return 0;
  }
}

export function couponLabel(c: CouponLike): string {
  const dur =
    c.duration === 'FOREVER' ? ' · לתמיד'
    : c.duration === 'REPEATING' ? ` · ${c.durationCycles} מחזורים`
    : ' · פעם אחת';
  switch (c.type) {
    case 'PERCENT':      return `${c.value}% הנחה${dur}`;
    case 'FIXED':        return `₪${c.value} הנחה${dur}`;
    case 'FREE_PERIODS': return c.value === 1 ? 'מחזור אחד חינם' : `${c.value} מחזורים חינם`;
    case 'TRIAL_EXTEND': return `הארכת ניסיון ב-${c.value} ימים`;
  }
}

/**
 * קופון חדש מחליף קיים רק אם הוא משתלם יותר ללקוח.
 * אחרת מציגים "הקופון הקיים שלך שווה יותר" במקום להחליף בשקט להנחה קטנה.
 */
export function isBetterCoupon(candidate: CouponLike, current: CouponLike | null, amountExVat: number): boolean {
  if (!current) return true;
  const a = couponDiscount(candidate, amountExVat, candidate.durationCycles);
  const b = couponDiscount(current, amountExVat, current.durationCycles);
  if (a !== b) return a > b;
  const weight = (c: CouponLike) => (c.duration === 'FOREVER' ? 1e9 : c.duration === 'REPEATING' ? (c.durationCycles ?? 1) : 1);
  return weight(candidate) > weight(current);
}

/* ═══════════ בניית חשבונית ═══════════ */

export interface BuildInvoiceInput {
  planName: string;
  planAmountExVat: number;
  interval: Interval;
  periodStart: Date;
  periodEnd: Date;
  addons: Array<{ label: string; quantity: number; unitExVat: number }>;
  extraLines?: LineDraft[];
  coupon?: { c: CouponLike; cyclesLeft: number | null } | null;
  at?: Date;
}

const fmtDate = (d: Date) =>
  `${d.getUTCDate()}.${d.getUTCMonth() + 1}.${String(d.getUTCFullYear()).slice(-2)}`;

export function buildInvoice(i: BuildInvoiceInput): InvoiceDraft {
  const at = i.at ?? new Date();
  const period = `${fmtDate(i.periodStart)}–${fmtDate(i.periodEnd)}`;
  const lines: LineDraft[] = [];

  if (i.planAmountExVat > 0) {
    lines.push({
      description: `${i.planName} · ${i.interval === 'YEARLY' ? 'שנתי' : 'חודשי'} · ${period}`,
      quantity: 1,
      unitExVat: i.planAmountExVat,
      amountExVat: i.planAmountExVat,
      kind: 'PLAN',
    });
  }

  for (const a of i.addons) {
    const amount = round2(a.unitExVat * a.quantity * (i.interval === 'YEARLY' ? 10 : 1));
    lines.push({
      description: `${a.label} ×${a.quantity}`,
      quantity: a.quantity,
      unitExVat: a.unitExVat,
      amountExVat: amount,
      kind: 'ADDON',
    });
  }

  if (i.extraLines) lines.push(...i.extraLines);

  const subtotalExVat = round2(lines.reduce((s, l) => s + l.amountExVat, 0));

  let discountExVat = 0;
  if (i.coupon) {
    discountExVat = couponDiscount(i.coupon.c, subtotalExVat, i.coupon.cyclesLeft);
    if (discountExVat > 0) {
      lines.push({
        description: `הנחה · ${i.coupon.c.code}`,
        quantity: 1,
        unitExVat: -discountExVat,
        amountExVat: -discountExVat,
        kind: 'DISCOUNT',
      });
    }
  }

  const netExVat = round2(Math.max(0, subtotalExVat - discountExVat));
  const { vatRate, vatAmount, totalIncVat } = withVat(netExVat, at);

  return { lines, subtotalExVat, discountExVat, netExVat, vatRate, vatAmount, totalIncVat };
}

/* ═══════════ מפתח אידמפוטנטיות ═══════════ */

/**
 * זה מה שמונע חיוב כפול.
 * אותו ערך פעמיים → קארדקום מחזיר את העסקה הקיימת ולא מחייב שוב.
 * לכן הוא חייב להיות דטרמיניסטי לפי (מנוי, תקופה) — לא לפי זמן ריצה.
 */
export function idempotencyKey(subscriptionId: string, periodStart: Date, suffix?: string): string {
  const ym = `${periodStart.getUTCFullYear()}-${String(periodStart.getUTCMonth() + 1).padStart(2, '0')}-${String(periodStart.getUTCDate()).padStart(2, '0')}`;
  const short = subscriptionId.replace(/-/g, '').slice(0, 16);
  return `sub_${short}_${ym}${suffix ? `_${suffix}` : ''}`;
}
