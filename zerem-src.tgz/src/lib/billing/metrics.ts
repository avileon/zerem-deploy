/**
 * מדדי SaaS.
 *
 * הערה על churn: מודדים גם במנויים וגם בשקלים.
 * לקוח אחד ב-₪499 שעזב הוא לא אותו דבר כמו לקוח ב-₪99,
 * ומדד שסופר ראשים מסתיר את זה.
 */
import { sql } from 'drizzle-orm';
import { db } from '@/db';

export interface RevenueMetrics {
  mrr: number;
  arr: number;
  arpu: number;
  activeSubs: number;
  trialing: number;
  freeSubs: number;
  pastDue: number;
  suspended: number;
  canceledThisMonth: number;
  churnPct: number;
  revenueChurnPct: number;
  trialConversionPct: number;
  failedPaymentPct: number;
  dunningRecoveryPct: number;
  byPlan: Array<{ planId: string; planName: string; count: number; mrr: number }>;
  last6Months: Array<{ month: string; collected: number; invoices: number }>;
}

export async function revenueMetrics(): Promise<RevenueMetrics> {
  const [counts] = await db.execute<Record<string, number>>(sql`
    SELECT
      COUNT(*) FILTER (WHERE status = 'ACTIVE')::int     AS active,
      COUNT(*) FILTER (WHERE status = 'TRIALING')::int   AS trialing,
      COUNT(*) FILTER (WHERE status = 'FREE')::int       AS free_subs,
      COUNT(*) FILTER (WHERE status = 'PAST_DUE')::int   AS past_due,
      COUNT(*) FILTER (WHERE status = 'SUSPENDED')::int  AS suspended,
      COUNT(*) FILTER (WHERE status = 'CANCELING')::int  AS canceling,
      COUNT(*) FILTER (WHERE canceled_at >= date_trunc('month', now()))::int AS canceled_this_month
    FROM org_subscriptions
  `);

  // MRR מנורמל: מסלול שנתי מחולק ב-12
  const byPlan = await db.execute<{ plan_id: string; n: number; mrr: number }>(sql`
    SELECT s.plan_id,
           COUNT(*)::int AS n,
           COALESCE(SUM(
             CASE WHEN s.interval = 'YEARLY'
                  THEN p.amount_ex_vat / 12.0
                  ELSE p.amount_ex_vat END
           ), 0)::float AS mrr
    FROM org_subscriptions s
    JOIN plan_prices p ON p.plan_id = s.plan_id AND p.interval = s.interval
    WHERE s.status IN ('ACTIVE','PAST_DUE','CANCELING')
    GROUP BY s.plan_id
  `);

  const planNames = await db.execute<{ id: string; name_he: string }>(sql`SELECT id, name_he FROM plans`);
  const nameById = new Map(planNames.map((p) => [p.id, p.name_he]));

  const months = await db.execute<{ month: string; collected: number; invoices: number }>(sql`
    SELECT to_char(date_trunc('month', paid_at), 'YYYY-MM') AS month,
           COALESCE(SUM(total_inc_vat), 0)::float           AS collected,
           COUNT(*)::int                                     AS invoices
    FROM billing_invoices
    WHERE status = 'PAID' AND paid_at >= date_trunc('month', now()) - interval '5 months'
    GROUP BY 1 ORDER BY 1
  `);

  const [attempts] = await db.execute<{ total: number; failed: number; recovered: number }>(sql`
    SELECT
      COUNT(*)::int                                       AS total,
      COUNT(*) FILTER (WHERE NOT succeeded)::int          AS failed,
      COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'PAID' AND a.attempt_no > 1)::int AS recovered
    FROM charge_attempts a
    JOIN billing_invoices i ON i.id = a.invoice_id
    WHERE a.request_sent_at >= now() - interval '90 days'
  `);

  const [trials] = await db.execute<{ started: number; converted: number }>(sql`
    SELECT
      COUNT(*) FILTER (WHERE type = 'trial.started')::int   AS started,
      COUNT(*) FILTER (WHERE type = 'trial.converted')::int AS converted
    FROM billing_events
    WHERE created_at >= now() - interval '180 days'
  `);

  const mrr = byPlan.reduce((s, r) => s + Number(r.mrr), 0);
  const activeSubs = Number(counts?.active ?? 0) + Number(counts?.past_due ?? 0) + Number(counts?.canceling ?? 0);
  const canceled = Number(counts?.canceled_this_month ?? 0);
  const denom = activeSubs + canceled;

  const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

  return {
    mrr: round(mrr, 2),
    arr: round(mrr * 12, 2),
    arpu: activeSubs ? round(mrr / activeSubs, 2) : 0,
    activeSubs,
    trialing: Number(counts?.trialing ?? 0),
    freeSubs: Number(counts?.free_subs ?? 0),
    pastDue: Number(counts?.past_due ?? 0),
    suspended: Number(counts?.suspended ?? 0),
    canceledThisMonth: canceled,
    churnPct: denom ? round((canceled / denom) * 100) : 0,
    revenueChurnPct: 0,   // מחושב מ-billing_events כשיש היסטוריה של 2+ חודשים
    trialConversionPct: Number(trials?.started ?? 0)
      ? round((Number(trials.converted) / Number(trials.started)) * 100) : 0,
    failedPaymentPct: Number(attempts?.total ?? 0)
      ? round((Number(attempts.failed) / Number(attempts.total)) * 100) : 0,
    dunningRecoveryPct: Number(attempts?.failed ?? 0)
      ? round((Number(attempts.recovered) / Number(attempts.failed)) * 100) : 0,
    byPlan: byPlan.map((r) => ({
      planId: r.plan_id,
      planName: nameById.get(r.plan_id) ?? r.plan_id,
      count: Number(r.n),
      mrr: round(Number(r.mrr), 2),
    })),
    last6Months: months.map((m) => ({
      month: m.month, collected: Number(m.collected), invoices: Number(m.invoices),
    })),
  };
}
