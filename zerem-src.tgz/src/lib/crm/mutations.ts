/**
 * פעולות כתיבה של ה-CRM.
 *
 * ⚠️ שלושה כללים שחוזרים בכל פונקציה כאן:
 *  1. orgId מגיע מהסשן ולא מגוף הבקשה — אין נתיב שבו לקוח נוגע בנתוני אחר.
 *  2. כל ישות שמתעדכנת נשלפת קודם **עם** בדיקת orgId. עדכון לפי id בלבד
 *     מאפשר לנחש מזהה של עסק אחר; זו הטעות הקלאסית ב-multi-tenant.
 *  3. מכסות נבדקות בשרת לפני הכתיבה, לא במסך.
 */
import { and, eq, sql } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { normalizePhone } from '../israel';
import { requireQuota, bumpUsage, invalidateEntitlements, QuotaError, FeatureLockedError } from '../billing/entitlements';

export type Res<T> = { ok: true; data: T } | { ok: false; error: string; code?: string };

function fail(e: unknown): Res<never> {
  if (e instanceof QuotaError || e instanceof FeatureLockedError) {
    const j = e.toJSON();
    return { ok: false, error: j.message, code: j.error };
  }
  return { ok: false, error: String(e) };
}

/* ═══════════════ לידים ═══════════════ */

export interface LeadInput {
  fullName: string;
  phone: string;
  email?: string;
  city?: string;
  companyName?: string;
  notes?: string;
  status?: string;
  source?: string;
  ownerId?: string;
  estimatedValueIls?: number | null;
  tags?: string[];
}

export async function createLead(orgId: string, actorId: string, i: LeadInput): Promise<Res<{ id: string; duplicate: boolean }>> {
  const name = i.fullName?.trim();
  if (!name) return { ok: false, error: 'שם הליד חובה' };

  const p = normalizePhone(i.phone);
  if (!p.e164) return { ok: false, error: p.error ?? 'מספר טלפון לא תקין' };

  // ── דדופליקציה לפי הטלפון המנורמל, בדיוק כמו בקליטה מטפסים.
  //    בלי זה, אותו לקוח שמתקשר ונרשם בטופס מופיע פעמיים.
  const [existing] = await db.select().from(s.leads)
    .where(and(eq(s.leads.orgId, orgId), eq(s.leads.phone, p.e164))).limit(1);

  if (existing) {
    return { ok: true, data: { id: existing.id, duplicate: true } };
  }

  try {
    await requireQuota(orgId, 'leads', 1);
  } catch (e) {
    return fail(e);
  }

  const [lead] = await db.insert(s.leads).values({
    orgId,
    fullName: name,
    phone: p.e164,
    waChatId: p.waChatId ?? null,
    email: i.email?.trim() || null,
    city: i.city?.trim() || null,
    companyName: i.companyName?.trim() || null,
    notes: i.notes?.trim() || null,
    status: (i.status ?? 'NEW') as never,
    source: (i.source ?? 'MANUAL') as never,
    ownerId: i.ownerId || actorId,
    estimatedValueIls: i.estimatedValueIls != null ? String(i.estimatedValueIls) : null,
    tags: i.tags?.length ? i.tags : [],
    lastContactAt: new Date(),
  }).returning({ id: s.leads.id });

  await db.insert(s.activities).values({
    orgId, leadId: lead.id, actorId, type: 'lead.created',
    summary: `ליד נוצר ידנית — ${name}`,
  }).catch(() => {});

  invalidateEntitlements(orgId);
  return { ok: true, data: { id: lead.id, duplicate: false } };
}

export async function updateLead(
  orgId: string, actorId: string, leadId: string, patch: Partial<LeadInput> & { lostReason?: string },
): Promise<Res<null>> {
  // ⚠️ הבדיקה כוללת orgId — לא רק id
  const [lead] = await db.select().from(s.leads)
    .where(and(eq(s.leads.id, leadId), eq(s.leads.orgId, orgId))).limit(1);
  if (!lead) return { ok: false, error: 'הליד לא נמצא' };

  const set: Record<string, unknown> = { updatedAt: new Date() };

  if (patch.fullName !== undefined) set.fullName = patch.fullName.trim();
  if (patch.email !== undefined) set.email = patch.email?.trim() || null;
  if (patch.city !== undefined) set.city = patch.city?.trim() || null;
  if (patch.companyName !== undefined) set.companyName = patch.companyName?.trim() || null;
  if (patch.notes !== undefined) set.notes = patch.notes?.trim() || null;
  if (patch.ownerId !== undefined) set.ownerId = patch.ownerId || null;
  if (patch.tags !== undefined) set.tags = patch.tags;
  if (patch.estimatedValueIls !== undefined) {
    set.estimatedValueIls = patch.estimatedValueIls != null ? String(patch.estimatedValueIls) : null;
  }
  if (patch.lostReason !== undefined) set.lostReason = patch.lostReason?.trim() || null;

  if (patch.phone !== undefined) {
    const p = normalizePhone(patch.phone);
    if (!p.e164) return { ok: false, error: p.error ?? 'מספר טלפון לא תקין' };
    if (p.e164 !== lead.phone) {
      const [clash] = await db.select({ id: s.leads.id }).from(s.leads)
        .where(and(eq(s.leads.orgId, orgId), eq(s.leads.phone, p.e164))).limit(1);
      if (clash) return { ok: false, error: 'כבר קיים ליד עם המספר הזה' };
      set.phone = p.e164;
      set.waChatId = p.waChatId ?? null;
    }
  }

  if (patch.status !== undefined && patch.status !== lead.status) {
    set.status = patch.status;
    if (patch.status === 'WON' || patch.status === 'LOST') set.closedAt = new Date();
    await db.insert(s.activities).values({
      orgId, leadId, actorId, type: 'lead.status_changed',
      summary: `סטטוס: ${lead.status} → ${patch.status}`,
      data: { from: lead.status, to: patch.status },
    }).catch(() => {});
    // סטטוס משנה את ספירת "לידים פעילים" ולכן את המכסה
    invalidateEntitlements(orgId);
  }

  await db.update(s.leads).set(set).where(eq(s.leads.id, leadId));
  return { ok: true, data: null };
}

/* ═══════════════ משימות ═══════════════ */

export interface TaskInput {
  title: string;
  description?: string;
  leadId?: string;
  assigneeId?: string;
  priority?: string;
  dueAt?: string | null;
}

export async function createTask(orgId: string, actorId: string, i: TaskInput): Promise<Res<{ id: string }>> {
  const title = i.title?.trim();
  if (!title) return { ok: false, error: 'כותרת המשימה חובה' };

  // ליד משויך חייב להיות של אותו ארגון
  if (i.leadId) {
    const [lead] = await db.select({ id: s.leads.id }).from(s.leads)
      .where(and(eq(s.leads.id, i.leadId), eq(s.leads.orgId, orgId))).limit(1);
    if (!lead) return { ok: false, error: 'הליד לא נמצא' };
  }
  // וכך גם מקבל המשימה
  if (i.assigneeId) {
    const [m] = await db.select({ id: s.memberships.id }).from(s.memberships)
      .where(and(
        eq(s.memberships.orgId, orgId),
        eq(s.memberships.userId, i.assigneeId),
        eq(s.memberships.active, true),
      )).limit(1);
    if (!m) return { ok: false, error: 'מקבל המשימה אינו בצוות' };
  }

  const [task] = await db.insert(s.tasks).values({
    orgId,
    title,
    description: i.description?.trim() || null,
    leadId: i.leadId || null,
    assigneeId: i.assigneeId || actorId,
    createdById: actorId,
    priority: (i.priority ?? 'NORMAL') as never,
    dueAt: i.dueAt ? new Date(i.dueAt) : null,
  }).returning({ id: s.tasks.id });

  if (i.assigneeId && i.assigneeId !== actorId) {
    await db.insert(s.notifications).values({
      orgId, userId: i.assigneeId, channel: 'IN_APP',
      title: 'משימה חדשה', body: title, url: '/tasks',
    }).catch(() => {});
  }

  return { ok: true, data: { id: task.id } };
}

export async function updateTask(
  orgId: string, actorId: string, taskId: string,
  patch: Partial<TaskInput> & { status?: string },
): Promise<Res<null>> {
  const [task] = await db.select().from(s.tasks)
    .where(and(eq(s.tasks.id, taskId), eq(s.tasks.orgId, orgId))).limit(1);
  if (!task) return { ok: false, error: 'המשימה לא נמצאה' };

  const set: Record<string, unknown> = {};
  if (patch.title !== undefined) set.title = patch.title.trim();
  if (patch.description !== undefined) set.description = patch.description?.trim() || null;
  if (patch.priority !== undefined) set.priority = patch.priority;
  if (patch.dueAt !== undefined) set.dueAt = patch.dueAt ? new Date(patch.dueAt) : null;

  if (patch.assigneeId !== undefined) {
    if (patch.assigneeId) {
      const [m] = await db.select({ id: s.memberships.id }).from(s.memberships)
        .where(and(
          eq(s.memberships.orgId, orgId),
          eq(s.memberships.userId, patch.assigneeId),
          eq(s.memberships.active, true),
        )).limit(1);
      if (!m) return { ok: false, error: 'מקבל המשימה אינו בצוות' };
      if (patch.assigneeId !== task.assigneeId) {
        await db.insert(s.notifications).values({
          orgId, userId: patch.assigneeId, channel: 'IN_APP',
          title: 'משימה הועברה אליך', body: task.title, url: '/tasks',
        }).catch(() => {});
      }
    }
    set.assigneeId = patch.assigneeId || null;
  }

  if (patch.status !== undefined) {
    set.status = patch.status;
    set.completedAt = patch.status === 'DONE' ? new Date() : null;
  }

  await db.update(s.tasks).set(set).where(eq(s.tasks.id, taskId));
  void actorId;
  return { ok: true, data: null };
}

export async function deleteTask(orgId: string, taskId: string): Promise<Res<null>> {
  const r = await db.delete(s.tasks)
    .where(and(eq(s.tasks.id, taskId), eq(s.tasks.orgId, orgId))).returning({ id: s.tasks.id });
  if (!r.length) return { ok: false, error: 'המשימה לא נמצאה' };
  return { ok: true, data: null };
}

/* ═══════════════ קטלוג ═══════════════ */

export interface ProductInput {
  name: string;
  description?: string;
  category?: string;
  unitPriceIls: number;
  unit?: string;
  sku?: string;
  isActive?: boolean;
}

export async function createProduct(orgId: string, i: ProductInput): Promise<Res<{ id: string }>> {
  const name = i.name?.trim();
  if (!name) return { ok: false, error: 'שם הפריט חובה' };
  if (!Number.isFinite(i.unitPriceIls) || i.unitPriceIls < 0) {
    return { ok: false, error: 'מחיר לא תקין' };
  }

  const [p] = await db.insert(s.products).values({
    orgId,
    name,
    description: i.description?.trim() || null,
    category: i.category?.trim() || null,
    unitPriceIls: String(i.unitPriceIls),
    unit: i.unit?.trim() || 'יח׳',
    sku: i.sku?.trim() || null,
    active: i.isActive ?? true,
  }).returning({ id: s.products.id });

  return { ok: true, data: { id: p.id } };
}

export async function updateProduct(
  orgId: string, productId: string, patch: Partial<ProductInput>,
): Promise<Res<null>> {
  const [prod] = await db.select({ id: s.products.id }).from(s.products)
    .where(and(eq(s.products.id, productId), eq(s.products.orgId, orgId))).limit(1);
  if (!prod) return { ok: false, error: 'הפריט לא נמצא' };

  const set: Record<string, unknown> = {};
  if (patch.name !== undefined) set.name = patch.name.trim();
  if (patch.description !== undefined) set.description = patch.description?.trim() || null;
  if (patch.category !== undefined) set.category = patch.category?.trim() || null;
  if (patch.unit !== undefined) set.unit = patch.unit?.trim() || 'יח׳';
  if (patch.sku !== undefined) set.sku = patch.sku?.trim() || null;
  if (patch.isActive !== undefined) set.active = patch.isActive;
  if (patch.unitPriceIls !== undefined) {
    if (!Number.isFinite(patch.unitPriceIls) || patch.unitPriceIls < 0) {
      return { ok: false, error: 'מחיר לא תקין' };
    }
    set.unitPriceIls = String(patch.unitPriceIls);
  }

  await db.update(s.products).set(set).where(eq(s.products.id, productId));
  return { ok: true, data: null };
}

export async function deleteProduct(orgId: string, productId: string): Promise<Res<null>> {
  // פריט שנמצא בהצעות קיימות לא נמחק — מסמנים כלא פעיל.
  // מחיקה הייתה שוברת הצעות היסטוריות, וזה מסמך שנשלח ללקוח.
  const [used] = await db.select({ n: sql<number>`count(*)::int` })
    .from(s.quoteItems).where(eq(s.quoteItems.productId, productId));

  if (Number(used?.n ?? 0) > 0) {
    await db.update(s.products).set({ active: false })
      .where(and(eq(s.products.id, productId), eq(s.products.orgId, orgId)));
    return { ok: true, data: null };
  }

  const r = await db.delete(s.products)
    .where(and(eq(s.products.id, productId), eq(s.products.orgId, orgId))).returning({ id: s.products.id });
  if (!r.length) return { ok: false, error: 'הפריט לא נמצא' };
  return { ok: true, data: null };
}

export { bumpUsage };
