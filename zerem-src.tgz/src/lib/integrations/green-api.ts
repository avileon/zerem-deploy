/**
 * Green API — WhatsApp
 *
 * ⚠️ קריטי להבנה: Green API מפעיל WhatsApp **Web** לא רשמי, לא Cloud API של Meta.
 *   · יתרון: אין חלון 24 שעות, אין תבניות לאישור, עלות קבועה נמוכה
 *   · חיסרון: תנאי השימוש של Meta אוסרים על כך במפורש, והמספר עלול להיחסם לצמיתות
 *
 * לכן הערוץ מופשט מאחורי ממשק — מעבר ל-Cloud API רשמי = מחלקה נוספת, בלי לגעת בליבה.
 */

export interface GreenApiConfig {
  idInstance: string;
  apiTokenInstance: string;
  apiUrl?: string;    // הקונסולה מנפיקה host ייעודי לכל instance
  mediaUrl?: string;
}

export interface SendResult {
  ok: boolean;
  externalId?: string;
  error?: string;
  /** true אם כדאי לנסות שוב (429 / 5xx), false אם זו שגיאה סופית */
  retryable?: boolean;
}

const DEFAULT_API = 'https://api.green-api.com';
const DEFAULT_MEDIA = 'https://media.green-api.com';

export class GreenApiClient {
  constructor(private cfg: GreenApiConfig) {}

  private url(method: string, media = false) {
    const base = media ? (this.cfg.mediaUrl ?? DEFAULT_MEDIA) : (this.cfg.apiUrl ?? DEFAULT_API);
    return `${base}/waInstance${this.cfg.idInstance}/${method}/${this.cfg.apiTokenInstance}`;
  }

  private async post(method: string, body: unknown, media = false): Promise<SendResult> {
    try {
      const res = await fetch(this.url(method, media), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.status === 429) return { ok: false, error: 'חריגה ממגבלת הקצב', retryable: true };
      if (!res.ok) {
        return { ok: false, error: `HTTP ${res.status}: ${await res.text()}`, retryable: res.status >= 500 };
      }
      const json = (await res.json()) as { idMessage?: string };
      return { ok: true, externalId: json.idMessage };
    } catch (e) {
      return { ok: false, error: String(e), retryable: true };
    }
  }

  /** טקסט. עד 20,000 תווים. */
  sendText(chatId: string, message: string, quotedMessageId?: string) {
    return this.post('sendMessage', { chatId, message, linkPreview: true, quotedMessageId });
  }

  /** קובץ מ-URL ציבורי. חייב להיות קישור ישיר לקובץ, לא עמוד HTML. עד 100MB. */
  sendFileByUrl(chatId: string, urlFile: string, fileName: string, caption?: string) {
    return this.post('sendFileByUrl', { chatId, urlFile, fileName, caption });
  }

  /**
   * כפתורים אינטראקטיביים (Beta).
   * ⚠️ אין יותר quick-reply עם payload חוזר — רק url / call / copy.
   * לכן כפתור "אישור הצעה" חייב להיות מסוג url שמצביע לקישור חתום אצלנו.
   */
  sendButtons(chatId: string, body: string, buttons: Array<
    | { type: 'url'; buttonId: string; buttonText: string; url: string }
    | { type: 'call'; buttonId: string; buttonText: string; phoneNumber: string }
    | { type: 'copy'; buttonId: string; buttonText: string; copyCode: string }
  >, header?: string, footer?: string) {
    if (buttons.length > 3) throw new Error('Green API מגביל ל-3 כפתורים');
    return this.post('sendInteractiveButtons', { chatId, header, body, footer, buttons });
  }

  async getState(): Promise<{ stateInstance: string } | null> {
    try {
      const res = await fetch(this.url('getStateInstance').replace('/waInstance', '/waInstance'), { method: 'GET' });
      if (!res.ok) return null;
      return (await res.json()) as { stateInstance: string };
    } catch { return null; }
  }

  /** בדיקה אם המספר קיים בוואטסאפ — לפני שמנסים לשלוח */
  async checkWhatsapp(phoneE164: string): Promise<boolean> {
    const chatId = phoneE164.replace('+', '');
    try {
      const res = await fetch(this.url('checkWhatsapp'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId }),
      });
      if (!res.ok) return false;
      const json = (await res.json()) as { existsWhatsapp?: boolean };
      return !!json.existsWhatsapp;
    } catch { return false; }
  }

  /**
   * הגדרת webhook.
   * delaySendMessagesMilliseconds הוא **הווסת היחיד נגד חסימה** —
   * 5000ms ≈ 12 הודעות בדקה. Meta לא מפרסמת סף, אז שמרנות משתלמת.
   */
  setWebhook(webhookUrl: string, webhookUrlToken: string, delayMs = 5000) {
    return this.post('setSettings', {
      webhookUrl,
      webhookUrlToken,
      delaySendMessagesMilliseconds: delayMs,
      incomingWebhook: 'yes',
      outgoingAPIMessageWebhook: 'yes',
      outgoingMessageWebhook: 'yes',
      stateWebhook: 'yes',
    });
  }
}

/* ── פענוח webhooks נכנסים ── */

export type GreenWebhook =
  | { typeWebhook: 'incomingMessageReceived'; idMessage: string; timestamp: number;
      senderData: { chatId: string; sender: string; senderName?: string };
      messageData: Record<string, unknown> }
  | { typeWebhook: 'outgoingMessageStatus'; idMessage: string; chatId: string;
      status: 'sent' | 'delivered' | 'read' | 'failed' | 'noAccount' | 'notInGroup' | 'suspended' | 'yellowCard';
      timestamp: number; description?: string }
  | { typeWebhook: 'stateInstanceChanged'; stateInstance: string; timestamp: number }
  | { typeWebhook: string; [k: string]: unknown };

export function extractText(messageData: Record<string, unknown>): string | undefined {
  const td = messageData.textMessageData as { textMessage?: string } | undefined;
  if (td?.textMessage) return td.textMessage;
  const ext = messageData.extendedTextMessageData as { text?: string } | undefined;
  if (ext?.text) return ext.text;
  const file = messageData.fileMessageData as { caption?: string } | undefined;
  return file?.caption;
}

/** סטטוסים שמחייבים התראה למשתמש — המספר בסכנה */
export const CRITICAL_STATES = ['blocked', 'suspended', 'yellowCard', 'notAuthorized'];

export const BAN_RISK_NOTICE =
  'Green API מפעיל את וואטסאפ דרך חיבור לא-רשמי. שליחה מרובה או תלונות נמענים ' +
  'עלולות לגרום לחסימת המספר על ידי Meta — חסימה שאינה ניתנת לערעור בפועל. ' +
  'מומלץ: לא לשלוח דיוור המוני, לשמור על מרווח בין הודעות, ולשקול מעבר ל-Cloud API הרשמי בהיקפים גדולים.';

/** בניית chatId מטלפון E.164 */
export function toChatId(e164: string): string {
  return `${e164.replace('+', '')}@c.us`;
}

/** החלפת משתנים בתבנית הודעה */
export function renderTemplate(body: string, vars: Record<string, string | number | null | undefined>): string {
  return body.replace(/\{\{(\w+)\}\}/g, (_, k: string) => String(vars[k] ?? ''));
}
