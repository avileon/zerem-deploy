/**
 * Cardcom — סליקת אשראי (API v11 JSON)
 * https://secure.cardcom.solutions/api/v11/...
 *
 * ⚠️ נקודת האבטחה הקריטית:
 * ל-Cardcom **אין חתימת HMAC על ה-webhook**. אסור להאמין לגוף הקריאה.
 * הדפוס הנכון: ה-webhook הוא רק "צלצול" → מוציאים ממנו LowProfileId →
 * קוראים GetLpResult שרת-לשרת → רק לתשובה הזו מאמינים.
 */

const BASE = 'https://secure.cardcom.solutions/api/v11';

export interface CardcomConfig {
  terminalNumber: number;   // מספר, לא מחרוזת — סיבה נפוצה ל-400
  apiName: string;
  apiPassword?: string;     // נדרש רק להחזרים ולמסמכים
}

export type CardcomOperation =
  | 'ChargeOnly'
  | 'ChargeAndCreateToken'
  | 'CreateTokenOnly'
  | 'SuspendedDeal'
  | 'Do3DSAndSubmit';

export interface CreatePayLinkInput {
  amountIls: number;
  /** מזהה הקורלציה שלנו — חוזר בכל תשובה ובכל webhook */
  returnValue: string;
  productName: string;
  operation?: CardcomOperation;
  successUrl: string;
  failedUrl: string;
  webhookUrl: string;
  customer?: { name?: string; phone?: string; email?: string };
  maxInstallments?: number;
  language?: 'he' | 'en' | 'ar' | 'ru';
}

export interface PayLinkResult {
  ok: boolean;
  lowProfileId?: string;
  url?: string;
  urlBit?: string;
  urlPayPal?: string;
  error?: string;
}

export class CardcomClient {
  constructor(private cfg: CardcomConfig) {}

  private async call<T>(path: string, body: Record<string, unknown>): Promise<T | { __error: string }> {
    try {
      const res = await fetch(`${BASE}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          TerminalNumber: this.cfg.terminalNumber,
          ApiName: this.cfg.apiName,
          ...body,
        }),
      });
      if (!res.ok) return { __error: `HTTP ${res.status}: ${await res.text()}` };
      return (await res.json()) as T;
    } catch (e) {
      return { __error: String(e) };
    }
  }

  /** שלב 1 — יצירת דף תשלום מתארח / PayLink לשליחה בוואטסאפ */
  async createPayLink(i: CreatePayLinkInput): Promise<PayLinkResult> {
    const r = await this.call<{
      ResponseCode: number; Description: string;
      LowProfileId?: string; Url?: string; UrlToBit?: string; UrlToPayPal?: string;
    }>('/LowProfile/Create', {
      ReturnValue: i.returnValue,
      Amount: i.amountIls,
      Operation: i.operation ?? 'ChargeOnly',
      SuccessRedirectUrl: i.successUrl,
      FailedRedirectUrl: i.failedUrl,
      WebHookUrl: i.webhookUrl,
      ISOCoinId: 1,                       // 1 = שקל
      Language: i.language ?? 'he',
      ProductName: i.productName,
      MaxNumOfPayments: i.maxInstallments ?? 1,
      UIDefinition: {
        CardOwnerNameValue: i.customer?.name,
        CardOwnerPhoneValue: i.customer?.phone,
        CardOwnerEmailValue: i.customer?.email,
      },
      // ⚠️ אין Document כאן בכוונה — ריווחית היא המנפיק היחיד.
      // הוספת Document תגרום לכפל הנפקה, וזו בעיית מס ולא רק באג.
    });

    if ('__error' in r) return { ok: false, error: r.__error };
    if (r.ResponseCode !== 0) return { ok: false, error: `${r.ResponseCode}: ${r.Description}` };
    return { ok: true, lowProfileId: r.LowProfileId, url: r.Url, urlBit: r.UrlToBit, urlPayPal: r.UrlToPayPal };
  }

  /**
   * שלב 2 — האמת היחידה. נקרא אחרי כל webhook.
   * לעולם לא מסתמכים על גוף ה-webhook עצמו.
   */
  async getResult(lowProfileId: string) {
    const r = await this.call<{
      ResponseCode: number; Description: string;
      ReturnValue?: string; Operation?: string;
      TranzactionInfo?: {
        TranzactionId?: number; ApprovalNumber?: string;
        Last4CardDigits?: number; Brand?: string; Amount?: number;
      };
      TokenInfo?: { Token?: string; CardMonth?: number; CardYear?: number };
      UIValues?: Record<string, unknown>;
    }>('/LowProfile/GetLpResult', { LowProfileId: lowProfileId });

    if ('__error' in r) return { ok: false as const, error: r.__error };
    return {
      ok: r.ResponseCode === 0,
      responseCode: r.ResponseCode,
      description: r.Description,
      returnValue: r.ReturnValue,
      transactionId: r.TranzactionInfo?.TranzactionId ? String(r.TranzactionInfo.TranzactionId) : undefined,
      approvalNumber: r.TranzactionInfo?.ApprovalNumber,
      last4: r.TranzactionInfo?.Last4CardDigits ? String(r.TranzactionInfo.Last4CardDigits) : undefined,
      brand: r.TranzactionInfo?.Brand,
      amount: r.TranzactionInfo?.Amount,
      token: r.TokenInfo?.Token,
      tokenExpiry: r.TokenInfo?.CardMonth && r.TokenInfo?.CardYear
        ? `${String(r.TokenInfo.CardMonth).padStart(2, '0')}${String(r.TokenInfo.CardYear).slice(-2)}`
        : undefined,
      raw: r,
    };
  }

  /**
   * חיוב בטוקן — למנויים / הוראות קבע.
   * ExternalUniqTranId הוא מפתח אידמפוטנטיות: אותו ערך פעמיים = לא יחויב פעמיים.
   */
  async chargeToken(p: {
    token: string; expiryMMYY: string; amountIls: number;
    idempotencyKey: string; installments?: number;
  }) {
    const r = await this.call<{
      ResponseCode: number; Description: string;
      TranzactionId?: number; ApprovalNumber?: string; Last4CardDigits?: number; Brand?: string;
    }>('/Transactions/Transaction', {
      Amount: p.amountIls,
      Token: p.token,
      CardExpirationMMYY: p.expiryMMYY,
      ExternalUniqTranId: p.idempotencyKey,
      NumOfPayments: p.installments ?? 1,
    });
    if ('__error' in r) return { ok: false as const, error: r.__error };
    return {
      ok: r.ResponseCode === 0,
      error: r.ResponseCode === 0 ? undefined : `${r.ResponseCode}: ${r.Description}`,
      transactionId: r.TranzactionId ? String(r.TranzactionId) : undefined,
      approvalNumber: r.ApprovalNumber,
      last4: r.Last4CardDigits ? String(r.Last4CardDigits) : undefined,
      brand: r.Brand,
    };
  }
}

/* ── סביבת בדיקות ──
 * אין hostname נפרד. ההבחנה היא במספר הטרמינל.
 * כלל התנהגות שימושי: סכום < 5,000 ₪ → הצלחה מדומה. סכום > 5,000 ₪ → כישלון מדומה.
 */
export const CARDCOM_TEST = {
  terminalNumber: 1000,
  apiName: 'Cardcomtest26',
  testCard: { number: '4580280000000008', expiry: '12/30', cvv: '123' },
  note: 'סכום מתחת ל-5,000 ₪ מדמה הצלחה; מעל — כישלון. שימושי לבדיקת מסלול הכישלון.',
} as const;

export const CARDCOM_WEBHOOK_WARNING =
  'ל-Cardcom אין חתימת HMAC על ה-webhook. גוף הקריאה אינו מהימן. ' +
  'הטיפול הנכון: לחלץ LowProfileId, לקרוא GetLpResult שרת-לשרת, ולהאמין רק לתשובה הזו.';
