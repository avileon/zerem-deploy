/**
 * ריווחית — הנפקת מסמכי חשבונאות
 * https://api.rivhit.co.il/online/RivhitOnlineAPI.svc/{Operation}
 *
 * ⚠️ שתי טעויות נפוצות שהקוד כאן מונע:
 *
 * 1. **document_type אינו קבוע גלובלי.** הקודים מוגדרים לכל חשבון בנפרד.
 *    (ה-"305" המוכר הוא קוד של מבנה אחיד של רשות המסים, לא של ריווחית.)
 *    לכן: בעת חיבור החשבון קוראים Document.TypeList, ממפים, ושומרים.
 *
 * 2. **send_mail ברירת המחדל היא true.** בלי לציין במפורש — הלקוחות
 *    יקבלו מיילים מסביבת הפיתוח.
 */

const BASE = 'https://api.rivhit.co.il/online/RivhitOnlineAPI.svc';

export interface RivhitConfig { apiToken: string }

interface Envelope<T> {
  error_code: number;
  client_message: string;
  debug_message: string | null;
  data: T;
}

export interface DocTypeEntry {
  document_type: number;
  document_name: string;
  document_english_name: string;
  is_invoice_receipt: boolean;
  is_accounting: boolean;
  price_include_vat: boolean;
}

export interface CreateDocInput {
  documentType: number;
  customerId?: number;
  lastName: string;                 // חובה — שם משפחה / שם החברה
  firstName?: string;
  address?: string;
  city?: string;
  phone?: string;
  email?: string;
  idNumber?: number;                // ח.פ. / ת.ז. — נדרש למספר הקצאה
  items: Array<{
    description: string;
    quantity: number;
    priceNis: number;
    catalogNumber?: string;
    itemId?: number;
    exemptVat?: boolean;
  }>;
  comments?: string;
  discountType?: 1 | 2;             // 1=אחוז 2=סכום
  discountValue?: number;
  priceIncludeVat?: boolean;
  sendMail?: boolean;
  createCustomer?: boolean;
  checkOnly?: boolean;              // הרצה יבשה לבדיקת תקינות
}

export class RivhitClient {
  constructor(private cfg: RivhitConfig) {}

  private async call<T>(op: string, body: Record<string, unknown> = {}): Promise<
    { ok: true; data: T } | { ok: false; error: string }
  > {
    try {
      const res = await fetch(`${BASE}/${op}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ api_token: this.cfg.apiToken, ...body }),
      });
      if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
      const json = (await res.json()) as Envelope<T>;
      if (json.error_code !== 0) {
        return { ok: false, error: `${json.error_code}: ${json.client_message}` };
      }
      return { ok: true, data: json.data };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  /**
   * חובה לקרוא בעת חיבור החשבון. בלי זה אין דרך לדעת
   * איזה קוד מייצג "חשבונית מס קבלה" אצל הלקוח הספציפי.
   */
  listDocumentTypes() {
    return this.call<{ document_type_list: DocTypeEntry[] }>('Document.TypeList');
  }

  listItems(updatedFrom?: string) {
    return this.call<{ item_list: Array<{
      item_id: number; item_name: string; item_part_num?: string;
      sale_nis: number; cost_nis?: number; exempt_vat?: boolean;
    }> }>('Item.List', { item_group_id: 0, updated_from: updatedFrom ?? '' });
  }

  createCustomer(c: { lastName: string; firstName?: string; phone?: string; email?: string; idNumber?: number; address?: string; city?: string }) {
    return this.call<{ customer_id: number }>('Customer.New', {
      last_name: c.lastName,
      first_name: c.firstName ?? '',
      phone: c.phone ?? '',
      email: c.email ?? '',
      id_number: c.idNumber ?? 0,
      address: c.address ?? '',
      city: c.city ?? '',
      currency_id: 1,
    });
  }

  /** יצירת מסמך. התשובה כוללת כבר את מספר ההקצאה כשנדרש. */
  createDocument(i: CreateDocInput) {
    return this.call<{
      document_type: number;
      document_number: number;
      customer_id: number;
      document_identity: string;
      document_link: string;
      amount: number;
      confirmation_number?: string | number;   // ← מספר הקצאה
    }>('Document.New', {
      document_type: i.documentType,
      customer_id: i.customerId ?? 0,
      last_name: i.lastName,
      first_name: i.firstName ?? '',
      address: i.address ?? '',
      city: i.city ?? '',
      phone: i.phone ?? '',
      email_to: i.email ?? '',
      id_number: i.idNumber ?? 0,
      currency_id: 1,
      sort_code: 100,                          // 100 = כולל מע״מ
      price_include_vat: i.priceIncludeVat ?? true,
      discount_type: i.discountType ?? 1,
      discount_value: i.discountValue ?? 0,
      comments: i.comments ?? '',
      language: 'he',
      // ← ברירת המחדל של ריווחית היא true. תמיד להעביר במפורש.
      send_mail: i.sendMail ?? false,
      create_customer: i.createCustomer ?? true,
      prevent_duplicates: true,
      check_only: i.checkOnly ?? false,
      items: i.items.map((it) => ({
        item_id: it.itemId ?? 0,
        catalog_number: it.catalogNumber ?? '',
        description: it.description,
        quantity: it.quantity,
        price_nis: it.priceNis,
        exempt_vat: it.exemptVat ?? false,
      })),
    });
  }

  /** קישור PDF למסמך קיים */
  getDocumentCopy(documentType: number, documentNumber: number) {
    return this.call<{ document_link: string; document_identity: string }>('Document.Copy', {
      document_type: documentType,
      document_number: documentNumber,
      language: 'he',
      force_copy: false,
    });
  }

  /** בקשת מספר הקצאה מרשות המסים עבור מסמך שכבר הונפק */
  acquireAllocationNumber(documentType: number, documentNumber: number, idNumber: number) {
    return this.call<{ confirmation_number: string }>('Document.InvoiceApproval', {
      document_type: documentType,
      document_number: documentNumber,
      id_number: idNumber,
    });
  }
}

/**
 * מיפוי סוגי מסמך פנימיים → קוד אצל הלקוח.
 * נבנה פעם אחת מ-Document.TypeList ונשמר ב-integrations.config.
 */
export type DocKind = 'QUOTE' | 'PROFORMA' | 'TAX_INVOICE' | 'RECEIPT' | 'TAX_INVOICE_RECEIPT' | 'CREDIT_NOTE';

const MATCHERS: Record<DocKind, RegExp> = {
  TAX_INVOICE_RECEIPT: /חשבונית\s*מס\s*[/־-]?\s*קבלה|invoice.*receipt/i,
  TAX_INVOICE: /^חשבונית\s*מס$|tax\s*invoice/i,
  RECEIPT: /^קבלה$|^receipt$/i,
  QUOTE: /הצעת\s*מחיר|quot/i,
  PROFORMA: /פרופורמה|proforma|חשבון\s*עסקה/i,
  CREDIT_NOTE: /זיכוי|credit/i,
};

/** ניחוש ראשוני של המיפוי — המשתמש מאשר או מתקן במסך ההגדרות */
export function guessDocTypeMap(list: DocTypeEntry[]): Partial<Record<DocKind, number>> {
  const map: Partial<Record<DocKind, number>> = {};
  for (const [kind, re] of Object.entries(MATCHERS) as Array<[DocKind, RegExp]>) {
    const hit = list.find((d) => re.test(d.document_name) || re.test(d.document_english_name ?? ''));
    if (hit) map[kind] = hit.document_type;
  }
  return map;
}

export const RIVHIT_DEMO = {
  apiToken: '0279BF82-CD57-49BA-837C-930F0E2EB805',
  user: 'DEMO',
  businessId: '8888',
  note: 'כתובות ה-sandbox שפורסמו נראות כשרתי staging ישנים — לאמת מול תמיכת ריווחית.',
} as const;

export const DOUBLE_ISSUE_WARNING =
  'Cardcom וריווחית שניהם יודעים להנפיק חשבוניות. אם שניהם פעילים — ייווצרו שתי חשבוניות ' +
  'לאותו תשלום, וזו בעיית מס. המערכת מגדירה מנפיק יחיד; ב-Cardcom לא נשלח אובייקט Document.';
