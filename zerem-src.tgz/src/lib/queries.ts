import { db, schema as s } from '@/db';
import { eq, and, desc, asc, count, sum, sql as raw, inArray, isNull, not } from 'drizzle-orm';

/** האב-טיפוס רץ על ארגון יחיד. ב-production מגיע מה-session. */
export async function currentOrg() {
  const [org] = await db.select().from(s.organizations).limit(1);
  return org;
}
export async function currentUser() {
  const [u] = await db.select().from(s.users).limit(1);
  return u;
}

export async function getDashboard(orgId: string) {
  const [openLeads, wonLeads, openTasks, overdueTasks] = await Promise.all([
    db.select({ n: count() }).from(s.leads).where(and(eq(s.leads.orgId, orgId), not(inArray(s.leads.status, ['WON', 'LOST'])))),
    db.select({ n: count(), v: raw<number>`COALESCE(SUM(${s.leads.estimatedValueIls}),0)` }).from(s.leads).where(and(eq(s.leads.orgId, orgId), eq(s.leads.status, 'WON'))),
    db.select({ n: count() }).from(s.tasks).where(and(eq(s.tasks.orgId, orgId), inArray(s.tasks.status, ['OPEN', 'IN_PROGRESS']))),
    db.select({ n: count() }).from(s.tasks).where(and(eq(s.tasks.orgId, orgId), inArray(s.tasks.status, ['OPEN', 'IN_PROGRESS']), raw`${s.tasks.dueAt} < now()`)),
  ]);

  const pipeline = await db
    .select({ status: s.leads.status, n: count(), v: raw<number>`COALESCE(SUM(${s.leads.estimatedValueIls}),0)` })
    .from(s.leads).where(eq(s.leads.orgId, orgId)).groupBy(s.leads.status);

  const quoteStats = await db
    .select({ status: s.quotes.status, n: count(), v: raw<number>`COALESCE(SUM(${s.quotes.totalIls}),0)` })
    .from(s.quotes).where(eq(s.quotes.orgId, orgId)).groupBy(s.quotes.status);

  const paid = await db
    .select({ n: count(), v: raw<number>`COALESCE(SUM(${s.payments.amountIls}),0)` })
    .from(s.payments).where(and(eq(s.payments.orgId, orgId), eq(s.payments.status, 'PAID')));

  const bySource = await db
    .select({ source: s.leads.source, n: count(), won: raw<number>`COUNT(*) FILTER (WHERE ${s.leads.status} = 'WON')` })
    .from(s.leads).where(eq(s.leads.orgId, orgId)).groupBy(s.leads.source);

  return {
    openLeads: openLeads[0].n,
    wonCount: wonLeads[0].n,
    wonValue: Number(wonLeads[0].v ?? 0),
    openTasks: openTasks[0].n,
    overdueTasks: overdueTasks[0].n,
    pipeline,
    quoteStats,
    paidCount: paid[0].n,
    paidValue: Number(paid[0].v ?? 0),
    bySource,
  };
}

export async function listLeads(orgId: string) {
  return db
    .select({
      id: s.leads.id, fullName: s.leads.fullName, phone: s.leads.phone, email: s.leads.email,
      status: s.leads.status, source: s.leads.source, city: s.leads.city, tags: s.leads.tags,
      value: s.leads.estimatedValueIls, lastContactAt: s.leads.lastContactAt,
      createdAt: s.leads.createdAt, utmCampaign: s.leads.utmCampaign,
      ownerName: s.users.name, ownerId: s.leads.ownerId,
    })
    .from(s.leads)
    .leftJoin(s.users, eq(s.leads.ownerId, s.users.id))
    .where(eq(s.leads.orgId, orgId))
    .orderBy(desc(s.leads.updatedAt));
}

export async function getLead(id: string) {
  const [lead] = await db.select().from(s.leads).where(eq(s.leads.id, id));
  if (!lead) return null;
  const [owner] = lead.ownerId ? await db.select().from(s.users).where(eq(s.users.id, lead.ownerId)) : [null];
  const [taskRows, quoteRows, msgRows, payRows, docRows, actRows] = await Promise.all([
    db.select({ id: s.tasks.id, title: s.tasks.title, status: s.tasks.status, priority: s.tasks.priority, dueAt: s.tasks.dueAt, assignee: s.users.name })
      .from(s.tasks).leftJoin(s.users, eq(s.tasks.assigneeId, s.users.id)).where(eq(s.tasks.leadId, id)).orderBy(asc(s.tasks.dueAt)),
    db.select().from(s.quotes).where(eq(s.quotes.leadId, id)).orderBy(desc(s.quotes.createdAt)),
    db.select().from(s.messages).where(eq(s.messages.leadId, id)).orderBy(asc(s.messages.sentAt)),
    db.select().from(s.payments).where(eq(s.payments.leadId, id)).orderBy(desc(s.payments.createdAt)),
    db.select().from(s.accountingDocs).where(eq(s.accountingDocs.leadId, id)).orderBy(desc(s.accountingDocs.issuedAt)),
    db.select().from(s.activities).where(eq(s.activities.leadId, id)).orderBy(desc(s.activities.createdAt)).limit(20),
  ]);
  return { lead, owner, tasks: taskRows, quotes: quoteRows, messages: msgRows, payments: payRows, docs: docRows, activities: actRows };
}

export async function listTasks(orgId: string) {
  return db
    .select({
      id: s.tasks.id, title: s.tasks.title, description: s.tasks.description,
      status: s.tasks.status, priority: s.tasks.priority, dueAt: s.tasks.dueAt,
      leadId: s.tasks.leadId, leadName: s.leads.fullName, leadPhone: s.leads.phone,
      assigneeId: s.tasks.assigneeId, assigneeName: s.users.name,
      completedAt: s.tasks.completedAt,
    })
    .from(s.tasks)
    .leftJoin(s.leads, eq(s.tasks.leadId, s.leads.id))
    .leftJoin(s.users, eq(s.tasks.assigneeId, s.users.id))
    .where(eq(s.tasks.orgId, orgId))
    .orderBy(asc(s.tasks.dueAt));
}

export async function listQuotes(orgId: string) {
  return db
    .select({
      id: s.quotes.id, number: s.quotes.number, title: s.quotes.title, status: s.quotes.status,
      totalIls: s.quotes.totalIls, vatIls: s.quotes.vatIls, vatRate: s.quotes.vatRate,
      sentAt: s.quotes.sentAt, firstViewedAt: s.quotes.firstViewedAt, viewCount: s.quotes.viewCount,
      signedAt: s.quotes.signedAt, validUntil: s.quotes.validUntil, publicToken: s.quotes.publicToken,
      leadId: s.quotes.leadId, leadName: s.leads.fullName, leadPhone: s.leads.phone,
      creator: s.users.name,
    })
    .from(s.quotes)
    .innerJoin(s.leads, eq(s.quotes.leadId, s.leads.id))
    .leftJoin(s.users, eq(s.quotes.createdById, s.users.id))
    .where(eq(s.quotes.orgId, orgId))
    .orderBy(desc(s.quotes.number));
}

export async function getQuoteByToken(token: string) {
  const [q] = await db.select().from(s.quotes).where(eq(s.quotes.publicToken, token));
  if (!q) return null;
  const [lead] = await db.select().from(s.leads).where(eq(s.leads.id, q.leadId));
  const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, q.orgId));
  const items = await db.select().from(s.quoteItems).where(eq(s.quoteItems.quoteId, q.id)).orderBy(asc(s.quoteItems.sortOrder));
  const [sig] = await db.select().from(s.quoteSignatures).where(eq(s.quoteSignatures.quoteId, q.id));
  const [pay] = await db.select().from(s.payments).where(eq(s.payments.quoteId, q.id)).orderBy(desc(s.payments.createdAt)).limit(1);
  return { quote: q, lead, org, items, signature: sig ?? null, payment: pay ?? null };
}

export async function getQuoteFull(id: string) {
  const [q] = await db.select().from(s.quotes).where(eq(s.quotes.id, id));
  if (!q) return null;
  const [lead] = await db.select().from(s.leads).where(eq(s.leads.id, q.leadId));
  const [org] = await db.select().from(s.organizations).where(eq(s.organizations.id, q.orgId));
  const items = await db.select().from(s.quoteItems).where(eq(s.quoteItems.quoteId, q.id)).orderBy(asc(s.quoteItems.sortOrder));
  const [sig] = await db.select().from(s.quoteSignatures).where(eq(s.quoteSignatures.quoteId, q.id));
  return { quote: q, lead, org, items, signature: sig ?? null };
}

export async function listProducts(orgId: string) {
  return db.select().from(s.products).where(eq(s.products.orgId, orgId)).orderBy(asc(s.products.category), asc(s.products.name));
}

export async function listPayments(orgId: string) {
  return db
    .select({
      id: s.payments.id, status: s.payments.status, provider: s.payments.provider,
      amountIls: s.payments.amountIls, installments: s.payments.installments,
      last4: s.payments.last4, cardBrand: s.payments.cardBrand,
      transactionId: s.payments.transactionId, approvalNumber: s.payments.approvalNumber,
      payLinkUrl: s.payments.payLinkUrl, paidAt: s.payments.paidAt, createdAt: s.payments.createdAt,
      leadName: s.leads.fullName, quoteNumber: s.quotes.number,
    })
    .from(s.payments)
    .leftJoin(s.leads, eq(s.payments.leadId, s.leads.id))
    .leftJoin(s.quotes, eq(s.payments.quoteId, s.quotes.id))
    .where(eq(s.payments.orgId, orgId))
    .orderBy(desc(s.payments.createdAt));
}

export async function listDocs(orgId: string) {
  return db
    .select({
      id: s.accountingDocs.id, kind: s.accountingDocs.kind, provider: s.accountingDocs.provider,
      documentNumber: s.accountingDocs.documentNumber, documentUrl: s.accountingDocs.documentUrl,
      amountIls: s.accountingDocs.amountIls, vatIls: s.accountingDocs.vatIls,
      allocationNumber: s.accountingDocs.allocationNumber,
      allocationRequired: s.accountingDocs.allocationRequired,
      allocationStatus: s.accountingDocs.allocationStatus,
      issuedAt: s.accountingDocs.issuedAt, leadName: s.leads.fullName,
    })
    .from(s.accountingDocs)
    .leftJoin(s.leads, eq(s.accountingDocs.leadId, s.leads.id))
    .where(eq(s.accountingDocs.orgId, orgId))
    .orderBy(desc(s.accountingDocs.issuedAt));
}

export async function listTeam(orgId: string) {
  return db
    .select({
      userId: s.users.id, name: s.users.name, email: s.users.email, phone: s.users.phone,
      role: s.memberships.role, active: s.memberships.active, target: s.memberships.monthlyTargetIls,
    })
    .from(s.memberships)
    .innerJoin(s.users, eq(s.memberships.userId, s.users.id))
    .where(eq(s.memberships.orgId, orgId));
}

export async function teamPerformance(orgId: string) {
  const leadsPer = await db
    .select({ userId: s.leads.ownerId, total: count(), won: raw<number>`COUNT(*) FILTER (WHERE ${s.leads.status}='WON')`,
              wonValue: raw<number>`COALESCE(SUM(${s.leads.estimatedValueIls}) FILTER (WHERE ${s.leads.status}='WON'),0)` })
    .from(s.leads).where(eq(s.leads.orgId, orgId)).groupBy(s.leads.ownerId);
  const tasksPer = await db
    .select({ userId: s.tasks.assigneeId, open: raw<number>`COUNT(*) FILTER (WHERE ${s.tasks.status} IN ('OPEN','IN_PROGRESS'))`,
              overdue: raw<number>`COUNT(*) FILTER (WHERE ${s.tasks.status} IN ('OPEN','IN_PROGRESS') AND ${s.tasks.dueAt} < now())` })
    .from(s.tasks).where(eq(s.tasks.orgId, orgId)).groupBy(s.tasks.assigneeId);
  return { leadsPer, tasksPer };
}

export async function listIntegrations(orgId: string) {
  return db.select().from(s.integrations).where(eq(s.integrations.orgId, orgId));
}

export async function listWebhookEndpoints(orgId: string) {
  return db
    .select({
      id: s.webhookEndpoints.id, name: s.webhookEndpoints.name, slug: s.webhookEndpoints.slug,
      source: s.webhookEndpoints.source, fieldMap: s.webhookEndpoints.fieldMap,
      active: s.webhookEndpoints.active, hitCount: s.webhookEndpoints.hitCount,
      lastHitAt: s.webhookEndpoints.lastHitAt, autoCreateTask: s.webhookEndpoints.autoCreateTask,
      ownerName: s.users.name,
    })
    .from(s.webhookEndpoints)
    .leftJoin(s.users, eq(s.webhookEndpoints.defaultOwnerId, s.users.id))
    .where(eq(s.webhookEndpoints.orgId, orgId));
}

export async function listOutgoingWebhooks(orgId: string) {
  return db.select().from(s.outgoingWebhooks).where(eq(s.outgoingWebhooks.orgId, orgId));
}

export async function listTemplates(orgId: string) {
  return db.select().from(s.messageTemplates).where(eq(s.messageTemplates.orgId, orgId)).orderBy(desc(s.messageTemplates.useCount));
}

export async function listActivities(orgId: string, limit = 20) {
  return db
    .select({ id: s.activities.id, type: s.activities.type, summary: s.activities.summary,
              createdAt: s.activities.createdAt, leadId: s.activities.leadId, actor: s.users.name })
    .from(s.activities).leftJoin(s.users, eq(s.activities.actorId, s.users.id))
    .where(eq(s.activities.orgId, orgId)).orderBy(desc(s.activities.createdAt)).limit(limit);
}

export async function listNotifications(orgId: string) {
  return db.select().from(s.notifications).where(eq(s.notifications.orgId, orgId)).orderBy(desc(s.notifications.createdAt)).limit(30);
}
