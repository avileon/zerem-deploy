/**
 * נתוני דמו — "מיזוג אוויר כהן ובניו", עסק שירות קטן עם 4 עובדים.
 * נבנה כדי להדגים את כל הזרימה: ליד מוורדפרס → משימה → הצעה → חתימה → תשלום → חשבונית.
 */
import 'dotenv/config';
import crypto from 'node:crypto';
import { db, sql, schema as s } from './index';
import { normalizePhone, calcTotals, vatRateAt } from '../lib/israel';

const hoursAgo = (h: number) => new Date(Date.now() - h * 3600_000);
const daysAgo = (d: number) => new Date(Date.now() - d * 86_400_000);
const daysAhead = (d: number) => new Date(Date.now() + d * 86_400_000);
const tok = (n = 32) => crypto.randomBytes(n).toString('base64url').slice(0, n);

async function main() {
  console.log('🧹 מנקה…');
  for (const t of [
    'audit_logs', 'notifications', 'activities', 'webhook_logs', 'outgoing_webhooks',
    'webhook_endpoints', 'integrations', 'message_templates', 'messages',
    'accounting_docs', 'subscriptions', 'payments', 'otp_codes', 'quote_signatures',
    'quote_items', 'quotes', 'products', 'task_assignments', 'tasks', 'leads',
    'push_subscriptions', 'memberships', 'users', 'organizations', 'vat_rates',
  ]) await sql.unsafe(`TRUNCATE TABLE "${t}" CASCADE`);

  await db.insert(s.vatRates).values([
    { rate: '0.1700', effectiveFrom: new Date('2015-10-01'), note: 'הורדה ל-17%' },
    { rate: '0.1800', effectiveFrom: new Date('2025-01-01'), note: 'העלאה ל-18% — תקציב 2025' },
  ]);

  const [org] = await db.insert(s.organizations).values({
    name: 'מיזוג אוויר כהן ובניו',
    slug: 'cohen-hvac',
    legalName: 'כהן ובניו מיזוג אוויר בע״מ',
    vatId: '514783925',
    address: 'האומן 12',
    city: 'ראשון לציון',
    phone: '03-9876543',
    email: 'office@cohen-hvac.co.il',
    brandColor: '#0f766e',
    quoteValidDays: 14,
    quoteTerms: 'המחירים אינם כוללים עבודות חשמל. אחריות יצרן 3 שנים. תוקף ההצעה 14 יום.',
  }).returning();

  const users = await db.insert(s.users).values([
    { email: 'avi@vibit.co.il', name: 'אבי (בעלים)', phone: '+972501112233' },
    { email: 'yaron@cohen-hvac.co.il', name: 'ירון כהן', phone: '+972502223344' },
    { email: 'sivan@cohen-hvac.co.il', name: 'סיוון לוי', phone: '+972503334455' },
    { email: 'moti@cohen-hvac.co.il', name: 'מוטי אזולאי', phone: '+972504445566' },
  ]).returning();

  await db.insert(s.memberships).values([
    { orgId: org.id, userId: users[0].id, role: 'OWNER' },
    { orgId: org.id, userId: users[1].id, role: 'ADMIN', monthlyTargetIls: '80000' },
    { orgId: org.id, userId: users[2].id, role: 'SALES_REP', monthlyTargetIls: '60000' },
    { orgId: org.id, userId: users[3].id, role: 'SALES_REP', monthlyTargetIls: '60000' },
  ]);

  /* ── קטלוג ── */
  const products = await db.insert(s.products).values([
    { orgId: org.id, sku: 'AC-INV-12', name: 'מזגן עילי אינוורטר 1.25 כ״ס', unitPriceIls: '2450', costIls: '1600', category: 'מזגנים', unit: 'יח׳' },
    { orgId: org.id, sku: 'AC-INV-18', name: 'מזגן עילי אינוורטר 2 כ״ס', unitPriceIls: '3200', costIls: '2100', category: 'מזגנים' },
    { orgId: org.id, sku: 'AC-MINI', name: 'מיני מרכזי 3 כ״ס', unitPriceIls: '8900', costIls: '6200', category: 'מזגנים' },
    { orgId: org.id, sku: 'INST-STD', name: 'התקנה סטנדרטית', unitPriceIls: '850', costIls: '400', category: 'עבודה' },
    { orgId: org.id, sku: 'INST-COMP', name: 'התקנה מורכבת (מנוף / צנרת מעל 5מ׳)', unitPriceIls: '1800', costIls: '900', category: 'עבודה' },
    { orgId: org.id, sku: 'SERV-YR', name: 'חוזה שירות שנתי', unitPriceIls: '1200', costIls: '450', category: 'שירות' },
    { orgId: org.id, sku: 'CLEAN', name: 'ניקוי וחיטוי מזגן', unitPriceIls: '280', costIls: '90', category: 'שירות' },
  ]).returning();

  /* ── לידים ── */
  const raw: Array<[name: string, phone: string, email: string, status: typeof s.leadStatusEnum.enumValues[number], source: typeof s.leadSourceEnum.enumValues[number], city: string, owner: number, value: number, utm: [string, string, string] | null]> = [
    ['דנה מזרחי', '052-8123456', 'dana.m@gmail.com', 'QUOTED', 'WORDPRESS', 'ראשון לציון', 2, 12400, ['google', 'cpc', 'מזגנים-קיץ-2026']],
    ['אלי ברקוביץ', '054-7234567', 'eli.b@walla.co.il', 'NEGOTIATION', 'META_LEAD_ADS', 'רחובות', 3, 21500, ['facebook', 'paid_social', 'lead-gen-אוגוסט']],
    ['שרון פרץ', '050-6345678', 'sharon.p@gmail.com', 'WON', 'WORDPRESS', 'נס ציונה', 2, 8900, ['google', 'organic', '']],
    ['יוסי אלמוג', '053-5456789', 'yossi.a@outlook.com', 'NEW', 'META_LEAD_ADS', 'ראשון לציון', 3, 0, ['instagram', 'paid_social', 'lead-gen-אוגוסט']],
    ['מיכל שטרן', '058-4567890', 'michal.s@gmail.com', 'CONTACTED', 'PHONE', 'יבנה', 2, 3200, null],
    ['רון גבאי', '052-3678901', 'ron.g@gmail.com', 'QUALIFIED', 'WORDPRESS', 'רחובות', 3, 15600, ['google', 'cpc', 'מיני-מרכזי']],
    ['ליאת אשכנזי', '054-2789012', 'liat.a@gmail.com', 'WON', 'REFERRAL', 'ראשון לציון', 2, 4050, null],
    ['עומר דהן', '050-1890123', 'omer.d@gmail.com', 'LOST', 'WORDPRESS', 'לוד', 3, 9800, ['google', 'cpc', 'מזגנים-קיץ-2026']],
    ['נועה קפלן', '053-9901234', 'noa.k@gmail.com', 'NEW', 'WORDPRESS', 'נס ציונה', 2, 0, ['google', 'organic', '']],
    ['אבנר טל', '055-8012345', 'avner.t@gmail.com', 'QUOTED', 'WHATSAPP', 'ראשון לציון', 3, 6350, null],
    ['הדס בן-שמעון', '052-7123450', 'hadas.bs@gmail.com', 'CONTACTED', 'META_LEAD_ADS', 'רחובות', 2, 2450, ['facebook', 'paid_social', 'רימרקטינג']],
    ['גיל אוחיון', '054-6234501', 'gil.o@gmail.com', 'QUALIFIED', 'PHONE', 'יבנה', 3, 11200, null],
  ];

  const leadRows = raw.map(([name, phone, email, status, source, city, owner, value, utm], i) => {
    const p = normalizePhone(phone);
    return {
      orgId: org.id,
      fullName: name,
      phone: p.e164!,
      waChatId: p.waChatId,
      email,
      city,
      status,
      source,
      ownerId: users[owner].id,
      estimatedValueIls: value ? String(value) : null,
      utmSource: utm?.[0] ?? null,
      utmMedium: utm?.[1] ?? null,
      utmCampaign: utm?.[2] || null,
      landingPage: utm ? 'https://cohen-hvac.co.il/lp/summer' : null,
      tags: status === 'WON' ? ['לקוח'] : i % 3 === 0 ? ['דחוף'] : [],
      lostReason: status === 'LOST' ? 'בחר מתחרה זול יותר' : null,
      wonAt: status === 'WON' ? daysAgo(3 + i) : null,
      lastContactAt: hoursAgo([2, 5, 30, 1, 12, 8, 72, 200, 0.5, 20, 48, 6][i]),
      createdAt: daysAgo([4, 9, 18, 0, 6, 11, 25, 30, 0, 8, 14, 12][i]),
    };
  });
  const leads = await db.insert(s.leads).values(leadRows).returning();

  /* ── משימות ── */
  const taskRows: (typeof s.tasks.$inferInsert)[] = [
    { orgId: org.id, title: 'לחזור לדנה — אישור הצעה 1042', leadId: leads[0].id, assigneeId: users[2].id, createdById: users[1].id, priority: 'HIGH', dueAt: hoursAgo(3), status: 'OPEN' },
    { orgId: org.id, title: 'מדידה באתר — אלי ברקוביץ', leadId: leads[1].id, assigneeId: users[3].id, createdById: users[1].id, priority: 'URGENT', dueAt: hoursAgo(1), status: 'IN_PROGRESS' },
    { orgId: org.id, title: 'לתאם התקנה — שרון פרץ', leadId: leads[2].id, assigneeId: users[2].id, priority: 'NORMAL', dueAt: daysAhead(1), status: 'OPEN' },
    { orgId: org.id, title: 'שיחת היכרות ראשונה — יוסי אלמוג', leadId: leads[3].id, assigneeId: users[3].id, priority: 'HIGH', dueAt: hoursAgo(0.2), status: 'OPEN' },
    { orgId: org.id, title: 'לשלוח הצעה למיכל', leadId: leads[4].id, assigneeId: users[2].id, priority: 'NORMAL', dueAt: daysAhead(2), status: 'OPEN' },
    { orgId: org.id, title: 'הצעה למיני מרכזי — רון גבאי', leadId: leads[5].id, assigneeId: users[3].id, priority: 'HIGH', dueAt: daysAhead(1), status: 'IN_PROGRESS' },
    { orgId: org.id, title: 'לשלוח חשבונית — ליאת', leadId: leads[6].id, assigneeId: users[2].id, priority: 'LOW', dueAt: daysAhead(4), status: 'OPEN' },
    { orgId: org.id, title: 'מעקב אחרי אבנר טל', leadId: leads[9].id, assigneeId: users[3].id, priority: 'NORMAL', dueAt: daysAhead(3), status: 'OPEN' },
    { orgId: org.id, title: 'ניקוי שנתי — הדס', leadId: leads[10].id, assigneeId: users[2].id, priority: 'LOW', dueAt: daysAhead(6), status: 'OPEN' },
    { orgId: org.id, title: 'סגירת עסקה — גיל אוחיון', leadId: leads[11].id, assigneeId: users[3].id, priority: 'HIGH', dueAt: daysAhead(2), status: 'OPEN' },
    { orgId: org.id, title: 'התקנה הושלמה — שרון פרץ', leadId: leads[2].id, assigneeId: users[3].id, priority: 'NORMAL', status: 'DONE', completedAt: daysAgo(2), dueAt: daysAgo(2) },
    { orgId: org.id, title: 'הזמנת מלאי מהיבואן', assigneeId: users[1].id, priority: 'NORMAL', status: 'DONE', completedAt: daysAgo(1), dueAt: daysAgo(1) },
  ];
  const tasks = await db.insert(s.tasks).values(taskRows).returning();

  await db.insert(s.taskAssignments).values([
    { orgId: org.id, taskId: tasks[1].id, fromUserId: users[2].id, toUserId: users[3].id, byUserId: users[1].id, note: 'מוטי קרוב יותר לאזור', notifiedPush: true, notifiedWhatsapp: true, createdAt: hoursAgo(5) },
    { orgId: org.id, taskId: tasks[5].id, fromUserId: users[2].id, toUserId: users[3].id, byUserId: users[1].id, note: 'עומס על סיוון', notifiedPush: true, notifiedWhatsapp: true, createdAt: hoursAgo(20) },
  ]);

  /* ── הצעות מחיר ── */
  const vat = vatRateAt();

  async function makeQuote(leadIdx: number, number: number, lines: Array<[pIdx: number, qty: number, disc?: number]>, status: typeof s.quoteStatusEnum.enumValues[number], opts: { discountPercent?: number; sentDaysAgo?: number; viewed?: boolean; signed?: boolean } = {}) {
    const inputs = lines.map(([pIdx, qty, disc]) => ({
      quantity: qty,
      unitPriceIls: Number(products[pIdx].unitPriceIls),
      discountPercent: disc ?? 0,
      vatExempt: false,
    }));
    const t = calcTotals(inputs, { discountType: 'PERCENT', discountValue: opts.discountPercent ?? 0 });

    const [q] = await db.insert(s.quotes).values({
      orgId: org.id, leadId: leads[leadIdx].id, createdById: users[2].id,
      number, title: `הצעת מחיר — ${leads[leadIdx].fullName}`,
      status, publicToken: tok(32),
      subtotalIls: String(t.subtotalIls),
      discountType: 'PERCENT', discountValue: String(opts.discountPercent ?? 0),
      discountIls: String(t.discountIls),
      vatRate: String(vat), vatIls: String(t.vatIls), totalIls: String(t.totalIls),
      validUntil: daysAhead(14 - (opts.sentDaysAgo ?? 0)),
      terms: org.quoteTerms,
      sentAt: opts.sentDaysAgo != null ? daysAgo(opts.sentDaysAgo) : null,
      firstViewedAt: opts.viewed ? daysAgo((opts.sentDaysAgo ?? 1) - 0.5) : null,
      viewCount: opts.viewed ? 2 + leadIdx % 4 : 0,
      signedAt: opts.signed ? daysAgo((opts.sentDaysAgo ?? 2) - 1) : null,
      createdAt: daysAgo((opts.sentDaysAgo ?? 0) + 1),
    }).returning();

    await db.insert(s.quoteItems).values(lines.map(([pIdx, qty, disc], i) => {
      const p = products[pIdx];
      const lineTotal = qty * Number(p.unitPriceIls) * (1 - (disc ?? 0) / 100);
      return {
        orgId: org.id, quoteId: q.id, productId: p.id,
        name: p.name, unit: p.unit, quantity: String(qty),
        unitPriceIls: p.unitPriceIls, discountPercent: String(disc ?? 0),
        lineTotalIls: String(Math.round(lineTotal * 100) / 100), sortOrder: i,
      };
    }));
    return { quote: q, totals: t };
  }

  const q1 = await makeQuote(0, 1041, [[1, 3], [3, 3]], 'VIEWED', { discountPercent: 5, sentDaysAgo: 2, viewed: true });
  const q2 = await makeQuote(1, 1042, [[2, 2], [4, 2]], 'SENT', { sentDaysAgo: 1 });
  const q3 = await makeQuote(2, 1043, [[2, 1]], 'PAID', { sentDaysAgo: 5, viewed: true, signed: true });
  const q4 = await makeQuote(6, 1044, [[0, 1], [3, 1], [6, 2]], 'SIGNED', { sentDaysAgo: 4, viewed: true, signed: true });
  const q5 = await makeQuote(9, 1045, [[1, 2]], 'VIEWED', { sentDaysAgo: 3, viewed: true });
  const q6 = await makeQuote(5, 1046, [[2, 1], [4, 1]], 'DRAFT', {});

  /* ── חתימות ── */
  for (const q of [q3, q4]) {
    const snapshot = { number: q.quote.number, total: q.totals.totalIls, vatRate: vat, items: 'frozen' };
    await db.insert(s.quoteSignatures).values({
      orgId: org.id, quoteId: q.quote.id,
      signerName: leads.find((l) => l.id === q.quote.leadId)!.fullName,
      signerPhone: leads.find((l) => l.id === q.quote.leadId)!.phone,
      signatureImage: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
      documentSha256: crypto.createHash('sha256').update(JSON.stringify(snapshot)).digest('hex'),
      documentSnapshot: snapshot,
      otpVerified: true, otpChannel: 'WHATSAPP', otpVerifiedAt: q.quote.signedAt,
      ipAddress: '82.166.44.' + (10 + q.quote.number % 40),
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X)',
      signedAt: q.quote.signedAt!,
    });
  }

  /* ── תשלומים ── */
  const [pay1] = await db.insert(s.payments).values({
    orgId: org.id, leadId: leads[2].id, quoteId: q3.quote.id,
    provider: 'CARDCOM', status: 'PAID',
    amountIls: String(q3.totals.totalIls), installments: 3,
    lowProfileId: 'AA-1F3C-99', transactionId: '205078451', approvalNumber: '0094A1B',
    last4: '4821', cardBrand: 'Visa', returnValue: `quote-${q3.quote.id.slice(0, 8)}`,
    paidAt: daysAgo(3), createdAt: daysAgo(3),
  }).returning();

  await db.insert(s.payments).values({
    orgId: org.id, leadId: leads[6].id, quoteId: q4.quote.id,
    provider: 'CARDCOM', status: 'PENDING',
    amountIls: String(q4.totals.totalIls),
    lowProfileId: 'BB-7D21-04', returnValue: `quote-${q4.quote.id.slice(0, 8)}`,
    payLinkUrl: 'https://secure.cardcom.solutions/EA/LPC6/demo',
    createdAt: hoursAgo(6),
  });

  /* ── מסמכי חשבונאות ── */
  const exVat = q3.totals.taxableIls + q3.totals.exemptIls;
  await db.insert(s.accountingDocs).values({
    orgId: org.id, leadId: leads[2].id, quoteId: q3.quote.id, paymentId: pay1.id,
    provider: 'RIVHIT', kind: 'TAX_INVOICE_RECEIPT', externalTypeCode: 3,
    documentNumber: '5001', documentIdentity: crypto.randomUUID(),
    documentUrl: 'https://api.rivhit.co.il/doc/demo-5001.pdf',
    amountIls: String(q3.totals.totalIls), vatIls: String(q3.totals.vatIls),
    allocationRequired: exVat >= 5000,
    allocationNumber: exVat >= 5000 ? '77410258' : null,
    allocationStatus: exVat >= 5000 ? 'OK' : 'NOT_REQUIRED',
    sentToCustomerAt: daysAgo(3), issuedAt: daysAgo(3),
  });

  /* ── תבניות הודעה ── */
  await db.insert(s.messageTemplates).values([
    { orgId: org.id, name: 'שליחת הצעת מחיר', shortcut: 'הצעה', category: 'מכירות', useCount: 42,
      body: 'היי {{full_name}}, מצרף את הצעת המחיר שדיברנו עליה 🙂\nסה״כ: {{total}}\nלצפייה ולאישור: {{quote_link}}' },
    { orgId: org.id, name: 'תזכורת הצעה', shortcut: 'תזכורת', category: 'מכירות', useCount: 18,
      body: 'היי {{full_name}}, רק מוודא שההצעה הגיעה. תוקף ההצעה עד {{valid_until}}.\n{{quote_link}}' },
    { orgId: org.id, name: 'תיאום התקנה', shortcut: 'התקנה', category: 'תפעול', useCount: 27,
      body: 'שלום {{full_name}}, נשמח לתאם מועד התקנה. אילו ימים נוחים לך השבוע?' },
    { orgId: org.id, name: 'קישור תשלום', shortcut: 'תשלום', category: 'גבייה', useCount: 31,
      body: '{{full_name}}, לתשלום מאובטח בכרטיס אשראי:\n{{pay_link}}\nסכום: {{total}}' },
    { orgId: org.id, name: 'שליחת חשבונית', shortcut: 'חשבונית', category: 'גבייה', useCount: 22,
      body: 'תודה רבה {{full_name}}! מצורפת חשבונית מס/קבלה:\n{{invoice_link}}' },
  ]);

  /* ── הודעות ── */
  await db.insert(s.messages).values([
    { orgId: org.id, leadId: leads[0].id, direction: 'OUT', channel: 'WHATSAPP', externalId: 'wamid.demo1', body: 'היי דנה, מצרף את הצעת המחיר 🙂', status: 'READ', authorId: users[2].id, sentAt: daysAgo(2) },
    { orgId: org.id, leadId: leads[0].id, direction: 'IN', channel: 'WHATSAPP', externalId: 'wamid.demo2', body: 'תודה! אני בודקת עם בעלי וחוזרת', status: 'DELIVERED', sentAt: hoursAgo(30) },
    { orgId: org.id, leadId: leads[0].id, direction: 'IN', channel: 'WHATSAPP', externalId: 'wamid.demo3', body: 'אפשר לפצל ל-3 תשלומים?', status: 'DELIVERED', sentAt: hoursAgo(2) },
    { orgId: org.id, leadId: leads[1].id, direction: 'OUT', channel: 'WHATSAPP', externalId: 'wamid.demo4', body: 'שלום אלי, נשמח לקבוע מדידה באתר', status: 'DELIVERED', authorId: users[3].id, sentAt: hoursAgo(8) },
    { orgId: org.id, leadId: leads[1].id, direction: 'IN', channel: 'WHATSAPP', externalId: 'wamid.demo5', body: 'מחר בבוקר מתאים לי', status: 'DELIVERED', sentAt: hoursAgo(5) },
    { orgId: org.id, leadId: leads[3].id, direction: 'OUT', channel: 'WHATSAPP', externalId: 'wamid.demo6', body: 'היי יוסי, קיבלנו את פנייתך מהאתר. מתי נוח לדבר?', status: 'SENT', isAutomated: true, sentAt: hoursAgo(1) },
  ]);

  /* ── אינטגרציות ── */
  await db.insert(s.integrations).values([
    { orgId: org.id, provider: 'GREEN_API', enabled: true, status: 'OK', statusMessage: 'authorized',
      config: { idInstance: '7103xxxxxx', delaySendMessagesMilliseconds: 5000, waNumber: '+972 3-9876543' }, lastCheckedAt: hoursAgo(0.3) },
    { orgId: org.id, provider: 'CARDCOM', enabled: true, status: 'OK',
      config: { terminalNumber: 1000, mode: 'test', maxInstallments: 12 }, lastCheckedAt: hoursAgo(1) },
    { orgId: org.id, provider: 'RIVHIT', enabled: true, status: 'OK',
      config: { docTypeMap: { TAX_INVOICE_RECEIPT: 3, TAX_INVOICE: 1, RECEIPT: 2, QUOTE: 10 }, isSoleIssuer: true }, lastCheckedAt: hoursAgo(1) },
    { orgId: org.id, provider: 'FCM', enabled: false, status: 'UNKNOWN', config: {} },
  ]);

  /* ── webhooks ── */
  await db.insert(s.webhookEndpoints).values([
    { orgId: org.id, name: 'אלמנטור — טופס צור קשר', slug: 'wp-contact-8f3a2c', secret: tok(24), source: 'WORDPRESS',
      fieldMap: { 'form_fields[name]': 'fullName', 'form_fields[phone]': 'phone', 'form_fields[email]': 'email', 'form_fields[message]': 'notes' },
      defaultOwnerId: users[2].id, autoCreateTask: true, hitCount: 148, lastHitAt: hoursAgo(0.5) },
    { orgId: org.id, name: 'דף נחיתה — מבצע קיץ', slug: 'lp-summer-b71d40', secret: tok(24), source: 'WORDPRESS',
      fieldMap: { name: 'fullName', tel: 'phone', mail: 'email' },
      defaultOwnerId: users[3].id, autoCreateTask: true, hitCount: 92, lastHitAt: hoursAgo(4) },
    { orgId: org.id, name: 'Meta Lead Ads', slug: 'meta-leads-3c9e18', secret: tok(24), source: 'META_LEAD_ADS',
      fieldMap: { full_name: 'fullName', phone_number: 'phone', email: 'email' },
      defaultOwnerId: users[3].id, autoCreateTask: true, hitCount: 61, lastHitAt: hoursAgo(9) },
  ]);

  await db.insert(s.outgoingWebhooks).values([
    { orgId: org.id, name: 'Google Sheets — עסקאות סגורות', url: 'https://hook.make.com/abc123', secret: tok(24), events: ['deal.won', 'payment.received'] },
    { orgId: org.id, name: 'Zapier — הצעה נחתמה', url: 'https://hooks.zapier.com/hooks/catch/999/xyz', secret: tok(24), events: ['quote.signed'] },
  ]);

  /* ── פעילות והתראות ── */
  await db.insert(s.activities).values([
    { orgId: org.id, type: 'lead.created', leadId: leads[3].id, summary: 'ליד חדש נקלט מטופס אלמנטור', data: { source: 'WORDPRESS' }, createdAt: hoursAgo(1) },
    { orgId: org.id, type: 'quote.viewed', leadId: leads[0].id, summary: 'דנה מזרחי צפתה בהצעה 1041 (פעם 2)', createdAt: hoursAgo(4) },
    { orgId: org.id, type: 'quote.signed', leadId: leads[6].id, summary: 'ליאת אשכנזי חתמה על הצעה 1044', createdAt: daysAgo(3) },
    { orgId: org.id, type: 'payment.received', leadId: leads[2].id, actorId: users[2].id, summary: `תשלום התקבל — ${q3.totals.totalIls} ₪ ב-3 תשלומים`, createdAt: daysAgo(3) },
    { orgId: org.id, type: 'task.reassigned', leadId: leads[1].id, actorId: users[1].id, summary: 'משימה הועברה מסיוון למוטי', createdAt: hoursAgo(5) },
    { orgId: org.id, type: 'doc.issued', leadId: leads[2].id, summary: 'חשבונית מס/קבלה 5001 הונפקה בריווחית · מספר הקצאה 77410258', createdAt: daysAgo(3) },
  ]);

  await db.insert(s.notifications).values([
    { orgId: org.id, userId: users[2].id, channel: 'PUSH', title: 'דנה מזרחי צפתה בהצעה', body: 'הצעה 1041 נצפתה זה עתה — רגע טוב להתקשר', url: '/leads', deliveredAt: hoursAgo(4) },
    { orgId: org.id, userId: users[3].id, channel: 'WHATSAPP', title: 'משימה חדשה הוקצתה לך', body: 'מדידה באתר — אלי ברקוביץ', url: '/tasks', deliveredAt: hoursAgo(5) },
    { orgId: org.id, userId: users[0].id, channel: 'IN_APP', title: 'תשלום התקבל', body: `${q3.totals.totalIls} ₪ — שרון פרץ`, url: '/payments', deliveredAt: daysAgo(3), readAt: daysAgo(3) },
  ]);

  console.log('✅ נטען:', {
    org: org.name, users: users.length, leads: leads.length,
    tasks: tasks.length, products: products.length, quotes: 6, vat: `${(vat * 100).toFixed(0)}%`,
  });
  await sql.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
