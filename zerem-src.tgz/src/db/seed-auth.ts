/**
 * זריעת אימות.
 *
 * יוצר: מנהל-על, סיסמאות לצוות הדמו, ועסק שני.
 *
 * ⚠️ העסק השני אינו קישוט. בלעדיו אי אפשר לבדוק בידוד דיירים —
 * ובידוד שלא נבדק הוא בידוד שלא קיים.
 */
import 'dotenv/config';
import { eq, sql as raw } from 'drizzle-orm';
import { db, sql, schema as s } from './index';
import { hashPassword } from '../lib/auth/password';
import { createBusiness, createInvitation } from '../lib/auth/accounts';
import { normalizePhone } from '../lib/israel';

const CONSOLE_EMAIL = process.env.SEED_CONSOLE_EMAIL ?? 'avi@vibit.co.il';

/**
 * ⚠️ סיסמת ברירת מחדל קיימת **רק** כשהמשתנה מוגדר במפורש.
 * בלעדיו, המנהל נוצר במצב PENDING ומודפס קישור חד-פעמי לקביעת סיסמה.
 * סיסמה קבועה שמגיעה עם הקוד לפרודקשן היא דלת אחורית, לא נוחות.
 */
const DEMO_PASSWORD = process.env.SEED_DEMO_PASSWORD ?? null;
const IS_DEMO = DEMO_PASSWORD !== null;

async function main() {
  console.log('🔐 זורע אימות…');

  /* ── מנהל-על ── */
  const [existingAdmin] = await db.select().from(s.platformAdmins)
    .where(eq(s.platformAdmins.email, CONSOLE_EMAIL)).limit(1);

  let adminInvite: string | null = null;

  if (!existingAdmin) {
    const [admin] = await db.insert(s.platformAdmins).values({
      email: CONSOLE_EMAIL,
      name: 'אבי',
      passwordHash: IS_DEMO ? await hashPassword(DEMO_PASSWORD!) : null,
      status: IS_DEMO ? 'ACTIVE' : 'PENDING',
      isOwner: true,
    }).returning();

    if (!IS_DEMO) {
      const inv = await createInvitation({
        email: CONSOLE_EMAIL, adminId: admin.id, invitedBy: 'system:seed',
      });
      adminInvite = inv.token;
    }
    console.log(`  ✓ מנהל-על: ${CONSOLE_EMAIL}`);
  } else {
    console.log('  ✓ מנהל-על כבר קיים');
  }

  /* ── סיסמאות לצוות הדמו — רק במצב דמו ── */
  const hash = IS_DEMO ? await hashPassword(DEMO_PASSWORD!) : null;
  if (IS_DEMO) {
    const users = await db.select().from(s.users);
    let updated = 0;
    for (const u of users) {
      if (!u.passwordHash) {
        await db.update(s.users).set({ passwordHash: hash, status: 'ACTIVE' })
          .where(eq(s.users.id, u.id));
        updated++;
      }
    }
    if (updated) console.log(`  ✓ ${updated} משתמשי דמו קיבלו סיסמה`);
  }

  /* ── עסק שני — לבדיקת בידוד ── */
  const [second] = await db.select().from(s.organizations)
    .where(eq(s.organizations.slug, 'siman-shel-shalom')).limit(1);

  if (!second) {
    const r = await createBusiness({
      businessName: 'סימן של שלום — שיפוצים',
      legalName: 'סימן של שלום בע״מ',
      vatId: '515987321',
      managerName: 'שלום מזרחי',
      managerEmail: 'shalom@siman.co.il',
      managerPhone: '052-9876543',
      planId: 'basic',
      interval: 'MONTHLY',
      mode: 'ACTIVE',
      createdBy: 'system:seed',
    });

    if (r.ok) {
      if (IS_DEMO) {
        await db.update(s.users).set({ passwordHash: hash, status: 'ACTIVE' })
          .where(eq(s.users.id, r.data.userId));
      }

      // כמה לידים משלו — כדי שהבדיקה תראה הפרדה אמיתית ולא רק שני חשבונות ריקים
      const p1 = normalizePhone('054-1112223');
      const p2 = normalizePhone('053-4445556');
      await db.insert(s.leads).values([
        { orgId: r.data.orgId, fullName: 'דנה שיפוצים לקוחה', phone: p1.e164!,
          waChatId: p1.waChatId, status: 'NEW', source: 'MANUAL',
          city: 'חיפה', estimatedValueIls: '18000' },
        { orgId: r.data.orgId, fullName: 'מוטי בן חמו', phone: p2.e164!,
          waChatId: p2.waChatId, status: 'QUALIFIED', source: 'WORDPRESS',
          city: 'קריית ביאליק', estimatedValueIls: '42000' },
      ]).onConflictDoNothing();

      console.log(`  ✓ עסק שני נפתח: ${r.data.slug} (shalom@siman.co.il)`);
    } else {
      console.log('  ⚠ פתיחת העסק השני נכשלה:', r.error);
    }
  } else {
    console.log('  ✓ העסק השני כבר קיים');
  }

  /* ── סיכום ── */
  const [counts] = await db.execute<Record<string, number>>(raw`
    SELECT (SELECT COUNT(*)::int FROM organizations) AS orgs,
           (SELECT COUNT(*)::int FROM users) AS users,
           (SELECT COUNT(*)::int FROM platform_admins) AS admins
  `);

  console.log('');
  console.log(`  ${counts?.orgs} ארגונים · ${counts?.users} משתמשים · ${counts?.admins} מנהלי מערכת`);

  if (IS_DEMO) {
    console.log('  ═══ פרטי כניסה (מצב דמו) ═══');
    console.log(`  קונסולה : ${CONSOLE_EMAIL} / ${DEMO_PASSWORD}`);
    console.log(`  עסק א׳  : avi@vibit.co.il / ${DEMO_PASSWORD}`);
    console.log(`  עסק ב׳  : shalom@siman.co.il / ${DEMO_PASSWORD}`);
    console.log('  ⚠️ סיסמאות דמו. אל תשתמש בהן בפרודקשן.');
  } else if (adminInvite) {
    const origin = process.env.APP_ORIGIN ?? '';
    console.log('  ═══ קביעת סיסמה למנהל-העל ═══');
    console.log(`  ${origin}/console/set-password?token=${adminInvite}&console=1`);
    console.log('  ⚠️ קישור חד-פעמי, תקף 72 שעות. מוצג רק כאן.');
  } else {
    console.log('  ✓ מנהל-על קיים — אין קישור חדש. איפוס דרך הקונסולה.');
  }

  await sql.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
