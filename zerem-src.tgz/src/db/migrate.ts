/**
 * מיגרציות — הדרך היחידה לשנות סכמה בפרודקשן.
 *
 * ⚠️ למה זה החליף את `drizzle-kit push --force`:
 * `push` משווה סכמה לבסיס נתונים ומייצר DDL בזמן אמת. כשהוא מזהה
 * עמודה שהשם שלה השתנה הוא לא יודע שזו אותה עמודה — הוא מוחק ויוצר
 * מחדש, והנתונים נעלמים בשקט. `--force` אומר לו לא לשאול.
 * מיגרציות הן קבצי SQL מגורסאות שרצים פעם אחת, לפי הסדר, ונרשמים.
 *
 * אימוץ בסיס נתונים קיים (baseline):
 * הדרופלט כבר מכיל את כל הטבלאות. הרצת 0000 עליו תיכשל על
 * "already exists". לכן: אם יש טבלאות אבל אין יומן מיגרציות —
 * מסמנים את 0000 כ"הוחלה" בלי להריץ אותה, וממשיכים מ-0001 והלאה.
 */
import 'dotenv/config';
import { createHash } from 'node:crypto';
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import { db, sql } from './index';

const FOLDER = 'drizzle';
const JOURNAL = join(FOLDER, 'meta', '_journal.json');

interface JournalEntry { idx: number; tag: string; when: number }

async function tableExists(name: string): Promise<boolean> {
  const [r] = await sql<{ ok: boolean }[]>`
    SELECT EXISTS (
      SELECT 1 FROM information_schema.tables
      WHERE table_schema = 'public' AND table_name = ${name}
    ) AS ok`;
  return r?.ok ?? false;
}

async function migrationsTableExists(): Promise<boolean> {
  const [r] = await sql<{ ok: boolean }[]>`
    SELECT EXISTS (
      SELECT 1 FROM information_schema.tables
      WHERE table_schema = 'drizzle' AND table_name = '__drizzle_migrations'
    ) AS ok`;
  return r?.ok ?? false;
}

/** אותו hash ש-drizzle מחשב — SHA-256 על תוכן קובץ ה-SQL */
function hashOf(tag: string): string {
  const p = join(FOLDER, `${tag}.sql`);
  return createHash('sha256').update(readFileSync(p, 'utf8')).digest('hex');
}

async function baseline(entry: JournalEntry) {
  await sql.unsafe(`CREATE SCHEMA IF NOT EXISTS drizzle`);
  await sql.unsafe(`
    CREATE TABLE IF NOT EXISTS drizzle."__drizzle_migrations" (
      id SERIAL PRIMARY KEY,
      hash text NOT NULL,
      created_at bigint
    )`);
  await sql`
    INSERT INTO drizzle."__drizzle_migrations" (hash, created_at)
    VALUES (${hashOf(entry.tag)}, ${entry.when})`;
  console.log(`  ✓ ${entry.tag} סומנה כהוחלה (baseline) — לא הורצה`);
}

async function main() {
  console.log('🗄️  מיגרציות…');

  if (!existsSync(JOURNAL)) {
    console.log('  ⚠ אין תיקיית מיגרציות — דלג');
    await sql.end();
    return;
  }

  const journal = JSON.parse(readFileSync(JOURNAL, 'utf8')) as { entries: JournalEntry[] };
  const entries = journal.entries ?? [];
  if (!entries.length) {
    console.log('  ⚠ היומן ריק — דלג');
    await sql.end();
    return;
  }

  const hasData = await tableExists('organizations');
  const hasJournal = await migrationsTableExists();

  if (hasData && !hasJournal) {
    console.log('  → בסיס נתונים קיים ללא יומן. מאמץ מיגרציות (baseline)…');
    await baseline(entries[0]);
  }

  const before = hasJournal || (hasData && !hasJournal)
    ? await appliedCount()
    : 0;

  await migrate(db, { migrationsFolder: FOLDER });

  const after = await appliedCount();
  const n = after - before;
  console.log(n > 0
    ? `  ✓ ${n} מיגרציות חדשות הוחלו`
    : '  ✓ הסכמה מעודכנת — אין מה להחיל');

  await sql.end();
}

async function appliedCount(): Promise<number> {
  if (!(await migrationsTableExists())) return 0;
  const [r] = await sql<{ n: number }[]>`
    SELECT COUNT(*)::int AS n FROM drizzle."__drizzle_migrations"`;
  return Number(r?.n ?? 0);
}

main().catch((e) => {
  console.error('✗ המיגרציה נכשלה:', e);
  // ⚠️ יציאה עם שגיאה מפילה את האתחול בכוונה.
  // אפליקציה שרצה על סכמה חלקית גרועה מאפליקציה שלא עולה.
  process.exit(1);
});
