/**
 * בדיקות אבטחה — מול השרת החי, דרך HTTP אמיתי.
 *
 * הרצה: npx tsx src/db/security-test.ts [baseUrl]
 *
 * הבדיקות כאן אינן בודקות "האם הקוד נראה נכון" אלא "האם תוקף מצליח".
 * כל תרחיש מדמה ניסיון אמיתי: להיכנס בלי סשן, לראות נתוני עסק אחר,
 * להסלים מעובד למנהל, ולהגיע לקונסולה מחשבון לקוח.
 */
const BASE = process.argv[2] ?? 'http://localhost:3222';
const PW = process.env.SEED_DEMO_PASSWORD ?? 'ZeremDemo2026!';

let pass = 0, fail = 0;
const lines: string[] = [];

function chk(name: string, ok: boolean, detail?: string) {
  if (ok) { pass++; lines.push(`  ✓ ${name}`); }
  else { fail++; lines.push(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); }
}
const group = (t: string) => lines.push(`\n${t}`);

/* ── לקוח HTTP עם ניהול עוגיות ידני ── */
class Client {
  private jar = new Map<string, string>();

  private cookieHeader() {
    return [...this.jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }

  private absorb(res: Response) {
    const raw = res.headers.getSetCookie?.() ?? [];
    for (const c of raw) {
      const [pair] = c.split(';');
      const idx = pair.indexOf('=');
      const k = pair.slice(0, idx).trim();
      const v = pair.slice(idx + 1).trim();
      if (v === '' ) this.jar.delete(k); else this.jar.set(k, v);
    }
  }

  async fetch(path: string, init: RequestInit = {}) {
    const res = await fetch(BASE + path, {
      ...init,
      redirect: 'manual',
      headers: {
        ...(init.headers ?? {}),
        ...(this.jar.size ? { cookie: this.cookieHeader() } : {}),
      },
    });
    this.absorb(res);
    return res;
  }

  async json(path: string, body: unknown) {
    const res = await this.fetch(path, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    let data: any = null;
    try { data = await res.json(); } catch { /* empty */ }
    return { status: res.status, data };
  }

  async text(path: string) {
    const res = await this.fetch(path);
    const body = res.status < 300 ? await res.text() : '';
    return { status: res.status, location: res.headers.get('location'), body };
  }

  hasCookie(name: string) { return this.jar.has(name); }
  clear() { this.jar.clear(); }
}

async function main() {
  /* ═══════════ 1. גישה בלי סשן ═══════════ */
  group('1. גישה ללא התחברות');
  {
    const anon = new Client();
    for (const p of ['/', '/leads', '/tasks', '/team', '/settings/billing', '/reports']) {
      const r = await anon.text(p);
      chk(`${p} מפנה להתחברות`,
          r.status === 307 || r.status === 302,
          `status=${r.status}`);
    }
    const c = await anon.text('/console');
    chk('/console מפנה להתחברות הקונסולה',
        (c.status === 307 || c.status === 302) && (c.location ?? '').includes('/console/login'),
        `${c.status} → ${c.location}`);

    const api = await anon.json('/api/team', { action: 'add', name: 'x', email: 'x@y.co.il' });
    chk('POST /api/team ללא סשן נדחה', api.status === 401, `status=${api.status}`);

    const cons = await anon.json('/api/console/businesses', { businessName: 'פריצה' });
    chk('POST /api/console/businesses ללא סשן נדחה', cons.status === 401, `status=${cons.status}`);
  }

  /* ═══════════ 2. הודעת שגיאה אחידה ═══════════ */
  group('2. התחברות');
  {
    const c = new Client();
    const bad = await c.json('/api/auth/login', { email: 'nobody@nowhere.co.il', password: 'x' });
    const wrong = await c.json('/api/auth/login', { email: 'avi@vibit.co.il', password: 'wrong-password-here' });
    chk('משתמש לא קיים נדחה', bad.status === 401);
    chk('סיסמה שגויה נדחית', wrong.status === 401);
    chk('⚠ הודעת השגיאה זהה — לא מדליף אילו כתובות רשומות',
        bad.data?.error === wrong.data?.error,
        `"${bad.data?.error}" מול "${wrong.data?.error}"`);
    chk('לא נוצרה עוגייה בכישלון', !c.hasCookie('zerem_session'));
  }

  /* ═══════════ 3. בידוד דיירים ═══════════ */
  group('3. בידוד דיירים — הבדיקה הקריטית');
  const orgA = new Client();
  const orgB = new Client();
  {
    const a = await orgA.json('/api/auth/login', { email: 'avi@vibit.co.il', password: PW });
    const b = await orgB.json('/api/auth/login', { email: 'shalom@siman.co.il', password: PW });
    chk('התחברות עסק א׳', a.status === 200, JSON.stringify(a.data));
    chk('התחברות עסק ב׳', b.status === 200, JSON.stringify(b.data));

    if (a.status === 200 && b.status === 200) {
      const entA = await orgA.fetch('/api/billing/entitlements').then((r) => r.json());
      const entB = await orgB.fetch('/api/billing/entitlements').then((r) => r.json());
      chk('כל עסק מקבל orgId משלו',
          entA.orgId !== entB.orgId, `${entA.orgId} מול ${entB.orgId}`);
      chk('כל עסק מקבל את החבילה שלו',
          entA.planName !== entB.planName || entA.planId !== entB.planId,
          `${entA.planName} מול ${entB.planName}`);

      const leadsA = await orgA.text('/leads');
      const leadsB = await orgB.text('/leads');
      chk('⚠ עסק ב׳ לא רואה לידים של עסק א׳',
          !leadsB.body.includes('אלי ברקוביץ') && !leadsB.body.includes('יוסי אלמוג'),
          'נמצא ליד של עסק א׳ במסך של עסק ב׳');
      chk('⚠ עסק א׳ לא רואה לידים של עסק ב׳',
          !leadsA.body.includes('מוטי בן חמו') && !leadsA.body.includes('דנה שיפוצים'),
          'נמצא ליד של עסק ב׳ במסך של עסק א׳');
      chk('כל עסק רואה את השם שלו',
          leadsA.body.includes('כהן') && leadsB.body.includes('שלום'));

      const invA = await orgA.fetch('/api/billing/invoices').then((r) => r.json());
      const invB = await orgB.fetch('/api/billing/invoices').then((r) => r.json());
      const idsA = new Set((invA.invoices ?? []).map((x: any) => x.id));
      const overlap = (invB.invoices ?? []).filter((x: any) => idsA.has(x.id));
      chk('⚠ חשבוניות לא דולפות בין עסקים', overlap.length === 0, `${overlap.length} חופפות`);
    }
  }

  /* ═══════════ 4. הסלמת הרשאות ═══════════ */
  group('4. הסלמת הרשאות — עובד');
  {
    const emp = new Client();
    const r = await emp.json('/api/auth/login', { email: 'sivan@cohen-hvac.co.il', password: PW });
    chk('התחברות עובד', r.status === 200, JSON.stringify(r.data));

    if (r.status === 200) {
      const team = await emp.text('/team');
      chk('⚠ עובד לא נכנס למסך צוות',
          team.status === 307 || team.status === 302, `status=${team.status}`);

      const billing = await emp.text('/settings/billing');
      chk('⚠ עובד לא נכנס למסך חיוב',
          billing.status === 307 || billing.status === 302, `status=${billing.status}`);

      const add = await emp.json('/api/team', {
        action: 'add', name: 'מתחזה', email: 'imposter@evil.co.il', role: 'MANAGER',
      });
      chk('⚠ עובד לא יכול להוסיף משתמש דרך ה-API', add.status === 403, `status=${add.status}`);

      const console_ = await emp.text('/console');
      chk('⚠ עובד לא מגיע לקונסולה',
          console_.status === 307 || console_.status === 302);

      const consoleApi = await emp.json('/api/console/businesses', { businessName: 'x', managerEmail: 'a@b.co.il', managerName: 'x' });
      chk('⚠ עוגיית לקוח לא פותחת את API הקונסולה', consoleApi.status === 401, `status=${consoleApi.status}`);
    }
  }

  /* ═══════════ 5. מנהל עסק אחד מול עסק אחר ═══════════ */
  group('5. מנהל של עסק א׳ מול משתמשי עסק ב׳');
  {
    // מנהל ב׳ שולף את מזהה המשתמש שלו עצמו מהצוות
    const teamB = await orgB.text('/team');
    const m = teamB.body.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g) ?? [];
    const foreignUserId = m[0];

    if (foreignUserId) {
      const r1 = await orgA.json('/api/team', { action: 'resend', userId: foreignUserId });
      chk('⚠ מנהל א׳ לא מייצר קישור איפוס למשתמש של עסק ב׳',
          r1.status === 404, `status=${r1.status}`);
      const r2 = await orgA.json('/api/team', { action: 'remove', userId: foreignUserId });
      chk('⚠ מנהל א׳ לא מסיר משתמש של עסק ב׳',
          r2.status === 404, `status=${r2.status}`);
    } else {
      chk('⚠ מנהל א׳ לא נוגע במשתמשי עסק ב׳', false, 'לא נמצא מזהה משתמש לבדיקה');
    }
  }

  /* ═══════════ 6. הקונסולה ═══════════ */
  group('6. קונסולת מנהל-על');
  {
    const con = new Client();
    // ⚠️ חשוב לבחור משתמש לקוח שאינו גם מנהל-על. אותה כתובת יכולה
    // להופיע בשתי הטבלאות (אתה גם בעל הפלטפורמה וגם משתמש בעסק דמו),
    // ואז ההתחברות מצליחה בצדק — אלה שני חשבונות נפרדים.
    const bad = await con.json('/api/auth/console-login', {
      email: 'yaron@cohen-hvac.co.il', password: PW,   // משתמש לקוח תקף, לא מנהל-על
    });
    chk('⚠ משתמש לקוח לא נכנס לקונסולה עם הסיסמה שלו',
        bad.status === 401, `status=${bad.status}`);

    const bad2 = await con.json('/api/auth/console-login', {
      email: 'shalom@siman.co.il', password: PW,
    });
    chk('⚠ מנהל עסק לא נכנס לקונסולה', bad2.status === 401, `status=${bad2.status}`);

    const ok = await con.json('/api/auth/console-login', {
      email: process.env.SEED_CONSOLE_EMAIL ?? 'avi@vibit.co.il', password: PW,
    });
    chk('מנהל-על מתחבר', ok.status === 200, JSON.stringify(ok.data));

    if (ok.status === 200) {
      chk('נוצרה עוגיית קונסולה נפרדת',
          con.hasCookie('zerem_console') && !con.hasCookie('zerem_session'));

      const page = await con.text('/console');
      chk('סקירת הקונסולה נטענת', page.status === 200, `status=${page.status}`);
      chk('הקונסולה מציגה את שני העסקים',
          page.body.includes('כהן') && page.body.includes('שלום'));

      const biz = await con.text('/console/businesses');
      chk('מסך העסקים נטען', biz.status === 200);

      // עוגיית קונסולה לא פותחת את אפליקציית הלקוח
      const tenant = await con.text('/leads');
      chk('⚠ עוגיית קונסולה לא נותנת גישה לאפליקציית הלקוח',
          tenant.status === 307 || tenant.status === 302, `status=${tenant.status}`);
    }
  }

  /* ═══════════ 7. יציאה ═══════════ */
  group('7. יציאה מבטלת את הסשן');
  {
    const c = new Client();
    await c.json('/api/auth/login', { email: 'avi@vibit.co.il', password: PW });
    const before = await c.text('/leads');
    await c.json('/api/auth/logout', { kind: 'TENANT' });
    const after = await c.text('/leads');
    chk('לפני היציאה — גישה', before.status === 200, `status=${before.status}`);
    chk('אחרי היציאה — חסום', after.status === 307 || after.status === 302, `status=${after.status}`);
  }

  /* ═══════════ 8. הגבלת קצב ═══════════ */
  group('8. הגבלת קצב על התחברות');
  {
    const c = new Client();
    const email = `bruteforce-${Date.now()}@test.co.il`;
    let blocked = false;
    for (let i = 0; i < 12; i++) {
      const r = await c.json('/api/auth/login', { email, password: `guess-${i}` });
      if (r.status === 429) { blocked = true; break; }
    }
    chk('⚠ ניחוש סיסמאות בכוח נחסם', blocked, 'לא נחסם אחרי 12 ניסיונות');
  }

  console.log(lines.join('\n'));
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} עברו · ${fail} נכשלו\n`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
