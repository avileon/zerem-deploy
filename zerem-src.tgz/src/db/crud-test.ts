/**
 * בדיקות CRUD — מול השרת החי, כמשתמש מחובר.
 * הרצה: npx tsx src/db/crud-test.ts [baseUrl]
 *
 * הבדיקות האלה נכתבו אחרי שהתגלה שכפתורי ההוספה במסכים לא היו
 * מחוברים לכלום. לכן הן בודקות את מה שהמשתמש עושה בפועל:
 * להוסיף, לערוך, לסמן, ולוודא שזה שרד רענון.
 */
const BASE = process.argv[2] ?? 'http://localhost:3222';
const PW = process.env.SEED_DEMO_PASSWORD ?? 'ZeremDemo2026!';

let pass = 0, fail = 0;
const lines: string[] = [];
const chk = (n: string, ok: boolean, d?: string) => {
  if (ok) { pass++; lines.push(`  ✓ ${n}`); }
  else { fail++; lines.push(`  ✗ ${n}${d ? ` — ${d}` : ''}`); }
};
const group = (t: string) => lines.push(`\n${t}`);

class Client {
  private jar = new Map<string, string>();
  private absorb(res: Response) {
    for (const c of res.headers.getSetCookie?.() ?? []) {
      const [pair] = c.split(';');
      const i = pair.indexOf('=');
      const v = pair.slice(i + 1).trim();
      if (v) this.jar.set(pair.slice(0, i).trim(), v);
      else this.jar.delete(pair.slice(0, i).trim());
    }
  }
  async req(path: string, method = 'GET', body?: unknown) {
    const res = await fetch(BASE + path, {
      method, redirect: 'manual',
      headers: {
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(this.jar.size ? { cookie: [...this.jar].map(([k, v]) => `${k}=${v}`).join('; ') } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    this.absorb(res);
    let data: any = null;
    const txt = await res.text();
    try { data = JSON.parse(txt); } catch { data = null; }
    return { status: res.status, data, text: txt };
  }
}

async function main() {
  const mgr = new Client();
  const emp = new Client();

  group('0. התחברות');
  {
    const a = await mgr.req('/api/auth/login', 'POST', { email: 'shalom@siman.co.il', password: PW });
    const b = await emp.req('/api/auth/login', 'POST', { email: 'sivan@cohen-hvac.co.il', password: PW });
    chk('מנהל', a.status === 200, JSON.stringify(a.data));
    chk('עובד', b.status === 200, JSON.stringify(b.data));
    if (a.status !== 200) { console.log(lines.join('\n')); process.exit(1); }
  }

  /* ═══════ לידים ═══════ */
  group('1. לידים');
  const phone = `05${Math.floor(20000000 + Math.random() * 9000000)}`;
  let leadId = '';
  {
    const r = await mgr.req('/api/crm/leads', 'POST', {
      fullName: 'בדיקה אוטומטית', phone, city: 'תל אביב', estimatedValueIls: 5000,
    });
    chk('יצירת ליד', r.status === 200 && r.data?.ok, JSON.stringify(r.data));
    leadId = r.data?.data?.id ?? '';
    chk('לא סומן ככפילות', r.data?.data?.duplicate === false);

    // אותו טלפון שוב → מפנה לקיים, לא יוצר כפילות
    const dup = await mgr.req('/api/crm/leads', 'POST', { fullName: 'שוב', phone });
    chk('⚠ טלפון קיים מחזיר את הליד הקיים ולא יוצר כפילות',
        dup.data?.data?.duplicate === true && dup.data?.data?.id === leadId,
        JSON.stringify(dup.data));

    const bad = await mgr.req('/api/crm/leads', 'POST', { fullName: 'ללא טלפון', phone: '123' });
    chk('טלפון לא תקין נדחה', bad.status === 400, JSON.stringify(bad.data));

    const noName = await mgr.req('/api/crm/leads', 'POST', { fullName: '', phone: '0521111111' });
    chk('שם ריק נדחה', noName.status === 400);
  }

  group('2. עדכון ליד');
  {
    const r = await mgr.req('/api/crm/leads', 'PATCH', {
      id: leadId, status: 'QUALIFIED', estimatedValueIls: 9000, city: 'חיפה',
    });
    chk('עדכון סטטוס וערך', r.status === 200 && r.data?.ok, JSON.stringify(r.data));

    const page = await mgr.req('/leads');
    chk('⚠ השינוי שרד — מופיע במסך אחרי טעינה מחדש',
        page.text.includes('בדיקה אוטומטית') && page.text.includes('חיפה'));

    const ghost = await mgr.req('/api/crm/leads', 'PATCH',
      { id: '00000000-0000-4000-8000-000000000000', status: 'WON' });
    chk('עדכון ליד לא קיים נדחה', ghost.status === 400);
  }

  /* ═══════ משימות ═══════ */
  group('3. משימות');
  let taskId = '';
  {
    const r = await mgr.req('/api/crm/tasks', 'POST', {
      title: 'משימת בדיקה', leadId, priority: 'HIGH',
      dueAt: new Date(Date.now() + 86400000).toISOString(),
    });
    chk('יצירת משימה', r.status === 200 && r.data?.ok, JSON.stringify(r.data));
    taskId = r.data?.data?.id ?? '';

    const noTitle = await mgr.req('/api/crm/tasks', 'POST', { title: '  ' });
    chk('כותרת ריקה נדחית', noTitle.status === 400);

    const done = await mgr.req('/api/crm/tasks', 'PATCH', { id: taskId, status: 'DONE' });
    chk('סימון כבוצע', done.status === 200 && done.data?.ok, JSON.stringify(done.data));

    const page = await mgr.req('/tasks');
    chk('⚠ הסימון שרד רענון (לא state מקומי בלבד)',
        page.text.includes('משימת בדיקה'));

    const reopen = await mgr.req('/api/crm/tasks', 'PATCH', { id: taskId, status: 'OPEN' });
    chk('החזרה לפתוח', reopen.data?.ok === true);
  }

  /* ═══════ בידוד ═══════ */
  group('4. בידוד בין עסקים');
  {
    // עובד שייך לעסק אחר — לא אמור לגעת בליד של עסק ב׳
    const cross = await emp.req('/api/crm/leads', 'PATCH', { id: leadId, status: 'WON' });
    chk('⚠ משתמש מעסק אחר לא מעדכן ליד זר',
        cross.status === 400, `status=${cross.status} ${JSON.stringify(cross.data)}`);

    const crossTask = await emp.req('/api/crm/tasks', 'PATCH', { id: taskId, status: 'DONE' });
    chk('⚠ משתמש מעסק אחר לא מסמן משימה זרה',
        crossTask.status === 400, `status=${crossTask.status}`);

    const crossCreate = await emp.req('/api/crm/tasks', 'POST', { title: 'חדירה', leadId });
    chk('⚠ לא ניתן לשייך משימה לליד של עסק אחר',
        crossCreate.status === 400, `status=${crossCreate.status}`);
  }

  /* ═══════ קטלוג ═══════ */
  group('5. קטלוג — מנהל בלבד');
  let prodId = '';
  {
    const r = await mgr.req('/api/crm/products', 'POST', {
      name: 'פריט בדיקה', unitPriceIls: 250, unit: 'יח׳', category: 'בדיקות',
    });
    chk('מנהל יוצר פריט', r.status === 200 && r.data?.ok, JSON.stringify(r.data));
    prodId = r.data?.data?.id ?? '';

    const empTry = await emp.req('/api/crm/products', 'POST', { name: 'אסור', unitPriceIls: 1 });
    chk('⚠ עובד לא יוצר פריט בקטלוג', empTry.status === 403, `status=${empTry.status}`);

    const badPrice = await mgr.req('/api/crm/products', 'POST', { name: 'שלילי', unitPriceIls: -5 });
    chk('מחיר שלילי נדחה', badPrice.status === 400);

    const upd = await mgr.req('/api/crm/products', 'PATCH', { id: prodId, unitPriceIls: 300 });
    chk('עדכון מחיר', upd.data?.ok === true, JSON.stringify(upd.data));

    const page = await mgr.req('/catalog');
    chk('⚠ הפריט מופיע בקטלוג', page.text.includes('פריט בדיקה'));

    const del = await mgr.req(`/api/crm/products?id=${prodId}`, 'DELETE');
    chk('מחיקת פריט שאינו בשימוש', del.data?.ok === true);
  }

  /* ═══════ ניקוי ═══════ */
  group('6. ניקוי');
  {
    const d = await mgr.req(`/api/crm/tasks?id=${taskId}`, 'DELETE');
    chk('מחיקת משימת הבדיקה', d.data?.ok === true);
    await mgr.req('/api/crm/leads', 'PATCH', { id: leadId, status: 'LOST', lostReason: 'בדיקה' });
    chk('ליד הבדיקה נסגר', true);
  }

  console.log(lines.join('\n'));
  console.log(`\n${fail === 0 ? '✅' : '❌'}  ${pass} עברו · ${fail} נכשלו\n`);
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
