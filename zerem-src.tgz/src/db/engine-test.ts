import 'dotenv/config';
import { db, sql, schema as s } from './index';
import { eq, desc, sql as raw } from 'drizzle-orm';
import { runBillingCycle } from '../lib/billing/engine';

const line = (t: string) => console.log(`\n── ${t} ──`);
let fails = 0;
const chk = (n: string, c: boolean, d?: string) => {
  console.log(`  ${c ? '✓' : '✗'} ${n}${c ? '' : ` — ${d ?? ''}`}`);
  if (!c) fails++;
};

async function state(subId: string) {
  const [x] = await db.select().from(s.orgSubscriptions).where(eq(s.orgSubscriptions.id, subId));
  const invs = await db.select().from(s.billingInvoices)
    .where(eq(s.billingInvoices.subscriptionId, subId)).orderBy(desc(s.billingInvoices.createdAt));
  const att = await db.select().from(s.chargeAttempts);
  return { sub: x, invs, att };
}

async function main() {
  const [sub0] = await db.select().from(s.orgSubscriptions).limit(1);
  const subId = sub0.id;
  const past = new Date(Date.now() - 2 * 86400000);

  /* ═══ תרחיש 1: קופון "חודשיים חינם" → חשבונית ₪0, בלי קריאה לקארדקום ═══ */
  line('תרחיש 1 — קופון שמאפס: לא נשלחת בקשת חיוב');
  const [freeCoupon] = await db.select().from(s.coupons).where(eq(s.coupons.code, 'LAUNCH2026'));
  // איפוס מלא — הבדיקה חייבת להיות ניתנת להרצה חוזרת
  await sql`DELETE FROM charge_attempts`;
  await sql`DELETE FROM billing_invoices WHERE subscription_id = ${subId}`;
  await db.update(s.orgSubscriptions).set({
    planId: 'pro', interval: 'MONTHLY',
    status: 'ACTIVE', currentPeriodStart: new Date(past.getTime() - 30*86400000),
    currentPeriodEnd: past, couponId: freeCoupon.id, couponCyclesLeft: 2,
    dunningAttempt: 0, nextRetryAt: null, cancelAtPeriodEnd: false,
  }).where(eq(s.orgSubscriptions.id, subId));
  const hasAddon = await db.select().from(s.subscriptionItems)
    .where(eq(s.subscriptionItems.subscriptionId, subId));
  if (!hasAddon.length) {
    await db.insert(s.subscriptionItems).values({
      subscriptionId: subId, kind: 'ADDON', addonKey: 'extra_user',
      quantity: 2, unitExVat: '29',
    });
  }

  const r1 = await runBillingCycle();
  const st1 = await state(subId);
  chk('נבדק מנוי אחד', r1.examined === 1, `examined=${r1.examined}`);
  chk('סווג כ-ZERO_RATED', r1.zeroRated === 1, JSON.stringify(r1));
  chk('לא נעשה ניסיון חיוב', r1.failed === 0 && r1.charged === 0);
  chk('חשבונית ₪0 נוצרה', Number(st1.invs[0].totalIncVat) === 0, st1.invs[0].totalIncVat);
  chk('סטטוס החשבונית ZERO_RATED', st1.invs[0].status === 'ZERO_RATED', st1.invs[0].status);
  chk('התקופה התקדמה קדימה', st1.sub.currentPeriodEnd > past);
  chk('המנוי נשאר ACTIVE', st1.sub.status === 'ACTIVE', st1.sub.status);
  chk('מחזור קופון ירד ל-1', st1.sub.couponCyclesLeft === 1, String(st1.sub.couponCyclesLeft));

  /* ═══ תרחיש 2: אידמפוטנטיות — ריצה חוזרת על אותה תקופה ═══ */
  line('תרחיש 2 — אידמפוטנטיות');
  const before = st1.invs.length;
  await db.update(s.orgSubscriptions).set({ currentPeriodEnd: past })
    .where(eq(s.orgSubscriptions.id, subId));
  await runBillingCycle();
  const st2 = await state(subId);
  chk('לא נוצרה חשבונית כפולה לאותה תקופה', st2.invs.length === before,
      `${before} → ${st2.invs.length}`);

  /* ═══ תרחיש 3: חיוב אמיתי שנכשל → dunning ═══ */
  line('תרחיש 3 — חיוב נכשל (קארדקום לא נגיש) → PAST_DUE');
  const newPeriodEnd = new Date(Date.now() - 86400000);
  await db.update(s.orgSubscriptions).set({
    planId: 'pro', status: 'ACTIVE',
    currentPeriodStart: new Date(newPeriodEnd.getTime() - 30*86400000),
    currentPeriodEnd: newPeriodEnd, couponId: null, couponCyclesLeft: null,
    dunningAttempt: 0, nextRetryAt: null,
  }).where(eq(s.orgSubscriptions.id, subId));

  const r3 = await runBillingCycle();
  const st3 = await state(subId);
  chk('נרשם ככישלון', r3.failed === 1, JSON.stringify({f:r3.failed,c:r3.charged,e:r3.errors}));
  chk('המנוי עבר ל-PAST_DUE', st3.sub.status === 'PAST_DUE', st3.sub.status);
  chk('הגישה לא נחסמה (לא SUSPENDED)', st3.sub.status !== 'SUSPENDED');
  chk('נקבע מועד ניסיון חוזר', !!st3.sub.nextRetryAt);
  chk('ניסיון 1', st3.sub.dunningAttempt === 1, String(st3.sub.dunningAttempt));
  chk('נרשם charge_attempt', st3.att.some(a => !a.succeeded && a.externalUniqId.startsWith('sub_')));
  const failedInv = st3.invs.find(i => i.status === 'FAILED');
  chk('החשבונית סומנה FAILED', !!failedInv);
  chk('סכום החשבונית נכון (249+58 +18%)',
      failedInv ? Math.abs(Number(failedInv.totalIncVat) - 362.26) < 0.02 : false,
      failedInv?.totalIncVat);

  /* ═══ תרחיש 4: dunning עד השהיה ═══ */
  line('תרחיש 4 — חמישה כשלים → SUSPENDED');
  for (let i = 0; i < 5; i++) {
    await db.update(s.orgSubscriptions).set({ nextRetryAt: new Date(Date.now() - 1000) })
      .where(eq(s.orgSubscriptions.id, subId));
    await runBillingCycle();
  }
  const st4 = await state(subId);
  chk('המנוי הושהה אחרי 5 ניסיונות', st4.sub.status === 'SUSPENDED',
      `${st4.sub.status} attempt=${st4.sub.dunningAttempt}`);

  /* ═══ תרחיש 5: ביטול בסוף תקופה → חינם, בלי מחיקת נתונים ═══ */
  line('תרחיש 5 — ביטול בסוף תקופה');
  const leadsBefore = await db.execute<{n:number}>(raw`SELECT COUNT(*)::int AS n FROM leads`);
  await db.update(s.orgSubscriptions).set({
    status: 'ACTIVE', cancelAtPeriodEnd: true, planId: 'pro',
    currentPeriodEnd: new Date(Date.now() - 1000), dunningAttempt: 0, nextRetryAt: null,
  }).where(eq(s.orgSubscriptions.id, subId));
  const r5 = await runBillingCycle();
  const st5 = await state(subId);
  const leadsAfter = await db.execute<{n:number}>(raw`SELECT COUNT(*)::int AS n FROM leads`);
  chk('שונמך לחבילת חינם', st5.sub.planId === 'free' && st5.sub.status === 'FREE',
      `${st5.sub.planId}/${st5.sub.status}`);
  chk('לא נגבה כסף', r5.charged === 0);
  chk('⚠ שום ליד לא נמחק', leadsBefore[0].n === leadsAfter[0].n,
      `${leadsBefore[0].n} → ${leadsAfter[0].n}`);

  /* ═══ תרחיש 6: נעילה — שתי ריצות במקביל ═══ */
  line('תרחיש 6 — נעילה מונעת ריצה כפולה');
  const [a, b] = await Promise.all([runBillingCycle(), runBillingCycle()]);
  chk('אחת מהריצות דילגה', a.skipped !== b.skipped, `${a.skipped}/${b.skipped}`);

  console.log(`\n${fails === 0 ? '✅' : '❌'}  ${fails} כשלים\n`);
  await sql.end();
  process.exit(fails ? 1 : 0);
}
main().catch(e => { console.error(e); process.exit(1); });
