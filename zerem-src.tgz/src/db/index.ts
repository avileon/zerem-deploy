import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

const connectionString =
  process.env.DATABASE_URL ?? 'postgres://postgres:postgres@127.0.0.1:5432/zerem';

declare global {
  // eslint-disable-next-line no-var
  var __zeremSql: ReturnType<typeof postgres> | undefined;
}

const sql = global.__zeremSql ?? postgres(connectionString, { max: 5 });
if (process.env.NODE_ENV !== 'production') global.__zeremSql = sql;

export const db = drizzle(sql, { schema });
export { schema, sql };
