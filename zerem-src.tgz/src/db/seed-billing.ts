/**
 * זריעת מודול הגבייה.
 * רץ אחרי seed.ts. אידמפוטנטי — אפשר להריץ שוב בלי לשבור כלום.
 */
import 'dotenv/config';
import { db, sql, schema as s } from './index';
import { PLANS, TRIAL_DAYS } from '../lib/billing/catalog';
import { anchorDayFrom, addInterval, withVat, round2 } from '../lib/billing/pricing';
import { eq } from 'drizzle-orm';

const daysAgo = (d: number) => new Date(Date.now() - d * 86_400_000);
const daysAhead = (d: number) => new Date(Date.now() + d * 86_400_000);

async function main() {
  console.log('💳 זורע קטלוג גבייה…');

  /* ── חבילות ומחירים ── */
  for (const p of PLANS) {
    await db.insert(s.plans).values({
      id: p.id, nameHe: p.nameHe, tagline: p.tagline, sortOrder: p.sortOrder,
    }).onConflictDoUpdate({
      target: s.plans.id,
      set: { nameHe: p.nameHe, tagline: p.tagline, sortOrder: p.sortOrder },
    });

    for (const interval of ['MONTHLY', 'YEARLY'] as const) {
      const amount = interval === 'YEARLY' ? p.yearly : p.monthly;
      if (amount === null) continue;
      await db.insert(s.planPrices)
        .values({ planId: p.id, interval, amountExVat: String(amount) })
        .onConflictDoUpdate({
          target: [s.planPrices.planId, s.planPrices.interval],
          set: { amountExVat: String(amount), isActive: true },
        });
    }

    for (const [featureKey, v] of Object.entries(p.entitlements)) {
      await db.insert(s.planEntitlements).values({
        planId: p.id,
        featureKey,
        limitValue: typeof v === 'number' ? v : null,
        isEnabled: v !== false,
      }).onConflictDoUpdate({
        target: [s.planEntitlements.planId, s.planEntitlements.featureKey],
        set: { limitValue: typeof v === 'number' ? v : null, isEnabled: v !== false },
      });
    }
  }
  console.log(`  ✓ ${PLANS.length} חבילות`);

  /* ── קופונים ── */
  const coupons = [
    {
      code: 'LAUNCH2026', type: 'FREE_PERIODS' as const, value: '2', duration: 'REPEATING' as const,
      durationCycles: 2, maxRedemptions: 100, firstTimeOnly: true,
      validUntil: new Date('2026-12-31'), campaign: 'launch-aug26',
      note: 'קמפיין השקה — חודשיים חינם ל-100 הראשונים',
    },
    {
      code: 'FREEMONTH', type: 'FREE_PERIODS' as const, value: '1', duration: 'ONCE' as const,
      durationCycles: 1, maxRedemptions: null, firstTimeOnly: true,
      campaign: 'evergreen', note: 'חודש ראשון חינם — לשימוש אנשי מכירות',
    },
    {
      code: 'PARTNER20', type: 'PERCENT' as const, value: '20', duration: 'FOREVER' as const,
      durationCycles: null, maxRedemptions: 50, firstTimeOnly: false,
      campaign: 'partners', note: '20% לתמיד — שותפים ורואי חשבון',
    },
    {
      code: 'YEARLY100', type: 'FIXED' as const, value: '100', duration: 'ONCE' as const,
      durationCycles: null, maxRedemptions: null, appliesToInterval: 'YEARLY' as const,
      campaign: 'annual-push', note: '₪100 הנחה למעבר למסלול שנתי',
    },
  ];

  for (const c of coupons) {
    await db.insert(s.coupons).values(c).onConflictDoNothing();
  }
  console.log(`  ✓ ${coupons.length} קופונים`);

  /* ── מנוי לארגון הדמו + היסטוריית חשבוניות ── */
  const [org] = await db.select().from(s.organizations).limit(1);
  if (!org) { console.log('  ⚠ אין ארגון — דלג'); await sql.end(); return; }

  const existing = await db.select().from(s.orgSubscriptions)
    .where(eq(s.orgSubscriptions.orgId, org.id)).limit(1);

  if (existing.length) {
    console.log('  ✓ מנוי כבר קיים');
    await sql.end();
    return;
  }

  const anchor = anchorDayFrom(daysAgo(97));
  const periodStart = daysAgo(7);
  const periodEnd = addInterval(periodStart, 'MONTHLY', anchor);

  const [pm] = await db.insert(s.billingPaymentMethods).values({
    orgId: org.id,
    token: 'demo-token-not-a-real-card',
    last4: '0008', brand: 'ויזה',
    expMonth: 12, expYear: 2030,
    holderName: org.legalName ?? org.name,
    isDefault: true, status: 'VALID',
  }).returning();

  const [sub] = await db.insert(s.orgSubscriptions).values({
    orgId: org.id,
    planId: 'pro',
    interval: 'MONTHLY',
    status: 'ACTIVE',
    currentPeriodStart: periodStart,
    currentPeriodEnd: periodEnd,
    billingAnchorDay: anchor,
    paymentMethodId: pm.id,
  }).returning();

  // תוספת אחת — כדי שהמסך יראה מציאותי
  await db.insert(s.subscriptionItems).values({
    subscriptionId: sub.id, kind: 'ADDON', addonKey: 'extra_user',
    quantity: 2, unitExVat: '29',
  });

  // שלוש חשבוניות היסטוריות
  const pro = PLANS.find((p) => p.id === 'pro')!;
  for (let i = 3; i >= 1; i--) {
    const ps = daysAgo(7 + i * 30);
    const pe = addInterval(ps, 'MONTHLY', anchor);
    const base = round2((pro.monthly ?? 0) + 29 * 2);
    const { vatRate, vatAmount, totalIncVat } = withVat(base, ps);

    const [inv] = await db.insert(s.billingInvoices).values({
      orgId: org.id, subscriptionId: sub.id,
      periodStart: ps, periodEnd: pe,
      subtotalExVat: String(base), discountExVat: '0',
      vatRate: String(vatRate), vatAmount: String(vatAmount),
      totalIncVat: String(totalIncVat),
      status: 'PAID', paidAt: ps,
      cardcomTranId: `demo-${90000 + i}`,
      cardcomDocNumber: String(1200 + i),
    }).returning();

    await db.insert(s.billingInvoiceLines).values([
      { invoiceId: inv.id, description: `מקצועי · חודשי`, quantity: '1',
        unitExVat: String(pro.monthly), amountExVat: String(pro.monthly), kind: 'PLAN' },
      { invoiceId: inv.id, description: 'משתמש נוסף ×2', quantity: '2',
        unitExVat: '29', amountExVat: '58', kind: 'ADDON' },
    ]);

    await db.insert(s.chargeAttempts).values({
      invoiceId: inv.id, attemptNo: 1,
      externalUniqId: `demo_sub_${i}`,
      responseCode: 0, responseText: 'Success',
      cardcomTranId: `demo-${90000 + i}`, succeeded: true,
    }).onConflictDoNothing();
  }

  await db.insert(s.billingEvents).values([
    { orgId: org.id, subscriptionId: sub.id, type: 'trial.started', payload: { days: TRIAL_DAYS }, actor: 'system:signup', createdAt: daysAgo(111) },
    { orgId: org.id, subscriptionId: sub.id, type: 'trial.converted', payload: {}, actor: 'system:cron', createdAt: daysAgo(97) },
    { orgId: org.id, subscriptionId: sub.id, type: 'subscription.activated', payload: { planId: 'pro' }, actor: 'webhook:cardcom', createdAt: daysAgo(97) },
    { orgId: org.id, subscriptionId: sub.id, type: 'addon.added', payload: { addonKey: 'extra_user', quantity: 2 }, actor: 'user', createdAt: daysAgo(40) },
    { orgId: org.id, subscriptionId: sub.id, type: 'invoice.paid', payload: { amount: 361.26 }, actor: 'system:cron', createdAt: daysAgo(7) },
  ]);

  void daysAhead;
  console.log(`  ✓ מנוי "מקצועי" + 3 חשבוניות לארגון ${org.name}`);
  await sql.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
