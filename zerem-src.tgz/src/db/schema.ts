/**
 * זרם CRM — סכמת PostgreSQL
 * Drizzle ORM · רב-דיירי (multi-tenant) · RTL · שוק ישראלי
 *
 * עקרונות תכן:
 *  1. orgId בכל טבלה עסקית → בידוד דיירים + Postgres RLS
 *  2. הטלפון הוא מפתח הדדופליקציה — נשמר E.164 מנורמל, unique per org
 *  3. כסף נשמר ב-numeric(12,2), לעולם לא float
 *  4. מע״מ נשמר על המסמך עצמו (vatRate) — לא קבוע גלובלי. השיעור משתנה בחוק.
 *  5. מסמכי חשבונאות אינם נוצרים אצלנו — רק נרשמת הפניה למנפיק (Rivhit/Cardcom)
 *  6. חתימה = snapshot + hash + audit trail. ראיה, לא רק תמונה.
 */
import {
  pgTable, uuid, text, varchar, timestamp, integer, boolean,
  jsonb, numeric, index, uniqueIndex, pgEnum, real, primaryKey,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

/* ══════════════════════════ ENUMS ══════════════════════════ */
export const roleEnum = pgEnum('role', ['OWNER', 'ADMIN', 'SALES_REP', 'VIEWER']);

export const leadStatusEnum = pgEnum('lead_status', [
  'NEW', 'CONTACTED', 'QUALIFIED', 'QUOTED', 'NEGOTIATION', 'WON', 'LOST',
]);
export const leadSourceEnum = pgEnum('lead_source', [
  'WORDPRESS', 'META_LEAD_ADS', 'MANUAL', 'WHATSAPP', 'PHONE', 'REFERRAL', 'API', 'IMPORT',
]);
export const taskStatusEnum = pgEnum('task_status', ['OPEN', 'IN_PROGRESS', 'DONE', 'CANCELLED']);
export const taskPriorityEnum = pgEnum('task_priority', ['LOW', 'NORMAL', 'HIGH', 'URGENT']);

export const quoteStatusEnum = pgEnum('quote_status', [
  'DRAFT', 'SENT', 'VIEWED', 'SIGNED', 'REJECTED', 'EXPIRED', 'PAID',
]);
export const paymentStatusEnum = pgEnum('payment_status', [
  'PENDING', 'AUTHORIZED', 'PAID', 'FAILED', 'REFUNDED', 'CHARGEBACK',
]);
export const paymentProviderEnum = pgEnum('payment_provider', ['CARDCOM', 'ICREDIT', 'MANUAL', 'BANK_TRANSFER', 'BIT']);
export const docProviderEnum = pgEnum('doc_provider', ['RIVHIT', 'CARDCOM', 'MANUAL']);

/** סוגי מסמך פנימיים. הקוד החיצוני אצל הספק נשמר בנפרד — הוא שונה בין חשבונות. */
export const docKindEnum = pgEnum('doc_kind', [
  'QUOTE', 'PROFORMA', 'TAX_INVOICE', 'RECEIPT', 'TAX_INVOICE_RECEIPT', 'CREDIT_NOTE',
]);

export const msgDirectionEnum = pgEnum('msg_direction', ['IN', 'OUT']);
export const msgStatusEnum = pgEnum('msg_status', ['QUEUED', 'SENT', 'DELIVERED', 'READ', 'FAILED']);
export const channelEnum = pgEnum('channel', ['WHATSAPP', 'SMS', 'EMAIL', 'CALL', 'SYSTEM']);

export const webhookDirEnum = pgEnum('webhook_dir', ['IN', 'OUT']);
export const notifChannelEnum = pgEnum('notif_channel', ['PUSH', 'WHATSAPP', 'EMAIL', 'IN_APP']);

/* ═══════════════ 1. דיירות · משתמשים · הרשאות ═══════════════ */

export const organizations = pgTable('organizations', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  slug: varchar('slug', { length: 64 }).notNull().unique(),

  // פרטי העוסק — נדרשים על כל מסמך
  legalName: text('legal_name'),
  vatId: varchar('vat_id', { length: 20 }),          // ח.פ. / ע.מ.
  address: text('address'),
  city: varchar('city', { length: 64 }),
  phone: varchar('phone', { length: 20 }),
  email: text('email'),
  logoUrl: text('logo_url'),
  brandColor: varchar('brand_color', { length: 9 }).default('#2563eb'),

  timezone: varchar('timezone', { length: 40 }).notNull().default('Asia/Jerusalem'),
  currency: varchar('currency', { length: 3 }).notNull().default('ILS'),
  quoteValidDays: integer('quote_valid_days').notNull().default(14),
  quoteTerms: text('quote_terms'),

  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').notNull().unique(),
  phone: varchar('phone', { length: 20 }),           // E.164 — לשליחת התראות בוואטסאפ
  name: text('name').notNull(),
  avatarUrl: text('avatar_url'),
  passwordHash: text('password_hash'),
  lastSeenAt: timestamp('last_seen_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const memberships = pgTable('memberships', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: roleEnum('role').notNull().default('SALES_REP'),
  active: boolean('active').notNull().default(true),
  // יעדי מכירות — מוצגים בדשבורד המנהל
  monthlyTargetIls: numeric('monthly_target_ils', { precision: 12, scale: 2 }),
}, (t) => [uniqueIndex('membership_org_user_uq').on(t.orgId, t.userId)]);

/** מכשירים לצורך Web Push (FCM / VAPID) */
export const pushSubscriptions = pgTable('push_subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  endpoint: text('endpoint').notNull(),
  p256dh: text('p256dh').notNull(),
  auth: text('auth').notNull(),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('push_endpoint_uq').on(t.endpoint)]);

/* ═══════════════ 2. לידים ולקוחות ═══════════════ */

export const leads = pgTable('leads', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),

  fullName: text('full_name').notNull(),
  /** E.164 מנורמל (+9725…). זהו מפתח הדדופליקציה. */
  phone: varchar('phone', { length: 20 }).notNull(),
  /** מזהה WhatsApp — Green API עובר ל-@lid, לכן נשמר בנפרד מהטלפון */
  waChatId: varchar('wa_chat_id', { length: 40 }),
  email: text('email'),

  companyName: text('company_name'),
  vatId: varchar('vat_id', { length: 20 }),          // לחשבונית מס
  address: text('address'),
  city: varchar('city', { length: 64 }),
  notes: text('notes'),

  status: leadStatusEnum('status').notNull().default('NEW'),
  source: leadSourceEnum('source').notNull().default('MANUAL'),
  ownerId: uuid('owner_id').references(() => users.id),
  tags: text('tags').array().notNull().default([]),

  estimatedValueIls: numeric('estimated_value_ils', { precision: 12, scale: 2 }),
  lostReason: text('lost_reason'),

  // ── ייחוס שיווקי ──
  utmSource: varchar('utm_source', { length: 120 }),
  utmMedium: varchar('utm_medium', { length: 120 }),
  utmCampaign: varchar('utm_campaign', { length: 200 }),
  utmTerm: varchar('utm_term', { length: 200 }),
  utmContent: varchar('utm_content', { length: 200 }),
  landingPage: text('landing_page'),
  referrer: text('referrer'),
  gclid: varchar('gclid', { length: 200 }),
  fbclid: varchar('fbclid', { length: 200 }),

  customFields: jsonb('custom_fields').$type<Record<string, unknown>>(),
  lastContactAt: timestamp('last_contact_at', { withTimezone: true }),
  wonAt: timestamp('won_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  // ← זהו מנגנון הדדופליקציה. שני לידים עם אותו טלפון באותו ארגון = בלתי אפשרי.
  uniqueIndex('lead_org_phone_uq').on(t.orgId, t.phone),
  index('lead_board_idx').on(t.orgId, t.status, t.ownerId),
  index('lead_owner_idx').on(t.orgId, t.ownerId, t.updatedAt),
  index('lead_email_idx').on(t.orgId, t.email),
]);

/* ═══════════════ 3. משימות והאצלה ═══════════════ */

export const tasks = pgTable('tasks', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  description: text('description'),
  status: taskStatusEnum('status').notNull().default('OPEN'),
  priority: taskPriorityEnum('priority').notNull().default('NORMAL'),

  dueAt: timestamp('due_at', { withTimezone: true }),
  remindAt: timestamp('remind_at', { withTimezone: true }),
  remindedAt: timestamp('reminded_at', { withTimezone: true }),

  leadId: uuid('lead_id').references(() => leads.id, { onDelete: 'cascade' }),
  assigneeId: uuid('assignee_id').references(() => users.id),
  createdById: uuid('created_by_id').references(() => users.id),

  boardOrder: integer('board_order').notNull().default(0),   // מיקום בקנבן
  completedAt: timestamp('completed_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index('task_assignee_idx').on(t.orgId, t.assigneeId, t.status, t.dueAt),
  index('task_lead_idx').on(t.leadId),
  index('task_due_idx').on(t.orgId, t.status, t.dueAt),
]);

/** היסטוריית האצלה — מי העביר למי ומתי. נדרש לביקורת ולמדידת עומס. */
export const taskAssignments = pgTable('task_assignments', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  taskId: uuid('task_id').notNull().references(() => tasks.id, { onDelete: 'cascade' }),
  fromUserId: uuid('from_user_id').references(() => users.id),
  toUserId: uuid('to_user_id').notNull().references(() => users.id),
  byUserId: uuid('by_user_id').references(() => users.id),
  note: text('note'),
  notifiedPush: boolean('notified_push').notNull().default(false),
  notifiedWhatsapp: boolean('notified_whatsapp').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('task_assign_idx').on(t.taskId, t.createdAt)]);

/* ═══════════════ 4. קטלוג מוצרים ═══════════════ */

export const products = pgTable('products', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  sku: varchar('sku', { length: 64 }),
  name: text('name').notNull(),
  description: text('description'),
  unit: varchar('unit', { length: 24 }).notNull().default('יח׳'),
  unitPriceIls: numeric('unit_price_ils', { precision: 12, scale: 2 }).notNull(),
  costIls: numeric('cost_ils', { precision: 12, scale: 2 }),
  /** פטור ממע״מ (סעיף 30/31 לחוק מע״מ — למשל אילת, יצוא) */
  vatExempt: boolean('vat_exempt').notNull().default(false),
  category: varchar('category', { length: 80 }),
  active: boolean('active').notNull().default(true),
  /** item_id אצל ריווחית — לסנכרון קטלוג */
  externalId: varchar('external_id', { length: 64 }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index('product_org_idx').on(t.orgId, t.active),
  uniqueIndex('product_org_sku_uq').on(t.orgId, t.sku),
]);

/* ═══════════════ 5. הצעות מחיר וחתימה ═══════════════ */

export const quotes = pgTable('quotes', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  leadId: uuid('lead_id').notNull().references(() => leads.id, { onDelete: 'cascade' }),
  createdById: uuid('created_by_id').references(() => users.id),

  number: integer('number').notNull(),                       // מספר רץ לארגון
  title: text('title'),
  status: quoteStatusEnum('status').notNull().default('DRAFT'),

  /** טוקן הקישור הציבורי — אקראי, לא ניתן לניחוש, לא ה-id */
  publicToken: varchar('public_token', { length: 48 }).notNull().unique(),

  // ── סכומים. כולם נגזרים מהשורות אבל מוקפאים כאן ברגע השליחה. ──
  subtotalIls: numeric('subtotal_ils', { precision: 12, scale: 2 }).notNull().default('0'),
  discountType: varchar('discount_type', { length: 8 }).notNull().default('PERCENT'), // PERCENT | AMOUNT
  discountValue: numeric('discount_value', { precision: 12, scale: 2 }).notNull().default('0'),
  discountIls: numeric('discount_ils', { precision: 12, scale: 2 }).notNull().default('0'),
  /** שיעור המע״מ שחל על מסמך זה. 0.18 מ-01.01.2025. נשמר, לא מחושב מחדש. */
  vatRate: numeric('vat_rate', { precision: 5, scale: 4 }).notNull().default('0.18'),
  vatIls: numeric('vat_ils', { precision: 12, scale: 2 }).notNull().default('0'),
  totalIls: numeric('total_ils', { precision: 12, scale: 2 }).notNull().default('0'),

  validUntil: timestamp('valid_until', { withTimezone: true }),
  notes: text('notes'),
  terms: text('terms'),

  // ── מעקב ──
  sentAt: timestamp('sent_at', { withTimezone: true }),
  firstViewedAt: timestamp('first_viewed_at', { withTimezone: true }),
  viewCount: integer('view_count').notNull().default(0),
  signedAt: timestamp('signed_at', { withTimezone: true }),
  rejectedAt: timestamp('rejected_at', { withTimezone: true }),
  rejectionReason: text('rejection_reason'),

  pdfUrl: text('pdf_url'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex('quote_org_number_uq').on(t.orgId, t.number),
  index('quote_lead_idx').on(t.leadId),
  index('quote_status_idx').on(t.orgId, t.status),
]);

export const quoteItems = pgTable('quote_items', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  quoteId: uuid('quote_id').notNull().references(() => quotes.id, { onDelete: 'cascade' }),
  productId: uuid('product_id').references(() => products.id),
  // הערכים מועתקים מהמוצר ולא מקושרים — שינוי מחיר בקטלוג לא משנה הצעה שנשלחה
  name: text('name').notNull(),
  description: text('description'),
  unit: varchar('unit', { length: 24 }).notNull().default('יח׳'),
  quantity: numeric('quantity', { precision: 12, scale: 3 }).notNull().default('1'),
  unitPriceIls: numeric('unit_price_ils', { precision: 12, scale: 2 }).notNull(),
  discountPercent: numeric('discount_percent', { precision: 5, scale: 2 }).notNull().default('0'),
  vatExempt: boolean('vat_exempt').notNull().default(false),
  lineTotalIls: numeric('line_total_ils', { precision: 12, scale: 2 }).notNull().default('0'),
  sortOrder: integer('sort_order').notNull().default(0),
}, (t) => [index('quote_item_idx').on(t.quoteId, t.sortOrder)]);

/**
 * חתימה דיגיטלית — ראיה, לא רק ציור.
 * חוק חתימה אלקטרונית תשס״א-2001: הצעת מחיר מסחרית אינה דורשת חתימה מאושרת.
 * מה שכן נדרש כדי לעמוד במבחן הראייתי (§3 — חתימה מאובטחת):
 *   ייחודיות לחותם · זיהוי · שליטה בלעדית · גילוי שינוי לאחר החתימה
 * לכן: OTP לטלפון + hash של ה-PDF המדויק + audit trail.
 */
export const quoteSignatures = pgTable('quote_signatures', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  quoteId: uuid('quote_id').notNull().references(() => quotes.id, { onDelete: 'cascade' }),

  signerName: text('signer_name').notNull(),
  signerPhone: varchar('signer_phone', { length: 20 }),
  signerEmail: text('signer_email'),

  /** PNG של הציור, base64 (data-URL) */
  signatureImage: text('signature_image').notNull(),
  /** SHA-256 של ה-PDF כפי שהוצג בפועל ברגע החתימה — מוכיח שלא שונה */
  documentSha256: varchar('document_sha256', { length: 64 }).notNull(),
  /** עותק ההצעה המוקפא (JSON) — גם אם ההצעה תערך אח״כ */
  documentSnapshot: jsonb('document_snapshot').notNull(),

  /** אימות OTP — מה שמעלה את הראיה מ"חתימה רגילה" ל"מאובטחת" */
  otpVerified: boolean('otp_verified').notNull().default(false),
  otpChannel: channelEnum('otp_channel'),
  otpVerifiedAt: timestamp('otp_verified_at', { withTimezone: true }),

  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  signedAt: timestamp('signed_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('quote_signature_uq').on(t.quoteId)]);

/** קודי OTF חד-פעמיים לחתימה */
export const otpCodes = pgTable('otp_codes', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  quoteId: uuid('quote_id').references(() => quotes.id, { onDelete: 'cascade' }),
  destination: varchar('destination', { length: 64 }).notNull(),
  codeHash: varchar('code_hash', { length: 64 }).notNull(),   // לא שומרים קוד גולמי
  attempts: integer('attempts').notNull().default(0),
  consumedAt: timestamp('consumed_at', { withTimezone: true }),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('otp_lookup_idx').on(t.destination, t.expiresAt)]);

/* ═══════════════ 6. תשלומים וחשבונאות ═══════════════ */

export const payments = pgTable('payments', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  leadId: uuid('lead_id').references(() => leads.id),
  quoteId: uuid('quote_id').references(() => quotes.id),

  provider: paymentProviderEnum('provider').notNull().default('CARDCOM'),
  status: paymentStatusEnum('status').notNull().default('PENDING'),
  amountIls: numeric('amount_ils', { precision: 12, scale: 2 }).notNull(),
  installments: integer('installments').notNull().default(1),

  // ── Cardcom ──
  /** LowProfileId — המזהה של דף התשלום המתארח */
  lowProfileId: varchar('low_profile_id', { length: 64 }),
  payLinkUrl: text('pay_link_url'),
  /** TranzactionId — מפתח האידמפוטנטיות. עסקה אחת = רשומה אחת. */
  transactionId: varchar('transaction_id', { length: 64 }),
  approvalNumber: varchar('approval_number', { length: 32 }),
  last4: varchar('last4', { length: 4 }),
  cardBrand: varchar('card_brand', { length: 24 }),
  /** ReturnValue ששלחנו ל-Cardcom — לקורלציה חזרה */
  returnValue: varchar('return_value', { length: 64 }),

  /** טוקן לחיוב חוזר (הוראת קבע) */
  cardToken: varchar('card_token', { length: 64 }),
  tokenExpiry: varchar('token_expiry', { length: 8 }),        // MMYY

  errorCode: varchar('error_code', { length: 16 }),
  errorMessage: text('error_message'),
  rawResponse: jsonb('raw_response'),

  paidAt: timestamp('paid_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  // ← מונע חיוב כפול כשה-webhook מגיע פעמיים
  uniqueIndex('payment_txn_uq').on(t.orgId, t.transactionId),
  index('payment_quote_idx').on(t.quoteId),
  index('payment_status_idx').on(t.orgId, t.status, t.createdAt),
]);

/** מנויים / הוראות קבע — התזמון אצלנו, החיוב בטוקן מול Cardcom */
export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  leadId: uuid('lead_id').notNull().references(() => leads.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  amountIls: numeric('amount_ils', { precision: 12, scale: 2 }).notNull(),
  intervalMonths: integer('interval_months').notNull().default(1),
  cardToken: varchar('card_token', { length: 64 }).notNull(),
  tokenExpiry: varchar('token_expiry', { length: 8 }),
  nextChargeAt: timestamp('next_charge_at', { withTimezone: true }).notNull(),
  lastChargeAt: timestamp('last_charge_at', { withTimezone: true }),
  failureCount: integer('failure_count').notNull().default(0),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('subscription_due_idx').on(t.active, t.nextChargeAt)]);

/**
 * מסמכי חשבונאות.
 * ⚠️ ה-CRM אינו מנפיק חשבוניות. הוא רק רושם מה שהמנפיק (ריווחית/Cardcom) יצר.
 * הנפקה עצמאית של חשבונית מס אינה חוקית ללא מערכת מאושרת + חתימה מאובטחת.
 */
export const accountingDocs = pgTable('accounting_docs', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  leadId: uuid('lead_id').references(() => leads.id),
  quoteId: uuid('quote_id').references(() => quotes.id),
  paymentId: uuid('payment_id').references(() => payments.id),

  provider: docProviderEnum('provider').notNull().default('RIVHIT'),
  kind: docKindEnum('kind').notNull(),
  /** הקוד המספרי אצל הספק. אצל ריווחית הוא לכל חשבון — נטען מ-Document.TypeList */
  externalTypeCode: integer('external_type_code'),
  documentNumber: varchar('document_number', { length: 32 }),
  documentIdentity: varchar('document_identity', { length: 64 }),
  documentUrl: text('document_url'),

  amountIls: numeric('amount_ils', { precision: 12, scale: 2 }).notNull(),
  vatIls: numeric('vat_ils', { precision: 12, scale: 2 }).notNull().default('0'),

  /** מספר הקצאה מרשות המסים. חובה מעל הסף — ₪5,000 (ללא מע״מ) מ-01.06.2026 */
  allocationNumber: varchar('allocation_number', { length: 32 }),
  allocationRequired: boolean('allocation_required').notNull().default(false),
  allocationStatus: varchar('allocation_status', { length: 24 }),  // OK | REJECTED | PENDING | NOT_REQUIRED
  allocationError: text('allocation_error'),

  sentToCustomerAt: timestamp('sent_to_customer_at', { withTimezone: true }),
  issuedAt: timestamp('issued_at', { withTimezone: true }).notNull().defaultNow(),
  rawResponse: jsonb('raw_response'),
}, (t) => [
  index('doc_lead_idx').on(t.leadId),
  // מונע כפל הנפקה על אותו תשלום — הבאג הקלאסי בשילוב Cardcom+ריווחית
  uniqueIndex('doc_payment_kind_uq').on(t.orgId, t.paymentId, t.kind),
]);

/* ═══════════════ 7. תקשורת ═══════════════ */

export const messages = pgTable('messages', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  leadId: uuid('lead_id').references(() => leads.id, { onDelete: 'cascade' }),
  channel: channelEnum('channel').notNull().default('WHATSAPP'),
  direction: msgDirectionEnum('direction').notNull(),
  /** idMessage של Green API — מפתח dedup */
  externalId: varchar('external_id', { length: 64 }),
  body: text('body'),
  mediaUrl: text('media_url'),
  mediaType: varchar('media_type', { length: 32 }),
  status: msgStatusEnum('status').notNull().default('QUEUED'),
  errorMessage: text('error_message'),
  templateId: uuid('template_id'),
  authorId: uuid('author_id').references(() => users.id),
  isAutomated: boolean('is_automated').notNull().default(false),
  sentAt: timestamp('sent_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex('message_external_uq').on(t.orgId, t.externalId),
  index('message_lead_idx').on(t.leadId, t.sentAt),
]);

export const messageTemplates = pgTable('message_templates', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  body: text('body').notNull(),               // תומך ב-{{full_name}}, {{quote_link}}, {{total}}
  shortcut: varchar('shortcut', { length: 24 }),
  category: varchar('category', { length: 40 }),
  useCount: integer('use_count').notNull().default(0),
});

/* ═══════════════ 8. אינטגרציות ו-webhooks ═══════════════ */

/** הגדרות ספקים. credentials מוצפן AES-256-GCM — לעולם לא בטקסט גלוי. */
export const integrations = pgTable('integrations', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  provider: varchar('provider', { length: 32 }).notNull(),   // GREEN_API | CARDCOM | RIVHIT | FCM
  enabled: boolean('enabled').notNull().default(false),
  credentialsEnc: text('credentials_enc'),
  config: jsonb('config').$type<Record<string, unknown>>(),
  status: varchar('status', { length: 32 }),                  // OK | AUTH_ERROR | BLOCKED | UNKNOWN
  statusMessage: text('status_message'),
  lastCheckedAt: timestamp('last_checked_at', { withTimezone: true }),
}, (t) => [uniqueIndex('integration_org_provider_uq').on(t.orgId, t.provider)]);

/** נקודות קליטה נכנסות — כל טופס/מקור מקבל endpoint ומיפוי שדות משלו */
export const webhookEndpoints = pgTable('webhook_endpoints', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),                               // "טופס צור קשר — אלמנטור"
  /** החלק הסודי בכתובת: /api/ingest/{slug} */
  slug: varchar('slug', { length: 48 }).notNull().unique(),
  secret: varchar('secret', { length: 64 }).notNull(),
  source: leadSourceEnum('source').notNull().default('WORDPRESS'),
  /** מיפוי דינמי: { "your-phone": "phone", "your-name": "fullName" } */
  fieldMap: jsonb('field_map').$type<Record<string, string>>().notNull().default({}),
  defaultOwnerId: uuid('default_owner_id').references(() => users.id),
  autoCreateTask: boolean('auto_create_task').notNull().default(true),
  taskTemplate: text('task_template').default('לחזור ללקוח {{full_name}}'),
  active: boolean('active').notNull().default(true),
  hitCount: integer('hit_count').notNull().default(0),
  lastHitAt: timestamp('last_hit_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

/** webhooks יוצאים — Make / Zapier / Sheets */
export const outgoingWebhooks = pgTable('outgoing_webhooks', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  url: text('url').notNull(),
  secret: varchar('secret', { length: 64 }).notNull(),
  /** lead.created · lead.status_changed · quote.signed · payment.received · deal.won */
  events: text('events').array().notNull().default([]),
  active: boolean('active').notNull().default(true),
  failureCount: integer('failure_count').notNull().default(0),
});

/** לוג גולמי של כל קריאה נכנסת/יוצאת — לדיבאג ולניתוח כשלים */
export const webhookLogs = pgTable('webhook_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').references(() => organizations.id, { onDelete: 'cascade' }),
  direction: webhookDirEnum('direction').notNull(),
  endpointId: uuid('endpoint_id'),
  provider: varchar('provider', { length: 32 }),
  event: varchar('event', { length: 64 }),
  httpStatus: integer('http_status'),
  payload: jsonb('payload'),
  response: jsonb('response'),
  errorMessage: text('error_message'),
  durationMs: integer('duration_ms'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('webhook_log_idx').on(t.orgId, t.createdAt)]);

/* ═══════════════ 9. פעילות והתראות ═══════════════ */

export const activities = pgTable('activities', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  type: varchar('type', { length: 48 }).notNull(),
  actorId: uuid('actor_id').references(() => users.id),
  leadId: uuid('lead_id').references(() => leads.id, { onDelete: 'cascade' }),
  entityType: varchar('entity_type', { length: 32 }),
  entityId: uuid('entity_id'),
  summary: text('summary').notNull(),
  data: jsonb('data'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('activity_lead_idx').on(t.orgId, t.leadId, t.createdAt)]);

export const notifications = pgTable('notifications', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  channel: notifChannelEnum('channel').notNull().default('IN_APP'),
  title: text('title').notNull(),
  body: text('body'),
  url: text('url'),
  readAt: timestamp('read_at', { withTimezone: true }),
  deliveredAt: timestamp('delivered_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('notification_user_idx').on(t.userId, t.readAt, t.createdAt)]);

export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  actorId: uuid('actor_id').references(() => users.id),
  action: varchar('action', { length: 64 }).notNull(),
  entityType: varchar('entity_type', { length: 32 }),
  entityId: uuid('entity_id'),
  ip: varchar('ip', { length: 45 }),
  diff: jsonb('diff'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

/** שיעורי מע״מ לפי תאריך — לעולם לא קבוע בקוד */
export const vatRates = pgTable('vat_rates', {
  id: uuid('id').primaryKey().defaultRandom(),
  rate: numeric('rate', { precision: 5, scale: 4 }).notNull(),
  effectiveFrom: timestamp('effective_from', { withTimezone: true }).notNull(),
  note: text('note'),
});

/* ══════════════════════════ RELATIONS ══════════════════════════ */

export const leadsRelations = relations(leads, ({ one, many }) => ({
  owner: one(users, { fields: [leads.ownerId], references: [users.id] }),
  org: one(organizations, { fields: [leads.orgId], references: [organizations.id] }),
  tasks: many(tasks),
  quotes: many(quotes),
  messages: many(messages),
  payments: many(payments),
  docs: many(accountingDocs),
  activities: many(activities),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  lead: one(leads, { fields: [tasks.leadId], references: [leads.id] }),
  assignee: one(users, { fields: [tasks.assigneeId], references: [users.id] }),
  createdBy: one(users, { fields: [tasks.createdById], references: [users.id] }),
  assignments: many(taskAssignments),
}));

export const quotesRelations = relations(quotes, ({ one, many }) => ({
  lead: one(leads, { fields: [quotes.leadId], references: [leads.id] }),
  createdBy: one(users, { fields: [quotes.createdById], references: [users.id] }),
  items: many(quoteItems),
  signature: one(quoteSignatures),
  payments: many(payments),
}));

export const quoteItemsRelations = relations(quoteItems, ({ one }) => ({
  quote: one(quotes, { fields: [quoteItems.quoteId], references: [quotes.id] }),
  product: one(products, { fields: [quoteItems.productId], references: [products.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  quote: one(quotes, { fields: [payments.quoteId], references: [quotes.id] }),
  lead: one(leads, { fields: [payments.leadId], references: [leads.id] }),
}));

export const membershipsRelations = relations(memberships, ({ one }) => ({
  user: one(users, { fields: [memberships.userId], references: [users.id] }),
  org: one(organizations, { fields: [memberships.orgId], references: [organizations.id] }),
}));

/* ═══════════════════════════════════════════════════════════════════
 *  מודול גבייה ומנויים (SaaS Billing)
 *  ────────────────────────────────────────────────────────────────
 *  ⚠️ הבחנה קריטית בשמות:
 *    `subscriptions`      = מנוי שהעסק גובה מהלקוחות **שלו** (הוראת קבע ללקוח קצה)
 *    `orgSubscriptions`   = המנוי של העסק **אלינו** — זה מה שנמצא כאן
 *
 *  שבע החלטות שנושאות את המודול:
 *   1. ExternalUniqTranId = "sub_<id>_<YYYY-MM>" → קארדקום דוחה חיוב כפול
 *   2. UNIQUE (subscription_id, period_start) על החשבוניות → הגנה שנייה
 *   3. vatRate מוקפא בכל חשבונית — השיעור משתנה בחוק, חשבונית מ-2024 היא 17%
 *   4. billingAnchorDay מוגבל 1–28 — אין 31 בפברואר
 *   5. אין PAN ואין CVV. רק טוקן, 4 ספרות ותוקף. PCI-DSS SAQ-A.
 *   6. UNIQUE חלקי: מנוי פעיל אחד לארגון
 *   7. billingEvents הוא מקור האמת לכל שינוי כספי — append only
 * ═══════════════════════════════════════════════════════════════════ */

export const billingIntervalEnum = pgEnum('billing_interval', ['MONTHLY', 'YEARLY']);

export const subStatusEnum = pgEnum('sub_status', [
  'TRIALING', 'FREE', 'ACTIVE', 'PAST_DUE', 'CANCELING', 'SUSPENDED', 'CLOSED',
]);

export const billingInvoiceStatusEnum = pgEnum('billing_invoice_status', [
  'DRAFT', 'OPEN', 'PAID', 'ZERO_RATED', 'FAILED', 'REFUNDED', 'VOID',
]);

export const couponTypeEnum = pgEnum('coupon_type', [
  'PERCENT', 'FIXED', 'FREE_PERIODS', 'TRIAL_EXTEND',
]);
export const couponDurationEnum = pgEnum('coupon_duration', ['ONCE', 'REPEATING', 'FOREVER']);

export const subItemKindEnum = pgEnum('sub_item_kind', ['PLAN', 'ADDON']);
export const invoiceLineKindEnum = pgEnum('invoice_line_kind', [
  'PLAN', 'ADDON', 'PRORATION', 'DISCOUNT', 'CREDIT',
]);
export const pmStatusEnum = pgEnum('pm_status', ['VALID', 'EXPIRING', 'INVALID']);

/* ── 1. קטלוג המוצר ─────────────────────────────────────────── */

export const plans = pgTable('plans', {
  id: varchar('id', { length: 32 }).primaryKey(),      // free | basic | pro | business
  nameHe: text('name_he').notNull(),
  tagline: text('tagline'),
  sortOrder: integer('sort_order').notNull().default(0),
  isPublic: boolean('is_public').notNull().default(true),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const planPrices = pgTable('plan_prices', {
  id: uuid('id').primaryKey().defaultRandom(),
  planId: varchar('plan_id', { length: 32 }).notNull().references(() => plans.id, { onDelete: 'cascade' }),
  interval: billingIntervalEnum('interval').notNull(),
  amountExVat: numeric('amount_ex_vat', { precision: 12, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).notNull().default('ILS'),
  isActive: boolean('is_active').notNull().default(true),
}, (t) => [uniqueIndex('plan_price_uq').on(t.planId, t.interval)]);

/** מגבלה NULL = ללא הגבלה. isEnabled=false = הפיצ'ר נעול בחבילה. */
export const planEntitlements = pgTable('plan_entitlements', {
  planId: varchar('plan_id', { length: 32 }).notNull().references(() => plans.id, { onDelete: 'cascade' }),
  featureKey: varchar('feature_key', { length: 40 }).notNull(),
  limitValue: integer('limit_value'),
  isEnabled: boolean('is_enabled').notNull().default(true),
}, (t) => [primaryKey({ columns: [t.planId, t.featureKey] })]);

/* ── 2. המנוי ────────────────────────────────────────────────── */

export const orgSubscriptions = pgTable('org_subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  planId: varchar('plan_id', { length: 32 }).notNull().references(() => plans.id),
  interval: billingIntervalEnum('interval').notNull().default('MONTHLY'),
  status: subStatusEnum('status').notNull().default('TRIALING'),

  currentPeriodStart: timestamp('current_period_start', { withTimezone: true }).notNull().defaultNow(),
  currentPeriodEnd: timestamp('current_period_end', { withTimezone: true }).notNull(),
  trialEndsAt: timestamp('trial_ends_at', { withTimezone: true }),

  cancelAtPeriodEnd: boolean('cancel_at_period_end').notNull().default(false),
  canceledAt: timestamp('canceled_at', { withTimezone: true }),
  cancelReason: text('cancel_reason'),

  paymentMethodId: uuid('payment_method_id'),
  couponId: uuid('coupon_id'),
  couponCyclesLeft: integer('coupon_cycles_left'),

  dunningAttempt: integer('dunning_attempt').notNull().default(0),
  nextRetryAt: timestamp('next_retry_at', { withTimezone: true }),

  /** 1–28 בלבד. מנוי שנפתח ב-31 בינואר לא יכול להתחדש ב-31 בפברואר. */
  billingAnchorDay: integer('billing_anchor_day').notNull().default(1),

  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex('sub_org_live_uq').on(t.orgId),
  index('sub_due_idx').on(t.status, t.currentPeriodEnd),
  index('sub_retry_idx').on(t.status, t.nextRetryAt),
]);

export const subscriptionItems = pgTable('subscription_items', {
  id: uuid('id').primaryKey().defaultRandom(),
  subscriptionId: uuid('subscription_id').notNull()
    .references(() => orgSubscriptions.id, { onDelete: 'cascade' }),
  kind: subItemKindEnum('kind').notNull(),
  addonKey: varchar('addon_key', { length: 40 }),      // extra_user | extra_wa | storage_10gb
  quantity: integer('quantity').notNull().default(1),
  /** מוקפא ברגע ההוספה — שינוי מחירון לא משנה מנויים קיימים */
  unitExVat: numeric('unit_ex_vat', { precision: 12, scale: 2 }).notNull(),
  addedAt: timestamp('added_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('sub_item_sub_idx').on(t.subscriptionId)]);

/* ── 3. אמצעי תשלום ─────────────────────────────────────────── */

export const billingPaymentMethods = pgTable('billing_payment_methods', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  provider: paymentProviderEnum('provider').notNull().default('CARDCOM'),
  token: text('token').notNull(),
  last4: varchar('last4', { length: 4 }),
  brand: varchar('brand', { length: 24 }),
  expMonth: integer('exp_month'),
  expYear: integer('exp_year'),
  holderName: text('holder_name'),
  isDefault: boolean('is_default').notNull().default(true),
  status: pmStatusEnum('status').notNull().default('VALID'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('pm_org_idx').on(t.orgId, t.isDefault)]);

/* ── 4. חשבוניות וחיובים ────────────────────────────────────── */

export const billingInvoices = pgTable('billing_invoices', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  subscriptionId: uuid('subscription_id').references(() => orgSubscriptions.id, { onDelete: 'set null' }),
  seq: integer('seq').notNull().default(0),            // מספר רץ פנימי — לא מספר חשבונית מס

  periodStart: timestamp('period_start', { withTimezone: true }).notNull(),
  periodEnd: timestamp('period_end', { withTimezone: true }).notNull(),

  subtotalExVat: numeric('subtotal_ex_vat', { precision: 12, scale: 2 }).notNull(),
  discountExVat: numeric('discount_ex_vat', { precision: 12, scale: 2 }).notNull().default('0'),
  /** מוקפא לפי תאריך העסקה. לעולם לא קבוע גלובלי. */
  vatRate: numeric('vat_rate', { precision: 5, scale: 4 }).notNull(),
  vatAmount: numeric('vat_amount', { precision: 12, scale: 2 }).notNull(),
  totalIncVat: numeric('total_inc_vat', { precision: 12, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).notNull().default('ILS'),

  status: billingInvoiceStatusEnum('status').notNull().default('OPEN'),
  paidAt: timestamp('paid_at', { withTimezone: true }),

  cardcomTranId: varchar('cardcom_tran_id', { length: 32 }),
  cardcomDocNumber: varchar('cardcom_doc_number', { length: 32 }),
  cardcomDocUrl: text('cardcom_doc_url'),

  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex('inv_sub_period_uq').on(t.subscriptionId, t.periodStart),
  index('inv_org_idx').on(t.orgId, t.createdAt),
]);

export const billingInvoiceLines = pgTable('billing_invoice_lines', {
  id: uuid('id').primaryKey().defaultRandom(),
  invoiceId: uuid('invoice_id').notNull().references(() => billingInvoices.id, { onDelete: 'cascade' }),
  description: text('description').notNull(),
  quantity: numeric('quantity', { precision: 10, scale: 2 }).notNull().default('1'),
  unitExVat: numeric('unit_ex_vat', { precision: 12, scale: 2 }).notNull(),
  amountExVat: numeric('amount_ex_vat', { precision: 12, scale: 2 }).notNull(),
  kind: invoiceLineKindEnum('kind').notNull().default('PLAN'),
});

/** כל ניסיון חיוב — מוצלח או לא. externalUniqId ייחודי = הגנת אידמפוטנטיות. */
export const chargeAttempts = pgTable('charge_attempts', {
  id: uuid('id').primaryKey().defaultRandom(),
  invoiceId: uuid('invoice_id').notNull().references(() => billingInvoices.id, { onDelete: 'cascade' }),
  attemptNo: integer('attempt_no').notNull().default(1),
  externalUniqId: varchar('external_uniq_id', { length: 80 }).notNull(),
  requestSentAt: timestamp('request_sent_at', { withTimezone: true }).notNull().defaultNow(),
  responseCode: integer('response_code'),
  responseText: text('response_text'),
  cardcomTranId: varchar('cardcom_tran_id', { length: 32 }),
  succeeded: boolean('succeeded').notNull().default(false),
}, (t) => [uniqueIndex('charge_uniq_uq').on(t.externalUniqId)]);

/* ── 5. קופונים ─────────────────────────────────────────────── */

export const coupons = pgTable('coupons', {
  id: uuid('id').primaryKey().defaultRandom(),
  code: varchar('code', { length: 40 }).notNull(),
  type: couponTypeEnum('type').notNull(),
  value: numeric('value', { precision: 12, scale: 2 }).notNull(),
  duration: couponDurationEnum('duration').notNull().default('ONCE'),
  durationCycles: integer('duration_cycles'),

  validFrom: timestamp('valid_from', { withTimezone: true }),
  validUntil: timestamp('valid_until', { withTimezone: true }),

  maxRedemptions: integer('max_redemptions'),
  redemptionCount: integer('redemption_count').notNull().default(0),
  maxPerOrg: integer('max_per_org').notNull().default(1),

  appliesToPlans: jsonb('applies_to_plans').$type<string[] | null>(),
  appliesToInterval: billingIntervalEnum('applies_to_interval'),
  firstTimeOnly: boolean('first_time_only').notNull().default(false),
  minAmountExVat: numeric('min_amount_ex_vat', { precision: 12, scale: 2 }),

  campaign: varchar('campaign', { length: 64 }),
  note: text('note'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('coupon_code_uq').on(t.code)]);

export const couponRedemptions = pgTable('coupon_redemptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  couponId: uuid('coupon_id').notNull().references(() => coupons.id, { onDelete: 'cascade' }),
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  subscriptionId: uuid('subscription_id').references(() => orgSubscriptions.id, { onDelete: 'set null' }),
  redeemedAt: timestamp('redeemed_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex('coupon_org_uq').on(t.couponId, t.orgId)]);

/* ── 6. מדידה ואודיט ────────────────────────────────────────── */

export const usageCounters = pgTable('usage_counters', {
  orgId: uuid('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  featureKey: varchar('feature_key', { length: 40 }).notNull(),
  periodStart: varchar('period_start', { length: 10 }).notNull(),   // YYYY-MM-DD
  used: integer('used').notNull().default(0),
}, (t) => [primaryKey({ columns: [t.orgId, t.featureKey, t.periodStart] })]);

/** append-only. מקור האמת לכל שינוי כספי. */
export const billingEvents = pgTable('billing_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  orgId: uuid('org_id').references(() => organizations.id, { onDelete: 'cascade' }),
  subscriptionId: uuid('subscription_id'),
  type: varchar('type', { length: 48 }).notNull(),
  payload: jsonb('payload').notNull(),
  actor: varchar('actor', { length: 64 }),           // system:cron | user:<id> | admin:<id> | webhook:cardcom
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index('be_org_time_idx').on(t.orgId, t.createdAt)]);

/* ── RELATIONS ──────────────────────────────────────────────── */

export const orgSubscriptionsRelations = relations(orgSubscriptions, ({ one, many }) => ({
  org: one(organizations, { fields: [orgSubscriptions.orgId], references: [organizations.id] }),
  plan: one(plans, { fields: [orgSubscriptions.planId], references: [plans.id] }),
  items: many(subscriptionItems),
  invoices: many(billingInvoices),
}));

export const plansRelations = relations(plans, ({ many }) => ({
  prices: many(planPrices),
  entitlements: many(planEntitlements),
}));

export const billingInvoicesRelations = relations(billingInvoices, ({ one, many }) => ({
  subscription: one(orgSubscriptions, {
    fields: [billingInvoices.subscriptionId], references: [orgSubscriptions.id],
  }),
  lines: many(billingInvoiceLines),
  attempts: many(chargeAttempts),
}));
