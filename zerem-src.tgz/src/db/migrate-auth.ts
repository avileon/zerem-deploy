/**
 * מיגרציית האימות.
 *
 * ⚠️ drizzle-kit push לא יודע להסיר ערכים מ-enum שנמצא בשימוש —
 * הוא ינסה למחוק את הטיפוס וייכשל. לכן הצמצום מ-4 תפקידים ל-2
 * נעשה ידנית כאן, לפני ה-push.
 *
 * אידמפוטנטי: אפשר להריץ שוב בלי לשבור כלום.
 */
import 'dotenv/config';
import { sql } from './index';

async function main() {
  console.log('🔐 מיגרציית אימות…');

  const [{ exists }] = await sql<{ exists: boolean }[]>`
    SELECT EXISTS (SELECT 1 FROM pg_type t JOIN pg_enum e ON e.enumtypid = t.oid
                   WHERE t.typname = 'role' AND e.enumlabel = 'OWNER') AS exists
  `;

  if (exists) {
    console.log('  → ממיר תפקידים: OWNER/ADMIN → MANAGER, SALES_REP/VIEWER → EMPLOYEE');
    await sql.unsafe(`
      ALTER TABLE memberships ALTER COLUMN role DROP DEFAULT;
      ALTER TABLE memberships ALTER COLUMN role TYPE text USING role::text;
      UPDATE memberships SET role =
        CASE WHEN role IN ('OWNER','ADMIN') THEN 'MANAGER' ELSE 'EMPLOYEE' END;
      DROP TYPE IF EXISTS role;
      CREATE TYPE role AS ENUM ('MANAGER','EMPLOYEE');
      ALTER TABLE memberships ALTER COLUMN role TYPE role USING role::role;
      ALTER TABLE memberships ALTER COLUMN role SET DEFAULT 'EMPLOYEE';
    `);
    console.log('  ✓ תפקידים הומרו');
  } else {
    console.log('  ✓ התפקידים כבר מצומצמים');
  }

  // סטטוס משתמש — משתמשים קיימים שכבר יש להם סיסמה נחשבים פעילים
  await sql.unsafe(`
    DO $$ BEGIN
      CREATE TYPE user_status AS ENUM ('PENDING','ACTIVE','DISABLED');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
  `);
  await sql.unsafe(`
    ALTER TABLE users ADD COLUMN IF NOT EXISTS status user_status NOT NULL DEFAULT 'PENDING';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
    UPDATE users SET status = 'ACTIVE' WHERE password_hash IS NOT NULL AND status = 'PENDING';
  `);

  console.log('✅ מיגרציה הושלמה');
  await sql.end();
}

main().catch((e) => { console.error(e); process.exit(1); });
