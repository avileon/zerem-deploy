import { NextRequest, NextResponse } from 'next/server';

/**
 * שכבת ההגנה הראשונה.
 *
 * ⚠️ מה שהיא **לא** עושה: לא מאמתת סשן מול בסיס הנתונים.
 * Middleware ב-Next רץ ב-Edge runtime, בלי גישה ל-Postgres.
 * לכן היא בודקת רק *נוכחות* עוגייה ומפנה מוקדם — האימות האמיתי
 * נעשה בכל דף ובכל מסלול API דרך requireTenant/requireConsole.
 *
 * מי שיזייף עוגייה יעבור את השלב הזה ויידחה בשלב הבא.
 * זה בכוונה: middleware לנוחות, שרת לאבטחה.
 */

const TENANT_COOKIE = 'zerem_session';
const CONSOLE_COOKIE = 'zerem_console';

/** נתיבים פתוחים לכולם */
const PUBLIC = [
  '/login', '/signup', '/set-password', '/forgot-password',
  '/pricing', '/billing/return', '/offline',
];

/** נתיבי API שחייבים להישאר פתוחים — נקראים ממערכות חיצוניות */
const PUBLIC_API = [
  '/api/ingest', '/api/webhooks', '/api/cron', '/api/auth',
];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // נכסים סטטיים, אייקונים, service worker
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/icons') ||
    /\.(png|jpg|jpeg|svg|ico|webmanifest|js|css|txt|xml)$/.test(pathname)
  ) return NextResponse.next();

  // חתימה ציבורית על הצעת מחיר — הלקוח של הלקוח אינו משתמש רשום
  if (pathname.startsWith('/q/')) return NextResponse.next();

  if (PUBLIC_API.some((p) => pathname.startsWith(p))) return NextResponse.next();

  /* ── מסלולי API מוגנים ──
     ⚠️ API מחזיר 401 עם JSON, לא הפניה. הפניה 307 עם HTML במקום
     401 שוברת כל לקוח שמצפה לתשובת JSON — הבדיקה תפסה בדיוק את זה. */
  if (pathname.startsWith('/api/')) {
    const needsConsole = pathname.startsWith('/api/console');
    const cookie = needsConsole ? CONSOLE_COOKIE : TENANT_COOKIE;
    if (!req.cookies.get(cookie)) {
      return NextResponse.json({ ok: false, error: 'נדרשת התחברות' }, { status: 401 });
    }
    return NextResponse.next();
  }

  /* ── עולם הקונסולה ── */
  if (pathname.startsWith('/console')) {
    if (pathname === '/console/login' || pathname.startsWith('/console/set-password')) {
      return NextResponse.next();
    }
    if (!req.cookies.get(CONSOLE_COOKIE)) {
      const url = req.nextUrl.clone();
      url.pathname = '/console/login';
      url.search = pathname === '/console' ? '' : `?next=${encodeURIComponent(pathname)}`;
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  /* ── עולם הלקוח ── */
  if (PUBLIC.some((p) => pathname === p || pathname.startsWith(p + '/'))) {
    return NextResponse.next();
  }

  if (!req.cookies.get(TENANT_COOKIE)) {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    url.search = pathname === '/' ? '' : `?next=${encodeURIComponent(pathname)}`;
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
