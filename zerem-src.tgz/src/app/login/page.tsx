import Link from 'next/link';
import { redirect } from 'next/navigation';
import AuthForm from '@/components/AuthForm';
import { getTenantSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export default async function LoginPage({
  searchParams,
}: { searchParams: Promise<{ next?: string }> }) {
  if (await getTenantSession()) redirect('/');
  const sp = await searchParams;

  return (
    <AuthForm
      mode="tenant"
      title="זרם"
      subtitle="כניסה למערכת"
      endpoint="/api/auth/login"
      next={sp.next}
      footer={
        <>
          שכחת סיסמה? <Link href="/forgot-password" className="font-bold text-teal-700">איפוס</Link>
          <span className="mx-1.5">·</span>
          אין לך חשבון? <Link href="/pricing" className="font-bold text-teal-700">התחלה חינם</Link>
        </>
      }
    />
  );
}
