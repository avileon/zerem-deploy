import type { Metadata, Viewport } from 'next';
import './globals.css';
import Shell from '@/components/Shell';
import { getTenantSession } from '@/lib/auth/session';

export const metadata: Metadata = {
  title: 'זרם — CRM לעסקים קטנים',
  description: 'ניהול לידים, משימות, הצעות מחיר ותשלומים — מהנייד ומהמחשב',
  manifest: '/manifest.webmanifest',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'זרם' },
  formatDetection: { telephone: true },
};

export const viewport: Viewport = {
  themeColor: '#0f766e',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  viewportFit: 'cover',
};

/**
 * הסשן נקרא כאן, בשרת, ומועבר ל-Shell כ-props.
 * זו הסיבה שהתפריט יודע להסתיר פריטי מנהל מעובד — אבל ההסתרה הזו
 * היא נוחות בלבד: האכיפה נמצאת ב-requireManager() בכל דף ומסלול.
 */
export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const sess = await getTenantSession();

  return (
    <html lang="he" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Assistant:wght@300;400;600;700;800&display=swap" rel="stylesheet" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body className="antialiased">
        <Shell
          session={sess && {
            role: sess.role,
            userName: sess.userName,
            orgName: sess.orgName,
            impersonatedBy: sess.impersonatedBy?.adminName ?? null,
          }}
        >
          {children}
        </Shell>
      </body>
    </html>
  );
}
