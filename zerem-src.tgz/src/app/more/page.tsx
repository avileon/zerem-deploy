import Link from 'next/link';
import { PageHeader } from '@/components/ui';

const ITEMS = [
  { href: '/payments', label: 'תשלומים וחשבוניות', icon: '💳', desc: 'Cardcom · ריווחית' },
  { href: '/catalog', label: 'קטלוג מוצרים', icon: '🏷️', desc: 'מחירים ורווחיות' },
  { href: '/reports', label: 'דוחות', icon: '📊', desc: 'ביצועי צוות ומקורות' },
  { href: '/integrations', label: 'אינטגרציות', icon: '🔌', desc: 'וואטסאפ, סליקה, טפסים' },
  { href: '/team', label: 'צוות והרשאות', icon: '🧑‍💼', desc: 'משתמשים ותפקידים' },
  { href: '/notifications', label: 'התראות', icon: '🔔', desc: 'Push ווואטסאפ' },
];

export default function More() {
  return (
    <div className="p-4">
      <PageHeader title="עוד" />
      <div className="space-y-2">
        {ITEMS.map((i) => (
          <Link key={i.href} href={i.href} className="card flex items-center gap-3 p-4">
            <span className="text-xl">{i.icon}</span>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold text-slate-800">{i.label}</div>
              <div className="text-[11px] text-slate-400">{i.desc}</div>
            </div>
            <span className="text-slate-300">←</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
