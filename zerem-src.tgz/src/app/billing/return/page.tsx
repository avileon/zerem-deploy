import Link from 'next/link';

export const dynamic = 'force-dynamic';

/**
 * דף החזרה מקארדקום.
 * ה-webhook וההפניה מגיעים שניהם, והסדר לא מובטח — לכן הדף
 * הזה לא מנסה "לסגור" את העסקה בעצמו אלא רק להראות מצב.
 * מקור האמת הוא GetLpResult שרץ מה-webhook.
 */
export default async function BillingReturn({
  searchParams,
}: { searchParams: Promise<{ ok?: string; pm?: string }> }) {
  const sp = await searchParams;
  const ok = sp.ok === '1';
  const isPm = sp.pm === '1';

  return (
    <div className="flex min-h-[70vh] items-center justify-center p-6">
      <div className="card w-full max-w-sm p-7 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full text-3xl"
             style={{ background: ok ? 'linear-gradient(135deg,#5eead4,#14b8a6)' : 'linear-gradient(135deg,#fecaca,#f87171)' }}>
          {ok ? '✓' : '✕'}
        </div>
        <h1 className="mt-4 text-lg font-black text-slate-900">
          {ok ? (isPm ? 'הכרטיס עודכן' : 'המנוי הופעל') : 'התשלום לא הושלם'}
        </h1>
        <p className="mt-2 text-[12px] leading-relaxed text-slate-500">
          {ok
            ? isPm
              ? 'החיוב הבא ייגבה מהכרטיס החדש. אם החשבון היה מושהה, הוא נפתח עכשיו.'
              : 'חשבונית המס נשלחה למייל. אפשר להתחיל לעבוד.'
            : 'לא בוצע חיוב. אפשר לנסות שוב או להשתמש בכרטיס אחר.'}
        </p>
        <div className="mt-5 flex gap-2">
          <Link href="/settings/billing" className="btn btn-ghost flex-1">לאזור החיוב</Link>
          <Link href="/" className="btn btn-primary flex-1">{ok ? 'למערכת' : 'לדשבורד'}</Link>
        </div>
        {ok && (
          <p className="mt-4 text-[10px] text-slate-400">
            עדכון הסטטוס עשוי לקחת עד דקה. רענון הדף יציג את המצב המעודכן.
          </p>
        )}
      </div>
    </div>
  );
}
