import Link from 'next/link';
import { currentOrg } from '@/lib/queries';
import { getSubscription, listInvoices } from '@/lib/billing/service';
import { ils } from '@/lib/israel';

export const dynamic = 'force-dynamic';

/** מסך אחד בלבד: מה חייבים, איך משלמים, ואיך מוציאים את הנתונים. */
export default async function Suspended() {
  const org = await currentOrg();
  const sub = org ? await getSubscription(org.id) : null;
  const invoices = org ? await listInvoices(org.id, 5) : [];
  const open = invoices.find((i) => i.status === 'FAILED' || i.status === 'OPEN');

  return (
    <div className="flex min-h-[70vh] items-center justify-center p-6">
      <div className="card w-full max-w-md p-7">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-2xl">⏸</div>
        <h1 className="mt-4 text-xl font-black text-slate-900">החשבון מושהה</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-slate-600">
          לא הצלחנו לגבות את התשלום אחרי חמישה ניסיונות. הנתונים שלך שמורים במלואם
          ונפתחים מיד עם השלמת התשלום.
        </p>

        {open && (
          <div className="mt-4 rounded-xl bg-slate-50 p-4">
            <div className="flex items-baseline justify-between">
              <span className="text-[12px] text-slate-500">סכום לתשלום</span>
              <span className="num text-xl font-black text-slate-900">{ils(open.totalIncVat)}</span>
            </div>
            <div className="mt-1 text-[10px] text-slate-400">כולל מע״מ · תקופה שלא שולמה</div>
          </div>
        )}

        <form action="/api/billing/payment-method" method="post" className="mt-5">
          <Link href="/settings/billing" className="btn btn-primary w-full">עדכון אמצעי תשלום</Link>
        </form>

        <div className="mt-4 border-t border-slate-100 pt-4">
          <div className="text-[11px] font-bold text-slate-500">גם אם לא תמשיך</div>
          <p className="mt-1 text-[11px] leading-relaxed text-slate-400">
            אפשר לייצא את כל הלידים, ההצעות והחשבוניות בכל רגע. הנתונים נשמרים
            {sub ? ' 30 יום נוספים' : ''} לפני סגירה סופית.
          </p>
          <Link href="/api/export" className="btn btn-ghost btn-sm mt-2 w-full">ייצוא הנתונים</Link>
        </div>
      </div>
    </div>
  );
}
