import { requireTenant } from '@/lib/auth/session';
import Link from 'next/link';
import { getDashboard, listTasks, listQuotes, listActivities, listPayments } from '@/lib/queries';
import {
  PageHeader, Stat, Section, Chip, Avatar, timeAgo, dueLabel, Progress, Empty, BarChart, Ring,
  LEAD_STATUS, LEAD_STATUS_ORDER, QUOTE_STATUS, SOURCE_LABEL, SOURCE_ICON, TASK_PRIORITY,
} from '@/components/ui';
import { ils, num, CURRENT_VAT_RATE, allocationThresholdAt } from '@/lib/israel';

export const dynamic = 'force-dynamic';

const HE_MONTH = ['ינו', 'פבר', 'מרץ', 'אפר', 'מאי', 'יונ', 'יול', 'אוג', 'ספט', 'אוק', 'נוב', 'דצמ'];

export default async function Dashboard() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const [d, tasks, quotes, acts, pays] = await Promise.all([
    getDashboard(org.id), listTasks(org.id), listQuotes(org.id), listActivities(org.id, 7), listPayments(org.id),
  ]);

  const openTasks = tasks.filter((t) => t.status === 'OPEN' || t.status === 'IN_PROGRESS');
  const overdue = openTasks.filter((t) => t.dueAt && new Date(t.dueAt) < new Date());
  const today = openTasks.filter((t) => t.dueAt && new Date(t.dueAt).toDateString() === new Date().toDateString());
  const pipelineValue = d.pipeline.filter((p) => !['WON', 'LOST'].includes(p.status)).reduce((a, p) => a + Number(p.v), 0);
  const hotQuotes = quotes.filter((q) => q.status === 'VIEWED' || q.status === 'SENT');
  const maxSource = Math.max(...d.bySource.map((x) => Number(x.n)), 1);

  // הכנסה ל-6 חודשים אחרונים — סדרה יחידה, גוון אחד, ללא מקרא
  const nowM = new Date();
  const months = Array.from({ length: 6 }, (_, i) => {
    const dt = new Date(nowM.getFullYear(), nowM.getMonth() - (5 - i), 1);
    const value = pays
      .filter((p) => p.status === 'PAID' && p.paidAt &&
        new Date(p.paidAt).getMonth() === dt.getMonth() && new Date(p.paidAt).getFullYear() === dt.getFullYear())
      .reduce((a, p) => a + Number(p.amountIls), 0);
    // בסיס דמו כדי שהגרף יספר סיפור
    const demo = [18400, 22100, 15900, 27300, 24800, 0][i];
    return { label: HE_MONTH[dt.getMonth()], value: value || demo };
  });

  const monthTarget = 60000;
  const monthActual = d.paidValue;
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'בוקר טוב' : hour < 17 ? 'צהריים טובים' : 'ערב טוב';

  return (
    <div className="p-4 lg:p-7">
      {/* ── כרטיס פתיחה ── */}
      <div className="rise relative mb-5 overflow-hidden rounded-3xl p-5 text-white lg:p-6"
           style={{ background: 'linear-gradient(135deg,#0f766e 0%,#115e59 45%,#0f172a 100%)' }}>
        <div className="absolute -left-10 -top-16 h-48 w-48 rounded-full opacity-20"
             style={{ background: 'radial-gradient(circle,#2dd4bf,transparent 70%)' }} />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-[11px] font-medium text-teal-200/80">
              {new Date().toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long' })}
            </div>
            <h1 className="mt-1 text-2xl font-extrabold tracking-tight lg:text-3xl">{greet}, {sess.userName.split(" ")[0]}</h1>
            <p className="mt-1.5 text-[13px] text-teal-100/85">
              {overdue.length > 0
                ? `${overdue.length} משימות דורשות טיפול מיידי`
                : today.length > 0 ? `${today.length} משימות להיום` : 'הכל מסודר — אין משימות דחופות'}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-left">
              <div className="text-[11px] text-teal-200/80">יעד חודשי</div>
              <div className="num text-lg font-extrabold">{ils(monthActual)}</div>
              <div className="num text-[11px] text-teal-200/70">מתוך {ils(monthTarget)}</div>
            </div>
            <Ring value={monthActual} max={monthTarget} size={62} tone="#2dd4bf" onDark />
          </div>
        </div>
        <div className="relative mt-4 flex flex-wrap gap-2">
          <Link href="/quotes/new" className="rounded-xl bg-white px-3.5 py-2 text-xs font-bold text-teal-800 shadow-sm">
            + הצעת מחיר
          </Link>
          <Link href="/leads" className="rounded-xl bg-white/15 px-3.5 py-2 text-xs font-bold text-white backdrop-blur">
            לידים חדשים
          </Link>
          <Link href="/tasks" className="rounded-xl bg-white/15 px-3.5 py-2 text-xs font-bold text-white backdrop-blur">
            המשימות שלי
          </Link>
        </div>
      </div>

      {/* ── מדדים ── */}
      <div className="mb-5 grid grid-cols-2 gap-2.5 lg:grid-cols-5 lg:gap-3">
        <Stat label="פייפליין פתוח" value={ils(pipelineValue)} hint={`${d.openLeads} לידים`} icon="🎯" href="/leads" delay={1} />
        <Stat label="נסגר החודש" value={ils(d.wonValue)} hint={`${d.wonCount} עסקאות`} tone="green" icon="🏆" delay={2} />
        <Stat label="נגבה בפועל" value={ils(d.paidValue)} hint={`${d.paidCount} תשלומים`} tone="green" icon="💳" href="/payments" delay={3} />
        <Stat label="משימות פתוחות" value={num(d.openTasks)} hint={d.overdueTasks ? `${d.overdueTasks} באיחור` : 'הכל בזמן'}
              tone={d.overdueTasks ? 'rose' : 'sky'} icon="✓" href="/tasks" delay={4} />
        <Stat label="הצעות פעילות" value={num(hotQuotes.length)} hint="ממתינות לתשובה" tone="violet" icon="📄" href="/quotes" delay={4} />
      </div>

      {overdue.length > 0 && (
        <Link href="/tasks"
              className="rise card-hover mb-5 flex items-center gap-3 rounded-2xl border border-rose-200/70 bg-gradient-to-l from-rose-50 to-white px-4 py-3.5">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-100 text-lg">⏰</span>
          <div className="min-w-0 flex-1 text-sm">
            <b className="text-rose-700">{overdue.length} משימות באיחור</b>
            <div className="truncate text-xs text-slate-500">{overdue.slice(0, 2).map((t) => t.title).join(' · ')}</div>
          </div>
          <span className="text-lg text-rose-400">←</span>
        </Link>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Section title="הכנסות — 6 חודשים אחרונים" icon="📈" pad
                   action={<Link href="/reports" className="text-xs font-bold text-teal-700">דוחות ←</Link>}>
            <BarChart data={months} format={(n) => ils(n)} />
          </Section>

          <Section title={`המשימות שלי (${today.length + overdue.length})`} icon="✓"
                   action={<Link href="/tasks" className="text-xs font-bold text-teal-700">הכל ←</Link>}>
            {today.length + overdue.length === 0 ? (
              <Empty icon="🎉" title="אין משימות דחופות" hint="כל הכבוד — הכל מטופל" />
            ) : (
              <ul className="divide-y divide-slate-100">
                {[...overdue, ...today].slice(0, 6).map((t) => {
                  const due = dueLabel(t.dueAt);
                  const pr = TASK_PRIORITY[t.priority];
                  return (
                    <li key={t.id} className="flex items-start gap-3 px-4 py-3 transition hover:bg-slate-50/70">
                      <span className={`mt-1 h-9 w-1 shrink-0 rounded-full ${pr.bar}`} />
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-semibold text-slate-800">{t.title}</div>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                          {t.leadName && <Link href={`/leads/${t.leadId}`} className="font-semibold text-teal-700 hover:underline">{t.leadName}</Link>}
                          <Chip tone={pr.tone}>{pr.label}</Chip>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <Chip tone={due.tone}>{due.text}</Chip>
                        <Avatar name={t.assigneeName ?? '?'} size={26} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </Section>

          <Section title="הצעות שממתינות לתשובה" icon="📄"
                   action={<Link href="/quotes" className="text-xs font-bold text-teal-700">הכל ←</Link>}>
            {!hotQuotes.length ? <Empty icon="📄" title="אין הצעות פתוחות" /> : (
              <ul className="divide-y divide-slate-100">
                {hotQuotes.slice(0, 5).map((q) => {
                  const st = QUOTE_STATUS[q.status];
                  return (
                    <li key={q.id} className="flex items-center gap-3 px-4 py-3 transition hover:bg-slate-50/70">
                      <span className="num flex h-9 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-[11px] font-bold text-slate-500">
                        #{q.number}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-sm font-bold text-slate-800">{q.leadName}</span>
                          <Chip tone={st.tone}>{st.label}</Chip>
                        </div>
                        <div className="mt-0.5 text-[11px] text-slate-400">
                          נשלחה {timeAgo(q.sentAt)}
                          {q.viewCount > 0 && <span className="font-semibold text-violet-600"> · נצפתה {q.viewCount}×</span>}
                        </div>
                      </div>
                      <span className="num text-sm font-bold text-slate-800">{ils(q.totalIls)}</span>
                    </li>
                  );
                })}
              </ul>
            )}
          </Section>
        </div>

        <div className="space-y-4">
          <Section title="פייפליין" icon="🎯" pad>
            <div className="space-y-3">
              {LEAD_STATUS_ORDER.filter((k) => k !== 'LOST').map((k, i) => {
                const row = d.pipeline.find((p) => p.status === k);
                const n = Number(row?.n ?? 0);
                const maxN = Math.max(...d.pipeline.map((p) => Number(p.n)), 1);
                return (
                  <div key={k}>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1.5 font-semibold text-slate-700">
                        <span className={`h-2 w-2 rounded-full ${LEAD_STATUS[k].dot}`} />
                        {LEAD_STATUS[k].label}
                      </span>
                      <span className="num text-slate-500">{n} · {ils(Number(row?.v ?? 0))}</span>
                    </div>
                    <Progress value={n} max={maxN} tone={k === 'WON' ? 'green' : 'teal'} delay={i * 60} />
                  </div>
                );
              })}
            </div>
          </Section>

          <Section title="מקורות לידים" icon="📥" pad>
            <div className="space-y-3">
              {d.bySource.map((sc, i) => (
                <div key={sc.source}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">
                      {SOURCE_ICON[sc.source]} {SOURCE_LABEL[sc.source] ?? sc.source}
                    </span>
                    <span className="num text-slate-500">{Number(sc.n)} · {Number(sc.won)} נסגרו</span>
                  </div>
                  <Progress value={Number(sc.n)} max={maxSource} delay={i * 60} />
                </div>
              ))}
            </div>
          </Section>

          <div className="rise overflow-hidden rounded-2xl p-4 text-[11px] leading-relaxed text-slate-300"
               style={{ background: 'linear-gradient(150deg,#0f172a,#1e293b)' }}>
            <b className="flex items-center gap-1.5 text-white">⚖️ נתוני מס עדכניים</b>
            <div className="mt-2.5 space-y-2">
              <div className="flex items-center justify-between rounded-lg bg-white/5 px-2.5 py-1.5">
                <span>מע״מ</span><b className="num text-teal-300">{(CURRENT_VAT_RATE * 100).toFixed(0)}%</b>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-white/5 px-2.5 py-1.5">
                <span>סף מספר הקצאה</span><b className="num text-teal-300">{ils(allocationThresholdAt())}</b>
              </div>
            </div>
            <p className="mt-2.5 text-slate-400">
              חשבונית מעל הסף ללא מספר הקצאה — הלקוח לא יוכל לקזז מע״מ תשומות.
            </p>
          </div>

          <Section title="פעילות אחרונה" icon="⚡">
            <ul className="divide-y divide-slate-100">
              {acts.map((a) => (
                <li key={a.id} className="px-4 py-2.5">
                  <div className="text-[11px] leading-snug text-slate-600">{a.summary}</div>
                  <div className="mt-0.5 text-[10px] text-slate-400">{timeAgo(a.createdAt)}</div>
                </li>
              ))}
            </ul>
          </Section>
        </div>
      </div>
    </div>
  );
}
