import { currentOrg, listPayments, listDocs } from '@/lib/queries';
import { PageHeader, Section, Chip, timeAgo, PAYMENT_STATUS, DOC_KIND } from '@/components/ui';
import { ils, ils2, allocationThresholdAt } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function PaymentsPage() {
  const org = await currentOrg();
  const [pays, docs] = await Promise.all([listPayments(org.id), listDocs(org.id)]);
  const paid = pays.filter((p) => p.status === 'PAID');
  const pending = pays.filter((p) => p.status === 'PENDING');

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="תשלומים וחשבוניות" subtitle="Cardcom לסליקה · ריווחית להנפקה" />

      <div className="mb-4 grid grid-cols-3 gap-2.5">
        <div className="card p-3.5"><div className="label">נגבה</div><div className="num mt-1 text-lg font-bold text-green-600 lg:text-2xl">{ils(paid.reduce((a,p)=>a+Number(p.amountIls),0))}</div></div>
        <div className="card p-3.5"><div className="label">ממתין</div><div className="num mt-1 text-lg font-bold text-amber-600 lg:text-2xl">{ils(pending.reduce((a,p)=>a+Number(p.amountIls),0))}</div></div>
        <div className="card p-3.5"><div className="label">מסמכים</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{docs.length}</div></div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="תשלומים">
          <ul className="divide-y divide-slate-100">
            {pays.map((p) => {
              const st = PAYMENT_STATUS[p.status];
              return (
                <li key={p.id} className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-bold">{p.leadName}</span>
                        <Chip tone={st.tone}>{st.label}</Chip>
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-400">
                        {p.provider}{p.quoteNumber ? ` · הצעה #${p.quoteNumber}` : ''}
                        {p.installments > 1 && ` · ${p.installments} תשלומים`}
                        {p.last4 && <> · <span className="ltr">{p.cardBrand} ••{p.last4}</span></>}
                      </div>
                      {p.approvalNumber && <div className="ltr mt-0.5 text-[10px] text-slate-400">אישור {p.approvalNumber} · עסקה {p.transactionId}</div>}
                    </div>
                    <div className="text-left">
                      <div className="num text-sm font-bold">{ils2(p.amountIls)}</div>
                      <div className="text-[10px] text-slate-400">{timeAgo(p.paidAt ?? p.createdAt)}</div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </Section>

        <Section title="מסמכי חשבונאות">
          <ul className="divide-y divide-slate-100">
            {docs.map((d) => (
              <li key={d.id} className="px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-bold">{DOC_KIND[d.kind]}</span>
                      <span className="num text-xs text-slate-400">#{d.documentNumber}</span>
                      <Chip tone="teal">{d.provider}</Chip>
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-400">{d.leadName} · {timeAgo(d.issuedAt)}</div>
                    {d.allocationRequired ? (
                      <div className="mt-1">
                        <Chip tone={d.allocationStatus === 'OK' ? 'green' : 'rose'}>
                          מספר הקצאה: {d.allocationNumber ?? 'חסר'}
                        </Chip>
                      </div>
                    ) : (
                      <div className="mt-1 text-[10px] text-slate-400">מתחת לסף {ils(allocationThresholdAt())} — לא נדרש מספר הקצאה</div>
                    )}
                  </div>
                  <div className="text-left">
                    <div className="num text-sm font-bold">{ils2(d.amountIls)}</div>
                    <div className="num text-[10px] text-slate-400">מע״מ {ils2(d.vatIls)}</div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Section>
      </div>
    </div>
  );
}
