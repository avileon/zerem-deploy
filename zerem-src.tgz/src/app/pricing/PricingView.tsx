'use client';
import { useState, useMemo } from 'react';
import { PageHeader, Chip, Section } from '@/components/ui';
import { ils } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

const ACCENT: Record<string, { bar: string; ring: string; text: string }> = {
  free:     { bar: 'linear-gradient(90deg,#94a3b8,#64748b)', ring: 'ring-slate-200',  text: 'text-slate-600' },
  basic:    { bar: 'linear-gradient(90deg,#38bdf8,#0284c7)', ring: 'ring-sky-200',    text: 'text-sky-700' },
  pro:      { bar: 'linear-gradient(90deg,#2dd4bf,#0d9488)', ring: 'ring-teal-300',   text: 'text-teal-700' },
  business: { bar: 'linear-gradient(90deg,#a78bfa,#7c3aed)', ring: 'ring-violet-200', text: 'text-violet-700' },
};

export default function PricingView({
  plans, addons, features, vatRate, trialDays, currentPlanId, currentInterval, status,
}: {
  plans: any[]; addons: any[]; features: any[];
  vatRate: number; trialDays: number;
  currentPlanId: string | null; currentInterval: string; status: string | null;
}) {
  const [interval, setInterval] = useState<'MONTHLY' | 'YEARLY'>(
    currentInterval === 'YEARLY' ? 'YEARLY' : 'MONTHLY',
  );
  const [coupon, setCoupon] = useState('');
  const [couponState, setCouponState] = useState<any>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);

  const savingPct = useMemo(() => {
    const p = plans.find((x) => x.id === 'pro');
    if (!p?.monthly || !p?.yearly) return 17;
    return Math.round((1 - p.yearly / (p.monthly * 12)) * 100);
  }, [plans]);

  async function checkCoupon(planId: string) {
    if (!coupon.trim()) return;
    setBusy('coupon');
    const r = await fetch('/api/billing/coupon/validate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: coupon, planId, interval }),
    }).then((x) => x.json()).catch(() => ({ ok: false, reason: 'שגיאת רשת' }));
    setCouponState(r);
    setBusy(null);
  }

  async function subscribe(planId: string) {
    setBusy(planId);
    const r = await fetch('/api/billing/checkout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planId, interval, couponCode: couponState?.ok ? coupon : undefined }),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(null);
    if (r.ok && r.url) window.location.href = r.url;
    else alert(r.error ?? 'לא הצלחנו לפתוח את דף התשלום');
  }

  const price = (p: any) => (interval === 'YEARLY' ? p.yearly : p.monthly) ?? 0;
  const monthlyEquivalent = (p: any) =>
    interval === 'YEARLY' && p.yearly ? Math.round((p.yearly / 12) * 10) / 10 : p.monthly ?? 0;

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="חבילות ומחירים"
        subtitle={`${trialDays} ימי ניסיון מלאים · ללא כרטיס אשראי · ביטול בקליק אחד`}
      />

      {/* ── מתג חודשי/שנתי ── */}
      <div className="mb-5 flex items-center justify-center">
        <div className="inline-flex items-center rounded-2xl border border-slate-200 bg-white p-1 shadow-sm">
          {(['MONTHLY', 'YEARLY'] as const).map((v) => (
            <button key={v} onClick={() => setInterval(v)}
              className={`relative rounded-xl px-4 py-2 text-sm font-bold transition ${
                interval === v ? 'bg-teal-700 text-white shadow' : 'text-slate-500 hover:text-slate-700'}`}>
              {v === 'MONTHLY' ? 'חודשי' : 'שנתי'}
              {v === 'YEARLY' && (
                <span className={`mr-1.5 rounded-full px-1.5 py-0.5 text-[10px] font-black ${
                  interval === 'YEARLY' ? 'bg-white/20 text-white' : 'bg-green-100 text-green-700'}`}>
                  −{savingPct}%
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* ── כרטיסי החבילות ── */}
      <div className="grid gap-3 lg:grid-cols-4">
        {plans.map((p) => {
          const a = ACCENT[p.id] ?? ACCENT.free;
          const isCurrent = currentPlanId === p.id && status !== 'TRIALING';
          const isPopular = p.id === 'pro';
          return (
            <div key={p.id}
              className={`card rise relative overflow-hidden p-4 ${isPopular ? `ring-2 ${a.ring}` : ''}`}>
              <span className="absolute inset-x-0 top-0 h-1" style={{ background: a.bar }} />
              {isPopular && (
                <div className="absolute left-3 top-3">
                  <Chip tone="teal">הכי נבחר</Chip>
                </div>
              )}

              <div className="mt-2">
                <div className={`text-base font-extrabold ${a.text}`}>{p.nameHe}</div>
                <div className="mt-0.5 min-h-[32px] text-[11px] leading-snug text-slate-400">{p.tagline}</div>
              </div>

              <div className="mt-3 flex items-end gap-1.5">
                <span className="num text-3xl font-black text-slate-900">
                  {price(p) === 0 ? '₪0' : ils(price(p))}
                </span>
                <span className="mb-1 text-[11px] text-slate-400">
                  {price(p) === 0 ? '' : interval === 'YEARLY' ? '/שנה' : '/חודש'}
                </span>
              </div>
              <div className="mt-0.5 text-[10px] text-slate-400">
                {price(p) === 0
                  ? 'ללא הגבלת זמן'
                  : <>≈ {ils(monthlyEquivalent(p))} לחודש · {ils(Math.round(price(p) * (1 + vatRate)))} כולל מע״מ</>}
              </div>

              <ul className="mt-3 space-y-1.5 border-t border-slate-100 pt-3">
                {p.highlights.map((h: string) => (
                  <li key={h} className="flex items-start gap-1.5 text-[12px] text-slate-600">
                    <span className="mt-[2px] text-teal-600">✓</span>{h}
                  </li>
                ))}
              </ul>

              <button
                disabled={isCurrent || busy === p.id}
                onClick={() => (p.id === 'free' ? null : subscribe(p.id))}
                className={`btn mt-4 w-full ${isCurrent ? 'btn-ghost' : isPopular ? 'btn-primary' : 'btn-ghost'}`}>
                {isCurrent ? 'החבילה שלך' : busy === p.id ? 'רגע…' : p.id === 'free' ? 'להתחיל חינם' : 'בחירה'}
              </button>
            </div>
          );
        })}
      </div>

      {/* ── קופון ── */}
      <div className="card mt-4 p-4">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-center">
          <div className="flex-1">
            <div className="text-sm font-bold text-slate-800">יש לך קוד קופון?</div>
            <div className="text-[11px] text-slate-400">ההנחה תוצג לפני שתאשר את התשלום</div>
          </div>
          <div className="flex gap-2">
            <input value={coupon} onChange={(e) => { setCoupon(e.target.value.toUpperCase()); setCouponState(null); }}
                   placeholder="LAUNCH2026" className="input ltr w-44 text-center font-bold tracking-wider" />
            <button onClick={() => checkCoupon('pro')} disabled={busy === 'coupon'} className="btn btn-ghost">
              {busy === 'coupon' ? '…' : 'בדיקה'}
            </button>
          </div>
        </div>
        {couponState && (
          <div className={`mt-3 rounded-xl px-3 py-2 text-[12px] font-semibold ${
            couponState.ok ? 'bg-green-50 text-green-800' : 'bg-rose-50 text-rose-700'}`}>
            {couponState.ok
              ? <>✓ {couponState.label} — לתשלום {ils(couponState.totalIncVat)} כולל מע״מ</>
              : <>✕ {couponState.reason}</>}
          </div>
        )}
      </div>

      {/* ── טבלת השוואה ── */}
      <Section title="השוואה מלאה" action={
        <button onClick={() => setShowAll((v) => !v)} className="text-[11px] font-bold text-teal-700">
          {showAll ? 'הסתרה' : 'הצגה'}
        </button>
      }>
        {showAll && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-[12px]">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] text-slate-400">
                  <th className="py-2 pr-2 font-semibold">יכולת</th>
                  {plans.map((p) => <th key={p.id} className="px-2 py-2 text-center font-bold text-slate-600">{p.nameHe}</th>)}
                </tr>
              </thead>
              <tbody>
                {features.map((f: any) => (
                  <tr key={f.key} className="border-b border-slate-50">
                    <td className="py-2 pr-2 text-slate-600">{f.label}</td>
                    {plans.map((p) => {
                      const v = p.entitlements[f.key];
                      return (
                        <td key={p.id} className="px-2 py-2 text-center">
                          {v === false ? <span className="text-slate-300">—</span>
                           : v === null ? <span className="font-bold text-teal-700">ללא הגבלה</span>
                           : v === true ? <span className="text-teal-600">✓</span>
                           : <span className="num font-semibold text-slate-700">{v}</span>}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Section>

      {/* ── תוספות ── */}
      <Section title="תוספות">
        <div className="grid gap-2 lg:grid-cols-3">
          {addons.map((a: any) => (
            <div key={a.key} className="flex items-center justify-between rounded-xl border border-slate-200 p-3">
              <div>
                <div className="text-[13px] font-bold text-slate-800">{a.label}</div>
                <div className="text-[10px] text-slate-400">זמין ב-{a.availableIn.length} חבילות</div>
              </div>
              <div className="num text-sm font-black text-slate-700">{ils(a.monthlyExVat)}<span className="text-[10px] font-normal text-slate-400">/ח׳</span></div>
            </div>
          ))}
        </div>
      </Section>

      {/* ── שקיפות ── */}
      <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-[11px] leading-relaxed text-slate-500">
        <div className="mb-1.5 font-bold text-slate-700">מה שחשוב לדעת</div>
        <ul className="space-y-1">
          <li>· כל המחירים לפני מע״מ ({Math.round(vatRate * 100)}%). חשבונית מס נשלחת אוטומטית לאחר כל חיוב.</li>
          <li>· ביטול בקליק אחד מתוך המערכת, בכל רגע. המנוי נשאר פעיל עד סוף התקופה ששולמה.</li>
          <li>· שדרוג חל מיד עם חיוב יחסי על הימים שנותרו. שנמוך חל בסוף התקופה, ללא זיכוי.</li>
          <li>· ירידה לחבילת חינם לא מוחקת נתונים — הכול נשאר, רק היצירה החדשה נחסמת מעל המכסה.</li>
          <li>· פרטי הכרטיס נשמרים בקארדקום בלבד. אנחנו רואים 4 ספרות אחרונות ותוקף.</li>
        </ul>
      </div>
    </div>
  );
}
