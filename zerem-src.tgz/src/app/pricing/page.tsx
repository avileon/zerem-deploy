import { PLANS, ADDONS, FEATURES, TRIAL_DAYS } from '@/lib/billing/catalog';
import { currentOrg } from '@/lib/queries';
import { getSubscription } from '@/lib/billing/service';
import { vatRateAt } from '@/lib/israel';
import PricingView from './PricingView';

export const dynamic = 'force-dynamic';

export default async function PricingPage() {
  const org = await currentOrg();
  const sub = org ? await getSubscription(org.id) : null;

  return (
    <PricingView
      plans={PLANS}
      addons={ADDONS}
      features={FEATURES}
      vatRate={vatRateAt()}
      trialDays={TRIAL_DAYS}
      currentPlanId={sub?.planId ?? null}
      currentInterval={sub?.interval ?? 'MONTHLY'}
      status={sub?.status ?? null}
    />
  );
}
