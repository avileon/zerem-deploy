import { desc, sql } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { PageHeader, Chip, Section, Empty, Progress } from '@/components/ui';
import { couponLabel } from '@/lib/billing/pricing';
import { ils } from '@/lib/israel';

export const dynamic = 'force-dynamic';

import { requireConsole } from '@/lib/auth/session';

export default async function AdminCoupons() {
  await requireConsole();
  const coupons = await db.select().from(s.coupons).orderBy(desc(s.coupons.createdAt));

  const perf = await db.execute<{ coupon_id: string; orgs: number; paid: number; revenue: number }>(sql`
    SELECT r.coupon_id,
           COUNT(DISTINCT r.org_id)::int AS orgs,
           COUNT(DISTINCT i.org_id) FILTER (WHERE i.status = 'PAID')::int AS paid,
           COALESCE(SUM(i.total_inc_vat) FILTER (WHERE i.status = 'PAID'), 0)::float AS revenue
    FROM coupon_redemptions r
    LEFT JOIN billing_invoices i ON i.org_id = r.org_id
    GROUP BY r.coupon_id
  `);
  const perfById = new Map(perf.map((p) => [p.coupon_id, p]));

  const now = new Date();
  const live = coupons.filter((c) => c.isActive && (!c.validUntil || c.validUntil > now));
  const dead = coupons.filter((c) => !live.includes(c));

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="קופונים"
        subtitle={`${live.length} פעילים · ${coupons.reduce((a, c) => a + c.redemptionCount, 0)} מימושים`}
      />

      <Section title="פעילים" icon="🎟️">
        {live.length === 0
          ? <Empty icon="🎟️" title="אין קופונים פעילים" hint="קופון השקה טוב מזיז את שיעור ההמרה יותר מכל באנר" />
          : <div className="grid gap-2 lg:grid-cols-2">{live.map((c) => <Card key={c.id} c={c} p={perfById.get(c.id)} />)}</div>}
      </Section>

      {dead.length > 0 && (
        <Section title="לא פעילים / פגי תוקף">
          <div className="grid gap-2 lg:grid-cols-2 opacity-60">
            {dead.map((c) => <Card key={c.id} c={c} p={perfById.get(c.id)} />)}
          </div>
        </Section>
      )}

      <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-[11px] leading-relaxed text-slate-500">
        <div className="mb-1.5 font-bold text-slate-700">איך הקופונים מתנהגים</div>
        <ul className="space-y-1">
          <li>· קופונים לא מצטברים. קוד חדש מחליף קיים רק אם הוא משתלם יותר ללקוח.</li>
          <li>· קופון שמאפס את הסכום לא שולח בקשת חיוב כלל — נרשמת חשבונית ₪0 והתקופה מתקדמת.</li>
          <li>· המימוש נעשה בנעילת שורה. קמפיין ל-100 מימושים לא ייפרע 200 פעם.</li>
          <li>· &quot;ללקוחות חדשים בלבד&quot; נבדק לפי הארגון ולפי טלפון הבעלים — לא רק לפי אימייל.</li>
        </ul>
      </div>
    </div>
  );
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function Card({ c, p }: { c: any; p?: { orgs: number; paid: number; revenue: number } }) {
  const label = couponLabel({
    id: c.id, code: c.code, type: c.type, value: Number(c.value),
    duration: c.duration, durationCycles: c.durationCycles,
    validFrom: c.validFrom, validUntil: c.validUntil,
    maxRedemptions: c.maxRedemptions, redemptionCount: c.redemptionCount,
    appliesToPlans: c.appliesToPlans, appliesToInterval: c.appliesToInterval,
    firstTimeOnly: c.firstTimeOnly, minAmountExVat: null, isActive: c.isActive,
  });
  const conv = p?.orgs ? Math.round((p.paid / p.orgs) * 100) : null;

  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="ltr num text-base font-black tracking-wider text-slate-900">{c.code}</div>
          <div className="mt-0.5 text-[12px] font-semibold text-teal-700">{label}</div>
        </div>
        <div className="flex flex-col items-end gap-1">
          {c.isActive ? <Chip tone="green">פעיל</Chip> : <Chip tone="slate">כבוי</Chip>}
          {c.firstTimeOnly && <Chip tone="violet">חדשים בלבד</Chip>}
        </div>
      </div>

      {c.maxRedemptions !== null && (
        <div className="mt-3">
          <div className="mb-1 flex items-baseline justify-between text-[11px]">
            <span className="text-slate-500">מימושים</span>
            <span className="num text-slate-600">{c.redemptionCount} / {c.maxRedemptions}</span>
          </div>
          <Progress value={c.redemptionCount} max={c.maxRedemptions}
                    tone={c.redemptionCount >= c.maxRedemptions ? 'rose' : 'teal'} />
        </div>
      )}

      <div className="mt-3 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3 text-center">
        <Mini label="ארגונים" value={String(p?.orgs ?? c.redemptionCount)} />
        <Mini label="המרה" value={conv === null ? '—' : `${conv}%`} />
        <Mini label="הכנסה" value={p?.revenue ? ils(p.revenue) : '—'} />
      </div>

      <div className="mt-2 flex flex-wrap gap-1 text-[10px] text-slate-400">
        {c.campaign && <span>קמפיין: {c.campaign}</span>}
        {c.validUntil && <span>· עד {new Date(c.validUntil).toLocaleDateString('he-IL')}</span>}
        {c.appliesToPlans?.length && <span>· חבילות: {c.appliesToPlans.join(', ')}</span>}
      </div>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="num text-sm font-bold text-slate-800">{value}</div>
      <div className="text-[10px] text-slate-400">{label}</div>
    </div>
  );
}
