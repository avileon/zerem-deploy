import { desc } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { requireConsole } from '@/lib/auth/session';
import AdminsView from './AdminsView';

export const dynamic = 'force-dynamic';

export default async function AdminsPage() {
  const me = await requireConsole();
  const admins = await db.select().from(s.platformAdmins).orderBy(desc(s.platformAdmins.createdAt));

  return (
    <AdminsView
      me={me}
      admins={admins.map((a) => ({
        id: a.id, name: a.name, email: a.email, status: a.status, isOwner: a.isOwner,
        lastLoginAt: a.lastLoginAt ? a.lastLoginAt.toISOString() : null,
      }))}
    />
  );
}
