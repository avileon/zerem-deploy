'use client';
import { useState } from 'react';
import { PageHeader, Chip, Avatar, timeAgo } from '@/components/ui';

/* eslint-disable @typescript-eslint/no-explicit-any */

export default function AdminsView({ me, admins }: { me: any; admins: any[] }) {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: '', email: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [invite, setInvite] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(null); setBusy(true);
    const r = await fetch('/api/console/admins', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(f),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(false);
    if (r.ok) { setInvite(r.inviteUrl); setOpen(false); }
    else setError(r.error);
  }

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="מנהלי מערכת"
        subtitle={`${admins.length} מנהלים · גישה מלאה לכל הלקוחות`}
        actions={me.isOwner
          ? <button onClick={() => setOpen(true)} className="btn btn-primary btn-sm">+ מנהל</button>
          : undefined}
      />

      <div className="mb-3 rounded-2xl bg-amber-50 p-3 text-[11px] leading-relaxed text-amber-900">
        <b>מנהל מערכת רואה את כל הלקוחות ויכול להיכנס לכל חשבון.</b> הוסף רק
        אנשים שאתה סומך עליהם ברמה הזו. מנהלי מערכת אינם חברים באף ארגון, ולכן
        חשבון לקוח שנפרץ לא יכול להפוך למנהל מערכת.
      </div>

      <div className="space-y-2">
        {admins.map((a) => (
          <div key={a.id} className="card flex flex-wrap items-center gap-3 p-3.5">
            <Avatar name={a.name} size={34} />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[13px] font-bold text-slate-800">{a.name}</span>
                {a.isOwner && <Chip tone="violet">בעלים</Chip>}
                {a.id === me.adminId && <Chip tone="teal">זה אתה</Chip>}
                <Chip tone={a.status === 'ACTIVE' ? 'green' : a.status === 'PENDING' ? 'sky' : 'rose'}>
                  {a.status === 'ACTIVE' ? 'פעיל' : a.status === 'PENDING' ? 'טרם הפעיל' : 'מושבת'}
                </Chip>
              </div>
              <div className="ltr mt-0.5 text-[10px] text-slate-400">{a.email}</div>
            </div>
            <div className="text-left text-[10px] text-slate-400">
              {a.lastLoginAt ? `נכנס ${timeAgo(a.lastLoginAt)}` : 'טרם נכנס'}
            </div>
          </div>
        ))}
      </div>

      {open && (
        <Sheet onClose={() => setOpen(false)}>
          <h3 className="text-base font-black text-slate-900">הוספת מנהל מערכת</h3>
          <form onSubmit={submit} className="mt-4 space-y-3">
            <label className="block">
              <span className="mb-1 block text-[11px] font-bold text-slate-500">שם מלא</span>
              <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })}
                     required className="input" />
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-bold text-slate-500">אימייל</span>
              <input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })}
                     required type="email" dir="ltr" className="input ltr" />
            </label>
            {error && <div className="rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{error}</div>}
            <div className="flex gap-2">
              <button type="button" onClick={() => setOpen(false)} className="btn btn-ghost flex-1">ביטול</button>
              <button type="submit" disabled={busy} className="btn btn-primary flex-1">
                {busy ? '…' : 'הוספה'}
              </button>
            </div>
          </form>
        </Sheet>
      )}

      {invite && (
        <Sheet onClose={() => { setInvite(null); location.reload(); }}>
          <h3 className="text-base font-black text-slate-900">קישור לקביעת סיסמה</h3>
          <div className="mt-3 rounded-xl bg-amber-50 p-3 text-[10px] text-amber-800">
            ⚠️ מוצג פעם אחת בלבד.
          </div>
          <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
            <div className="ltr break-all text-[10px] text-slate-600">{invite}</div>
          </div>
          <button onClick={() => { navigator.clipboard.writeText(invite); setCopied(true); }}
                  className="btn btn-primary mt-3 w-full">{copied ? '✓ הועתק' : 'העתקה'}</button>
        </Sheet>
      )}
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/50 lg:items-center lg:justify-center" onClick={onClose}>
      <div className="safe-b w-full rounded-t-3xl bg-white p-5 lg:max-w-sm lg:rounded-3xl"
           onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
        {children}
      </div>
    </div>
  );
}
