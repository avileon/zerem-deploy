import Link from 'next/link';
import { platformOverview, listBusinesses } from '@/lib/console/queries';
import { requireConsole } from '@/lib/auth/session';
import { PageHeader, Stat, Section, Chip, Avatar, Empty, timeAgo } from '@/components/ui';
import { ils } from '@/lib/israel';

export const dynamic = 'force-dynamic';

const STATUS: Record<string, { label: string; tone: string }> = {
  TRIALING: { label: 'ניסיון', tone: 'violet' },
  FREE: { label: 'חינם', tone: 'slate' },
  ACTIVE: { label: 'פעיל', tone: 'green' },
  PAST_DUE: { label: 'חיוב נכשל', tone: 'amber' },
  CANCELING: { label: 'מבוטל', tone: 'amber' },
  SUSPENDED: { label: 'מושהה', tone: 'rose' },
  CLOSED: { label: 'סגור', tone: 'rose' },
};

export default async function ConsoleHome() {
  const admin = await requireConsole();
  const [o, businesses] = await Promise.all([platformOverview(), listBusinesses()]);

  const attention = businesses.filter(
    (b) => b.status === 'PAST_DUE' || b.status === 'SUSPENDED' || b.pending_users > 0,
  );
  const recent = businesses.slice(0, 8);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title={`שלום, ${admin.name.split(' ')[0]}`}
        subtitle={`${o.businesses} עסקים · ${o.totalUsers} משתמשים · ${o.totalLeads.toLocaleString('he-IL')} לידים במערכת`}
        actions={<Link href="/console/businesses?new=1" className="btn btn-primary btn-sm">+ עסק חדש</Link>}
      />

      <div className="grid gap-2.5 lg:grid-cols-4">
        <Stat label="MRR" value={ils(o.mrr)} hint={`${o.activePaying} משלמים`} tone="teal" icon="📈" />
        <Stat label="נגבה עד היום" value={ils(o.totalCollected)} hint="מצטבר" tone="sky" icon="💰" />
        <Stat label="בתקופת ניסיון" value={String(o.trialing)} hint="להמרה" tone="violet" icon="🌱" />
        <Stat label="עסקים חדשים החודש" value={String(o.newThisMonth)} hint="גיוס" tone="green" icon="✨" />
      </div>

      {attention.length > 0 && (
        <div className="mt-3 rounded-2xl bg-amber-50 p-4">
          <div className="text-sm font-bold text-amber-900">{attention.length} עסקים דורשים טיפול</div>
          <div className="mt-2 space-y-1.5">
            {attention.slice(0, 6).map((b) => (
              <Link key={b.org_id} href={`/console/businesses/${b.org_id}`}
                    className="flex flex-wrap items-center gap-2 text-[12px] hover:underline">
                <Avatar name={b.org_name} size={22} />
                <span className="font-semibold text-slate-800">{b.org_name}</span>
                {b.status !== 'ACTIVE' && b.status !== 'FREE' && b.status !== 'TRIALING' && (
                  <Chip tone={STATUS[b.status]?.tone ?? 'slate'}>{STATUS[b.status]?.label}</Chip>
                )}
                {b.pending_users > 0 && <Chip tone="sky">{b.pending_users} טרם הפעילו חשבון</Chip>}
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="mt-3 grid gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Section title="עסקים אחרונים" icon="🏢"
                   action={<Link href="/console/businesses" className="text-[11px] font-bold text-indigo-600">הכל ←</Link>}>
            {recent.length === 0 ? (
              <Empty icon="🏢" title="אין עדיין עסקים" hint="לחץ על ״עסק חדש״ כדי לפתוח את הראשון" />
            ) : (
              <div className="space-y-1.5">
                {recent.map((b) => (
                  <Link key={b.org_id} href={`/console/businesses/${b.org_id}`}
                        className="flex items-center gap-3 rounded-xl border border-slate-100 p-2.5 transition hover:bg-slate-50">
                    <Avatar name={b.org_name} size={32} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-bold text-slate-800">{b.org_name}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10px] text-slate-400">
                        <Chip tone={STATUS[b.status]?.tone ?? 'slate'}>{STATUS[b.status]?.label ?? b.status}</Chip>
                        <span>{b.plan_name ?? b.plan_id}</span>
                        <span>· {b.seats_used}{b.seats_limit ? `/${b.seats_limit}` : ''} משתמשים</span>
                        <span>· {b.leads} לידים</span>
                      </div>
                    </div>
                    <div className="shrink-0 text-left">
                      {b.mrr > 0 && <div className="num text-[13px] font-bold text-slate-800">{ils(b.mrr)}</div>}
                      <div className="text-[10px] text-slate-400">{timeAgo(b.created_at)}</div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Section>
        </div>

        <Section title="פילוח" icon="📊">
          <div className="space-y-2">
            <Row label="משלמים" n={o.activePaying} tone="green" />
            <Row label="בניסיון" n={o.trialing} tone="violet" />
            <Row label="חבילת חינם" n={o.freePlan} tone="slate" />
            <Row label="חיוב נכשל" n={o.pastDue} tone="amber" />
            <Row label="מושהים" n={o.suspended} tone="rose" />
          </div>
          {o.pendingActivation > 0 && (
            <div className="mt-3 rounded-xl bg-sky-50 px-3 py-2 text-[11px] text-sky-800">
              {o.pendingActivation} משתמשים קיבלו קישור ועדיין לא קבעו סיסמה.
            </div>
          )}
        </Section>
      </div>
    </div>
  );
}

function Row({ label, n, tone }: { label: string; n: number; tone: string }) {
  const bg: Record<string, string> = {
    green: 'bg-green-50 text-green-700', violet: 'bg-violet-50 text-violet-700',
    slate: 'bg-slate-50 text-slate-600', amber: 'bg-amber-50 text-amber-800',
    rose: 'bg-rose-50 text-rose-700',
  };
  return (
    <div className={`flex items-center justify-between rounded-xl px-3 py-2 ${bg[tone] ?? bg.slate}`}>
      <span className="text-[12px] font-semibold">{label}</span>
      <span className="num text-sm font-black">{n}</span>
    </div>
  );
}
