import { requireConsole } from '@/lib/auth/session';
import { PLANS, ADDONS, FEATURES } from '@/lib/billing/catalog';
import { PageHeader, Section, Chip } from '@/components/ui';
import { ils, vatRateAt } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function PlansPage() {
  await requireConsole();
  const vat = vatRateAt();

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="חבילות" subtitle="המחירון והמגבלות שכל עסק מקבל" />

      <div className="card overflow-x-auto p-0">
        <table className="w-full text-right text-[12px]">
          <thead>
            <tr className="border-b border-slate-100 text-[11px] text-slate-400">
              <th className="px-3 py-2.5 font-semibold">יכולת</th>
              {PLANS.map((p) => (
                <th key={p.id} className="px-3 py-2.5 text-center">
                  <div className="font-black text-slate-700">{p.nameHe}</div>
                  <div className="num mt-0.5 text-[11px] font-normal text-slate-400">
                    {p.monthly ? `${ils(p.monthly)}/ח׳` : 'חינם'}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {FEATURES.map((f) => (
              <tr key={f.key} className="border-b border-slate-50">
                <td className="px-3 py-2 text-slate-600">{f.label}</td>
                {PLANS.map((p) => {
                  const v = p.entitlements[f.key];
                  return (
                    <td key={p.id} className="px-3 py-2 text-center">
                      {v === false ? <span className="text-slate-300">—</span>
                       : v === null ? <span className="font-bold text-indigo-600">∞</span>
                       : v === true ? <span className="text-indigo-600">✓</span>
                       : <span className="num font-semibold text-slate-700">{v}</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
            <tr className="bg-slate-50">
              <td className="px-3 py-2 font-bold text-slate-600">שנתי</td>
              {PLANS.map((p) => (
                <td key={p.id} className="num px-3 py-2 text-center font-semibold text-slate-700">
                  {p.yearly ? ils(p.yearly) : '—'}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      <Section title="תוספות" icon="➕">
        <div className="grid gap-2 lg:grid-cols-3">
          {ADDONS.map((a) => (
            <div key={a.key} className="flex items-center justify-between rounded-xl border border-slate-200 p-3">
              <div>
                <div className="text-[13px] font-bold text-slate-800">{a.label}</div>
                <div className="mt-0.5 flex gap-1">
                  {a.availableIn.map((p) => <Chip key={p}>{p}</Chip>)}
                </div>
              </div>
              <div className="num text-sm font-black text-slate-700">{ils(a.monthlyExVat)}</div>
            </div>
          ))}
        </div>
      </Section>

      <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-[11px] leading-relaxed text-slate-500">
        <div className="mb-1.5 font-bold text-slate-700">איך לשנות מחירים</div>
        <p>
          המחירים חיים בטבלאות <span className="ltr">plans / plan_prices / plan_entitlements</span> ונטענים
          מ-<span className="ltr">catalog.ts</span> בהרצה הראשונה. שינוי מחיר בטבלה משפיע על מנויים
          חדשים בלבד — מנוי קיים ממשיך במחיר שהוקפא בשורות שלו, וזו התנהגות מכוונת:
          העלאת מחיר לא אמורה לתפוס לקוח ותיק באמצע תקופה. כל המחירים לפני
          מע״מ ({Math.round(vat * 100)}%).
        </p>
      </div>
    </div>
  );
}
