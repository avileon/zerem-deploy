import { requireConsole } from '@/lib/auth/session';
import { auditTrail } from '@/lib/console/queries';
import { PageHeader, Chip, Empty, timeAgo } from '@/components/ui';

export const dynamic = 'force-dynamic';

const EVENT_HE: Record<string, { label: string; tone: string }> = {
  'business.created': { label: 'עסק נפתח', tone: 'green' },
  'trial.started': { label: 'ניסיון החל', tone: 'violet' },
  'trial.converted': { label: 'הומר לתשלום', tone: 'green' },
  'subscription.activated': { label: 'מנוי הופעל', tone: 'green' },
  'invoice.paid': { label: 'חשבונית שולמה', tone: 'green' },
  'invoice.zero_rated': { label: 'מחזור חינם', tone: 'violet' },
  'charge.failed': { label: 'חיוב נכשל', tone: 'amber' },
  'subscription.suspended': { label: 'הושהה', tone: 'rose' },
  'subscription.downgraded': { label: 'שונמך', tone: 'slate' },
  'subscription.cancel_scheduled': { label: 'ביטול תוזמן', tone: 'amber' },
  'admin.set_plan': { label: 'שינוי חבילה ידני', tone: 'sky' },
  'admin.extend_trial': { label: 'הארכת ניסיון', tone: 'sky' },
  'admin.grant_days': { label: 'הענקת ימים', tone: 'sky' },
  'admin.suspend': { label: 'השהיה ידנית', tone: 'rose' },
  'admin.reactivate': { label: 'הפעלה מחדש', tone: 'green' },
  'admin.impersonate_start': { label: 'כניסה לחשבון לקוח', tone: 'amber' },
};

export default async function AuditPage() {
  await requireConsole();
  const rows = await auditTrail(150);
  const manual = rows.filter((r) => r.actor?.startsWith('admin:')).length;

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="יומן פעולות"
        subtitle={`${rows.length} אירועים אחרונים · ${manual} פעולות ידניות מהקונסולה`}
      />

      <div className="mb-3 rounded-2xl bg-slate-50 p-3 text-[11px] leading-relaxed text-slate-500">
        היומן הוא append-only ומהווה את מקור האמת לכל שינוי כספי. פעולה ידנית
        נרשמת עם מזהה המנהל שביצע אותה — כולל כניסה לחשבון לקוח.
      </div>

      {rows.length === 0 ? (
        <div className="card"><Empty icon="🧾" title="אין אירועים עדיין" /></div>
      ) : (
        <div className="card p-0">
          {rows.map((r, i) => {
            const e = EVENT_HE[r.type] ?? { label: r.type, tone: 'slate' };
            const isManual = r.actor?.startsWith('admin:');
            return (
              <div key={i} className={`flex flex-wrap items-center gap-2 border-b border-slate-50 px-3 py-2 text-[12px] ${
                isManual ? 'bg-sky-50/40' : ''}`}>
                <Chip tone={e.tone}>{e.label}</Chip>
                <span className="font-semibold text-slate-700">{r.org_name ?? '—'}</span>
                {isManual && <span className="text-[10px] font-bold text-sky-700">ידני</span>}
                <span className="mr-auto text-[10px] text-slate-400">{timeAgo(r.created_at)}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
