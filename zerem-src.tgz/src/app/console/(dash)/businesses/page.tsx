import { listBusinesses } from '@/lib/console/queries';
import { requireConsole } from '@/lib/auth/session';
import { PLANS } from '@/lib/billing/catalog';
import BusinessesView from './BusinessesView';

export const dynamic = 'force-dynamic';

export default async function BusinessesPage({
  searchParams,
}: { searchParams: Promise<{ new?: string }> }) {
  await requireConsole();
  const [rows, sp] = await Promise.all([listBusinesses(), searchParams]);

  return (
    <BusinessesView
      rows={rows.map((r) => ({
        ...r,
        created_at: String(r.created_at),
        current_period_end: r.current_period_end ? String(r.current_period_end) : null,
        trial_ends_at: r.trial_ends_at ? String(r.trial_ends_at) : null,
        last_activity: r.last_activity ? String(r.last_activity) : null,
      }))}
      plans={PLANS.map((p) => ({ id: p.id, nameHe: p.nameHe, monthly: p.monthly, yearly: p.yearly }))}
      openNew={sp.new === '1'}
    />
  );
}
