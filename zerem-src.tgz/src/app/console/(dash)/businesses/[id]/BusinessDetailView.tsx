'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHeader, Chip, Avatar, Section, Empty, timeAgo } from '@/components/ui';
import { ils } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

const STATUS: Record<string, { label: string; tone: string }> = {
  TRIALING: { label: 'ניסיון', tone: 'violet' }, FREE: { label: 'חינם', tone: 'slate' },
  ACTIVE: { label: 'פעיל', tone: 'green' }, PAST_DUE: { label: 'חיוב נכשל', tone: 'amber' },
  CANCELING: { label: 'מבוטל', tone: 'amber' }, SUSPENDED: { label: 'מושהה', tone: 'rose' },
  CLOSED: { label: 'סגור', tone: 'rose' },
};

const USER_STATUS: Record<string, { label: string; tone: string }> = {
  PENDING: { label: 'טרם הפעיל', tone: 'sky' },
  ACTIVE: { label: 'פעיל', tone: 'green' },
  DISABLED: { label: 'מושבת', tone: 'rose' },
};

const EVENT_HE: Record<string, string> = {
  'business.created': 'העסק נפתח',
  'trial.started': 'תקופת ניסיון החלה',
  'trial.converted': 'הומר לתשלום',
  'subscription.activated': 'המנוי הופעל',
  'invoice.paid': 'חשבונית שולמה',
  'invoice.zero_rated': 'מחזור חינם (קופון)',
  'charge.failed': 'חיוב נכשל',
  'subscription.suspended': 'המנוי הושהה',
  'subscription.downgraded': 'שונמך לחינם',
  'admin.set_plan': 'שינוי חבילה ידני',
  'admin.extend_trial': 'הארכת ניסיון',
  'admin.grant_days': 'הענקת ימים',
  'admin.suspend': 'השהיה ידנית',
  'admin.reactivate': 'הפעלה מחדש',
  'admin.impersonate_start': 'כניסה לחשבון לתמיכה',
  'payment_method.updated': 'אמצעי תשלום עודכן',
  'addon.added': 'תוספת נרכשה',
};

const heDate = (d: string | null) =>
  d ? new Date(d).toLocaleDateString('he-IL', { day: 'numeric', month: 'short', year: 'numeric' }) : '—';

export default function BusinessDetailView({
  detail, members, usage, invoices, events, plans,
}: { detail: any; members: any[]; usage: any; invoices: any[]; events: any[]; plans: any[] }) {
  const [busy, setBusy] = useState<string | null>(null);
  const [invite, setInvite] = useState<{ url: string; who: string } | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [planOpen, setPlanOpen] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const st = STATUS[detail.status] ?? STATUS.FREE;
  const active = members.filter((m) => m.active);

  async function call(url: string, body: unknown, key: string) {
    setBusy(key); setMsg(null);
    const r = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(null);
    if (!r.ok) setMsg(r.error ?? 'הפעולה נכשלה');
    return r;
  }

  async function planAction(action: string, extra: Record<string, unknown> = {}) {
    const r = await call('/api/console/plan', { orgId: detail.org_id, action, ...extra }, action);
    if (r.ok) location.reload();
  }

  async function impersonate() {
    const r = await call('/api/console/impersonate', { orgId: detail.org_id }, 'imp');
    if (r.ok) window.location.href = r.redirect;
  }

  async function resend(userId: string, name: string) {
    const r = await call('/api/console/users', { action: 'resend', userId }, `r${userId}`);
    if (r.ok) setInvite({ url: r.inviteUrl, who: name });
  }

  return (
    <div className="p-4 lg:p-7">
      <Link href="/console/businesses" className="mb-2 inline-block text-[11px] font-bold text-indigo-600">
        → כל העסקים
      </Link>

      <PageHeader
        title={detail.org_name}
        subtitle={`נפתח ${heDate(detail.created_at)}${detail.vat_id ? ` · ח.פ. ${detail.vat_id}` : ''}`}
        actions={
          <>
            <button onClick={impersonate} disabled={busy === 'imp'} className="btn btn-ghost btn-sm">
              {busy === 'imp' ? '…' : 'כניסה לחשבון'}
            </button>
            <button onClick={() => setPlanOpen(true)} className="btn btn-primary btn-sm">ניהול מנוי</button>
          </>
        }
      />

      {msg && <div className="mb-3 rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{msg}</div>}

      <div className="grid gap-3 lg:grid-cols-3">
        {/* ── המנוי ── */}
        <div className="card p-5 lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-lg font-black text-slate-900">
                  {plans.find((p) => p.id === detail.plan_id)?.nameHe ?? detail.plan_id}
                </span>
                <Chip tone={st.tone}>{st.label}</Chip>
                {detail.interval === 'YEARLY' && <Chip tone="teal">שנתי</Chip>}
                {detail.cancel_at_period_end && <Chip tone="amber">מבוטל בסוף התקופה</Chip>}
              </div>
              <div className="mt-1 text-[12px] text-slate-500">
                {detail.status === 'TRIALING'
                  ? <>ניסיון עד {heDate(detail.trial_ends_at)}</>
                  : <>תקופה נוכחית עד {heDate(detail.current_period_end)}</>}
                {detail.coupon_code && <span className="ltr mr-2 text-violet-600">🎟️ {detail.coupon_code}</span>}
              </div>
            </div>
            <div className="text-left text-[11px] text-slate-400">
              {detail.last4 ? <>כרטיס <span className="ltr num">•• {detail.last4}</span></> : 'אין כרטיס שמור'}
              {detail.dunning_attempt > 0 && (
                <div className="mt-0.5 font-bold text-amber-700">ניסיון גבייה {detail.dunning_attempt}/5</div>
              )}
            </div>
          </div>

          <div className="mt-4 grid grid-cols-4 gap-2 border-t border-slate-100 pt-3 text-center">
            <Mini label="לידים" n={usage?.leads ?? 0} />
            <Mini label="הצעות" n={usage?.quotes ?? 0} />
            <Mini label="משימות" n={usage?.tasks ?? 0} />
            <Mini label="תשלומים" n={usage?.payments ?? 0} />
          </div>
        </div>

        {/* ── יצירת קשר ── */}
        <div className="card p-5">
          <div className="text-[11px] font-bold text-slate-400">פרטי קשר</div>
          <div className="mt-2 space-y-1.5 text-[12px]">
            {detail.legal_name && <div className="text-slate-700">{detail.legal_name}</div>}
            {detail.email && <div className="ltr text-slate-500">{detail.email}</div>}
            {detail.phone && (
              <div className="flex items-center gap-2">
                <span className="ltr text-slate-500">{detail.phone}</span>
                <a href={`https://wa.me/${String(detail.phone).replace('+', '')}`} target="_blank"
                   rel="noreferrer" className="text-[11px] font-bold text-green-700">וואטסאפ</a>
              </div>
            )}
            <div className="ltr text-[10px] text-slate-400">/{detail.slug}</div>
          </div>
        </div>
      </div>

      {/* ── משתמשים ── */}
      <Section title={`משתמשים (${active.length})`} icon="👥"
               action={<button onClick={() => setAddOpen(true)} className="text-[11px] font-bold text-indigo-600">+ הוספה</button>}>
        <div className="space-y-1.5">
          {members.map((m) => {
            const us = USER_STATUS[m.status] ?? USER_STATUS.PENDING;
            return (
              <div key={m.user_id}
                   className={`flex flex-wrap items-center gap-2.5 rounded-xl border border-slate-100 p-2.5 ${
                     m.active ? '' : 'opacity-50'}`}>
                <Avatar name={m.name} size={30} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[13px] font-bold text-slate-800">{m.name}</span>
                    <Chip tone={m.role === 'MANAGER' ? 'violet' : 'sky'}>
                      {m.role === 'MANAGER' ? 'מנהל' : 'עובד'}
                    </Chip>
                    <Chip tone={us.tone}>{us.label}</Chip>
                    {!m.active && <Chip tone="slate">הוסר</Chip>}
                  </div>
                  <div className="ltr mt-0.5 text-[10px] text-slate-400">{m.email}</div>
                </div>
                <div className="shrink-0 text-left text-[10px] text-slate-400">
                  {m.last_login_at ? `נכנס ${timeAgo(m.last_login_at)}` : 'טרם נכנס'}
                </div>
                {m.active && (
                  <button onClick={() => resend(m.user_id, m.name)} disabled={busy === `r${m.user_id}`}
                          className="btn btn-ghost btn-sm shrink-0">
                    {busy === `r${m.user_id}` ? '…' : m.status === 'PENDING' ? 'קישור הפעלה' : 'איפוס סיסמה'}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </Section>

      <div className="grid gap-3 lg:grid-cols-2">
        <Section title="חשבוניות" icon="🧾">
          {invoices.length === 0
            ? <Empty icon="🧾" title="אין חשבוניות" />
            : (
              <div className="space-y-1">
                {invoices.map((i) => (
                  <div key={i.id} className="flex items-center justify-between border-b border-slate-50 py-1.5 text-[12px]">
                    <span className="text-slate-500">{heDate(i.period_start)}</span>
                    <span className="num font-bold text-slate-800">{ils(i.total_inc_vat)}</span>
                    <Chip tone={i.status === 'PAID' ? 'green' : i.status === 'FAILED' ? 'rose' : 'slate'}>
                      {i.status === 'PAID' ? 'שולם' : i.status === 'FAILED' ? 'נכשל' : i.status === 'ZERO_RATED' ? 'חינם' : i.status}
                    </Chip>
                    {i.doc_url
                      ? <a href={i.doc_url} target="_blank" rel="noreferrer" className="font-bold text-indigo-600">PDF</a>
                      : <span className="text-slate-300">—</span>}
                  </div>
                ))}
              </div>
            )}
        </Section>

        <Section title="ציר זמן" icon="🕘">
          {events.length === 0
            ? <Empty icon="🕘" title="אין אירועים" />
            : (
              <div className="space-y-2">
                {events.map((e, idx) => (
                  <div key={idx} className="flex gap-2.5 text-[12px]">
                    <div className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-400" />
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-slate-700">{EVENT_HE[e.type] ?? e.type}</div>
                      <div className="text-[10px] text-slate-400">
                        {timeAgo(e.created_at)}
                        {e.actor?.startsWith('admin:') && ' · ידני מהקונסולה'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
        </Section>
      </div>

      {addOpen && <AddUserSheet orgId={detail.org_id} onClose={() => setAddOpen(false)}
                                onDone={(url, who) => { setAddOpen(false); setInvite({ url, who }); }} />}
      {planOpen && <PlanSheet plans={plans} detail={detail} busy={busy}
                              onAction={planAction} onClose={() => setPlanOpen(false)} />}
      {invite && <InviteSheet invite={invite} onClose={() => { setInvite(null); location.reload(); }} />}
    </div>
  );
}

function Mini({ label, n }: { label: string; n: number }) {
  return (
    <div>
      <div className="num text-lg font-black text-slate-800">{n.toLocaleString('he-IL')}</div>
      <div className="text-[10px] text-slate-400">{label}</div>
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/50 lg:items-center lg:justify-center" onClick={onClose}>
      <div className="safe-b max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 lg:max-w-md lg:rounded-3xl"
           onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
        {children}
      </div>
    </div>
  );
}

function InviteSheet({ invite, onClose }: { invite: { url: string; who: string }; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-black text-slate-900">קישור עבור {invite.who}</h3>
      <div className="mt-3 rounded-xl bg-amber-50 p-3 text-[10px] leading-relaxed text-amber-800">
        ⚠️ מוצג פעם אחת בלבד. הקישור אינו נשמר בצורה קריאה — סגירה בלי העתקה
        מחייבת יצירת קישור חדש.
      </div>
      <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
        <div className="ltr break-all text-[10px] text-slate-600">{invite.url}</div>
      </div>
      <div className="mt-3 flex gap-2">
        <button onClick={() => { navigator.clipboard.writeText(invite.url); setCopied(true); }}
                className="btn btn-primary flex-1">{copied ? '✓ הועתק' : 'העתקה'}</button>
        <a href={`https://wa.me/?text=${encodeURIComponent(`קישור לקביעת סיסמה בזרם: ${invite.url}`)}`}
           target="_blank" rel="noreferrer" className="btn btn-ghost flex-1 !text-green-700">וואטסאפ</a>
      </div>
      <button onClick={onClose} className="btn btn-ghost mt-2 w-full">סגירה</button>
    </Sheet>
  );
}

function AddUserSheet({ orgId, onClose, onDone }: {
  orgId: string; onClose: () => void; onDone: (url: string, who: string) => void;
}) {
  const [f, setF] = useState({ name: '', email: '', phone: '', role: 'EMPLOYEE' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(null); setBusy(true);
    const r = await fetch('/api/console/users', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add', orgId, ...f }),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(false);
    if (r.ok) onDone(r.inviteUrl, f.name);
    else setError(r.error);
  }

  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-black text-slate-900">הוספת משתמש</h3>
      <p className="mt-1 text-[12px] text-slate-500">
        המכסה נבדקת מול החבילה. אם אין מקום, השדרוג נדרש קודם.
      </p>
      <form onSubmit={submit} className="mt-4 space-y-3">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">שם מלא</span>
          <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required className="input" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">אימייל</span>
          <input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })}
                 required type="email" dir="ltr" className="input ltr" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">טלפון</span>
          <input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })}
                 dir="ltr" className="input ltr" />
        </label>
        <div>
          <span className="mb-1 block text-[11px] font-bold text-slate-500">תפקיד</span>
          <div className="flex gap-1.5">
            {[['MANAGER', 'מנהל'], ['EMPLOYEE', 'עובד']].map(([k, l]) => (
              <button key={k} type="button" onClick={() => setF({ ...f, role: k })}
                className={`chip flex-1 justify-center px-2 py-1.5 ${
                  f.role === k ? 'bg-indigo-600 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
                {l}
              </button>
            ))}
          </div>
          <div className="mt-1.5 text-[10px] leading-relaxed text-slate-400">
            מנהל רואה חיוב, צוות ואינטגרציות. עובד רואה רק לידים, משימות והצעות.
          </div>
        </div>
        {error && <div className="rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{error}</div>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn btn-ghost flex-1">ביטול</button>
          <button type="submit" disabled={busy} className="btn btn-primary flex-1">
            {busy ? 'מוסיף…' : 'הוספה'}
          </button>
        </div>
      </form>
    </Sheet>
  );
}

function PlanSheet({ plans, detail, busy, onAction, onClose }: {
  plans: any[]; detail: any; busy: string | null;
  onAction: (a: string, extra?: Record<string, unknown>) => void; onClose: () => void;
}) {
  const [planId, setPlanId] = useState(detail.plan_id);
  const [interval, setInterval] = useState(detail.interval);
  const [days, setDays] = useState(30);

  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-black text-slate-900">ניהול המנוי</h3>
      <div className="mt-3 rounded-xl bg-amber-50 p-3 text-[10px] leading-relaxed text-amber-800">
        פעולות כאן עוקפות את מנוע הגבייה. כל אחת נרשמת ביומן עם שמך.
      </div>

      <div className="mt-4 space-y-4">
        <div>
          <div className="mb-1.5 text-[11px] font-bold text-slate-500">קביעת חבילה</div>
          <div className="flex gap-2">
            <select value={planId} onChange={(e) => setPlanId(e.target.value)} className="input flex-1">
              {plans.map((p) => <option key={p.id} value={p.id}>{p.nameHe}</option>)}
            </select>
            <select value={interval} onChange={(e) => setInterval(e.target.value)} className="input w-28">
              <option value="MONTHLY">חודשי</option>
              <option value="YEARLY">שנתי</option>
            </select>
          </div>
          <button onClick={() => onAction('set_plan', { planId, interval })}
                  disabled={busy === 'set_plan'} className="btn btn-primary btn-sm mt-2 w-full">
            {busy === 'set_plan' ? '…' : 'החלה'}
          </button>
        </div>

        <div className="border-t border-slate-100 pt-3">
          <div className="mb-1.5 text-[11px] font-bold text-slate-500">הענקת ימים / הארכת ניסיון</div>
          <div className="flex gap-2">
            <input type="number" value={days} onChange={(e) => setDays(Number(e.target.value))}
                   dir="ltr" className="input ltr w-24" />
            <button onClick={() => onAction('grant_days', { days })} disabled={busy === 'grant_days'}
                    className="btn btn-ghost btn-sm flex-1">הענקת ימים</button>
            <button onClick={() => onAction('extend_trial', { days })} disabled={busy === 'extend_trial'}
                    className="btn btn-ghost btn-sm flex-1">הארכת ניסיון</button>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-3">
          <div className="mb-1.5 text-[11px] font-bold text-slate-500">מצב החשבון</div>
          <div className="flex gap-2">
            {detail.status === 'SUSPENDED' ? (
              <button onClick={() => onAction('reactivate')} disabled={busy === 'reactivate'}
                      className="btn btn-primary btn-sm flex-1">הפעלה מחדש</button>
            ) : (
              <button onClick={() => onAction('suspend')} disabled={busy === 'suspend'}
                      className="btn btn-ghost btn-sm flex-1 !text-rose-600">השהיית החשבון</button>
            )}
          </div>
        </div>
      </div>

      <button onClick={onClose} className="btn btn-ghost mt-4 w-full">סגירה</button>
    </Sheet>
  );
}
