import { notFound } from 'next/navigation';
import { businessDetail } from '@/lib/console/queries';
import { requireConsole } from '@/lib/auth/session';
import { PLANS } from '@/lib/billing/catalog';
import BusinessDetailView from './BusinessDetailView';

export const dynamic = 'force-dynamic';

export default async function BusinessPage({ params }: { params: Promise<{ id: string }> }) {
  await requireConsole();
  const { id } = await params;
  const data = await businessDetail(id);
  if (!data) notFound();

  const str = (v: unknown) => (v == null ? null : String(v));

  return (
    <BusinessDetailView
      detail={{ ...data.detail,
        created_at: str(data.detail.created_at),
        current_period_start: str(data.detail.current_period_start),
        current_period_end: str(data.detail.current_period_end),
        trial_ends_at: str(data.detail.trial_ends_at) }}
      members={data.members.map((m) => ({ ...m, last_login_at: str(m.last_login_at) }))}
      usage={data.usage}
      invoices={data.invoices.map((i) => ({ ...i, period_start: str(i.period_start) }))}
      events={data.events.map((e) => ({ ...e, created_at: str(e.created_at) }))}
      plans={PLANS.map((p) => ({ id: p.id, nameHe: p.nameHe, monthly: p.monthly }))}
    />
  );
}
