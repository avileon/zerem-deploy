'use client';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { PageHeader, Chip, Avatar, Empty, timeAgo } from '@/components/ui';
import { ils } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

const STATUS: Record<string, { label: string; tone: string }> = {
  TRIALING: { label: 'ניסיון', tone: 'violet' },
  FREE: { label: 'חינם', tone: 'slate' },
  ACTIVE: { label: 'פעיל', tone: 'green' },
  PAST_DUE: { label: 'חיוב נכשל', tone: 'amber' },
  CANCELING: { label: 'מבוטל', tone: 'amber' },
  SUSPENDED: { label: 'מושהה', tone: 'rose' },
  CLOSED: { label: 'סגור', tone: 'rose' },
};

const FILTERS = [
  ['ALL', 'הכל'], ['ACTIVE', 'משלמים'], ['TRIALING', 'בניסיון'],
  ['FREE', 'חינם'], ['ATTENTION', 'דורשים טיפול'],
] as const;

export default function BusinessesView({ rows, plans, openNew }: {
  rows: any[]; plans: any[]; openNew: boolean;
}) {
  const [filter, setFilter] = useState<string>('ALL');
  const [q, setQ] = useState('');
  const [showNew, setShowNew] = useState(openNew);

  const filtered = useMemo(() => rows.filter((r) => {
    if (filter === 'ATTENTION' && !['PAST_DUE', 'SUSPENDED'].includes(r.status) && !r.pending_users) return false;
    if (filter !== 'ALL' && filter !== 'ATTENTION' && r.status !== filter) return false;
    if (!q) return true;
    const t = q.toLowerCase();
    return r.org_name.toLowerCase().includes(t)
      || (r.manager_email ?? '').toLowerCase().includes(t)
      || (r.vat_id ?? '').includes(t);
  }), [rows, filter, q]);

  const totalMrr = filtered.reduce((a, r) => a + Number(r.mrr ?? 0), 0);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="עסקים"
        subtitle={`${filtered.length} מתוך ${rows.length} · ${ils(totalMrr)} MRR`}
        actions={<button onClick={() => setShowNew(true)} className="btn btn-primary btn-sm">+ עסק חדש</button>}
      />

      <div className="mb-3 flex flex-col gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} className="input"
               placeholder="חיפוש שם עסק, אימייל מנהל או ח.פ…" inputMode="search" />
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {FILTERS.map(([k, label]) => (
            <button key={k} onClick={() => setFilter(k)}
              className={`chip whitespace-nowrap px-2.5 py-1 ${
                filter === k ? 'bg-indigo-600 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="card">
          <Empty icon="🏢" title="לא נמצאו עסקים"
                 hint={rows.length ? 'נסה סינון אחר' : 'לחץ על ״עסק חדש״ כדי לפתוח את הראשון'} />
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((r) => (
            <Link key={r.org_id} href={`/console/businesses/${r.org_id}`}
                  className="card card-hover block p-3.5">
              <div className="flex items-start gap-3">
                <Avatar name={r.org_name} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-sm font-bold text-slate-900">{r.org_name}</span>
                    <Chip tone={STATUS[r.status]?.tone ?? 'slate'}>{STATUS[r.status]?.label ?? r.status}</Chip>
                    <Chip>{r.plan_name ?? r.plan_id}</Chip>
                    {r.interval === 'YEARLY' && <Chip tone="teal">שנתי</Chip>}
                    {r.pending_users > 0 && <Chip tone="sky">{r.pending_users} טרם הפעילו</Chip>}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                    {r.manager_name && <span>{r.manager_name}</span>}
                    {r.manager_email && <span className="ltr">· {r.manager_email}</span>}
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-400">
                    <span>{r.seats_used}{r.seats_limit ? `/${r.seats_limit}` : ''} משתמשים</span>
                    <span>· {r.leads} לידים</span>
                    {r.paid_total > 0 && <span>· שולם {ils(r.paid_total)}</span>}
                    <span>· נפתח {timeAgo(r.created_at)}</span>
                  </div>
                </div>
                <div className="shrink-0 text-left">
                  {r.mrr > 0
                    ? <div className="num text-sm font-black text-slate-800">{ils(r.mrr)}<span className="text-[10px] font-normal text-slate-400">/ח׳</span></div>
                    : <span className="text-[11px] text-slate-300">—</span>}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showNew && <NewBusinessSheet plans={plans} onClose={() => setShowNew(false)} />}
    </div>
  );
}

/* ═══════════ פתיחת עסק ═══════════ */

function NewBusinessSheet({ plans, onClose }: { plans: any[]; onClose: () => void }) {
  const [f, setF] = useState({
    businessName: '', legalName: '', vatId: '',
    managerName: '', managerEmail: '', managerPhone: '',
    planId: 'pro', interval: 'MONTHLY', mode: 'TRIAL', trialDays: 14,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ inviteUrl: string; orgId: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const set = (k: string, v: unknown) => setF((p) => ({ ...p, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null); setBusy(true);
    const r = await fetch('/api/console/businesses', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(f),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(false);
    if (r.ok) setDone({ inviteUrl: r.inviteUrl, orgId: r.orgId });
    else setError(r.error ?? 'לא הצלחנו לפתוח את העסק');
  }

  if (done) {
    return (
      <Sheet onClose={onClose}>
        <div className="text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full text-2xl"
               style={{ background: 'linear-gradient(135deg,#a5b4fc,#6366f1)' }}>✓</div>
          <h3 className="mt-3 text-base font-black text-slate-900">העסק נפתח</h3>
          <p className="mt-1 text-[12px] text-slate-500">
            שלח למנהל את הקישור לקביעת סיסמה. הוא תקף 72 שעות.
          </p>
        </div>

        <div className="mt-4 rounded-xl bg-amber-50 p-3">
          <div className="text-[11px] font-bold text-amber-900">⚠️ הקישור מוצג פעם אחת בלבד</div>
          <div className="mt-0.5 text-[10px] leading-relaxed text-amber-800">
            הוא לא נשמר בצורה קריאה בשום מקום. אם תסגור את החלון בלי להעתיק,
            תצטרך לשלוח קישור חדש ממסך העסק.
          </div>
        </div>

        <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
          <div className="ltr break-all text-[10px] text-slate-600">{done.inviteUrl}</div>
        </div>

        <div className="mt-3 flex gap-2">
          <button onClick={() => { navigator.clipboard.writeText(done.inviteUrl); setCopied(true); }}
                  className="btn btn-primary flex-1">{copied ? '✓ הועתק' : 'העתקת הקישור'}</button>
          <a href={`https://wa.me/?text=${encodeURIComponent(`שלום, נפתח לך חשבון בזרם. לקביעת סיסמה: ${done.inviteUrl}`)}`}
             target="_blank" rel="noreferrer" className="btn btn-ghost flex-1 !text-green-700">שליחה בוואטסאפ</a>
        </div>
        <Link href={`/console/businesses/${done.orgId}`} className="btn btn-ghost mt-2 w-full">
          למסך העסק
        </Link>
      </Sheet>
    );
  }

  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-black text-slate-900">פתיחת עסק חדש</h3>
      <p className="mt-1 text-[12px] text-slate-500">
        נוצרים: ארגון, משתמש מנהל, מנוי, וקישור לקביעת סיסמה.
      </p>

      <form onSubmit={submit} className="mt-4 space-y-3">
        <div className="text-[11px] font-bold text-slate-400">העסק</div>
        <Input label="שם העסק" value={f.businessName} onChange={(v) => set('businessName', v)} required />
        <div className="grid grid-cols-2 gap-2">
          <Input label="שם משפטי" value={f.legalName} onChange={(v) => set('legalName', v)}
                 hint="ריק = שם העסק" />
          <Input label="ח.פ. / ע.מ." value={f.vatId} onChange={(v) => set('vatId', v)} ltr />
        </div>

        <div className="border-t border-slate-100 pt-3 text-[11px] font-bold text-slate-400">המנהל</div>
        <div className="grid grid-cols-2 gap-2">
          <Input label="שם מלא" value={f.managerName} onChange={(v) => set('managerName', v)} required />
          <Input label="טלפון" value={f.managerPhone} onChange={(v) => set('managerPhone', v)} ltr />
        </div>
        <Input label="אימייל" value={f.managerEmail} onChange={(v) => set('managerEmail', v)}
               required ltr type="email" hint="לכאן יישלח הקישור לקביעת סיסמה" />

        <div className="border-t border-slate-100 pt-3 text-[11px] font-bold text-slate-400">החבילה</div>
        <div className="flex gap-1.5">
          {[['TRIAL', 'ניסיון'], ['ACTIVE', 'פעיל מיד'], ['FREE', 'חינם']].map(([k, label]) => (
            <button key={k} type="button" onClick={() => set('mode', k)}
              className={`chip flex-1 justify-center px-2 py-1.5 ${
                f.mode === k ? 'bg-indigo-600 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
              {label}
            </button>
          ))}
        </div>

        {f.mode === 'TRIAL' && (
          <Input label="ימי ניסיון" value={String(f.trialDays)}
                 onChange={(v) => set('trialDays', Number(v) || 14)} ltr type="number" />
        )}

        {f.mode === 'ACTIVE' && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="mb-1 block text-[11px] font-bold text-slate-500">חבילה</span>
                <select value={f.planId} onChange={(e) => set('planId', e.target.value)} className="input">
                  {plans.filter((p) => p.id !== 'free').map((p) => (
                    <option key={p.id} value={p.id}>{p.nameHe} · {ils(p.monthly)}</option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="mb-1 block text-[11px] font-bold text-slate-500">מסלול</span>
                <select value={f.interval} onChange={(e) => set('interval', e.target.value)} className="input">
                  <option value="MONTHLY">חודשי</option>
                  <option value="YEARLY">שנתי</option>
                </select>
              </label>
            </div>
            <div className="rounded-xl bg-sky-50 px-3 py-2 text-[10px] leading-relaxed text-sky-800">
              ״פעיל מיד״ מפעיל את החבילה בלי לגבות כרטיס. מתאים ללקוח שמשלם
              בהעברה בנקאית. כדי לגבות אוטומטית, הלקוח צריך להזין כרטיס במסך החיוב שלו.
            </div>
          </>
        )}

        {error && <div className="rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{error}</div>}

        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn btn-ghost flex-1">ביטול</button>
          <button type="submit" disabled={busy} className="btn btn-primary flex-1">
            {busy ? 'פותח…' : 'פתיחת העסק'}
          </button>
        </div>
      </form>
    </Sheet>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/50 lg:items-center lg:justify-center"
         onClick={onClose}>
      <div className="safe-b max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 lg:max-w-md lg:rounded-3xl"
           onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
        {children}
      </div>
    </div>
  );
}

function Input({ label, value, onChange, required, ltr, type, hint }: {
  label: string; value: string; onChange: (v: string) => void;
  required?: boolean; ltr?: boolean; type?: string; hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-bold text-slate-500">{label}</span>
      <input
        value={value} onChange={(e) => onChange(e.target.value)}
        required={required} type={type ?? 'text'}
        dir={ltr ? 'ltr' : undefined}
        className={`input ${ltr ? 'ltr' : ''}`}
      />
      {hint && <span className="mt-0.5 block text-[10px] text-slate-400">{hint}</span>}
    </label>
  );
}
