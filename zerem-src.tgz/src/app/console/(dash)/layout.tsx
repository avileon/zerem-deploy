import { redirect } from 'next/navigation';
import ConsoleShell from '@/components/ConsoleShell';
import { getConsoleSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

/**
 * ⚠️ בקרת הגישה האמיתית לקונסולה נמצאת כאן.
 * ה-middleware בודק רק נוכחות עוגייה (הוא רץ ב-Edge בלי גישה ל-DB);
 * האימות מול בסיס הנתונים נעשה בשכבה הזו, ולכן עוגייה מזויפת נדחית.
 *
 * דפי ההתחברות יושבים מחוץ לקבוצה הזו ולכן אינם עוברים כאן.
 */
export default async function ConsoleDashLayout({ children }: { children: React.ReactNode }) {
  const sess = await getConsoleSession();
  if (!sess) redirect('/console/login');

  return (
    <ConsoleShell admin={{ name: sess.name, email: sess.email, isOwner: sess.isOwner }}>
      {children}
    </ConsoleShell>
  );
}
