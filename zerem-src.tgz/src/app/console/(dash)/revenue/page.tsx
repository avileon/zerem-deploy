import { revenueMetrics } from '@/lib/billing/metrics';
import { PageHeader, Stat, Section, BarChart, Chip, Progress } from '@/components/ui';
import { ils } from '@/lib/israel';

export const dynamic = 'force-dynamic';

import { requireConsole } from '@/lib/auth/session';

const MONTH_HE = ['ינו', 'פבר', 'מרץ', 'אפר', 'מאי', 'יונ', 'יול', 'אוג', 'ספט', 'אוק', 'נוב', 'דצמ'];
const shortMonth = (ym: string) => MONTH_HE[Number(ym.slice(5, 7)) - 1] ?? ym;

export default async function RevenuePage() {
  await requireConsole();
  const m = await revenueMetrics();

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="הכנסות" subtitle="MRR, נטישה, והמרה מניסיון — התמונה של העסק" />

      <div className="grid gap-2.5 lg:grid-cols-4">
        <Stat label="MRR" value={ils(m.mrr)} hint={`${m.activeSubs} מנויים משלמים`} tone="teal" icon="📈" />
        <Stat label="ARR" value={ils(m.arr)} hint="הכנסה שנתית חוזרת" tone="sky" icon="🎯" />
        <Stat label="ARPU" value={ils(m.arpu)} hint="ממוצע למנוי" tone="violet" icon="👤" />
        <Stat label="נטישה חודשית" value={`${m.churnPct}%`}
              hint={`${m.canceledThisMonth} ביטולים החודש`}
              tone={m.churnPct > 5 ? "rose" : "green"} icon="📉" />
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Section title="גבייה — 6 חודשים אחרונים" icon="💰">
            {m.last6Months.length ? (
              <BarChart data={m.last6Months.map((x) => ({ label: shortMonth(x.month), value: x.collected }))} format={ils} />
            ) : (
              <div className="py-10 text-center text-[12px] text-slate-400">
                עדיין אין גבייה. הגרף יתמלא אחרי החיוב הראשון.
              </div>
            )}
          </Section>
        </div>

        <Section title="לפי חבילה" icon="📦">
          {m.byPlan.length === 0 && (
            <div className="py-6 text-center text-[12px] text-slate-400">אין מנויים בתשלום</div>
          )}
          <div className="space-y-3">
            {m.byPlan.map((p) => (
              <div key={p.planId}>
                <div className="mb-1 flex items-baseline justify-between">
                  <span className="text-[12px] font-semibold text-slate-700">{p.planName}</span>
                  <span className="num text-[11px] text-slate-500">{ils(p.mrr)} · {p.count}</span>
                </div>
                <Progress value={p.mrr} max={Math.max(m.mrr, 1)} tone="teal" />
              </div>
            ))}
          </div>
        </Section>
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <Section title="בריאות הגבייה" icon="🩺">
          <div className="space-y-2.5">
            <Row label="המרה מניסיון לתשלום" value={`${m.trialConversionPct}%`}
                 tone={m.trialConversionPct >= 20 ? 'green' : 'amber'}
                 note="מתחת ל-15% מרמז שהניסיון קצר מדי או שהחיכוך בקופה גבוה" />
            <Row label="חיובים כושלים" value={`${m.failedPaymentPct}%`}
                 tone={m.failedPaymentPct > 8 ? 'rose' : 'green'}
                 note="מעל 8% מצביע על בעיה במנגנון, לא על הלקוחות" />
            <Row label="שוקם ב-dunning" value={`${m.dunningRecoveryPct}%`}
                 tone={m.dunningRecoveryPct >= 50 ? 'green' : 'amber'}
                 note="מהכשלים שנגבו בסוף. מתחת ל-40% — לשפר את נוסח ההודעות" />
          </div>
        </Section>

        <Section title="מצב המנויים" icon="👥">
          <div className="grid grid-cols-2 gap-2">
            <Tile label="בניסיון"  n={m.trialing}  tone="violet" />
            <Tile label="חינם"     n={m.freeSubs}  tone="slate" />
            <Tile label="חיוב נכשל" n={m.pastDue}  tone="amber" />
            <Tile label="מושהים"   n={m.suspended} tone="rose" />
          </div>
          {m.pastDue > 0 && (
            <div className="mt-3 rounded-xl bg-amber-50 px-3 py-2 text-[11px] text-amber-800">
              {m.pastDue} מנויים בתהליך גבייה חוזרת. הגישה שלהם פתוחה — הם לא נחסמו.
            </div>
          )}
        </Section>
      </div>
    </div>
  );
}

function Row({ label, value, tone, note }: { label: string; value: string; tone: string; note: string }) {
  return (
    <div className="rounded-xl border border-slate-100 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[12px] font-semibold text-slate-700">{label}</span>
        <Chip tone={tone}>{value}</Chip>
      </div>
      <div className="mt-1 text-[10px] leading-relaxed text-slate-400">{note}</div>
    </div>
  );
}

function Tile({ label, n, tone }: { label: string; n: number; tone: string }) {
  const bg: Record<string, string> = {
    violet: 'bg-violet-50 text-violet-700', slate: 'bg-slate-50 text-slate-600',
    amber: 'bg-amber-50 text-amber-800', rose: 'bg-rose-50 text-rose-700',
  };
  return (
    <div className={`rounded-xl p-3 ${bg[tone] ?? bg.slate}`}>
      <div className="num text-xl font-black">{n}</div>
      <div className="text-[11px] font-semibold opacity-80">{label}</div>
    </div>
  );
}
