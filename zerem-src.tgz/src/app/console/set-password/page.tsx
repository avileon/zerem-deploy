import AuthForm from '@/components/AuthForm';

export const dynamic = 'force-dynamic';

export default async function SetPassword({
  searchParams,
}: { searchParams: Promise<{ token?: string; console?: string }> }) {
  const sp = await searchParams;

  if (!sp.token) {
    return (
      <div className="flex min-h-screen items-center justify-center p-6">
        <div className="card max-w-sm p-7 text-center">
          <div className="text-2xl">🔗</div>
          <h1 className="mt-3 text-base font-black text-slate-900">קישור חסר או לא תקין</h1>
          <p className="mt-2 text-[12px] text-slate-500">
            השתמש בקישור המלא שקיבלת. אם עברו יותר משלושה ימים, בקש קישור חדש.
          </p>
        </div>
      </div>
    );
  }

  return (
    <AuthForm
      mode="set-password"
      title="קביעת סיסמה"
      subtitle={sp.console === '1' ? 'קונסולת ניהול' : 'ברוך הבא לזרם'}
      endpoint="/api/auth/set-password"
      token={sp.token}
    />
  );
}
