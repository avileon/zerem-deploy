import { redirect } from 'next/navigation';
import AuthForm from '@/components/AuthForm';
import { getConsoleSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

/** עולם נפרד. עיצוב כהה כדי שתדע במבט אחד איפה אתה. */
export default async function ConsoleLogin({
  searchParams,
}: { searchParams: Promise<{ next?: string }> }) {
  if (await getConsoleSession()) redirect('/console');
  const sp = await searchParams;

  return (
    <AuthForm
      mode="console"
      title="קונסולת ניהול"
      subtitle="זרם · פלטפורמה"
      endpoint="/api/auth/console-login"
      next={sp.next}
      footer="אזור מוגבל. כל כניסה מתועדת."
    />
  );
}
