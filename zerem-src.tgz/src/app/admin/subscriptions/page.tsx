import Link from 'next/link';
import { sql } from 'drizzle-orm';
import { db } from '@/db';
import { PageHeader, Chip, Avatar, Empty, timeAgo } from '@/components/ui';
import { ils } from '@/lib/israel';

export const dynamic = 'force-dynamic';

const STATUS: Record<string, { label: string; tone: string }> = {
  TRIALING: { label: 'ניסיון', tone: 'violet' },
  FREE: { label: 'חינם', tone: 'slate' },
  ACTIVE: { label: 'פעיל', tone: 'green' },
  PAST_DUE: { label: 'חיוב נכשל', tone: 'amber' },
  CANCELING: { label: 'מבוטל', tone: 'amber' },
  SUSPENDED: { label: 'מושהה', tone: 'rose' },
  CLOSED: { label: 'סגור', tone: 'rose' },
};

interface Row extends Record<string, unknown> {
  id: string; org_id: string; org_name: string; plan_id: string; plan_name: string;
  interval: string; status: string; current_period_end: string;
  dunning_attempt: number; mrr: number; last4: string | null; coupon_code: string | null;
  paid_total: number; invoices: number;
}

export default async function AdminSubscriptions() {
  const rows = await db.execute<Row>(sql`
    SELECT s.id, s.org_id, o.name AS org_name, s.plan_id,
           pl.name_he AS plan_name, s.interval, s.status,
           s.current_period_end, s.dunning_attempt,
           COALESCE(CASE WHEN s.interval = 'YEARLY' THEN pp.amount_ex_vat/12.0 ELSE pp.amount_ex_vat END, 0)::float AS mrr,
           pm.last4,
           c.code AS coupon_code,
           COALESCE((SELECT SUM(total_inc_vat) FROM billing_invoices bi
                     WHERE bi.subscription_id = s.id AND bi.status = 'PAID'), 0)::float AS paid_total,
           (SELECT COUNT(*)::int FROM billing_invoices bi WHERE bi.subscription_id = s.id) AS invoices
    FROM org_subscriptions s
    JOIN organizations o ON o.id = s.org_id
    LEFT JOIN plans pl ON pl.id = s.plan_id
    LEFT JOIN plan_prices pp ON pp.plan_id = s.plan_id AND pp.interval = s.interval
    LEFT JOIN billing_payment_methods pm ON pm.id = s.payment_method_id
    LEFT JOIN coupons c ON c.id = s.coupon_id
    ORDER BY
      CASE s.status WHEN 'PAST_DUE' THEN 0 WHEN 'SUSPENDED' THEN 1 WHEN 'ACTIVE' THEN 2 ELSE 3 END,
      s.current_period_end
  `);

  const attention = rows.filter((r) => r.status === 'PAST_DUE' || r.status === 'SUSPENDED');

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="מנויים"
        subtitle={`${rows.length} ארגונים · ${attention.length} דורשים טיפול`}
        actions={<Link href="/admin/revenue" className="btn btn-ghost btn-sm">הכנסות</Link>}
      />

      {attention.length > 0 && (
        <div className="mb-4 rounded-2xl bg-amber-50 p-4">
          <div className="text-sm font-bold text-amber-900">{attention.length} מנויים בתהליך גבייה</div>
          <div className="mt-2 space-y-1.5">
            {attention.map((r) => (
              <div key={r.id} className="flex items-center gap-2 text-[12px]">
                <Avatar name={r.org_name} size={22} />
                <span className="font-semibold text-slate-800">{r.org_name}</span>
                <Chip tone={STATUS[r.status]?.tone ?? 'slate'}>{STATUS[r.status]?.label}</Chip>
                <span className="text-slate-500">ניסיון {r.dunning_attempt}/5</span>
                <span className="text-slate-400">· {r.last4 ? `כרטיס ••${r.last4}` : 'אין כרטיס'}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {rows.length === 0 ? (
        <div className="card"><Empty icon="📋" title="אין מנויים עדיין" hint="הארגון הראשון שיירשם יופיע כאן" /></div>
      ) : (
        <div className="card overflow-x-auto p-0">
          <table className="w-full text-right text-[12px]">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] text-slate-400">
                <th className="px-3 py-2.5 font-semibold">ארגון</th>
                <th className="px-3 py-2.5 font-semibold">חבילה</th>
                <th className="px-3 py-2.5 font-semibold">מצב</th>
                <th className="px-3 py-2.5 font-semibold">MRR</th>
                <th className="px-3 py-2.5 font-semibold">חידוש</th>
                <th className="px-3 py-2.5 font-semibold">שולם עד היום</th>
                <th className="px-3 py-2.5 font-semibold">כרטיס</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <Avatar name={r.org_name} size={26} />
                      <span className="font-bold text-slate-800">{r.org_name}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-slate-600">{r.plan_name ?? r.plan_id}</span>
                    {r.interval === 'YEARLY' && <Chip tone="teal">שנתי</Chip>}
                    {r.coupon_code && <span className="ltr mr-1 text-[10px] text-violet-600">{r.coupon_code}</span>}
                  </td>
                  <td className="px-3 py-2.5">
                    <Chip tone={STATUS[r.status]?.tone ?? 'slate'}>{STATUS[r.status]?.label ?? r.status}</Chip>
                  </td>
                  <td className="num px-3 py-2.5 font-bold text-slate-800">
                    {r.mrr > 0 ? ils(r.mrr) : '—'}
                  </td>
                  <td className="px-3 py-2.5 text-slate-500">{timeAgo(r.current_period_end)}</td>
                  <td className="num px-3 py-2.5 text-slate-600">
                    {r.paid_total > 0 ? ils(r.paid_total) : '—'}
                    {r.invoices > 0 && <span className="mr-1 text-[10px] text-slate-400">({r.invoices})</span>}
                  </td>
                  <td className="ltr num px-3 py-2.5 text-slate-500">{r.last4 ? `•• ${r.last4}` : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
