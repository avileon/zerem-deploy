'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHeader, Chip, Section, Progress, Empty } from '@/components/ui';
import { ils } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

const STATUS: Record<string, { label: string; tone: string; note?: string }> = {
  TRIALING:  { label: 'תקופת ניסיון', tone: 'violet' },
  FREE:      { label: 'חבילת חינם',   tone: 'slate' },
  ACTIVE:    { label: 'פעיל',         tone: 'green' },
  PAST_DUE:  { label: 'חיוב נכשל',    tone: 'amber',  note: 'הגישה שלך פתוחה. נמשיך לנסות לגבות.' },
  CANCELING: { label: 'מבוטל',        tone: 'amber',  note: 'המנוי פעיל עד סוף התקופה ששולמה.' },
  SUSPENDED: { label: 'מושהה',        tone: 'rose',   note: 'עדכון אמצעי תשלום פותח את החשבון מיד.' },
  CLOSED:    { label: 'סגור',         tone: 'rose' },
};

const INV_STATUS: Record<string, { label: string; tone: string }> = {
  PAID:       { label: 'שולם',    tone: 'green' },
  ZERO_RATED: { label: 'חינם',    tone: 'violet' },
  OPEN:       { label: 'ממתין',   tone: 'sky' },
  FAILED:     { label: 'נכשל',    tone: 'rose' },
  REFUNDED:   { label: 'זוכה',    tone: 'slate' },
  VOID:       { label: 'בוטל',    tone: 'slate' },
  DRAFT:      { label: 'טיוטה',   tone: 'slate' },
};

const heDate = (d: string | null) =>
  d ? new Date(d).toLocaleDateString('he-IL', { day: 'numeric', month: 'short', year: 'numeric' }) : '—';

export default function BillingView({ sub, ent, plans, invoices, pm, addons, coupon }: {
  sub: any; ent: any; plans: any[]; invoices: any[]; pm: any; addons: any[]; coupon: any;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState('');

  const status = STATUS[ent.status] ?? STATUS.FREE;
  const plan = plans.find((p) => p.id === ent.planId);
  const monthly = sub?.interval === 'YEARLY' ? plan?.yearly : plan?.monthly;

  const quotaFeatures = ['users', 'leads', 'quotes_per_month', 'wa_channels']
    .map((k) => ent.features[k]).filter((f: any) => f && f.limit !== 0);

  async function post(url: string, body?: unknown, key = url) {
    setBusy(key);
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(null);
    return r;
  }

  async function updateCard() {
    const r = await post('/api/billing/payment-method');
    if (r.ok && r.url) window.location.href = r.url;
    else alert(r.error ?? 'לא הצלחנו לפתוח את עמוד הכרטיס');
  }

  async function doCancel() {
    const r = await post('/api/billing/subscription/cancel', { reason });
    if (r.ok) { setCancelOpen(false); location.reload(); }
    else alert(r.error);
  }

  async function doResume() {
    const r = await post('/api/billing/subscription/resume');
    if (r.ok) location.reload();
  }

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="חיוב ומנוי"
        subtitle="החבילה, השימוש, אמצעי התשלום והחשבוניות"
        actions={<Link href="/pricing" className="btn btn-ghost btn-sm">כל החבילות</Link>}
      />

      {/* ── באנר מצב חריג ── */}
      {(ent.status === 'PAST_DUE' || ent.status === 'SUSPENDED') && (
        <div className={`mb-4 flex flex-col gap-2 rounded-2xl p-4 lg:flex-row lg:items-center ${
          ent.status === 'SUSPENDED' ? 'bg-rose-50' : 'bg-amber-50'}`}>
          <div className="flex-1">
            <div className={`text-sm font-bold ${ent.status === 'SUSPENDED' ? 'text-rose-800' : 'text-amber-800'}`}>
              {ent.status === 'SUSPENDED' ? 'החשבון מושהה' : 'החיוב האחרון לא עבר'}
            </div>
            <div className="mt-0.5 text-[12px] text-slate-600">
              {status.note} רוב המקרים הם כרטיס שהתחדש — העדכון לוקח פחות מדקה.
            </div>
          </div>
          <button onClick={updateCard} disabled={busy === '/api/billing/payment-method'} className="btn btn-primary btn-sm">
            עדכון אמצעי תשלום
          </button>
        </div>
      )}

      {ent.status === 'CANCELING' && (
        <div className="mb-4 flex flex-col gap-2 rounded-2xl bg-slate-100 p-4 lg:flex-row lg:items-center">
          <div className="flex-1 text-[12px] text-slate-600">
            <span className="font-bold text-slate-800">המנוי יסתיים ב-{heDate(sub?.currentPeriodEnd)}.</span>{' '}
            עד אז הכול ממשיך לעבוד. אחר כך תעבור לחבילת חינם — הנתונים נשמרים.
          </div>
          <button onClick={doResume} className="btn btn-ghost btn-sm">ביטול הביטול</button>
        </div>
      )}

      <div className="grid gap-3 lg:grid-cols-3">
        {/* ── החבילה ── */}
        <div className="card relative overflow-hidden p-5 lg:col-span-2">
          <span className="absolute inset-x-0 top-0 h-1" style={{ background: 'linear-gradient(90deg,#2dd4bf,#0d9488)' }} />
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black text-slate-900">{ent.planName}</span>
                <Chip tone={status.tone}>{status.label}</Chip>
                {sub?.interval === 'YEARLY' && <Chip tone="teal">שנתי</Chip>}
              </div>
              <div className="mt-1 text-[12px] text-slate-500">
                {ent.status === 'TRIALING'
                  ? <>הניסיון מסתיים ב-{heDate(sub?.trialEndsAt)} · כל היכולות פתוחות</>
                  : ent.planId === 'free'
                  ? 'ללא הגבלת זמן · שדרוג פותח את כל היכולות'
                  : <>החידוש הבא ב-{heDate(sub?.currentPeriodEnd)}</>}
              </div>
            </div>
            <div className="text-left">
              <div className="num text-2xl font-black text-slate-900">
                {monthly ? ils(monthly) : '₪0'}
              </div>
              <div className="text-[10px] text-slate-400">
                {monthly ? (sub?.interval === 'YEARLY' ? 'לשנה · לפני מע״מ' : 'לחודש · לפני מע״מ') : 'ללא עלות'}
              </div>
            </div>
          </div>

          {coupon && (
            <div className="mt-3 flex items-center gap-2 rounded-xl bg-violet-50 px-3 py-2">
              <span className="text-violet-600">🎟️</span>
              <div className="flex-1 text-[12px] text-violet-900">
                <span className="ltr font-bold">{coupon.code}</span> פעיל
                {coupon.cyclesLeft ? ` · נותרו ${coupon.cyclesLeft} מחזורים` : ''}
              </div>
            </div>
          )}

          {addons.length > 0 && (
            <div className="mt-3 border-t border-slate-100 pt-3">
              <div className="mb-1.5 text-[11px] font-bold text-slate-500">תוספות</div>
              <div className="flex flex-wrap gap-1.5">
                {addons.map((a: any) => (
                  <Chip key={a.id} tone="sky">{a.label} ×{a.quantity} · {ils(a.unitExVat)}</Chip>
                ))}
              </div>
            </div>
          )}

          <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-3">
            <Link href="/pricing" className="btn btn-primary btn-sm">שינוי חבילה</Link>
            <button onClick={updateCard} className="btn btn-ghost btn-sm">
              {pm ? 'החלפת כרטיס' : 'הוספת כרטיס'}
            </button>
            {ent.planId !== 'free' && ent.status !== 'CANCELING' && (
              <button onClick={() => setCancelOpen(true)} className="btn btn-ghost btn-sm !text-slate-400">
                ביטול מנוי
              </button>
            )}
          </div>
        </div>

        {/* ── אמצעי תשלום ── */}
        <div className="card p-5">
          <div className="text-[11px] font-bold text-slate-400">אמצעי תשלום</div>
          {pm ? (
            <>
              <div className="mt-3 flex items-center gap-3">
                <div className="flex h-10 w-14 items-center justify-center rounded-lg text-white"
                     style={{ background: 'linear-gradient(135deg,#334155,#0f172a)' }}>
                  <span className="text-[10px] font-bold">{pm.brand ?? 'CARD'}</span>
                </div>
                <div>
                  <div className="ltr num text-sm font-bold text-slate-800">•••• {pm.last4 ?? '____'}</div>
                  <div className="text-[10px] text-slate-400">
                    תוקף {String(pm.expMonth ?? '').padStart(2, '0')}/{String(pm.expYear ?? '').slice(-2)}
                  </div>
                </div>
              </div>
              {pm.status !== 'VALID' && (
                <div className={`mt-3 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold ${
                  pm.status === 'INVALID' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-800'}`}>
                  {pm.status === 'INVALID' ? 'הכרטיס פג תוקף' : 'הכרטיס עומד לפוג'}
                </div>
              )}
              <div className="mt-3 text-[10px] leading-relaxed text-slate-400">
                פרטי הכרטיס נשמרים בקארדקום. אנחנו רואים רק 4 ספרות ותוקף.
              </div>
            </>
          ) : (
            <div className="mt-2">
              <Empty icon="💳" title="אין כרטיס שמור" hint="נדרש למנוי בתשלום" />
              <button onClick={updateCard} className="btn btn-primary btn-sm mt-2 w-full">הוספת כרטיס</button>
            </div>
          )}
        </div>
      </div>

      {/* ── שימוש ── */}
      <Section title="שימוש בחבילה" icon="📊">
        <div className="grid gap-4 lg:grid-cols-2">
          {quotaFeatures.map((f: any) => (
            <div key={f.key}>
              <div className="mb-1 flex items-baseline justify-between">
                <span className="text-[12px] font-semibold text-slate-700">{f.label}</span>
                <span className="num text-[11px] text-slate-400">
                  {f.used}{f.limit === null ? ' · ללא הגבלה' : ` / ${f.limit}`}
                </span>
              </div>
              {/* מכסה ללא הגבלה לא מקבלת פס מלא — פס מלא בצבע נראה
                  כאילו הגעת לתקרה, וזו בדיוק ההפך מהמצב. */}
              {f.limit === null
                ? <div className="h-1.5 rounded-full bg-slate-100" />
                : <Progress value={f.used} max={f.limit}
                    tone={f.pct !== null && f.pct >= 90 ? 'rose' : f.pct !== null && f.pct >= 70 ? 'amber' : 'teal'} />}
              {f.pct !== null && f.pct >= 90 && (
                <div className="mt-1 text-[10px] font-semibold text-rose-600">
                  נשארו {f.remaining} — שדרוג פותח את המגבלה
                </div>
              )}
            </div>
          ))}
        </div>
      </Section>

      {/* ── חשבוניות ── */}
      <Section title="חשבוניות" icon="🧾">
        {invoices.length === 0 ? (
          <Empty icon="🧾" title="עדיין אין חשבוניות" hint="החשבונית הראשונה תופיע כאן אחרי החיוב הראשון" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-[12px]">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] text-slate-400">
                  <th className="py-2 font-semibold">תקופה</th>
                  <th className="py-2 font-semibold">סכום</th>
                  <th className="py-2 font-semibold">מע״מ</th>
                  <th className="py-2 font-semibold">סטטוס</th>
                  <th className="py-2 font-semibold">מסמך</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv: any) => {
                  const st = INV_STATUS[inv.status] ?? INV_STATUS.OPEN;
                  return (
                    <tr key={inv.id} className="border-b border-slate-50">
                      <td className="py-2.5 text-slate-600">
                        {heDate(inv.periodStart)} – {heDate(inv.periodEnd)}
                      </td>
                      <td className="num py-2.5 font-bold text-slate-800">{ils(inv.totalIncVat)}</td>
                      <td className="num py-2.5 text-slate-400">{Math.round(Number(inv.vatRate) * 100)}%</td>
                      <td className="py-2.5"><Chip tone={st.tone}>{st.label}</Chip></td>
                      <td className="py-2.5">
                        {inv.cardcomDocUrl
                          ? <a href={inv.cardcomDocUrl} target="_blank" rel="noreferrer"
                               className="font-bold text-teal-700">PDF ←</a>
                          : <span className="text-slate-300">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Section>

      {/* ── גיליון ביטול ── */}
      {cancelOpen && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/40 lg:items-center lg:justify-center"
             onClick={() => setCancelOpen(false)}>
          <div className="safe-b w-full rounded-t-3xl bg-white p-5 lg:max-w-md lg:rounded-3xl"
               onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
            <h3 className="text-base font-bold text-slate-900">ביטול המנוי</h3>
            <p className="mt-1 text-[12px] leading-relaxed text-slate-500">
              המנוי יישאר פעיל עד <b>{heDate(sub?.currentPeriodEnd)}</b> — לא נגבה ממך שוב.
              אחר כך תעבור לחבילת חינם. <b>שום נתון לא נמחק.</b>
            </p>

            <div className="mt-4">
              <div className="mb-1.5 text-[11px] font-bold text-slate-500">מה גרם לך לעזוב?</div>
              <div className="flex flex-wrap gap-1.5">
                {['יקר מדי', 'לא השתמשתי', 'חסר לי משהו', 'עברתי למערכת אחרת', 'סגרתי את העסק'].map((r) => (
                  <button key={r} onClick={() => setReason(r)}
                    className={`chip px-2.5 py-1 ${reason === r ? 'bg-teal-700 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button onClick={() => setCancelOpen(false)} className="btn btn-primary flex-1">להישאר</button>
              <button onClick={doCancel} disabled={busy?.includes('cancel')}
                      className="btn btn-ghost flex-1 !text-rose-600">אישור ביטול</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
