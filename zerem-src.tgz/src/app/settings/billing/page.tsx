import { currentOrg } from '@/lib/queries';
import { getSubscription, listInvoices, subscriptionAddons } from '@/lib/billing/service';
import { getEntitlements } from '@/lib/billing/entitlements';
import { defaultPaymentMethod } from '@/lib/billing/engine';
import { PLANS, ADDON_BY_KEY } from '@/lib/billing/catalog';
import { db, schema as s } from '@/db';
import { eq } from 'drizzle-orm';
import BillingView from './BillingView';

export const dynamic = 'force-dynamic';

export default async function BillingPage() {
  const org = await currentOrg();
  if (!org) return <div className="p-6">אין ארגון</div>;

  const sub = await getSubscription(org.id);
  const [ent, invoices, pm, addons] = await Promise.all([
    getEntitlements(org.id, { fresh: true }),
    listInvoices(org.id),
    defaultPaymentMethod(org.id),
    sub ? subscriptionAddons(sub.id) : Promise.resolve([]),
  ]);

  const coupon = sub?.couponId
    ? (await db.select().from(s.coupons).where(eq(s.coupons.id, sub.couponId)).limit(1))[0] ?? null
    : null;

  return (
    <BillingView
      sub={sub ? { ...sub, currentPeriodEnd: sub.currentPeriodEnd.toISOString(),
                   trialEndsAt: sub.trialEndsAt?.toISOString() ?? null } : null}
      ent={ent}
      plans={PLANS}
      invoices={invoices.map((i) => ({
        ...i,
        periodStart: i.periodStart.toISOString(),
        periodEnd: i.periodEnd.toISOString(),
        createdAt: i.createdAt.toISOString(),
      }))}
      pm={pm}
      addons={addons.map((a) => ({
        ...a,
        label: a.addonKey ? (ADDON_BY_KEY[a.addonKey]?.label ?? a.addonKey) : 'תוספת',
      }))}
      coupon={coupon ? { code: coupon.code, type: coupon.type, value: Number(coupon.value),
                         duration: coupon.duration, cyclesLeft: sub?.couponCyclesLeft ?? null } : null}
    />
  );
}
