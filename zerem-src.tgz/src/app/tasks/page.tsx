import { requireTenant } from '@/lib/auth/session';
import { listTasks, listTeam } from '@/lib/queries';
import TasksView from './TasksView';

export const dynamic = 'force-dynamic';

export default async function TasksPage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const [tasks, team] = await Promise.all([listTasks(org.id), listTeam(org.id)]);
  return <TasksView tasks={JSON.parse(JSON.stringify(tasks))} team={JSON.parse(JSON.stringify(team))} />;
}
