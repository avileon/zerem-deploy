import { requireTenant } from '@/lib/auth/session';
import { listTasks, listTeam, listLeads } from '@/lib/queries';
import TasksView from './TasksView';

export const dynamic = 'force-dynamic';

export default async function TasksPage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const [tasks, team, leads] = await Promise.all([
    listTasks(org.id), listTeam(org.id), listLeads(org.id),
  ]);
  return <TasksView
    tasks={JSON.parse(JSON.stringify(tasks))}
    team={JSON.parse(JSON.stringify(team))}
    leads={leads.map((l) => ({ id: l.id, fullName: l.fullName }))}
  />;
}
