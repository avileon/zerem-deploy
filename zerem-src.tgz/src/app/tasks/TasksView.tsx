'use client';
import Link from 'next/link';
import { useState, useMemo } from 'react';
import { PageHeader, Chip, Avatar, dueLabel, Empty, TASK_PRIORITY, ROLE_LABEL } from '@/components/ui';

/* eslint-disable @typescript-eslint/no-explicit-any */

const COLUMNS = [
  { key: 'OPEN', label: 'לביצוע', tone: 'sky' },
  { key: 'IN_PROGRESS', label: 'בעבודה', tone: 'amber' },
  { key: 'DONE', label: 'הושלם', tone: 'green' },
];

export default function TasksView({ tasks, team }: { tasks: any[]; team: any[] }) {
  const [view, setView] = useState<'list' | 'board'>('list');
  const [done, setDone] = useState<Set<string>>(new Set());
  const [assignFor, setAssignFor] = useState<string | null>(null);
  const [owner, setOwner] = useState<string>('ALL');

  const visible = useMemo(
    () => tasks.filter((t) => owner === 'ALL' || t.assigneeId === owner),
    [tasks, owner],
  );

  const isDone = (t: any) => t.status === 'DONE' || done.has(t.id);
  const now = Date.now();
  const groups = [
    { title: 'באיחור', tone: 'rose', items: visible.filter((t) => !isDone(t) && t.dueAt && new Date(t.dueAt).getTime() < now) },
    { title: 'היום', tone: 'amber', items: visible.filter((t) => !isDone(t) && t.dueAt && new Date(t.dueAt).getTime() >= now && new Date(t.dueAt).toDateString() === new Date().toDateString()) },
    { title: 'בהמשך', tone: 'sky', items: visible.filter((t) => !isDone(t) && t.dueAt && new Date(t.dueAt).getTime() >= now && new Date(t.dueAt).toDateString() !== new Date().toDateString()) },
    { title: 'הושלמו', tone: 'green', items: visible.filter(isDone) },
  ];

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="משימות"
        subtitle={`${visible.filter((t) => !isDone(t)).length} פתוחות · החלק ימינה לסימון כבוצע`}
        actions={
          <>
            <div className="hidden rounded-xl border border-slate-200 bg-white p-0.5 lg:flex">
              {(['list', 'board'] as const).map((v) => (
                <button key={v} onClick={() => setView(v)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${view === v ? 'bg-teal-700 text-white' : 'text-slate-500'}`}>
                  {v === 'list' ? 'רשימה' : 'קנבן'}
                </button>
              ))}
            </div>
            <button className="btn btn-primary btn-sm">+ משימה</button>
          </>
        }
      />

      <div className="mb-3 flex gap-1.5 overflow-x-auto pb-1">
        <button onClick={() => setOwner('ALL')}
          className={`chip whitespace-nowrap px-2.5 py-1 ${owner === 'ALL' ? 'bg-teal-700 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
          כל הצוות
        </button>
        {team.map((m) => (
          <button key={m.userId} onClick={() => setOwner(m.userId)}
            className={`chip whitespace-nowrap px-2.5 py-1 ${owner === m.userId ? 'bg-teal-700 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
            {m.name}
          </button>
        ))}
      </div>

      {/* ── קנבן דסקטופ ── */}
      {view === 'board' && (
        <div className="hidden gap-3 lg:grid lg:grid-cols-3">
          {COLUMNS.map((c) => {
            const items = visible.filter((t) => (c.key === 'DONE' ? isDone(t) : t.status === c.key && !isDone(t)));
            return (
              <div key={c.key}>
                <div className="mb-2 flex items-center gap-2 px-1">
                  <Chip tone={c.tone}>{c.label}</Chip>
                  <span className="num text-[11px] text-slate-400">{items.length}</span>
                </div>
                <div className="space-y-2">
                  {items.map((t) => <TaskCard key={t.id} t={t} done={isDone(t)} onDone={() => toggle(t.id)} onAssign={() => setAssignFor(t.id)} />)}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── רשימה ── */}
      <div className={view === 'board' ? 'space-y-4 lg:hidden' : 'space-y-4'}>
        {groups.filter((g) => g.items.length).map((g) => (
          <div key={g.title}>
            <div className="mb-2 flex items-center gap-2 px-1">
              <Chip tone={g.tone}>{g.title}</Chip>
              <span className="num text-[11px] text-slate-400">{g.items.length}</span>
            </div>
            <div className="space-y-2">
              {g.items.map((t) => (
                <TaskCard key={t.id} t={t} done={isDone(t)} onDone={() => toggle(t.id)} onAssign={() => setAssignFor(t.id)} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* ── גיליון האצלה ── */}
      {assignFor && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/40 lg:items-center lg:justify-center" onClick={() => setAssignFor(null)}>
          <div className="safe-b w-full rounded-t-3xl bg-white p-5 lg:max-w-sm lg:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
            <h3 className="mb-1 text-base font-bold">העברת משימה</h3>
            <p className="mb-4 text-xs text-slate-500">
              הנמען יקבל התראת Push והודעת וואטסאפ מיידית.
            </p>
            <div className="space-y-1.5">
              {team.map((m) => (
                <button key={m.userId} onClick={() => setAssignFor(null)}
                  className="flex w-full items-center gap-3 rounded-xl border border-slate-200 p-2.5 text-right transition active:bg-slate-50">
                  <Avatar name={m.name} size={36} />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold text-slate-800">{m.name}</div>
                    <div className="text-[11px] text-slate-400">{ROLE_LABEL[m.role]}</div>
                  </div>
                  <span className="text-slate-300">←</span>
                </button>
              ))}
            </div>
            <button onClick={() => setAssignFor(null)} className="btn btn-ghost mt-3 w-full">ביטול</button>
          </div>
        </div>
      )}
    </div>
  );

  function toggle(id: string) {
    setDone((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  }
}

function TaskCard({ t, done, onDone, onAssign }: { t: any; done: boolean; onDone: () => void; onAssign: () => void }) {
  const [dx, setDx] = useState(0);
  const [start, setStart] = useState<number | null>(null);
  const due = dueLabel(t.dueAt);
  const pr = TASK_PRIORITY[t.priority];

  return (
    <div className="relative overflow-hidden rounded-2xl">
      {/* רקע חשיפה בהחלקה */}
      <div className="absolute inset-0 flex items-center px-5 text-sm font-bold text-white" style={{background:"linear-gradient(90deg,#16a34a,#15803d)"}}>
        ✓ בוצע
      </div>
      <div
        className="swipe-row card card-hover relative p-3.5 transition-transform"
        style={{ transform: `translateX(${dx}px)` }}
        onTouchStart={(e) => setStart(e.touches[0].clientX)}
        onTouchMove={(e) => {
          if (start === null) return;
          const d = e.touches[0].clientX - start;
          if (d < 0) setDx(Math.max(d, -120));      // RTL: החלקה שמאלה חושפת
        }}
        onTouchEnd={() => {
          if (dx < -70) { onDone(); }
          setDx(0); setStart(null);
        }}
      >
        <div className="flex items-start gap-3">
          <button onClick={onDone}
            className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 transition active:scale-90 ${
              done ? 'border-green-600 bg-green-600 text-white' : 'border-slate-300 hover:border-teal-500'}`}>
            {done && <span className="text-[11px]">✓</span>}
          </button>
          <div className="min-w-0 flex-1">
            <div className={`text-sm font-semibold ${done ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{t.title}</div>
            <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
              {t.leadName && <Link href={`/leads/${t.leadId}`} className="font-semibold text-teal-700">{t.leadName}</Link>}
              <Chip tone={pr.tone}>{pr.label}</Chip>
              <Chip tone={due.tone}>{due.text}</Chip>
            </div>
          </div>
          <button onClick={onAssign} title="העבר לעובד אחר"
                  className="flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 px-1.5 py-1">
            <Avatar name={t.assigneeName ?? '?'} size={22} />
            <span className="text-[10px] text-slate-400">⇄</span>
          </button>
        </div>
        {t.leadPhone && !done && (
          <div className="mt-2.5 flex gap-1.5 border-t border-slate-100 pt-2.5">
            <a href={`tel:${t.leadPhone}`} className="btn btn-ghost btn-sm flex-1">📞</a>
            <a href={`https://wa.me/${t.leadPhone.replace('+', '')}`} target="_blank" rel="noreferrer"
               className="btn btn-ghost btn-sm flex-1 !text-green-700">💬</a>
          </div>
        )}
      </div>
    </div>
  );
}
