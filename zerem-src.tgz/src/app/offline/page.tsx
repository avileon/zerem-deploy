export default function Offline() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center p-8 text-center">
      <div className="text-5xl">📡</div>
      <h1 className="mt-4 text-lg font-bold text-slate-800">אין חיבור לאינטרנט</h1>
      <p className="mt-1 text-sm text-slate-500">
        הנתונים שנטענו קודם עדיין זמינים. פעולות חדשות יסתנכרנו כשהחיבור יחזור.
      </p>
    </div>
  );
}
