import { currentOrg, getDashboard, listQuotes, teamPerformance, listTeam } from '@/lib/queries';
import { PageHeader, Section, Progress, Chip, LEAD_STATUS, LEAD_STATUS_ORDER, SOURCE_LABEL, QUOTE_STATUS } from '@/components/ui';
import { ils, num, CURRENT_VAT_RATE } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function ReportsPage() {
  const org = await currentOrg();
  const [d, quotes, perf, team] = await Promise.all([
    getDashboard(org.id), listQuotes(org.id), teamPerformance(org.id), listTeam(org.id),
  ]);

  const funnel = LEAD_STATUS_ORDER.filter((k) => k !== 'LOST').map((k) => ({
    k, n: Number(d.pipeline.find((p) => p.status === k)?.n ?? 0),
  }));
  const maxF = Math.max(...funnel.map((f) => f.n), 1);
  const sent = quotes.filter((q) => q.status !== 'DRAFT');
  const signed = quotes.filter((q) => ['SIGNED', 'PAID'].includes(q.status));
  const avgTicket = signed.length ? signed.reduce((a, q) => a + Number(q.totalIls), 0) / signed.length : 0;

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="דוחות" subtitle="משפך, מקורות, ביצועי צוות" />

      <div className="mb-4 grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        <div className="card p-3.5"><div className="label">שיעור סגירת הצעות</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{sent.length ? ((signed.length/sent.length)*100).toFixed(0) : 0}%</div></div>
        <div className="card p-3.5"><div className="label">עסקה ממוצעת</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{ils(avgTicket)}</div></div>
        <div className="card p-3.5"><div className="label">הכנסה שנגבתה</div><div className="num mt-1 text-lg font-bold text-green-600 lg:text-2xl">{ils(d.paidValue)}</div></div>
        <div className="card p-3.5"><div className="label">מע״מ שנצבר</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{ils(d.paidValue - d.paidValue/(1+CURRENT_VAT_RATE))}</div></div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="משפך מכירות" pad>
          <div className="space-y-3">
            {funnel.map((f, i) => {
              const prev = i > 0 ? funnel[i-1].n : null;
              const conv = prev && prev > 0 ? (f.n / prev) * 100 : null;
              return (
                <div key={f.k}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">{LEAD_STATUS[f.k].label}</span>
                    <span className="num text-slate-500">
                      {f.n}{conv !== null && <span className="mr-1.5 text-[10px] text-slate-400">({conv.toFixed(0)}% המרה)</span>}
                    </span>
                  </div>
                  <Progress value={f.n} max={maxF} tone={f.k === 'WON' ? 'green' : 'teal'} />
                </div>
              );
            })}
          </div>
        </Section>

        <Section title="מקורות לידים — איכות ולא רק כמות" pad>
          <table className="w-full text-xs">
            <thead className="text-slate-400">
              <tr><th className="pb-2 text-right font-bold">מקור</th><th className="pb-2 text-center font-bold">לידים</th><th className="pb-2 text-center font-bold">נסגרו</th><th className="pb-2 text-left font-bold">שיעור</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {d.bySource.map((sc) => {
                const rate = Number(sc.n) ? (Number(sc.won)/Number(sc.n))*100 : 0;
                return (
                  <tr key={sc.source}>
                    <td className="py-2 font-semibold text-slate-700">{SOURCE_LABEL[sc.source] ?? sc.source}</td>
                    <td className="num py-2 text-center text-slate-600">{Number(sc.n)}</td>
                    <td className="num py-2 text-center text-slate-600">{Number(sc.won)}</td>
                    <td className="py-2 text-left"><Chip tone={rate >= 25 ? 'green' : rate >= 10 ? 'amber' : 'slate'}>{rate.toFixed(0)}%</Chip></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Section>

        <Section title="ביצועי צוות" pad>
          <table className="w-full text-xs">
            <thead className="text-slate-400">
              <tr><th className="pb-2 text-right font-bold">נציג</th><th className="pb-2 text-center font-bold">לידים</th><th className="pb-2 text-center font-bold">נסגרו</th><th className="pb-2 text-center font-bold">משימות</th><th className="pb-2 text-left font-bold">הכנסה</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {team.map((m) => {
                const l = perf.leadsPer.find((x) => x.userId === m.userId);
                const t = perf.tasksPer.find((x) => x.userId === m.userId);
                return (
                  <tr key={m.userId}>
                    <td className="py-2 font-semibold text-slate-700">{m.name}</td>
                    <td className="num py-2 text-center">{Number(l?.total ?? 0)}</td>
                    <td className="num py-2 text-center">{Number(l?.won ?? 0)}</td>
                    <td className="num py-2 text-center">
                      {Number(t?.open ?? 0)}
                      {Number(t?.overdue ?? 0) > 0 && <span className="mr-1 text-rose-600">({Number(t?.overdue)})</span>}
                    </td>
                    <td className="num py-2 text-left font-bold text-green-600">{ils(Number(l?.wonValue ?? 0))}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Section>

        <Section title="סטטוס הצעות" pad>
          <div className="space-y-2.5">
            {Object.keys(QUOTE_STATUS).map((k) => {
              const row = d.quoteStats.find((q) => q.status === k);
              const n = Number(row?.n ?? 0);
              if (!n) return null;
              return (
                <div key={k}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="font-semibold text-slate-700">{QUOTE_STATUS[k].label}</span>
                    <span className="num text-slate-500">{n} · {ils(Number(row?.v ?? 0))}</span>
                  </div>
                  <Progress value={n} max={Math.max(...d.quoteStats.map((q)=>Number(q.n)),1)} tone={k==='PAID'?'green':'teal'} />
                </div>
              );
            })}
          </div>
        </Section>
      </div>
    </div>
  );
}
