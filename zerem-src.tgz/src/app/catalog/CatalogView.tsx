'use client';
import { useState } from 'react';
import { PageHeader, Chip, Empty } from '@/components/ui';
import { Sheet, Field, TextInput, FormError, Actions, useSubmit } from '@/components/Sheet';
import { ils2 } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

export default function CatalogView({ products, canEdit, vatRate }: {
  products: any[]; canEdit: boolean; vatRate: number;
}) {
  const [editing, setEditing] = useState<any | null>(null);
  const [addOpen, setAddOpen] = useState(false);

  const cats = [...new Set(products.map((p) => p.category ?? 'אחר'))];

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="קטלוג"
        subtitle={`${products.length} פריטים · משמשים בהצעות מחיר`}
        actions={canEdit
          ? <button onClick={() => setAddOpen(true)} className="btn btn-primary btn-sm">+ פריט</button>
          : undefined}
      />

      {products.length === 0 ? (
        <div className="card">
          <Empty icon="🏷️" title="הקטלוג ריק"
                 hint={canEdit ? 'הוסף פריט כדי לבנות הצעות מחיר מהר' : 'המנהל יוסיף פריטים'} />
        </div>
      ) : (
        <div className="space-y-4">
          {cats.map((c) => (
            <div key={c}>
              <div className="mb-2 px-1"><Chip tone="teal">{c}</Chip></div>
              <div className="grid gap-2 lg:grid-cols-2">
                {products.filter((p) => (p.category ?? 'אחר') === c).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => canEdit && setEditing(p)}
                    disabled={!canEdit}
                    className={`card flex items-center gap-3 p-3.5 text-right ${
                      canEdit ? 'card-hover cursor-pointer' : 'cursor-default'} ${
                      p.active === false ? 'opacity-50' : ''}`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold text-slate-900">{p.name}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                        {p.sku && <span className="ltr">{p.sku}</span>}
                        <span>· ליחידה: {p.unit}</span>
                        {p.vatExempt && <Chip tone="amber">פטור ממע״מ</Chip>}
                        {p.active === false && <Chip tone="slate">לא פעיל</Chip>}
                      </div>
                    </div>
                    <div className="shrink-0 text-left">
                      <div className="num text-sm font-bold text-slate-800">{ils2(p.unitPriceIls)}</div>
                      <div className="num text-[10px] text-slate-400">
                        כולל מע״מ {ils2(Number(p.unitPriceIls) * (1 + vatRate))}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {addOpen && <ProductSheet onClose={() => setAddOpen(false)} />}
      {editing && <ProductSheet product={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function ProductSheet({ product, onClose }: { product?: any; onClose: () => void }) {
  const isEdit = !!product;
  const [f, setF] = useState({
    name: product?.name ?? '',
    category: product?.category ?? '',
    unitPriceIls: product ? String(product.unitPriceIls) : '',
    unit: product?.unit ?? 'יח׳',
    sku: product?.sku ?? '',
    description: product?.description ?? '',
  });
  const { busy, error, setError, send } = useSubmit();
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const r = await send('/api/crm/products', isEdit ? 'PATCH' : 'POST',
      isEdit ? { id: product.id, ...f } : f);
    if (r.ok) location.reload();
  }

  async function remove() {
    if (!confirm(`למחוק את "${product.name}"? אם הוא מופיע בהצעות קיימות הוא יסומן כלא פעיל במקום להימחק.`)) return;
    const r = await fetch(`/api/crm/products?id=${product.id}`, { method: 'DELETE' })
      .then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    if (r.ok) location.reload();
    else setError(r.error);
  }

  return (
    <Sheet
      title={isEdit ? 'עריכת פריט' : 'פריט חדש'}
      subtitle="המחיר נשמר לפני מע״מ. ההצעה מחשבת מע״מ לפי תאריך המסמך."
      onClose={onClose}
    >
      <form onSubmit={submit} className="space-y-3">
        <Field label="שם הפריט" required>
          <TextInput value={f.name} onChange={(v) => set('name', v)} required autoFocus />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="מחיר לפני מע״מ" required>
            <TextInput value={f.unitPriceIls} onChange={(v) => set('unitPriceIls', v)}
                       ltr type="number" required />
          </Field>
          <Field label="יחידה" hint="יח׳ / שעה / מ״ר">
            <TextInput value={f.unit} onChange={(v) => set('unit', v)} />
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="קטגוריה">
            <TextInput value={f.category} onChange={(v) => set('category', v)} />
          </Field>
          <Field label="מק״ט">
            <TextInput value={f.sku} onChange={(v) => set('sku', v)} ltr />
          </Field>
        </div>
        <Field label="תיאור">
          <textarea value={f.description} onChange={(e) => set('description', e.target.value)}
                    rows={2} className="input resize-none" />
        </Field>
        <FormError error={error} />
        <Actions onCancel={() => { setError(null); onClose(); }} busy={busy}
                 submitLabel={isEdit ? 'שמירה' : 'הוספה'} />
        {isEdit && (
          <button type="button" onClick={remove} className="btn btn-ghost w-full !text-rose-600">
            מחיקת הפריט
          </button>
        )}
      </form>
    </Sheet>
  );
}
