import { currentOrg, listProducts } from '@/lib/queries';
import { PageHeader, Chip } from '@/components/ui';
import { ils2, CURRENT_VAT_RATE } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function CatalogPage() {
  const org = await currentOrg();
  const products = await listProducts(org.id);
  const cats = [...new Set(products.map((p) => p.category ?? 'אחר'))];

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="קטלוג" subtitle={`${products.length} פריטים · מסונכרן עם ריווחית`}
        actions={<button className="btn btn-primary btn-sm">+ פריט</button>} />
      <div className="space-y-4">
        {cats.map((c) => (
          <div key={c}>
            <div className="mb-2 px-1"><Chip tone="teal">{c}</Chip></div>
            <div className="grid gap-2 lg:grid-cols-2">
              {products.filter((p) => (p.category ?? 'אחר') === c).map((p) => {
                const margin = p.costIls ? ((Number(p.unitPriceIls) - Number(p.costIls)) / Number(p.unitPriceIls)) * 100 : null;
                return (
                  <div key={p.id} className="card flex items-center gap-3 p-3.5">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold text-slate-900">{p.name}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                        {p.sku && <span className="ltr">{p.sku}</span>}
                        <span>· ליחידה: {p.unit}</span>
                        {p.vatExempt && <Chip tone="amber">פטור ממע״מ</Chip>}
                      </div>
                    </div>
                    <div className="shrink-0 text-left">
                      <div className="num text-sm font-bold text-slate-800">{ils2(p.unitPriceIls)}</div>
                      <div className="num text-[10px] text-slate-400">
                        כולל מע״מ {ils2(Number(p.unitPriceIls) * (1 + CURRENT_VAT_RATE))}
                      </div>
                      {margin !== null && <div className="num text-[10px] text-green-600">רווחיות {margin.toFixed(0)}%</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
