import { requireTenant } from '@/lib/auth/session';
import { listProducts } from '@/lib/queries';
import { vatRateAt } from '@/lib/israel';
import CatalogView from './CatalogView';

export const dynamic = 'force-dynamic';

export default async function CatalogPage() {
  const sess = await requireTenant();
  const products = await listProducts(sess.orgId);

  return (
    <CatalogView
      products={JSON.parse(JSON.stringify(products))}
      canEdit={sess.role === 'MANAGER'}
      vatRate={vatRateAt()}
    />
  );
}
