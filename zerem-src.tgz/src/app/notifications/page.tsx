import { currentOrg, listNotifications } from '@/lib/queries';
import { PageHeader, Chip, timeAgo } from '@/components/ui';

export const dynamic = 'force-dynamic';

const CH: Record<string, { label: string; tone: string }> = {
  PUSH: { label: 'Push', tone: 'violet' }, WHATSAPP: { label: 'וואטסאפ', tone: 'green' },
  EMAIL: { label: 'דוא״ל', tone: 'sky' }, IN_APP: { label: 'באפליקציה', tone: 'slate' },
};

export default async function NotificationsPage() {
  const org = await currentOrg();
  const rows = await listNotifications(org.id);
  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="התראות" subtitle="Push למכשיר · וואטסאפ לנציג · באפליקציה" />
      <div className="space-y-2">
        {rows.map((n) => (
          <div key={n.id} className={`card p-3.5 ${!n.readAt ? 'border-r-4 border-r-teal-600' : ''}`}>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-800">{n.title}</span>
              <Chip tone={CH[n.channel]?.tone}>{CH[n.channel]?.label}</Chip>
              <span className="mr-auto text-[10px] text-slate-400">{timeAgo(n.createdAt)}</span>
            </div>
            {n.body && <p className="mt-0.5 text-xs text-slate-500">{n.body}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
