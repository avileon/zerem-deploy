import { requireTenant } from '@/lib/auth/session';
import Link from 'next/link';
import { listQuotes } from '@/lib/queries';
import { PageHeader, Chip, timeAgo, QUOTE_STATUS } from '@/components/ui';
import { ils, ils2 } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function QuotesPage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const rows = await listQuotes(org.id);
  const open = rows.filter((q) => ['SENT', 'VIEWED'].includes(q.status));
  const closed = rows.filter((q) => ['SIGNED', 'PAID'].includes(q.status));
  const closedValue = closed.reduce((a, q) => a + Number(q.totalIls), 0);
  const openValue = open.reduce((a, q) => a + Number(q.totalIls), 0);
  const rate = rows.length ? (closed.length / rows.filter((q) => q.status !== 'DRAFT').length) * 100 : 0;

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="הצעות מחיר" subtitle={`${rows.length} הצעות · ${ils(openValue)} ממתין לתשובה`}
        actions={<Link href="/quotes/new" className="btn btn-primary btn-sm">+ הצעה</Link>} />

      <div className="mb-4 grid grid-cols-3 gap-2.5">
        <div className="card p-3.5"><div className="label">ממתין לתשובה</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{ils(openValue)}</div></div>
        <div className="card p-3.5"><div className="label">נחתם</div><div className="num mt-1 text-lg font-bold text-green-600 lg:text-2xl">{ils(closedValue)}</div></div>
        <div className="card p-3.5"><div className="label">שיעור סגירה</div><div className="num mt-1 text-lg font-bold lg:text-2xl">{rate.toFixed(0)}%</div></div>
      </div>

      <div className="space-y-2">
        {rows.map((q) => {
          const st = QUOTE_STATUS[q.status];
          return (
            <div key={q.id} className="card p-3.5">
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="num text-xs font-bold text-slate-400">#{q.number}</span>
                    <Link href={`/leads/${q.leadId}`} className="truncate text-sm font-bold text-slate-900">{q.leadName}</Link>
                    <Chip tone={st.tone}>{st.label}</Chip>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-slate-400">
                    <span>{q.creator}</span>
                    {q.sentAt && <><span>·</span><span>נשלחה {timeAgo(q.sentAt)}</span></>}
                    {q.viewCount > 0 && <><span>·</span><span className="font-semibold text-violet-700">נצפתה {q.viewCount}×</span></>}
                    {q.signedAt && <><span>·</span><span className="font-semibold text-teal-700">נחתמה {timeAgo(q.signedAt)}</span></>}
                  </div>
                </div>
                <div className="shrink-0 text-left">
                  <div className="num text-sm font-bold text-slate-800">{ils2(q.totalIls)}</div>
                  <div className="num text-[10px] text-slate-400">מע״מ {ils2(q.vatIls)}</div>
                </div>
              </div>
              <div className="mt-2.5 flex gap-1.5 border-t border-slate-100 pt-2.5">
                <Link href={`/q/${q.publicToken}`} target="_blank" className="btn btn-ghost btn-sm flex-1">👁 תצוגת לקוח</Link>
                <a href={`https://wa.me/${(q.leadPhone ?? '').replace('+','')}`} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm flex-1 !text-green-700">💬 שלח שוב</a>
                {['SIGNED','PAID'].includes(q.status) && <button className="btn btn-ghost btn-sm flex-1">🧾 חשבונית</button>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
