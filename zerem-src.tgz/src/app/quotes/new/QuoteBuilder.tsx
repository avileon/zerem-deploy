'use client';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { PageHeader, Chip } from '@/components/ui';
import { calcTotals, ils2, normalizePhone, allocationThresholdAt, CURRENT_VAT_RATE } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

interface Line { key: string; productId?: string; name: string; unit: string; qty: number; price: number; disc: number; vatExempt: boolean }

export default function QuoteBuilder({ org, products, leads }: { org: any; products: any[]; leads: any[] }) {
  const [leadId, setLeadId] = useState<string>(leads[0]?.id ?? '');
  const [lines, setLines] = useState<Line[]>([]);
  const [discount, setDiscount] = useState(0);
  const [notes, setNotes] = useState('');
  const [tab, setTab] = useState<'edit' | 'preview'>('edit');
  const [picker, setPicker] = useState(false);

  const lead = leads.find((l) => l.id === leadId);
  const totals = useMemo(
    () => calcTotals(
      lines.map((l) => ({ quantity: l.qty, unitPriceIls: l.price, discountPercent: l.disc, vatExempt: l.vatExempt })),
      { discountType: 'PERCENT', discountValue: discount },
    ),
    [lines, discount],
  );

  const add = (p: any) => {
    setLines((prev) => [...prev, {
      key: crypto.randomUUID(), productId: p.id, name: p.name, unit: p.unit,
      qty: 1, price: Number(p.unitPriceIls), disc: 0, vatExempt: p.vatExempt,
    }]);
    setPicker(false);
  };
  const upd = (k: string, patch: Partial<Line>) =>
    setLines((prev) => prev.map((l) => (l.key === k ? { ...l, ...patch } : l)));
  const del = (k: string) => setLines((prev) => prev.filter((l) => l.key !== k));

  const byCategory = useMemo(() => {
    const m: Record<string, any[]> = {};
    for (const p of products) (m[p.category ?? 'אחר'] ??= []).push(p);
    return m;
  }, [products]);

  return (
    <div className="p-4 lg:p-7">
      <div className="mb-1 text-xs text-slate-400">
        <Link href="/quotes" className="hover:underline">הצעות מחיר</Link> / חדשה
      </div>
      <PageHeader
        title="הצעת מחיר חדשה"
        subtitle={`מע״מ ${(totals.vatRate * 100).toFixed(0)}% · ${lines.length} שורות`}
        actions={
          <>
            <button className="btn btn-ghost btn-sm">שמור טיוטה</button>
            <button disabled={!lines.length || !lead} className="btn btn-primary btn-sm disabled:opacity-40">
              שלח בוואטסאפ
            </button>
          </>
        }
      />

      {/* מתג עורך/תצוגה — במובייל */}
      <div className="mb-3 flex rounded-xl border border-slate-200 bg-white p-0.5 lg:hidden">
        {(['edit', 'preview'] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 rounded-lg py-2 text-xs font-bold transition ${tab === t ? 'bg-teal-700 text-white' : 'text-slate-500'}`}>
            {t === 'edit' ? 'עריכה' : 'תצוגה מקדימה'}
          </button>
        ))}
      </div>

      {/* מסך מפוצל בדסקטופ */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* ── טופס ── */}
        <div className={`space-y-3 ${tab === 'preview' ? 'hidden lg:block' : ''}`}>
          <div className="card p-4">
            <label className="label mb-1.5 block">לקוח</label>
            <select value={leadId} onChange={(e) => setLeadId(e.target.value)} className="input">
              {leads.map((l) => <option key={l.id} value={l.id}>{l.fullName} — {l.phone}</option>)}
            </select>
            {lead && (
              <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] text-slate-500">
                <span className="ltr">{normalizePhone(lead.phone).display}</span>
                {lead.email && <><span>·</span><span className="ltr">{lead.email}</span></>}
                {lead.city && <><span>·</span><span>{lead.city}</span></>}
              </div>
            )}
          </div>

          <div className="card overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
              <h2 className="text-sm font-bold">פריטים</h2>
              <button onClick={() => setPicker(true)} className="btn btn-ghost btn-sm">+ הוסף מהקטלוג</button>
            </div>
            {lines.length === 0 ? (
              <div className="px-4 py-10 text-center text-sm text-slate-400">
                בחר פריטים מהקטלוג כדי להתחיל
              </div>
            ) : (
              <ul className="divide-y divide-slate-100">
                {lines.map((l) => (
                  <li key={l.key} className="p-3">
                    <div className="flex items-start gap-2">
                      <div className="min-w-0 flex-1">
                        <input value={l.name} onChange={(e) => upd(l.key, { name: e.target.value })}
                               className="w-full bg-transparent text-sm font-semibold outline-none" />
                        <div className="mt-2 grid grid-cols-3 gap-1.5">
                          <div>
                            <label className="label">כמות</label>
                            <input type="number" inputMode="decimal" min={0} step="0.5" value={l.qty}
                                   onChange={(e) => upd(l.key, { qty: Number(e.target.value) })}
                                   className="input !min-h-9 !py-1 text-sm" />
                          </div>
                          <div>
                            <label className="label">מחיר ליח׳</label>
                            <input type="number" inputMode="decimal" min={0} value={l.price}
                                   onChange={(e) => upd(l.key, { price: Number(e.target.value) })}
                                   className="input !min-h-9 !py-1 text-sm" />
                          </div>
                          <div>
                            <label className="label">הנחה %</label>
                            <input type="number" inputMode="decimal" min={0} max={100} value={l.disc}
                                   onChange={(e) => upd(l.key, { disc: Number(e.target.value) })}
                                   className="input !min-h-9 !py-1 text-sm" />
                          </div>
                        </div>
                      </div>
                      <div className="shrink-0 text-left">
                        <div className="num text-sm font-bold">{ils2(l.qty * l.price * (1 - l.disc / 100))}</div>
                        <button onClick={() => del(l.key)} className="mt-1 text-[11px] text-rose-500">הסר</button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card p-4">
            <label className="label mb-1.5 block">הנחה כללית (%)</label>
            <input type="range" min={0} max={30} value={discount} onChange={(e) => setDiscount(Number(e.target.value))} className="w-full" />
            <div className="mt-1 flex justify-between text-xs text-slate-500">
              <span>{discount}%</span><span className="num">−{ils2(totals.discountIls)}</span>
            </div>
            <label className="label mb-1.5 mt-4 block">הערות ללקוח</label>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="input" placeholder="למשל: לוח זמנים, תנאי תשלום…" />
          </div>
        </div>

        {/* ── תצוגה מקדימה חיה ── */}
        <div className={`${tab === 'edit' ? 'hidden lg:block' : ''}`}>
          <div className="card overflow-hidden lg:sticky lg:top-4">
            <div className="flex items-center justify-between px-5 py-4" style={{ background: org.brandColor, color: '#fff' }}>
              <div>
                <div className="text-base font-bold">{org.legalName ?? org.name}</div>
                <div className="text-[11px] opacity-90">ח.פ. {org.vatId} · {org.address}, {org.city}</div>
              </div>
              <div className="text-left text-[11px] opacity-90">
                <div className="text-sm font-bold">הצעת מחיר</div>
                <div className="num">#1047</div>
              </div>
            </div>

            <div className="border-b border-slate-100 px-5 py-3 text-xs">
              <span className="label">לכבוד</span>
              <div className="mt-0.5 font-bold text-slate-800">{lead?.fullName ?? '—'}</div>
              <div className="text-slate-400">
                <span className="ltr">{lead ? normalizePhone(lead.phone).display : ''}</span>
                {lead?.email && <> · <span className="ltr">{lead.email}</span></>}
              </div>
            </div>

            <table className="w-full text-xs">
              <thead className="bg-slate-50 text-[10px] text-slate-500">
                <tr>
                  <th className="px-3 py-2 text-right font-bold">תיאור</th>
                  <th className="px-2 py-2 text-right font-bold">כמות</th>
                  <th className="px-2 py-2 text-right font-bold">מחיר</th>
                  <th className="px-3 py-2 text-left font-bold">סה״כ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {lines.map((l) => (
                  <tr key={l.key}>
                    <td className="px-3 py-2">
                      {l.name}
                      {l.disc > 0 && <span className="mr-1 text-[10px] text-rose-500">−{l.disc}%</span>}
                    </td>
                    <td className="num px-2 py-2 text-slate-500">{l.qty} {l.unit}</td>
                    <td className="num px-2 py-2 text-slate-500">{ils2(l.price)}</td>
                    <td className="num px-3 py-2 text-left font-semibold">{ils2(l.qty * l.price * (1 - l.disc / 100))}</td>
                  </tr>
                ))}
                {!lines.length && <tr><td colSpan={4} className="px-3 py-8 text-center text-slate-300">אין פריטים</td></tr>}
              </tbody>
            </table>

            <div className="space-y-1 border-t border-slate-100 px-5 py-3 text-xs">
              <Row label="סכום ביניים" value={ils2(totals.subtotalIls)} />
              {totals.discountIls > 0 && <Row label={`הנחה ${discount}%`} value={`−${ils2(totals.discountIls)}`} tone="rose" />}
              <Row label={`מע״מ ${(totals.vatRate * 100).toFixed(0)}%`} value={ils2(totals.vatIls)} />
              <div className="mt-1.5 flex justify-between border-t border-slate-200 pt-1.5 text-sm">
                <b>סה״כ לתשלום</b><b className="num">{ils2(totals.totalIls)}</b>
              </div>
            </div>

            {notes && <div className="border-t border-slate-100 px-5 py-3 text-[11px] leading-relaxed text-slate-600">{notes}</div>}
            <div className="border-t border-slate-100 px-5 py-3 text-[10px] leading-relaxed text-slate-400">{org.quoteTerms}</div>
          </div>

          {/* אזהרת מספר הקצאה — לפני שנשלח, לא אחרי */}
          {totals.allocationRequired && (
            <div className="mt-3 rounded-2xl border border-amber-100 bg-amber-50 p-3.5 text-[11px] leading-relaxed">
              <b className="text-amber-700">⚠️ חשבונית זו תחייב מספר הקצאה</b>
              <p className="mt-1 text-slate-600">
                הסכום לפני מע״מ ({ils2(totals.taxableIls + totals.exemptIls)}) חוצה את הסף של {ils2(totals.allocationThreshold)}.
                המערכת תבקש את המספר אוטומטית מריווחית בעת ההנפקה. ודא שמספר ח.פ./ת.ז. של הלקוח מעודכן —
                בלעדיו הבקשה תידחה והלקוח לא יוכל לקזז מע״מ תשומות.
              </p>
              {!lead?.vatId && <div className="mt-1.5 font-bold text-rose-600">חסר ח.פ. / ת.ז. בכרטיס הלקוח</div>}
            </div>
          )}
        </div>
      </div>

      {/* בורר קטלוג */}
      {picker && (
        <div className="fixed inset-0 z-50 flex items-end bg-black/40 lg:items-center lg:justify-center" onClick={() => setPicker(false)}>
          <div className="safe-b max-h-[80vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 lg:max-w-md lg:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
            <h3 className="mb-3 text-base font-bold">בחר פריט</h3>
            {Object.entries(byCategory).map(([cat, items]) => (
              <div key={cat} className="mb-3">
                <div className="label mb-1.5">{cat}</div>
                <div className="space-y-1.5">
                  {items.map((p) => (
                    <button key={p.id} onClick={() => add(p)}
                      className="flex w-full items-center gap-3 rounded-xl border border-slate-200 p-2.5 text-right active:bg-slate-50">
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-semibold text-slate-800">{p.name}</div>
                        {p.sku && <div className="ltr text-[10px] text-slate-400">{p.sku}</div>}
                      </div>
                      <span className="num text-sm font-bold text-teal-700">{ils2(p.unitPriceIls)}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <button onClick={() => setPicker(false)} className="btn btn-ghost w-full">סגור</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-500">{label}</span>
      <span className={`num ${tone === 'rose' ? 'text-rose-600' : 'text-slate-700'}`}>{value}</span>
    </div>
  );
}
