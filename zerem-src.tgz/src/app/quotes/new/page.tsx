import { currentOrg, listProducts, listLeads } from '@/lib/queries';
import QuoteBuilder from './QuoteBuilder';

export const dynamic = 'force-dynamic';

export default async function NewQuotePage() {
  const org = await currentOrg();
  const [products, leads] = await Promise.all([listProducts(org.id), listLeads(org.id)]);
  return (
    <QuoteBuilder
      org={JSON.parse(JSON.stringify(org))}
      products={JSON.parse(JSON.stringify(products))}
      leads={JSON.parse(JSON.stringify(leads))}
    />
  );
}
