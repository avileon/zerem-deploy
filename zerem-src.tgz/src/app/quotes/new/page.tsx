import { requireTenant } from '@/lib/auth/session';
import { listProducts, listLeads } from '@/lib/queries';
import QuoteBuilder from './QuoteBuilder';

export const dynamic = 'force-dynamic';

export default async function NewQuotePage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const [products, leads] = await Promise.all([listProducts(org.id), listLeads(org.id)]);
  return (
    <QuoteBuilder
      org={JSON.parse(JSON.stringify(org))}
      products={JSON.parse(JSON.stringify(products))}
      leads={JSON.parse(JSON.stringify(leads))}
    />
  );
}
