import { currentOrg, listIntegrations, listWebhookEndpoints, listOutgoingWebhooks, listTemplates } from '@/lib/queries';
import { PageHeader, Section, Chip, timeAgo, SOURCE_LABEL } from '@/components/ui';
import { BAN_RISK_NOTICE } from '@/lib/integrations/green-api';
import { CARDCOM_WEBHOOK_WARNING } from '@/lib/integrations/cardcom';
import { DOUBLE_ISSUE_WARNING } from '@/lib/integrations/rivhit';

export const dynamic = 'force-dynamic';

const PROVIDER: Record<string, { name: string; desc: string; icon: string }> = {
  GREEN_API: { name: 'Green API', desc: 'וואטסאפ — שליחה, קבלה, קישורים', icon: '💬' },
  CARDCOM: { name: 'Cardcom', desc: 'סליקת אשראי, PayLink, הוראות קבע', icon: '💳' },
  RIVHIT: { name: 'ריווחית', desc: 'חשבוניות, קבלות, מספרי הקצאה', icon: '🧾' },
  FCM: { name: 'Firebase Push', desc: 'התראות למכשירי הצוות', icon: '🔔' },
};

export default async function IntegrationsPage() {
  const org = await currentOrg();
  const [ints, endpoints, outgoing, templates] = await Promise.all([
    listIntegrations(org.id), listWebhookEndpoints(org.id), listOutgoingWebhooks(org.id), listTemplates(org.id),
  ]);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="אינטגרציות" subtitle="חיבורים חיצוניים, קליטת לידים ותבניות" />

      <div className="mb-4 grid gap-2.5 lg:grid-cols-2">
        {ints.map((i) => {
          const meta = PROVIDER[i.provider] ?? { name: i.provider, desc: '', icon: '🔌' };
          const cfg = (i.config ?? {}) as Record<string, unknown>;
          return (
            <div key={i.id} className="card p-4">
              <div className="flex items-start gap-3">
                <span className="text-2xl">{meta.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900">{meta.name}</span>
                    <Chip tone={i.enabled ? (i.status === 'OK' ? 'green' : 'amber') : 'slate'}>
                      {i.enabled ? (i.status === 'OK' ? 'מחובר' : i.status ?? 'בעיה') : 'כבוי'}
                    </Chip>
                  </div>
                  <p className="mt-0.5 text-[11px] text-slate-400">{meta.desc}</p>
                  {i.enabled && (
                    <div className="ltr mt-2 space-y-0.5 text-[10px] text-slate-500">
                      {Object.entries(cfg).slice(0, 3).map(([k, v]) => (
                        <div key={k}>{k}: <b>{typeof v === 'object' ? JSON.stringify(v) : String(v)}</b></div>
                      ))}
                    </div>
                  )}
                  {i.lastCheckedAt && <div className="mt-1 text-[10px] text-slate-400">נבדק {timeAgo(i.lastCheckedAt)}</div>}
                </div>
                <button className="btn btn-ghost btn-sm shrink-0">הגדר</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* אזהרות שנובעות מהמחקר — לא קישוט, זה משפיע על החלטות */}
      <div className="mb-4 space-y-2">
        <Warn tone="amber" title="סיכון חסימת מספר בוואטסאפ" body={BAN_RISK_NOTICE} />
        <Warn tone="rose" title="אימות webhook של Cardcom" body={CARDCOM_WEBHOOK_WARNING} />
        <Warn tone="amber" title="מנפיק חשבוניות יחיד" body={DOUBLE_ISSUE_WARNING} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title={`קליטת לידים — ${endpoints.length} נקודות`}>
          <ul className="divide-y divide-slate-100">
            {endpoints.map((e) => (
              <li key={e.id} className="px-4 py-3">
                <div className="flex items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-800">{e.name}</span>
                      <Chip tone={e.active ? 'green' : 'slate'}>{SOURCE_LABEL[e.source]}</Chip>
                    </div>
                    <code className="ltr mt-1 block truncate rounded bg-slate-100 px-1.5 py-1 text-[10px] text-slate-600">
                      POST /api/ingest/{e.slug}
                    </code>
                    <div className="mt-1.5">
                      <div className="label mb-1">מיפוי שדות</div>
                      <div className="flex flex-wrap gap-1">
                        {Object.entries(e.fieldMap ?? {}).map(([from, to]) => (
                          <span key={from} className="ltr rounded bg-slate-100 px-1.5 py-0.5 text-[9px] text-slate-600">
                            {from} → {to}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="shrink-0 text-left text-[10px] text-slate-400">
                    <div className="num font-bold text-slate-700">{e.hitCount}</div>
                    <div>פניות</div>
                    <div className="mt-0.5">{timeAgo(e.lastHitAt)}</div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <div className="border-t border-slate-100 px-4 py-2.5">
            <button className="btn btn-ghost btn-sm w-full">+ נקודת קליטה חדשה</button>
          </div>
        </Section>

        <div className="space-y-4">
          <Section title="Webhooks יוצאים">
            <ul className="divide-y divide-slate-100">
              {outgoing.map((w) => (
                <li key={w.id} className="px-4 py-3">
                  <div className="text-sm font-bold text-slate-800">{w.name}</div>
                  <code className="ltr mt-0.5 block truncate text-[10px] text-slate-400">{w.url}</code>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {w.events.map((ev) => <Chip key={ev} tone="violet">{ev}</Chip>)}
                  </div>
                </li>
              ))}
            </ul>
          </Section>

          <Section title="תבניות הודעה">
            <ul className="divide-y divide-slate-100">
              {templates.map((t) => (
                <li key={t.id} className="px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-800">{t.name}</span>
                    {t.shortcut && <Chip tone="teal">/{t.shortcut}</Chip>}
                    <span className="num mr-auto text-[10px] text-slate-400">{t.useCount}×</span>
                  </div>
                  <p className="mt-1 line-clamp-2 whitespace-pre-wrap text-[11px] leading-snug text-slate-500">{t.body}</p>
                </li>
              ))}
            </ul>
          </Section>
        </div>
      </div>
    </div>
  );
}

function Warn({ tone, title, body }: { tone: string; title: string; body: string }) {
  const cls = tone === 'rose' ? 'border-rose-100 bg-rose-50' : 'border-amber-100 bg-amber-50';
  const txt = tone === 'rose' ? 'text-rose-700' : 'text-amber-700';
  return (
    <div className={`rounded-2xl border ${cls} p-3.5`}>
      <div className={`text-xs font-bold ${txt}`}>⚠️ {title}</div>
      <p className="mt-1 text-[11px] leading-relaxed text-slate-600">{body}</p>
    </div>
  );
}
