import { notFound } from 'next/navigation';
import { getQuoteByToken } from '@/lib/queries';
import PublicQuote from './PublicQuote';

export const dynamic = 'force-dynamic';

/** דף ציבורי — הלקוח מגיע לכאן מקישור בוואטסאפ. בלי מעטפת האפליקציה. */
export default async function PublicQuotePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const data = await getQuoteByToken(token);
  if (!data) notFound();
  return <PublicQuote data={JSON.parse(JSON.stringify(data))} />;
}
