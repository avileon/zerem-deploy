'use client';
import { useRef, useState, useEffect } from 'react';
import { ils2 } from '@/lib/israel';
import { SIGNATURE_LEGAL_DISCLAIMER } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

type Step = 'view' | 'otp' | 'sign' | 'done';

export default function PublicQuote({ data }: { data: any }) {
  const { quote, lead, org, items, signature, payment } = data;
  const already = !!signature || quote.status === 'SIGNED' || quote.status === 'PAID';
  const [step, setStep] = useState<Step>(already ? 'done' : 'view');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [name, setName] = useState(lead?.fullName ?? '');

  const brand = org.brandColor || '#0f766e';
  const expired = quote.validUntil && new Date(quote.validUntil) < new Date();

  return (
    <div className="min-h-screen bg-slate-100 pb-32">
      {/* כותרת ממותגת */}
      <header className="safe-t px-5 py-6 text-white" style={{ background: brand }}>
        <div className="mx-auto max-w-2xl">
          <div className="text-lg font-bold">{org.legalName ?? org.name}</div>
          <div className="mt-0.5 text-[11px] opacity-90">
            ח.פ. {org.vatId} · {org.address}, {org.city} · <span className="ltr">{org.phone}</span>
          </div>
          <div className="mt-4 flex items-end justify-between">
            <div>
              <div className="text-xs opacity-80">הצעת מחיר</div>
              <div className="num text-2xl font-bold">#{quote.number}</div>
            </div>
            <div className="text-left">
              <div className="text-xs opacity-80">סה״כ כולל מע״מ</div>
              <div className="num text-2xl font-bold">{ils2(quote.totalIls)}</div>
            </div>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-2xl space-y-3 p-4">
        {expired && step !== 'done' && (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
            תוקף ההצעה פג ב-{new Date(quote.validUntil).toLocaleDateString('he-IL')}. ניתן לפנות אלינו לחידוש.
          </div>
        )}

        <div className="card overflow-hidden">
          <div className="border-b border-slate-100 px-4 py-3">
            <div className="label">לכבוד</div>
            <div className="mt-0.5 text-sm font-bold text-slate-800">{lead?.fullName}</div>
          </div>
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-[10px] text-slate-500">
              <tr>
                <th className="px-4 py-2 text-right font-bold">תיאור</th>
                <th className="px-2 py-2 text-right font-bold">כמות</th>
                <th className="px-4 py-2 text-left font-bold">סה״כ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.map((it: any) => (
                <tr key={it.id}>
                  <td className="px-4 py-2.5">
                    <div className="font-medium text-slate-800">{it.name}</div>
                    {Number(it.discountPercent) > 0 && <div className="text-[10px] text-rose-500">הנחה {Number(it.discountPercent)}%</div>}
                  </td>
                  <td className="num px-2 py-2.5 text-slate-500">{Number(it.quantity)} {it.unit}</td>
                  <td className="num px-4 py-2.5 text-left font-semibold">{ils2(it.lineTotalIls)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="space-y-1 border-t border-slate-100 px-4 py-3 text-sm">
            <div className="flex justify-between text-slate-500"><span>סכום ביניים</span><span className="num">{ils2(quote.subtotalIls)}</span></div>
            {Number(quote.discountIls) > 0 && (
              <div className="flex justify-between text-rose-600"><span>הנחה</span><span className="num">−{ils2(quote.discountIls)}</span></div>
            )}
            <div className="flex justify-between text-slate-500">
              <span>מע״מ {(Number(quote.vatRate) * 100).toFixed(0)}%</span><span className="num">{ils2(quote.vatIls)}</span>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-1.5 text-base font-bold">
              <span>סה״כ לתשלום</span><span className="num">{ils2(quote.totalIls)}</span>
            </div>
          </div>
          {quote.terms && (
            <div className="border-t border-slate-100 px-4 py-3 text-[11px] leading-relaxed text-slate-500">{quote.terms}</div>
          )}
        </div>

        {step === 'done' ? (
          <div className="card p-5 text-center">
            <div className="text-3xl">✅</div>
            <h2 className="mt-2 text-base font-bold text-slate-800">ההצעה אושרה</h2>
            <p className="mt-1 text-xs text-slate-500">
              {signature ? `נחתם ע״י ${signature.signerName} · ${new Date(signature.signedAt).toLocaleString('he-IL')}` : 'תודה!'}
            </p>
            {signature?.documentSha256 && (
              <p className="ltr mt-2 break-all rounded-lg bg-slate-50 p-2 text-[9px] text-slate-400">
                SHA-256: {signature.documentSha256}
              </p>
            )}
            {quote.status !== 'PAID' && (
              <a href={payment?.payLinkUrl ?? '#'} className="btn btn-primary mt-4 w-full" style={{ background: brand }}>
                💳 לתשלום מאובטח — {ils2(quote.totalIls)}
              </a>
            )}
            {quote.status === 'PAID' && (
              <div className="mt-4 rounded-xl bg-green-100 px-3 py-2 text-sm font-bold text-green-700">
                שולם · חשבונית מס/קבלה נשלחה לוואטסאפ
              </div>
            )}
            <p className="mt-3 text-[10px] leading-relaxed text-slate-400">{SIGNATURE_LEGAL_DISCLAIMER}</p>
          </div>
        ) : step === 'view' ? (
          <div className="card p-4">
            <h2 className="text-sm font-bold text-slate-800">אישור ההצעה</h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500">
              לאישור ההצעה נשלח קוד אימות חד-פעמי למספר שלך המסתיים ב-
              <span className="ltr font-bold">{String(lead?.phone ?? '').slice(-4)}</span>.
              הקוד מוודא שמי שחותם הוא באמת אתה.
            </p>
            <button onClick={() => { setOtpSent(true); setStep('otp'); }}
                    className="btn btn-primary mt-3 w-full" style={{ background: brand }}>
              שלח לי קוד אימות
            </button>
          </div>
        ) : step === 'otp' ? (
          <div className="card p-4">
            <h2 className="text-sm font-bold text-slate-800">הזן את הקוד</h2>
            <p className="mt-1 text-xs text-slate-500">
              {otpSent && 'שלחנו קוד בן 6 ספרות לוואטסאפ שלך.'}
            </p>
            <input
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
              inputMode="numeric"
              autoComplete="one-time-code"
              placeholder="••••••"
              className="input ltr mt-3 text-center text-2xl tracking-[0.4em]"
            />
            <button disabled={otp.length !== 6} onClick={() => setStep('sign')}
                    className="btn btn-primary mt-3 w-full disabled:opacity-40" style={{ background: brand }}>
              אמת והמשך לחתימה
            </button>
            <button onClick={() => setStep('view')} className="btn btn-ghost mt-2 w-full">חזרה</button>
          </div>
        ) : (
          <SignPad name={name} setName={setName} brand={brand} onDone={() => setStep('done')} />
        )}
      </div>
    </div>
  );
}

/** קנבס חתימה — אצבע בנייד, עכבר בדסקטופ */
function SignPad({ name, setName, brand, onDone }: { name: string; setName: (v: string) => void; brand: string; onDone: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [drawing, setDrawing] = useState(false);
  const [hasInk, setHasInk] = useState(false);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = c.getBoundingClientRect();
    c.width = rect.width * dpr;
    c.height = rect.height * dpr;
    const ctx = c.getContext('2d')!;
    ctx.scale(dpr, dpr);
    ctx.lineWidth = 2.2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0f172a';
  }, []);

  const pos = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  return (
    <div className="card p-4">
      <h2 className="text-sm font-bold text-slate-800">חתימה</h2>
      <label className="label mb-1 mt-3 block">שם החותם</label>
      <input value={name} onChange={(e) => setName(e.target.value)} className="input" />

      <label className="label mb-1 mt-3 block">חתום כאן באצבע</label>
      <div className="relative overflow-hidden rounded-xl border-2 border-dashed border-slate-300 bg-white">
        <canvas
          ref={ref}
          className="h-40 w-full touch-none"
          onPointerDown={(e) => {
            setDrawing(true); setHasInk(true);
            const ctx = ref.current!.getContext('2d')!;
            const { x, y } = pos(e);
            ctx.beginPath(); ctx.moveTo(x, y);
            (e.target as Element).setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (!drawing) return;
            const ctx = ref.current!.getContext('2d')!;
            const { x, y } = pos(e);
            ctx.lineTo(x, y); ctx.stroke();
          }}
          onPointerUp={() => setDrawing(false)}
          onPointerLeave={() => setDrawing(false)}
        />
        {!hasInk && (
          <span className="pointer-events-none absolute inset-0 flex items-center justify-center text-xs text-slate-300">
            ✍️ חתום כאן
          </span>
        )}
      </div>
      <button
        onClick={() => {
          const c = ref.current!;
          c.getContext('2d')!.clearRect(0, 0, c.width, c.height);
          setHasInk(false);
        }}
        className="mt-2 text-xs text-slate-400"
      >
        נקה חתימה
      </button>

      <button disabled={!hasInk || !name.trim()} onClick={onDone}
              className="btn btn-primary mt-4 w-full disabled:opacity-40" style={{ background: brand }}>
        אשר וחתום על ההצעה
      </button>
      <p className="mt-2 text-[10px] leading-relaxed text-slate-400">
        בלחיצה על הכפתור נשמרים: עותק מוקפא של המסמך, חתימת גיבוב SHA-256, מועד החתימה,
        כתובת ה-IP ואישור ה-OTP — כראיה לכך שהמסמך לא שונה לאחר החתימה.
      </p>
    </div>
  );
}
