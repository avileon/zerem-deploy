import { requireTenant } from '@/lib/auth/session';
import { listLeads } from '@/lib/queries';
import LeadsView from './LeadsView';

export const dynamic = 'force-dynamic';

export default async function LeadsPage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const leads = await listLeads(org.id);
  return <LeadsView leads={JSON.parse(JSON.stringify(leads))} />;
}
