import { requireTenant } from '@/lib/auth/session';
import { listLeads, listTeam } from '@/lib/queries';
import LeadsView from './LeadsView';

export const dynamic = 'force-dynamic';

export default async function LeadsPage() {
  const sess = await requireTenant();
  const org = { id: sess.orgId, name: sess.orgName };
  const [leads, team] = await Promise.all([listLeads(org.id), listTeam(org.id)]);
  return <LeadsView
    leads={JSON.parse(JSON.stringify(leads))}
    team={team.map((m) => ({ userId: m.userId, name: m.name }))}
  />;
}
