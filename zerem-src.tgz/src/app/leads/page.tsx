import { currentOrg, listLeads } from '@/lib/queries';
import LeadsView from './LeadsView';

export const dynamic = 'force-dynamic';

export default async function LeadsPage() {
  const org = await currentOrg();
  const leads = await listLeads(org.id);
  return <LeadsView leads={JSON.parse(JSON.stringify(leads))} />;
}
