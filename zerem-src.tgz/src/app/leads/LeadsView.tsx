'use client';
import Link from 'next/link';
import { useState, useMemo } from 'react';
import { PageHeader, Chip, Avatar, timeAgo, Empty, LEAD_STATUS, LEAD_STATUS_ORDER, SOURCE_LABEL, SOURCE_ICON } from '@/components/ui';
import { Sheet, Field, TextInput, Choice, FormError, Actions, useSubmit } from '@/components/Sheet';
import { ils, normalizePhone } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

export default function LeadsView({ leads, team }: { leads: any[]; team: any[] }) {
  const [view, setView] = useState<'list' | 'board'>('list');
  const [addOpen, setAddOpen] = useState(false);
  const [filter, setFilter] = useState<string>('ALL');
  const [q, setQ] = useState('');

  const filtered = useMemo(() => leads.filter((l) => {
    if (filter === 'ACTIVE' && ['WON', 'LOST'].includes(l.status)) return false;
    if (filter !== 'ALL' && filter !== 'ACTIVE' && l.status !== filter) return false;
    if (!q) return true;
    const s = q.toLowerCase();
    return l.fullName.toLowerCase().includes(s) || l.phone.includes(s) || (l.email ?? '').toLowerCase().includes(s);
  }), [leads, filter, q]);

  const totalValue = filtered.reduce((a, l) => a + Number(l.value ?? 0), 0);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="לידים"
        subtitle={`${filtered.length} מתוך ${leads.length} · ${ils(totalValue)} בפייפליין`}
        actions={
          <>
            <div className="hidden rounded-xl border border-slate-200 bg-white p-0.5 lg:flex">
              {(['list', 'board'] as const).map((v) => (
                <button key={v} onClick={() => setView(v)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${view === v ? 'bg-teal-700 text-white' : 'text-slate-500'}`}>
                  {v === 'list' ? 'רשימה' : 'קנבן'}
                </button>
              ))}
            </div>
            <button onClick={() => setAddOpen(true)} className="btn btn-primary btn-sm">+ ליד</button>
          </>
        }
      />

      <div className="mb-3 flex flex-col gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} className="input"
               placeholder="חיפוש שם, טלפון או אימייל…" inputMode="search" />
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {[['ALL', 'הכל'], ['ACTIVE', 'פעילים'], ...LEAD_STATUS_ORDER.map((k) => [k, LEAD_STATUS[k].label])].map(([k, label]) => (
            <button key={k as string} onClick={() => setFilter(k as string)}
              className={`chip whitespace-nowrap px-2.5 py-1 ${filter === k ? 'bg-teal-700 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}>
              {label as string}
            </button>
          ))}
        </div>
      </div>

      {/* ── קנבן (דסקטופ) ── */}
      {view === 'board' ? (
        <div className="hidden gap-3 overflow-x-auto pb-4 lg:flex">
          {LEAD_STATUS_ORDER.map((st) => {
            const cards = filtered.filter((l) => l.status === st);
            const sum = cards.reduce((a, l) => a + Number(l.value ?? 0), 0);
            return (
              <div key={st} className="w-64 shrink-0">
                <div className="mb-2 flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5">
                    <Chip tone={LEAD_STATUS[st].tone}>{LEAD_STATUS[st].label}</Chip>
                    <span className="num text-[10px] text-slate-400">{cards.length}</span>
                  </div>
                  <span className="num text-[11px] font-semibold text-slate-500">{ils(sum)}</span>
                </div>
                <div className="space-y-2">
                  {cards.map((l) => <LeadCard key={l.id} lead={l} />)}
                  {!cards.length && <div className="rounded-xl border border-dashed border-slate-200 py-6 text-center text-[11px] text-slate-300">ריק</div>}
                </div>
              </div>
            );
          })}
        </div>
      ) : null}

      {/* ── רשימה (מובייל תמיד, דסקטופ במצב list) ── */}
      <div className={view === 'board' ? 'lg:hidden' : ''}>
        <div className="space-y-2">
          {filtered.map((l) => <LeadCard key={l.id} lead={l} wide />)}
          {!filtered.length && (
            <div className="card">
              <Empty
                icon={leads.length ? '🔍' : '👥'}
                title={leads.length ? 'לא נמצאו לידים' : 'עדיין אין לידים'}
                hint={leads.length ? 'נסה חיפוש אחר או שנה סינון' : 'לחץ על ״+ ליד״ כדי להוסיף את הראשון'}
              />
            </div>
          )}
        </div>
      </div>

      {addOpen && <NewLeadSheet team={team} onClose={() => setAddOpen(false)} />}
    </div>
  );
}

/* ═══════════ הוספת ליד ═══════════ */

function NewLeadSheet({ team, onClose }: { team: any[]; onClose: () => void }) {
  const [f, setF] = useState({
    fullName: '', phone: '', email: '', city: '',
    status: 'NEW', source: 'PHONE', estimatedValueIls: '', ownerId: '', notes: '',
  });
  const { busy, error, setError, send } = useSubmit();
  const [dupe, setDupe] = useState<string | null>(null);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setDupe(null);
    const r = await send('/api/crm/leads', 'POST', f);
    if (r.ok) {
      // ⚠️ ליד קיים אינו שגיאה — מפנים אליו במקום ליצור כפילות
      if (r.data?.duplicate) { setDupe(r.data.id); return; }
      window.location.href = `/leads/${r.data.id}`;
    }
  }

  if (dupe) {
    return (
      <Sheet title="הליד כבר קיים" subtitle="מצאנו ליד עם אותו מספר טלפון בעסק שלך." onClose={onClose}>
        <p className="text-[12px] leading-relaxed text-slate-500">
          לא יצרנו כפילות. אפשר לפתוח את הליד הקיים ולעדכן אותו.
        </p>
        <div className="mt-4 flex gap-2">
          <button onClick={onClose} className="btn btn-ghost flex-1">סגירה</button>
          <Link href={`/leads/${dupe}`} className="btn btn-primary flex-1">לליד הקיים</Link>
        </div>
      </Sheet>
    );
  }

  return (
    <Sheet title="ליד חדש" subtitle="הטלפון הוא המפתח — אם הוא כבר קיים, נפנה אותך לליד הקיים." onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <Field label="שם מלא" required>
          <TextInput value={f.fullName} onChange={(v) => set('fullName', v)} required autoFocus />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="טלפון" required hint="נייד או קווי">
            <TextInput value={f.phone} onChange={(v) => set('phone', v)} ltr type="tel" required
                       placeholder="052-1234567" />
          </Field>
          <Field label="עיר">
            <TextInput value={f.city} onChange={(v) => set('city', v)} />
          </Field>
        </div>
        <Field label="אימייל">
          <TextInput value={f.email} onChange={(v) => set('email', v)} ltr type="email" />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="שווי משוער" hint="₪, לא חובה">
            <TextInput value={f.estimatedValueIls} onChange={(v) => set('estimatedValueIls', v)}
                       ltr type="number" />
          </Field>
          <Field label="אחראי">
            <select value={f.ownerId} onChange={(e) => set('ownerId', e.target.value)} className="input">
              <option value="">אני</option>
              {team.map((m: any) => <option key={m.userId} value={m.userId}>{m.name}</option>)}
            </select>
          </Field>
        </div>
        <Field label="מקור">
          <Choice value={f.source} onChange={(v) => set('source', v)}
                  options={[['PHONE','טלפון'],['WHATSAPP','וואטסאפ'],['REFERRAL','המלצה'],['MANUAL','אחר']]} />
        </Field>
        <Field label="סטטוס">
          <Choice value={f.status} onChange={(v) => set('status', v)}
                  options={[['NEW','חדש'],['CONTACTED','נוצר קשר'],['QUALIFIED','מוסמך']]} />
        </Field>
        <Field label="הערות">
          <textarea value={f.notes} onChange={(e) => set('notes', e.target.value)}
                    rows={2} className="input resize-none" />
        </Field>
        <FormError error={error} />
        <Actions onCancel={() => { setError(null); onClose(); }} busy={busy} submitLabel="הוספת ליד" />
      </form>
    </Sheet>
  );
}

function LeadCard({ lead: l, wide }: { lead: any; wide?: boolean }) {
  const st = LEAD_STATUS[l.status];
  const p = normalizePhone(l.phone);
  return (
    <div className="card card-hover rise relative overflow-hidden p-3.5">
      <span className={`absolute inset-y-0 right-0 w-[3px] ${st.dot}`} />
      <div className="flex items-start gap-3">
        <Avatar name={l.fullName} size={wide ? 40 : 32} />
        <div className="min-w-0 flex-1">
          <Link href={`/leads/${l.id}`} className="block truncate text-sm font-bold text-slate-900">{l.fullName}</Link>
          <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
            <span className="ltr">{p.display ?? l.phone}</span>
            {l.city && <><span>·</span><span>{l.city}</span></>}
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-1">
            <Chip tone={st.tone}>{st.label}</Chip>
            <Chip>{SOURCE_ICON[l.source]} {SOURCE_LABEL[l.source] ?? l.source}</Chip>
            {l.tags?.map((t: string) => <Chip key={t} tone="violet">{t}</Chip>)}
          </div>
        </div>
        <div className="shrink-0 text-left">
          {Number(l.value) > 0 && <div className="num text-sm font-bold text-slate-800">{ils(l.value)}</div>}
          <div className="mt-0.5 text-[10px] text-slate-400">{timeAgo(l.lastContactAt)}</div>
        </div>
      </div>

      {/* פעולות בקליק אחד — זה מה שהופך את זה לשימושי בנייד */}
      <div className="mt-2.5 flex gap-1.5 border-t border-slate-100 pt-2.5">
        <a href={`tel:${l.phone}`} className="btn btn-ghost btn-sm flex-1">📞 חיוג</a>
        <a href={`https://wa.me/${l.phone.replace('+', '')}`} target="_blank" rel="noreferrer"
           className="btn btn-ghost btn-sm flex-1 !text-green-700">💬 וואטסאפ</a>
        <Link href={`/quotes/new?lead=${l.id}`} className="btn btn-ghost btn-sm flex-1">📄 הצעה</Link>
      </div>
      {l.utmCampaign && (
        <div className="mt-1.5 truncate text-[10px] text-slate-400">קמפיין: {l.utmCampaign}</div>
      )}
    </div>
  );
}
