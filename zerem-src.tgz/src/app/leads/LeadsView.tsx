'use client';
import Link from 'next/link';
import { useState, useMemo } from 'react';
import { PageHeader, Chip, Avatar, timeAgo, Empty, LEAD_STATUS, LEAD_STATUS_ORDER, SOURCE_LABEL, SOURCE_ICON } from '@/components/ui';
import { ils, normalizePhone } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

export default function LeadsView({ leads }: { leads: any[] }) {
  const [view, setView] = useState<'list' | 'board'>('list');
  const [filter, setFilter] = useState<string>('ALL');
  const [q, setQ] = useState('');

  const filtered = useMemo(() => leads.filter((l) => {
    if (filter === 'ACTIVE' && ['WON', 'LOST'].includes(l.status)) return false;
    if (filter !== 'ALL' && filter !== 'ACTIVE' && l.status !== filter) return false;
    if (!q) return true;
    const s = q.toLowerCase();
    return l.fullName.toLowerCase().includes(s) || l.phone.includes(s) || (l.email ?? '').toLowerCase().includes(s);
  }), [leads, filter, q]);

  const totalValue = filtered.reduce((a, l) => a + Number(l.value ?? 0), 0);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="לידים"
        subtitle={`${filtered.length} מתוך ${leads.length} · ${ils(totalValue)} בפייפליין`}
        actions={
          <>
            <div className="hidden rounded-xl border border-slate-200 bg-white p-0.5 lg:flex">
              {(['list', 'board'] as const).map((v) => (
                <button key={v} onClick={() => setView(v)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${view === v ? 'bg-teal-700 text-white' : 'text-slate-500'}`}>
                  {v === 'list' ? 'רשימה' : 'קנבן'}
                </button>
              ))}
            </div>
            <button className="btn btn-primary btn-sm">+ ליד</button>
          </>
        }
      />

      <div className="mb-3 flex flex-col gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} className="input"
               placeholder="חיפוש שם, טלפון או אימייל…" inputMode="search" />
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {[['ALL', 'הכל'], ['ACTIVE', 'פעילים'], ...LEAD_STATUS_ORDER.map((k) => [k, LEAD_STATUS[k].label])].map(([k, label]) => (
            <button key={k as string} onClick={() => setFilter(k as string)}
              className={`chip whitespace-nowrap px-2.5 py-1 ${filter === k ? 'bg-teal-700 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}>
              {label as string}
            </button>
          ))}
        </div>
      </div>

      {/* ── קנבן (דסקטופ) ── */}
      {view === 'board' ? (
        <div className="hidden gap-3 overflow-x-auto pb-4 lg:flex">
          {LEAD_STATUS_ORDER.map((st) => {
            const cards = filtered.filter((l) => l.status === st);
            const sum = cards.reduce((a, l) => a + Number(l.value ?? 0), 0);
            return (
              <div key={st} className="w-64 shrink-0">
                <div className="mb-2 flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5">
                    <Chip tone={LEAD_STATUS[st].tone}>{LEAD_STATUS[st].label}</Chip>
                    <span className="num text-[10px] text-slate-400">{cards.length}</span>
                  </div>
                  <span className="num text-[11px] font-semibold text-slate-500">{ils(sum)}</span>
                </div>
                <div className="space-y-2">
                  {cards.map((l) => <LeadCard key={l.id} lead={l} />)}
                  {!cards.length && <div className="rounded-xl border border-dashed border-slate-200 py-6 text-center text-[11px] text-slate-300">ריק</div>}
                </div>
              </div>
            );
          })}
        </div>
      ) : null}

      {/* ── רשימה (מובייל תמיד, דסקטופ במצב list) ── */}
      <div className={view === 'board' ? 'lg:hidden' : ''}>
        <div className="space-y-2">
          {filtered.map((l) => <LeadCard key={l.id} lead={l} wide />)}
          {!filtered.length && <div className="card"><Empty icon="🔍" title="לא נמצאו לידים" hint="נסה חיפוש אחר או שנה סינון" /></div>}
        </div>
      </div>
    </div>
  );
}

function LeadCard({ lead: l, wide }: { lead: any; wide?: boolean }) {
  const st = LEAD_STATUS[l.status];
  const p = normalizePhone(l.phone);
  return (
    <div className="card card-hover rise relative overflow-hidden p-3.5">
      <span className={`absolute inset-y-0 right-0 w-[3px] ${st.dot}`} />
      <div className="flex items-start gap-3">
        <Avatar name={l.fullName} size={wide ? 40 : 32} />
        <div className="min-w-0 flex-1">
          <Link href={`/leads/${l.id}`} className="block truncate text-sm font-bold text-slate-900">{l.fullName}</Link>
          <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
            <span className="ltr">{p.display ?? l.phone}</span>
            {l.city && <><span>·</span><span>{l.city}</span></>}
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-1">
            <Chip tone={st.tone}>{st.label}</Chip>
            <Chip>{SOURCE_ICON[l.source]} {SOURCE_LABEL[l.source] ?? l.source}</Chip>
            {l.tags?.map((t: string) => <Chip key={t} tone="violet">{t}</Chip>)}
          </div>
        </div>
        <div className="shrink-0 text-left">
          {Number(l.value) > 0 && <div className="num text-sm font-bold text-slate-800">{ils(l.value)}</div>}
          <div className="mt-0.5 text-[10px] text-slate-400">{timeAgo(l.lastContactAt)}</div>
        </div>
      </div>

      {/* פעולות בקליק אחד — זה מה שהופך את זה לשימושי בנייד */}
      <div className="mt-2.5 flex gap-1.5 border-t border-slate-100 pt-2.5">
        <a href={`tel:${l.phone}`} className="btn btn-ghost btn-sm flex-1">📞 חיוג</a>
        <a href={`https://wa.me/${l.phone.replace('+', '')}`} target="_blank" rel="noreferrer"
           className="btn btn-ghost btn-sm flex-1 !text-green-700">💬 וואטסאפ</a>
        <Link href={`/quotes/new?lead=${l.id}`} className="btn btn-ghost btn-sm flex-1">📄 הצעה</Link>
      </div>
      {l.utmCampaign && (
        <div className="mt-1.5 truncate text-[10px] text-slate-400">קמפיין: {l.utmCampaign}</div>
      )}
    </div>
  );
}
