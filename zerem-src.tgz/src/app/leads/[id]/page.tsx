import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getLead } from '@/lib/queries';
import { PageHeader, Section, Chip, Avatar, timeAgo, dueLabel,
         LEAD_STATUS, SOURCE_LABEL, QUOTE_STATUS, PAYMENT_STATUS, DOC_KIND, TASK_PRIORITY } from '@/components/ui';
import { ils, ils2, normalizePhone } from '@/lib/israel';

export const dynamic = 'force-dynamic';

export default async function LeadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const data = await getLead(id);
  if (!data) notFound();
  const { lead, owner, tasks, quotes, messages, payments, docs, activities } = data;
  const st = LEAD_STATUS[lead.status];
  const p = normalizePhone(lead.phone);
  const paidTotal = payments.filter((x) => x.status === 'PAID').reduce((a, x) => a + Number(x.amountIls), 0);

  return (
    <div className="p-4 lg:p-7">
      <div className="mb-1 text-xs text-slate-400">
        <Link href="/leads" className="hover:underline">לידים</Link> / {lead.fullName}
      </div>
      <PageHeader title={lead.fullName}
        subtitle={`${st.label} · ${SOURCE_LABEL[lead.source]} · ${owner?.name ?? 'ללא בעלים'}`} />

      {/* פעולות מהירות — הדבר הראשון שרואים בנייד */}
      <div className="mb-4 grid grid-cols-4 gap-2">
        <a href={`tel:${lead.phone}`} className="card flex flex-col items-center gap-1 py-3 text-[11px] font-bold text-slate-700">
          <span className="text-xl">📞</span>חיוג
        </a>
        <a href={`https://wa.me/${lead.phone.replace('+','')}`} target="_blank" rel="noreferrer"
           className="card flex flex-col items-center gap-1 py-3 text-[11px] font-bold text-green-700">
          <span className="text-xl">💬</span>וואטסאפ
        </a>
        <Link href={`/quotes/new?lead=${lead.id}`} className="card flex flex-col items-center gap-1 py-3 text-[11px] font-bold text-slate-700">
          <span className="text-xl">📄</span>הצעה
        </Link>
        <a href={`mailto:${lead.email ?? ''}`} className="card flex flex-col items-center gap-1 py-3 text-[11px] font-bold text-slate-700">
          <span className="text-xl">✉️</span>מייל
        </a>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4">
          <Section title="פרטים" pad>
            <div className="space-y-2.5 text-sm">
              <Row label="טלפון" value={<span className="ltr">{p.display ?? lead.phone}</span>} />
              <Row label="סוג מספר" value={p.kind === 'MOBILE' ? 'נייד' : p.kind === 'LANDLINE' ? 'קו נייח' : p.kind} />
              <Row label="אימייל" value={<span className="ltr">{lead.email ?? '—'}</span>} />
              <Row label="עיר" value={lead.city ?? '—'} />
              <Row label="ח.פ. / ת.ז." value={lead.vatId ?? '—'} />
              <Row label="שווי משוער" value={lead.estimatedValueIls ? ils(lead.estimatedValueIls) : '—'} />
              <Row label="נוצר" value={timeAgo(lead.createdAt)} />
              {lead.tags.length > 0 && (
                <div>
                  <div className="label mb-1">תגיות</div>
                  <div className="flex flex-wrap gap-1">{lead.tags.map((t) => <Chip key={t} tone="violet">{t}</Chip>)}</div>
                </div>
              )}
            </div>
          </Section>

          {(lead.utmSource || lead.landingPage) && (
            <Section title="ייחוס שיווקי" pad>
              <div className="space-y-2 text-xs">
                <Row label="מקור" value={lead.utmSource ?? '—'} />
                <Row label="מדיום" value={lead.utmMedium ?? '—'} />
                <Row label="קמפיין" value={lead.utmCampaign ?? '—'} />
                {lead.landingPage && <Row label="דף נחיתה" value={<span className="ltr break-all text-[10px]">{lead.landingPage}</span>} />}
              </div>
            </Section>
          )}

          {docs.length > 0 && (
            <Section title="מסמכים">
              <ul className="divide-y divide-slate-100">
                {docs.map((d) => (
                  <li key={d.id} className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-800">{DOC_KIND[d.kind]}</span>
                      <span className="num text-[11px] text-slate-400">#{d.documentNumber}</span>
                    </div>
                    <div className="mt-0.5 flex items-center justify-between text-[11px]">
                      <span className="num text-slate-500">{ils2(d.amountIls)}</span>
                      {d.allocationNumber && <Chip tone="green">הקצאה {d.allocationNumber}</Chip>}
                    </div>
                  </li>
                ))}
              </ul>
            </Section>
          )}
        </div>

        <div className="space-y-4 lg:col-span-2">
          {quotes.length > 0 && (
            <Section title="הצעות מחיר">
              <ul className="divide-y divide-slate-100">
                {quotes.map((q) => (
                  <li key={q.id} className="flex items-center gap-3 px-4 py-3">
                    <span className="num text-xs font-bold text-slate-400">#{q.number}</span>
                    <div className="min-w-0 flex-1">
                      <Chip tone={QUOTE_STATUS[q.status].tone}>{QUOTE_STATUS[q.status].label}</Chip>
                      <div className="mt-0.5 text-[11px] text-slate-400">
                        {q.sentAt ? `נשלחה ${timeAgo(q.sentAt)}` : 'טיוטה'}
                        {q.viewCount > 0 && ` · נצפתה ${q.viewCount}×`}
                      </div>
                    </div>
                    <span className="num text-sm font-bold">{ils2(q.totalIls)}</span>
                    <Link href={`/q/${q.publicToken}`} target="_blank" className="btn btn-ghost btn-sm">👁</Link>
                  </li>
                ))}
              </ul>
            </Section>
          )}

          {payments.length > 0 && (
            <Section title={`תשלומים · ${ils(paidTotal)} נגבה`}>
              <ul className="divide-y divide-slate-100">
                {payments.map((x) => (
                  <li key={x.id} className="flex items-center gap-3 px-4 py-2.5 text-xs">
                    <Chip tone={PAYMENT_STATUS[x.status].tone}>{PAYMENT_STATUS[x.status].label}</Chip>
                    <span className="text-slate-500">{x.provider}{x.installments > 1 && ` · ${x.installments} תשלומים`}</span>
                    <span className="num mr-auto font-bold">{ils2(x.amountIls)}</span>
                  </li>
                ))}
              </ul>
            </Section>
          )}

          <Section title="משימות">
            <ul className="divide-y divide-slate-100">
              {tasks.map((t) => {
                const due = dueLabel(t.dueAt);
                return (
                  <li key={t.id} className="flex items-center gap-2.5 px-4 py-2.5">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${t.status === 'DONE' ? 'bg-green-600' : 'bg-amber-500'}`} />
                    <span className={`flex-1 text-sm ${t.status === 'DONE' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{t.title}</span>
                    <Chip tone={TASK_PRIORITY[t.priority].tone}>{TASK_PRIORITY[t.priority].label}</Chip>
                    <Chip tone={due.tone}>{due.text}</Chip>
                  </li>
                );
              })}
              {!tasks.length && <li className="px-4 py-6 text-center text-xs text-slate-400">אין משימות</li>}
            </ul>
          </Section>

          <Section title="שיחת וואטסאפ">
            <div className="space-y-2 bg-[#e5ddd5] p-4">
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.direction === 'OUT' ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-[13px] shadow-sm ${
                    m.direction === 'OUT' ? 'bg-[#dcf8c6] text-slate-900' : 'bg-white text-slate-900'}`}>
                    <p className="whitespace-pre-wrap">{m.body}</p>
                    <div className="mt-0.5 text-left text-[9px] text-slate-400">
                      <span className="ltr">{new Date(m.sentAt).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})}</span>
                      {m.direction === 'OUT' && <span className="mr-1">{m.status === 'READ' ? '✓✓' : '✓'}</span>}
                      {m.isAutomated && <span className="mr-1 rounded bg-slate-200 px-1">אוטומטי</span>}
                    </div>
                  </div>
                </div>
              ))}
              {!messages.length && <div className="py-6 text-center text-xs text-slate-500">אין הודעות</div>}
            </div>
          </Section>

          <Section title="ציר זמן">
            <ul className="divide-y divide-slate-100">
              {activities.map((a) => (
                <li key={a.id} className="px-4 py-2.5">
                  <div className="text-[11px] leading-snug text-slate-600">{a.summary}</div>
                  <div className="mt-0.5 text-[10px] text-slate-400">{timeAgo(a.createdAt)}</div>
                </li>
              ))}
            </ul>
          </Section>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="label">{label}</span>
      <span className="text-xs font-semibold text-slate-700">{value}</span>
    </div>
  );
}
