/**
 * קליטת לידים מטפסים חיצוניים.
 * POST /api/ingest/{slug}   — אלמנטור, Gravity, WPForms, Meta Lead Ads, כל דבר.
 *
 * שלושה דברים שהופכים את זה לעמיד:
 *  1. **מיפוי שדות דינמי** — כל טופס שולח שמות אחרים. המיפוי נשמר ב-DB, לא בקוד.
 *  2. **דדופליקציה לפי טלפון מנורמל** — 050-1234567 ו-+972501234567 הם אותו אדם.
 *  3. **תמיד 200** — טופס בוורדפרס שמקבל 500 יציג שגיאה ללקוח. נכשלים בשקט ולוגים.
 */
import { NextRequest, NextResponse } from 'next/server';
import { db, schema as s } from '@/db';
import { eq, and } from 'drizzle-orm';
import { normalizePhone } from '@/lib/israel';

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const started = Date.now();
  const { slug } = await ctx.params;

  const [endpoint] = await db.select().from(s.webhookEndpoints)
    .where(and(eq(s.webhookEndpoints.slug, slug), eq(s.webhookEndpoints.active, true))).limit(1);

  if (!endpoint) {
    return NextResponse.json({ ok: false, error: 'unknown endpoint' }, { status: 404 });
  }

  // הגוף יכול להיות JSON או form-encoded — וורדפרס שולח את שניהם
  let payload: Record<string, unknown> = {};
  try {
    const ct = req.headers.get('content-type') ?? '';
    if (ct.includes('application/json')) {
      payload = await req.json();
    } else {
      const fd = await req.formData();
      fd.forEach((v, k) => { payload[k] = typeof v === 'string' ? v : v.name; });
    }
  } catch {
    payload = {};
  }

  const log = async (error?: string, status = 200) => {
    await db.insert(s.webhookLogs).values({
      orgId: endpoint.orgId, direction: 'IN', endpointId: endpoint.id,
      provider: endpoint.source, event: 'lead.ingest',
      httpStatus: status, payload, errorMessage: error, durationMs: Date.now() - started,
    });
  };

  try {
    // ── מיפוי דינמי ──
    const map = endpoint.fieldMap ?? {};
    const get = (target: string): string | undefined => {
      for (const [from, to] of Object.entries(map)) {
        if (to === target && payload[from] != null) return String(payload[from]);
      }
      // נפילה חזרה לשם השדה עצמו — נוח כשלא הוגדר מיפוי
      return payload[target] != null ? String(payload[target]) : undefined;
    };

    const rawPhone = get('phone');
    const phone = normalizePhone(rawPhone);
    if (!phone.ok) {
      await log(`טלפון לא תקין: ${rawPhone} (${phone.error})`);
      return NextResponse.json({ ok: false, reason: phone.error });  // 200 בכוונה
    }

    const fullName = get('fullName')?.trim() || 'ליד ללא שם';
    const email = get('email')?.trim() || null;

    // ── UTM וייחוס ──
    const url = new URL(req.url);
    const utm = (k: string) => (payload[k] as string) ?? url.searchParams.get(k) ?? null;

    // ── דדופליקציה ──
    const [existing] = await db.select().from(s.leads)
      .where(and(eq(s.leads.orgId, endpoint.orgId), eq(s.leads.phone, phone.e164!))).limit(1);

    let leadId: string;
    let isNew = false;

    if (existing) {
      leadId = existing.id;
      await db.update(s.leads).set({
        email: existing.email ?? email,
        notes: [existing.notes, get('notes')].filter(Boolean).join('\n---\n') || null,
        updatedAt: new Date(),
      }).where(eq(s.leads.id, leadId));

      await db.insert(s.activities).values({
        orgId: endpoint.orgId, type: 'lead.duplicate', leadId,
        summary: `פנייה חוזרת מ${endpoint.name} — אוחדה לליד קיים`,
        data: { endpoint: endpoint.slug },
      });
    } else {
      isNew = true;
      const [created] = await db.insert(s.leads).values({
        orgId: endpoint.orgId,
        fullName,
        phone: phone.e164!,
        waChatId: phone.waChatId,
        email,
        notes: get('notes') ?? null,
        city: get('city') ?? null,
        source: endpoint.source,
        ownerId: endpoint.defaultOwnerId,
        status: 'NEW',
        utmSource: utm('utm_source'),
        utmMedium: utm('utm_medium'),
        utmCampaign: utm('utm_campaign'),
        utmTerm: utm('utm_term'),
        utmContent: utm('utm_content'),
        landingPage: (payload.page_url as string) ?? (payload.landing_page as string) ?? null,
        referrer: req.headers.get('referer'),
        gclid: utm('gclid'),
        fbclid: utm('fbclid'),
        customFields: payload,
      }).returning();
      leadId = created.id;

      await db.insert(s.activities).values({
        orgId: endpoint.orgId, type: 'lead.created', leadId,
        summary: `ליד חדש נקלט מ${endpoint.name}`,
        data: { source: endpoint.source, utm: utm('utm_campaign') },
      });

      // ── משימת מעקב אוטומטית ──
      if (endpoint.autoCreateTask && endpoint.defaultOwnerId) {
        const title = (endpoint.taskTemplate ?? 'לחזור ללקוח {{full_name}}')
          .replace('{{full_name}}', fullName);
        await db.insert(s.tasks).values({
          orgId: endpoint.orgId, title, leadId,
          assigneeId: endpoint.defaultOwnerId,
          priority: 'HIGH',
          dueAt: new Date(Date.now() + 30 * 60_000),   // 30 דקות — מהירות תגובה היא הכל בלידים
        });
        await db.insert(s.notifications).values({
          orgId: endpoint.orgId, userId: endpoint.defaultOwnerId, channel: 'PUSH',
          title: 'ליד חדש 🔥', body: `${fullName} — ${phone.display}`, url: `/leads/${leadId}`,
        });
      }
    }

    await db.update(s.webhookEndpoints)
      .set({ hitCount: endpoint.hitCount + 1, lastHitAt: new Date() })
      .where(eq(s.webhookEndpoints.id, endpoint.id));

    await log();
    return NextResponse.json({ ok: true, leadId, duplicate: !isNew });
  } catch (e) {
    await log(String(e), 500);
    // עדיין 200 — לא רוצים שהטופס באתר של הלקוח יציג שגיאה
    return NextResponse.json({ ok: false });
  }
}

/** בדיקת חיים — נוח לוודא שה-endpoint חי מהדפדפן */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const [e] = await db.select({ name: s.webhookEndpoints.name, active: s.webhookEndpoints.active })
    .from(s.webhookEndpoints).where(eq(s.webhookEndpoints.slug, slug)).limit(1);
  if (!e) return NextResponse.json({ ok: false }, { status: 404 });
  return NextResponse.json({ ok: true, endpoint: e.name, active: e.active, method: 'POST' });
}
