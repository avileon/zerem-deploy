/**
 * ניהול צוות — מנהל העסק בלבד.
 *
 * ⚠️ שני דברים שנאכפים כאן ולא במסך:
 *  1. requireManager() — עובד שיקרא ל-API ישירות יקבל 403.
 *  2. orgId מגיע מהסשן ולא מגוף הבקשה — מנהל של עסק א' לא יכול
 *     להוסיף משתמש לעסק ב' גם אם ישלח את ה-orgId שלו.
 */
import { NextRequest, NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { apiManager } from '@/lib/auth/session';
import { addTeamMember, removeTeamMember, changeMemberRole, createInvitation } from '@/lib/auth/accounts';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const guard = await apiManager();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const sess = guard.session;

  const b = await req.json().catch(() => ({}));
  const action = String(b.action ?? '');
  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;

  if (action === 'add') {
    const r = await addTeamMember({
      orgId: sess.orgId,                               // ← מהסשן, לא מהבקשה
      name: String(b.name ?? '').trim(),
      email: String(b.email ?? '').trim(),
      phone: b.phone ? String(b.phone) : undefined,
      role: b.role === 'MANAGER' ? 'MANAGER' : 'EMPLOYEE',
      createdBy: `user:${sess.userId}`,
    });
    if (!r.ok) return NextResponse.json(r, { status: 400 });
    return NextResponse.json({ ok: true, inviteUrl: `${origin}/set-password?token=${r.data.inviteToken}` });
  }

  if (action === 'resend') {
    const userId = String(b.userId ?? '');
    // ⚠️ אימות שהמשתמש שייך לארגון של המבקש — אחרת אפשר לייצר
    // קישור איפוס סיסמה למשתמש של עסק אחר לפי ניחוש מזהה.
    const [member] = await db.select().from(s.memberships).where(eq(s.memberships.userId, userId)).limit(1);
    if (!member || member.orgId !== sess.orgId) {
      return NextResponse.json({ ok: false, error: 'המשתמש לא נמצא בצוות שלך' }, { status: 404 });
    }
    const [u] = await db.select().from(s.users).where(eq(s.users.id, userId)).limit(1);
    if (!u) return NextResponse.json({ ok: false, error: 'המשתמש לא נמצא' }, { status: 404 });

    const inv = await createInvitation({
      email: u.email, userId: u.id, invitedBy: `user:${sess.userId}`,
      kind: u.status === 'PENDING' ? 'SET_PASSWORD' : 'RESET_PASSWORD',
    });
    return NextResponse.json({ ok: true, inviteUrl: `${origin}/set-password?token=${inv.token}` });
  }

  if (action === 'remove') {
    const userId = String(b.userId ?? '');
    const [member] = await db.select().from(s.memberships).where(eq(s.memberships.userId, userId)).limit(1);
    if (!member || member.orgId !== sess.orgId) {
      return NextResponse.json({ ok: false, error: 'המשתמש לא נמצא בצוות שלך' }, { status: 404 });
    }
    const r = await removeTeamMember(sess.orgId, userId, sess.userId);
    return NextResponse.json(r, { status: r.ok ? 200 : 400 });
  }

  if (action === 'role') {
    const userId = String(b.userId ?? '');
    const [member] = await db.select().from(s.memberships).where(eq(s.memberships.userId, userId)).limit(1);
    if (!member || member.orgId !== sess.orgId) {
      return NextResponse.json({ ok: false, error: 'המשתמש לא נמצא בצוות שלך' }, { status: 404 });
    }
    const r = await changeMemberRole(
      sess.orgId, userId, b.role === 'MANAGER' ? 'MANAGER' : 'EMPLOYEE', sess.userId,
    );
    return NextResponse.json(r, { status: r.ok ? 200 : 400 });
  }

  return NextResponse.json({ ok: false, error: 'פעולה לא מוכרת' }, { status: 400 });
}
