/**
 * Webhook גבייה — קארדקום.
 *
 * ⚠️ קו ההגנה: לקארדקום **אין חתימת HMAC** על ה-webhook.
 * כל מי שמכיר את הכתובת יכול לשלוח {"ResponseCode":0,"ReturnValue":"sub_..."}
 * ולהפעיל מנוי בחינם. לכן:
 *   1. מהגוף לוקחים **רק** את LowProfileId — שום שדה אחר לא מהימן
 *   2. קוראים GetLpResult שרת-לשרת
 *   3. רק התשובה ההיא מזיזה כסף
 *
 * מחזירים תמיד 200 — קארדקום מנסה שוב על שגיאה, וניסיונות חוזרים
 * על באג שלנו רק מציפים את הלוג.
 */
import { NextRequest, NextResponse } from 'next/server';
import { db, schema as s } from '@/db';
import { settleLowProfile } from '@/lib/billing/service';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const started = Date.now();
  let payload: Record<string, unknown> = {};

  try {
    const ct = req.headers.get('content-type') ?? '';
    if (ct.includes('application/json')) {
      payload = await req.json();
    } else {
      const form = await req.formData();
      payload = Object.fromEntries([...form.entries()].map(([k, v]) => [k, String(v)]));
    }
  } catch {
    payload = {};
  }

  // השדה היחיד שמותר לקחת מהגוף
  const lowProfileId =
    (payload.LowProfileId as string) ??
    (payload.lowprofilecode as string) ??
    (payload.LowProfileCode as string) ??
    null;

  let result: unknown = { ignored: true };
  let error: string | null = null;

  if (lowProfileId) {
    const r = await settleLowProfile(String(lowProfileId), 'webhook:cardcom');
    result = r;
    if (!r.ok) error = r.error;
  } else {
    error = 'LowProfileId חסר בגוף הקריאה';
  }

  await db.insert(s.webhookLogs).values({
    direction: 'IN',
    provider: 'CARDCOM_BILLING',
    event: 'lowprofile.settle',
    httpStatus: 200,
    payload: payload as Record<string, unknown>,
    response: result as Record<string, unknown>,
    errorMessage: error,
    durationMs: Date.now() - started,
  }).catch(() => {});

  return NextResponse.json({ received: true });
}

/** קארדקום מוודא לפעמים שהכתובת חיה לפני שהוא שולח POST */
export async function GET() {
  return NextResponse.json({ ok: true });
}
