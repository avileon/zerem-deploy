/**
 * Webhook מ-Cardcom אחרי תשלום.
 *
 * ⚠️ ל-Cardcom אין חתימת HMAC. גוף הקריאה **אינו מהימן** — כל אחד יכול לזייף אותו.
 * הדפוס הבטוח היחיד:
 *    webhook = "צלצול" → מחלצים LowProfileId → קוראים GetLpResult שרת-לשרת
 *    → מאמינים רק לתשובה של Cardcom.
 *
 * ואז השרשרת: תשלום ✓ → הצעה ל-PAID → ליד ל-WON → חשבונית בריווחית → שליחה בוואטסאפ.
 */
import { NextRequest, NextResponse } from 'next/server';
import { db, schema as s } from '@/db';
import { eq, and } from 'drizzle-orm';
import { CardcomClient } from '@/lib/integrations/cardcom';
import { requiresAllocationNumber } from '@/lib/israel';

export async function POST(req: NextRequest) {
  const started = Date.now();
  let body: Record<string, unknown> = {};
  try { body = await req.json(); } catch { /* ייתכן form-encoded */ }

  const lowProfileId =
    (body.LowProfileId as string) ?? (body.lowProfileId as string) ??
    req.nextUrl.searchParams.get('LowProfileId') ?? undefined;

  if (!lowProfileId) {
    return NextResponse.json({ ok: true });   // תמיד 200 — לא מעודדים ניסיונות חוזרים
  }

  // מאתרים את התשלום שיצרנו כשהנפקנו את ה-PayLink
  const [payment] = await db.select().from(s.payments)
    .where(eq(s.payments.lowProfileId, lowProfileId)).limit(1);
  if (!payment) return NextResponse.json({ ok: true });

  const [integration] = await db.select().from(s.integrations)
    .where(and(eq(s.integrations.orgId, payment.orgId), eq(s.integrations.provider, 'CARDCOM'))).limit(1);

  const cfg = (integration?.config ?? {}) as { terminalNumber?: number; apiName?: string };
  const client = new CardcomClient({
    terminalNumber: cfg.terminalNumber ?? 1000,
    apiName: cfg.apiName ?? process.env.CARDCOM_API_NAME ?? 'Cardcomtest26',
  });

  // ── האימות האמיתי ──
  const result = await client.getResult(lowProfileId);

  await db.insert(s.webhookLogs).values({
    orgId: payment.orgId, direction: 'IN', provider: 'CARDCOM', event: 'payment.callback',
    payload: body, response: result as unknown as Record<string, unknown>,
    httpStatus: 200, durationMs: Date.now() - started,
  });

  if (!result.ok) {
    await db.update(s.payments).set({
      status: 'FAILED',
      errorCode: String((result as { responseCode?: number }).responseCode ?? ''),
      errorMessage: (result as { description?: string }).description ?? (result as { error?: string }).error,
    }).where(eq(s.payments.id, payment.id));
    return NextResponse.json({ ok: true });
  }

  // ── אידמפוטנטיות: אותה עסקה לא תעובד פעמיים ──
  if (payment.transactionId && payment.transactionId === result.transactionId) {
    return NextResponse.json({ ok: true, note: 'already processed' });
  }

  await db.update(s.payments).set({
    status: 'PAID',
    transactionId: result.transactionId,
    approvalNumber: result.approvalNumber,
    last4: result.last4,
    cardBrand: result.brand,
    cardToken: result.token,
    tokenExpiry: result.tokenExpiry,
    paidAt: new Date(),
    rawResponse: result.raw as unknown as Record<string, unknown>,
  }).where(eq(s.payments.id, payment.id));

  if (payment.quoteId) {
    await db.update(s.quotes).set({ status: 'PAID' }).where(eq(s.quotes.id, payment.quoteId));
  }
  if (payment.leadId) {
    await db.update(s.leads).set({ status: 'WON', wonAt: new Date(), updatedAt: new Date() })
      .where(eq(s.leads.id, payment.leadId));
  }

  await db.insert(s.activities).values({
    orgId: payment.orgId, type: 'payment.received', leadId: payment.leadId,
    summary: `תשלום התקבל — ${payment.amountIls} ₪ · אישור ${result.approvalNumber ?? '—'}`,
    data: { transactionId: result.transactionId },
  });

  /* ── כאן נכנס לתור: הנפקת חשבונית בריווחית ושליחה בוואטסאפ ──
     מסומן כ-required מראש כדי שהמשתמש יראה אם חסר ח.פ. */
  const amountExVat = Number(payment.amountIls) / 1.18;
  await db.insert(s.accountingDocs).values({
    orgId: payment.orgId, leadId: payment.leadId, quoteId: payment.quoteId, paymentId: payment.id,
    provider: 'RIVHIT', kind: 'TAX_INVOICE_RECEIPT',
    amountIls: payment.amountIls, vatIls: String((Number(payment.amountIls) - amountExVat).toFixed(2)),
    allocationRequired: requiresAllocationNumber(amountExVat),
    allocationStatus: requiresAllocationNumber(amountExVat) ? 'PENDING' : 'NOT_REQUIRED',
  }).onConflictDoNothing();   // ← ה-unique index מונע כפל הנפקה

  return NextResponse.json({ ok: true });
}

/** Cardcom לפעמים בודק את ה-URL ב-GET */
export async function GET() {
  return NextResponse.json({ ok: true });
}
