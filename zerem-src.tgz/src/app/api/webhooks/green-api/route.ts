/**
 * Webhook מ-Green API.
 * אימות: Green API שולח את webhookUrlToken בכותרת Authorization.
 * dedup לפי idMessage — ההודעות עשויות להגיע יותר מפעם אחת.
 */
import { NextRequest, NextResponse } from 'next/server';
import { db, schema as s } from '@/db';
import { eq, and } from 'drizzle-orm';
import { extractText, CRITICAL_STATES, type GreenWebhook } from '@/lib/integrations/green-api';

export async function POST(req: NextRequest) {
  const expected = process.env.GREEN_API_WEBHOOK_TOKEN;
  if (expected) {
    const got = (req.headers.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
    if (got !== expected) return NextResponse.json({ ok: false }, { status: 401 });
  }

  let hook: GreenWebhook;
  try { hook = await req.json(); } catch { return NextResponse.json({ ok: true }); }

  const [org] = await db.select().from(s.organizations).limit(1);
  if (!org) return NextResponse.json({ ok: true });

  await db.insert(s.webhookLogs).values({
    orgId: org.id, direction: 'IN', provider: 'GREEN_API',
    event: String(hook.typeWebhook), payload: hook as unknown as Record<string, unknown>, httpStatus: 200,
  });

  if (hook.typeWebhook === 'incomingMessageReceived') {
    const h = hook as Extract<GreenWebhook, { typeWebhook: 'incomingMessageReceived' }>;
    const phone = '+' + h.senderData.chatId.split('@')[0];

    const [lead] = await db.select().from(s.leads)
      .where(and(eq(s.leads.orgId, org.id), eq(s.leads.phone, phone))).limit(1);

    await db.insert(s.messages).values({
      orgId: org.id, leadId: lead?.id ?? null, channel: 'WHATSAPP', direction: 'IN',
      externalId: h.idMessage, body: extractText(h.messageData) ?? null,
      status: 'DELIVERED', sentAt: new Date(h.timestamp * 1000),
    }).onConflictDoNothing();

    if (lead) {
      await db.update(s.leads).set({ lastContactAt: new Date(), updatedAt: new Date() })
        .where(eq(s.leads.id, lead.id));
    }
  }

  if (hook.typeWebhook === 'outgoingMessageStatus') {
    const h = hook as Extract<GreenWebhook, { typeWebhook: 'outgoingMessageStatus' }>;
    const map: Record<string, 'SENT' | 'DELIVERED' | 'READ' | 'FAILED'> = {
      sent: 'SENT', delivered: 'DELIVERED', read: 'READ',
      failed: 'FAILED', noAccount: 'FAILED', notInGroup: 'FAILED', suspended: 'FAILED', yellowCard: 'FAILED',
    };
    await db.update(s.messages)
      .set({ status: map[h.status] ?? 'SENT', errorMessage: h.description ?? null })
      .where(eq(s.messages.externalId, h.idMessage));
  }

  if (hook.typeWebhook === 'stateInstanceChanged') {
    const h = hook as Extract<GreenWebhook, { typeWebhook: 'stateInstanceChanged' }>;
    const critical = CRITICAL_STATES.includes(h.stateInstance);
    await db.update(s.integrations)
      .set({ status: critical ? 'BLOCKED' : 'OK', statusMessage: h.stateInstance, lastCheckedAt: new Date() })
      .where(and(eq(s.integrations.orgId, org.id), eq(s.integrations.provider, 'GREEN_API')));

    // מספר חסום = העסק מנותק מהלקוחות. זו התראה למנהל, לא שורת לוג.
    if (critical) {
      const owners = await db.select().from(s.memberships)
        .where(and(eq(s.memberships.orgId, org.id), eq(s.memberships.role, 'MANAGER')));
      for (const o of owners) {
        await db.insert(s.notifications).values({
          orgId: org.id, userId: o.userId, channel: 'PUSH',
          title: '⚠️ חיבור וואטסאפ נותק',
          body: `מצב החיבור: ${h.stateInstance}. שליחת הודעות מושבתת.`,
          url: '/integrations',
        });
      }
    }
  }

  return NextResponse.json({ ok: true });
}
