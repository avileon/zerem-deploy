import { NextRequest, NextResponse } from 'next/server';
import { apiManager, apiTenant } from '@/lib/auth/session';
import { createProduct, updateProduct, deleteProduct } from '@/lib/crm/mutations';

export const dynamic = 'force-dynamic';

/** הקטלוג הוא הגדרת מחירים — ניהול שלו שמור למנהל. עובד רק קורא ממנו. */
export async function POST(req: NextRequest) {
  const g = await apiManager();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  const r = await createProduct(g.session.orgId, {
    name: String(b.name ?? ''),
    description: b.description ? String(b.description) : undefined,
    category: b.category ? String(b.category) : undefined,
    unitPriceIls: Number(b.unitPriceIls),
    unit: b.unit ? String(b.unit) : undefined,
    sku: b.sku ? String(b.sku) : undefined,
  });
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function PATCH(req: NextRequest) {
  const g = await apiManager();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  const id = String(b.id ?? '');
  if (!id) return NextResponse.json({ ok: false, error: 'חסר מזהה' }, { status: 400 });

  const patch: Record<string, unknown> = {};
  for (const k of ['name','description','category','unit','sku']) {
    if (b[k] !== undefined) patch[k] = String(b[k]);
  }
  if (b.unitPriceIls !== undefined) patch.unitPriceIls = Number(b.unitPriceIls);
  if (b.isActive !== undefined) patch.isActive = Boolean(b.isActive);

  const r = await updateProduct(g.session.orgId, id, patch);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function DELETE(req: NextRequest) {
  const g = await apiManager();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });
  const id = req.nextUrl.searchParams.get('id') ?? '';
  const r = await deleteProduct(g.session.orgId, id);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function GET() {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });
  return NextResponse.json({ ok: true });
}
