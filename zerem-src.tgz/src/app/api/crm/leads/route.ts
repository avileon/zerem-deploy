import { NextRequest, NextResponse } from 'next/server';
import { apiTenant } from '@/lib/auth/session';
import { createLead, updateLead } from '@/lib/crm/mutations';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  // ⚠️ orgId מהסשן. גוף הבקשה לא נשאל.
  const r = await createLead(g.session.orgId, g.session.userId, {
    fullName: String(b.fullName ?? ''),
    phone: String(b.phone ?? ''),
    email: b.email ? String(b.email) : undefined,
    city: b.city ? String(b.city) : undefined,
    companyName: b.companyName ? String(b.companyName) : undefined,
    notes: b.notes ? String(b.notes) : undefined,
    status: b.status ? String(b.status) : undefined,
    source: b.source ? String(b.source) : undefined,
    ownerId: b.ownerId ? String(b.ownerId) : undefined,
    estimatedValueIls: b.estimatedValueIls != null && b.estimatedValueIls !== ''
      ? Number(b.estimatedValueIls) : null,
    tags: Array.isArray(b.tags) ? b.tags.map(String) : undefined,
  });
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function PATCH(req: NextRequest) {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  const id = String(b.id ?? '');
  if (!id) return NextResponse.json({ ok: false, error: 'חסר מזהה' }, { status: 400 });

  const patch: Record<string, unknown> = {};
  for (const k of ['fullName','phone','email','city','companyName','notes','status','ownerId','lostReason']) {
    if (b[k] !== undefined) patch[k] = b[k] === null ? undefined : String(b[k]);
  }
  if (b.estimatedValueIls !== undefined) {
    patch.estimatedValueIls = b.estimatedValueIls === null || b.estimatedValueIls === ''
      ? null : Number(b.estimatedValueIls);
  }
  if (Array.isArray(b.tags)) patch.tags = b.tags.map(String);

  const r = await updateLead(g.session.orgId, g.session.userId, id, patch);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
