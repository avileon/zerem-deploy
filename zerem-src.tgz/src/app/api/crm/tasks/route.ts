import { NextRequest, NextResponse } from 'next/server';
import { apiTenant } from '@/lib/auth/session';
import { createTask, updateTask, deleteTask } from '@/lib/crm/mutations';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  const r = await createTask(g.session.orgId, g.session.userId, {
    title: String(b.title ?? ''),
    description: b.description ? String(b.description) : undefined,
    leadId: b.leadId ? String(b.leadId) : undefined,
    assigneeId: b.assigneeId ? String(b.assigneeId) : undefined,
    priority: b.priority ? String(b.priority) : undefined,
    dueAt: b.dueAt ? String(b.dueAt) : null,
  });
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function PATCH(req: NextRequest) {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });

  const b = await req.json().catch(() => ({}));
  const id = String(b.id ?? '');
  if (!id) return NextResponse.json({ ok: false, error: 'חסר מזהה' }, { status: 400 });

  const patch: Record<string, unknown> = {};
  for (const k of ['title','description','priority','status','assigneeId']) {
    if (b[k] !== undefined) patch[k] = b[k] === null ? null : String(b[k]);
  }
  if (b.dueAt !== undefined) patch.dueAt = b.dueAt ? String(b.dueAt) : null;

  const r = await updateTask(g.session.orgId, g.session.userId, id, patch);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}

export async function DELETE(req: NextRequest) {
  const g = await apiTenant();
  if (!g.ok) return NextResponse.json({ ok: false, error: g.error }, { status: g.status });
  const id = req.nextUrl.searchParams.get('id') ?? '';
  if (!id) return NextResponse.json({ ok: false, error: 'חסר מזהה' }, { status: 400 });
  const r = await deleteTask(g.session.orgId, id);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
