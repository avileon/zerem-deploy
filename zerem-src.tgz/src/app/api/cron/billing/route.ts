/**
 * המשימה היומית — 03:00 שעון ישראל.
 *
 * מוגן ב-CRON_SECRET. הנתיב הזה מזיז כסף; חשיפה שלו לאינטרנט הפתוח
 * מאפשרת לכל אחד להריץ מחזורי חיוב. בפרודקשן הוא נחסם גם ב-Caddy.
 *
 * dryRun=1 מריץ את כל החישובים בלי לשלוח בקשת חיוב אחת — זה
 * מה שמריצים לפני עליה לאוויר כדי לראות מה היה קורה.
 */
import { NextRequest, NextResponse } from 'next/server';
import { runBillingCycle } from '@/lib/billing/engine';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

function authorized(req: NextRequest): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return process.env.NODE_ENV !== 'production';  // בפיתוח מותר בלי
  const header = req.headers.get('authorization') ?? '';
  const bearer = header.startsWith('Bearer ') ? header.slice(7) : '';
  return bearer === secret || req.nextUrl.searchParams.get('key') === secret;
}

export async function POST(req: NextRequest) {
  if (!authorized(req)) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  const dryRun = req.nextUrl.searchParams.get('dryRun') === '1';
  const report = await runBillingCycle({ dryRun });
  return NextResponse.json(report);
}

export async function GET(req: NextRequest) {
  return POST(req);
}
