import { NextRequest, NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { previewCoupon } from '@/lib/billing/service';
import type { Interval } from '@/lib/billing/pricing';

export async function POST(req: NextRequest) {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const r = await previewCoupon(
    org.id, String(b.code ?? ''), String(b.planId ?? 'pro'),
    (b.interval === 'YEARLY' ? 'YEARLY' : 'MONTHLY') as Interval,
  );
  return NextResponse.json(r);
}
