import { NextRequest, NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { startCheckout } from '@/lib/billing/service';
import type { Interval } from '@/lib/billing/pricing';

export async function POST(req: NextRequest) {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const planId = String(body.planId ?? '');
  const interval = (body.interval === 'YEARLY' ? 'YEARLY' : 'MONTHLY') as Interval;
  const couponCode = body.couponCode ? String(body.couponCode) : undefined;

  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  const r = await startCheckout({ orgId: org.id, planId, interval, couponCode, origin });
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
