import { NextRequest, NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { startPaymentMethodUpdate } from '@/lib/billing/service';

export async function POST(req: NextRequest) {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  const r = await startPaymentMethodUpdate(org.id, origin);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
