import { NextRequest, NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { previewChange, startCheckout } from '@/lib/billing/service';
import type { Interval } from '@/lib/billing/pricing';

export async function POST(req: NextRequest) {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const planId = String(b.planId ?? '');
  const interval = (b.interval === 'YEARLY' ? 'YEARLY' : 'MONTHLY') as Interval;

  const preview = await previewChange(org.id, planId, interval);
  if ('error' in preview) return NextResponse.json(preview, { status: 400 });
  if (b.preview) return NextResponse.json(preview);

  // שדרוג עובר דרך הקופה (ייתכן שאין עדיין כרטיס שמור)
  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  const r = await startCheckout({ orgId: org.id, planId, interval, origin });
  return NextResponse.json({ ...r, preview }, { status: r.ok ? 200 : 400 });
}
