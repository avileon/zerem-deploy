import { NextRequest, NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { cancelSubscription } from '@/lib/billing/service';

export async function POST(req: NextRequest) {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const r = await cancelSubscription(org.id, b.reason ? String(b.reason) : undefined);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
