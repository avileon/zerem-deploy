import { NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { resumeSubscription } from '@/lib/billing/service';

export async function POST() {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  const r = await resumeSubscription(org.id);
  return NextResponse.json(r, { status: r.ok ? 200 : 400 });
}
