import { NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { getEntitlements } from '@/lib/billing/entitlements';

export async function GET() {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  return NextResponse.json(await getEntitlements(org.id, { fresh: true }));
}
