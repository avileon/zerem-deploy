import { NextResponse } from 'next/server';
import { currentOrg } from '@/lib/queries';
import { listInvoices } from '@/lib/billing/service';

export async function GET() {
  const org = await currentOrg();
  if (!org) return NextResponse.json({ error: 'NO_ORG' }, { status: 401 });
  return NextResponse.json({ invoices: await listInvoices(org.id) });
}
