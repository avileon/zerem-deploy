import { NextRequest, NextResponse } from 'next/server';
import { and, eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { verifyPassword } from '@/lib/auth/password';
import { createTenantSession, recordAttempt, tooManyAttempts } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const email = String(b.email ?? '').trim().toLowerCase();
  const password = String(b.password ?? '');

  if (!email || !password) {
    return NextResponse.json({ ok: false, error: 'נדרשים אימייל וסיסמה' }, { status: 400 });
  }

  if (await tooManyAttempts(email)) {
    return NextResponse.json(
      { ok: false, error: 'יותר מדי ניסיונות. נסה שוב בעוד רבע שעה.' }, { status: 429 },
    );
  }

  const [row] = await db
    .select({
      userId: s.users.id,
      passwordHash: s.users.passwordHash,
      status: s.users.status,
      orgId: s.memberships.orgId,
      active: s.memberships.active,
    })
    .from(s.users)
    .leftJoin(s.memberships, eq(s.memberships.userId, s.users.id))
    .where(eq(s.users.email, email))
    .limit(1);

  const valid = await verifyPassword(password, row?.passwordHash ?? null);

  // ⚠️ הודעת שגיאה אחידה בכוונה. "המשתמש לא קיים" מול "הסיסמה שגויה"
  // מאפשר למפות אילו כתובות רשומות במערכת.
  if (!row || !valid || !row.orgId || !row.active || row.status === 'DISABLED') {
    await recordAttempt(email, false);
    const msg = row && valid && row.status === 'PENDING'
      ? 'החשבון עדיין לא הופעל — השתמש בקישור שקיבלת לקביעת סיסמה'
      : 'אימייל או סיסמה שגויים';
    return NextResponse.json({ ok: false, error: msg }, { status: 401 });
  }

  await recordAttempt(email, true);
  await createTenantSession(row.userId, row.orgId);
  await db.update(s.users).set({ lastLoginAt: new Date() }).where(eq(s.users.id, row.userId));

  const next = typeof b.next === 'string' && b.next.startsWith('/') && !b.next.startsWith('//')
    ? b.next : '/';
  return NextResponse.json({ ok: true, redirect: next });
}
