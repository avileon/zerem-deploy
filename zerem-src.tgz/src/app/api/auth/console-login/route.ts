import { NextRequest, NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { verifyPassword } from '@/lib/auth/password';
import { createConsoleSession, recordAttempt, tooManyAttempts } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const email = String(b.email ?? '').trim().toLowerCase();
  const password = String(b.password ?? '');
  const key = `console:${email}`;

  if (await tooManyAttempts(key)) {
    return NextResponse.json({ ok: false, error: 'יותר מדי ניסיונות. נסה שוב בעוד רבע שעה.' }, { status: 429 });
  }

  const [admin] = await db.select().from(s.platformAdmins)
    .where(eq(s.platformAdmins.email, email)).limit(1);

  const valid = await verifyPassword(password, admin?.passwordHash ?? null);
  if (!admin || !valid || admin.status === 'DISABLED') {
    await recordAttempt(key, false);
    return NextResponse.json({ ok: false, error: 'אימייל או סיסמה שגויים' }, { status: 401 });
  }

  await recordAttempt(key, true);
  await createConsoleSession(admin.id);
  await db.update(s.platformAdmins).set({ lastLoginAt: new Date() })
    .where(eq(s.platformAdmins.id, admin.id));

  const next = typeof b.next === 'string' && b.next.startsWith('/console') ? b.next : '/console';
  return NextResponse.json({ ok: true, redirect: next });
}
