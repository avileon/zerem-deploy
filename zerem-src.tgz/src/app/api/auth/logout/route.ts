import { NextRequest, NextResponse } from 'next/server';
import { logout } from '@/lib/auth/session';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const kind = b.kind === 'CONSOLE' ? 'CONSOLE' : 'TENANT';
  await logout(kind);
  return NextResponse.json({ ok: true, redirect: kind === 'CONSOLE' ? '/console/login' : '/login' });
}
