import { NextRequest, NextResponse } from 'next/server';
import { consumeInvitation } from '@/lib/auth/accounts';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const token = String(b.token ?? '');
  const password = String(b.password ?? '');
  if (!token) return NextResponse.json({ ok: false, error: 'קישור חסר' }, { status: 400 });

  const r = await consumeInvitation(token, password);
  if (!r.ok) return NextResponse.json(r, { status: 400 });
  return NextResponse.json({ ok: true, redirect: r.data.redirect });
}
