import { NextRequest, NextResponse } from 'next/server';
import { apiConsole } from '@/lib/auth/session';
import { createBusiness } from '@/lib/auth/accounts';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const guard = await apiConsole();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const admin = guard.session;

  const b = await req.json().catch(() => ({}));
  const r = await createBusiness({
    businessName: String(b.businessName ?? '').trim(),
    legalName: b.legalName ? String(b.legalName) : undefined,
    vatId: b.vatId ? String(b.vatId) : undefined,
    managerName: String(b.managerName ?? '').trim(),
    managerEmail: String(b.managerEmail ?? '').trim(),
    managerPhone: b.managerPhone ? String(b.managerPhone) : undefined,
    planId: String(b.planId ?? 'pro'),
    interval: b.interval === 'YEARLY' ? 'YEARLY' : 'MONTHLY',
    mode: ['TRIAL', 'ACTIVE', 'FREE'].includes(b.mode) ? b.mode : 'TRIAL',
    trialDays: b.trialDays ? Number(b.trialDays) : undefined,
    createdBy: `admin:${admin.adminId}`,
  });

  if (!r.ok) return NextResponse.json(r, { status: 400 });

  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  return NextResponse.json({
    ok: true,
    orgId: r.data.orgId,
    // ⚠️ הקישור מוחזר פעם אחת בלבד — הוא לא נשמר בשום מקום בצורה קריאה.
    inviteUrl: `${origin}/set-password?token=${r.data.inviteToken}`,
  });
}
