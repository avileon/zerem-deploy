import { NextRequest, NextResponse } from 'next/server';
import { apiConsole } from '@/lib/auth/session';
import { addTeamMember, removeTeamMember, createInvitation } from '@/lib/auth/accounts';
import { db, schema as s } from '@/db';
import { eq } from 'drizzle-orm';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const guard = await apiConsole();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const admin = guard.session;

  const b = await req.json().catch(() => ({}));
  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  const action = String(b.action ?? 'add');

  if (action === 'add') {
    const r = await addTeamMember({
      orgId: String(b.orgId), name: String(b.name ?? '').trim(),
      email: String(b.email ?? '').trim(), phone: b.phone ? String(b.phone) : undefined,
      role: b.role === 'MANAGER' ? 'MANAGER' : 'EMPLOYEE',
      createdBy: `admin:${admin.adminId}`,
    });
    if (!r.ok) return NextResponse.json(r, { status: 400 });
    return NextResponse.json({
      ok: true, inviteUrl: `${origin}/set-password?token=${r.data.inviteToken}`,
    });
  }

  if (action === 'resend') {
    const [u] = await db.select().from(s.users).where(eq(s.users.id, String(b.userId))).limit(1);
    if (!u) return NextResponse.json({ ok: false, error: 'המשתמש לא נמצא' }, { status: 404 });
    const inv = await createInvitation({
      email: u.email, userId: u.id, invitedBy: `admin:${admin.adminId}`,
      kind: u.status === 'PENDING' ? 'SET_PASSWORD' : 'RESET_PASSWORD',
    });
    return NextResponse.json({
      ok: true, inviteUrl: `${origin}/set-password?token=${inv.token}`,
    });
  }

  if (action === 'remove') {
    const r = await removeTeamMember(String(b.orgId), String(b.userId), '');
    return NextResponse.json(r, { status: r.ok ? 200 : 400 });
  }

  return NextResponse.json({ ok: false, error: 'פעולה לא מוכרת' }, { status: 400 });
}
