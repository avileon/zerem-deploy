import { NextRequest, NextResponse } from 'next/server';
import { eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { apiConsole } from '@/lib/auth/session';
import { createInvitation } from '@/lib/auth/accounts';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const guard = await apiConsole();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const me = guard.session;

  // ⚠️ רק בעלים פותח מנהלי מערכת נוספים. בלי זה, מנהל אחד שנפרץ
  // יכול לשכפל את עצמו ולשמור גישה גם אחרי שתשבית אותו.
  if (!me.isOwner) {
    return NextResponse.json({ ok: false, error: 'רק בעלים יכול להוסיף מנהלי מערכת' }, { status: 403 });
  }

  const b = await req.json().catch(() => ({}));
  const email = String(b.email ?? '').trim().toLowerCase();
  const name = String(b.name ?? '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || !name) {
    return NextResponse.json({ ok: false, error: 'שם ואימייל תקין נדרשים' }, { status: 400 });
  }

  const [exists] = await db.select().from(s.platformAdmins)
    .where(eq(s.platformAdmins.email, email)).limit(1);
  if (exists) return NextResponse.json({ ok: false, error: 'האימייל כבר רשום' }, { status: 400 });

  const [admin] = await db.insert(s.platformAdmins)
    .values({ email, name, status: 'PENDING', isOwner: false }).returning();

  const inv = await createInvitation({
    email, adminId: admin.id, invitedBy: `admin:${me.adminId}`,
  });

  const origin = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  return NextResponse.json({
    ok: true, inviteUrl: `${origin}/console/set-password?token=${inv.token}&console=1`,
  });
}
