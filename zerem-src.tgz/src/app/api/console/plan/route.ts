import { NextRequest, NextResponse } from 'next/server';
import { and, eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { apiConsole } from '@/lib/auth/session';
import { addInterval } from '@/lib/billing/pricing';
import { invalidateEntitlements } from '@/lib/billing/entitlements';
import { PLAN_BY_ID } from '@/lib/billing/catalog';

export const dynamic = 'force-dynamic';

/**
 * שינוי חבילה ידני מהקונסולה — עוקף את מנוע הגבייה בכוונה.
 * שימושים אמיתיים: לקוח שמשלם בהעברה בנקאית, הארכת ניסיון,
 * פיצוי על תקלה. כל שינוי כזה נרשם ב-billing_events עם מזהה המנהל.
 */
export async function POST(req: NextRequest) {
  const guard = await apiConsole();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const admin = guard.session;

  const b = await req.json().catch(() => ({}));
  const orgId = String(b.orgId ?? '');
  const [sub] = await db.select().from(s.orgSubscriptions)
    .where(eq(s.orgSubscriptions.orgId, orgId)).limit(1);
  if (!sub) return NextResponse.json({ ok: false, error: 'אין מנוי' }, { status: 404 });

  const action = String(b.action ?? '');
  const now = new Date();
  const before = { planId: sub.planId, status: sub.status, periodEnd: sub.currentPeriodEnd };

  if (action === 'set_plan') {
    const planId = String(b.planId ?? '');
    if (!PLAN_BY_ID[planId]) return NextResponse.json({ ok: false, error: 'חבילה לא מוכרת' }, { status: 400 });
    const interval = b.interval === 'YEARLY' ? 'YEARLY' : 'MONTHLY';
    await db.update(s.orgSubscriptions).set({
      planId, interval,
      status: planId === 'free' ? 'FREE' : 'ACTIVE',
      currentPeriodStart: now,
      currentPeriodEnd: addInterval(now, interval, sub.billingAnchorDay),
      dunningAttempt: 0, nextRetryAt: null, cancelAtPeriodEnd: false, updatedAt: now,
    }).where(eq(s.orgSubscriptions.id, sub.id));

  } else if (action === 'extend_trial') {
    const days = Math.max(1, Math.min(365, Number(b.days ?? 14)));
    const base = sub.trialEndsAt && sub.trialEndsAt > now ? sub.trialEndsAt : now;
    const until = new Date(base.getTime() + days * 86_400_000);
    await db.update(s.orgSubscriptions).set({
      status: 'TRIALING', trialEndsAt: until, currentPeriodEnd: until, updatedAt: now,
    }).where(eq(s.orgSubscriptions.id, sub.id));

  } else if (action === 'grant_days') {
    const days = Math.max(1, Math.min(365, Number(b.days ?? 30)));
    const base = sub.currentPeriodEnd > now ? sub.currentPeriodEnd : now;
    await db.update(s.orgSubscriptions).set({
      currentPeriodEnd: new Date(base.getTime() + days * 86_400_000),
      status: sub.status === 'SUSPENDED' || sub.status === 'PAST_DUE' ? 'ACTIVE' : sub.status,
      dunningAttempt: 0, nextRetryAt: null, updatedAt: now,
    }).where(eq(s.orgSubscriptions.id, sub.id));

  } else if (action === 'suspend') {
    await db.update(s.orgSubscriptions).set({ status: 'SUSPENDED', updatedAt: now })
      .where(eq(s.orgSubscriptions.id, sub.id));

  } else if (action === 'reactivate') {
    await db.update(s.orgSubscriptions).set({
      status: 'ACTIVE', dunningAttempt: 0, nextRetryAt: null, updatedAt: now,
    }).where(eq(s.orgSubscriptions.id, sub.id));

  } else {
    return NextResponse.json({ ok: false, error: 'פעולה לא מוכרת' }, { status: 400 });
  }

  await db.insert(s.billingEvents).values({
    orgId, subscriptionId: sub.id, type: `admin.${action}`,
    payload: { before, requested: b }, actor: `admin:${admin.adminId}`,
  });
  invalidateEntitlements(orgId);

  return NextResponse.json({ ok: true });
}
