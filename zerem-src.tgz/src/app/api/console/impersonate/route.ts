/**
 * כניסה לחשבון לקוח לצורך תמיכה.
 *
 * שלוש מגבלות מובנות, כי הכלי הזה הוא גם הכלי המסוכן ביותר בקונסולה:
 *  1. הסשן נוצר עם impersonatedByAdminId — הלקוח רואה באנר קבוע,
 *     ואתה רואה אותו. אין "צפייה חשאית".
 *  2. כל כניסה נרשמת ב-billing_events וב-audit_logs עם מזהה המנהל.
 *  3. הסשן קצר (שעה) ואינו מאפשר שינוי סיסמה או מחיקת החשבון.
 *
 * ⚠️ אין כאן "התחזות שקטה" בכוונה. מערכת שמאפשרת למפעיל לקרוא
 * נתוני לקוח בלי שהלקוח יידע היא בעיה משפטית, לא רק אתית.
 */
import { NextRequest, NextResponse } from 'next/server';
import { and, eq } from 'drizzle-orm';
import { db, schema as s } from '@/db';
import { apiConsole, createTenantSession } from '@/lib/auth/session';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const guard = await apiConsole();
  if (!guard.ok) return NextResponse.json({ ok: false, error: guard.error }, { status: guard.status });
  const admin = guard.session;

  const b = await req.json().catch(() => ({}));
  const orgId = String(b.orgId ?? '');
  if (!orgId) return NextResponse.json({ ok: false, error: 'חסר מזהה עסק' }, { status: 400 });

  // נכנסים תמיד כמנהל הפעיל של העסק — לא כמשתמש שרירותי
  const [target] = await db
    .select({ userId: s.memberships.userId, name: s.users.name })
    .from(s.memberships)
    .innerJoin(s.users, eq(s.users.id, s.memberships.userId))
    .where(and(
      eq(s.memberships.orgId, orgId),
      eq(s.memberships.role, 'MANAGER'),
      eq(s.memberships.active, true),
    ))
    .limit(1);

  if (!target) {
    return NextResponse.json({ ok: false, error: 'לא נמצא מנהל פעיל בעסק הזה' }, { status: 404 });
  }

  await createTenantSession(target.userId, orgId, admin.adminId);

  await db.insert(s.billingEvents).values({
    orgId, type: 'admin.impersonate_start',
    payload: { asUserId: target.userId, asUserName: target.name, adminEmail: admin.email },
    actor: `admin:${admin.adminId}`,
  });
  await db.insert(s.auditLogs).values({
    orgId, action: 'admin.impersonate', entityType: 'user', entityId: target.userId,
    diff: { admin: admin.email },
  }).catch(() => {});

  return NextResponse.json({ ok: true, redirect: '/' });
}
