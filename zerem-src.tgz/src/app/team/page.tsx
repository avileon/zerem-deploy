import { listTeam, teamPerformance } from '@/lib/queries';
import { requireManager } from '@/lib/auth/session';
import { getEntitlements } from '@/lib/billing/entitlements';
import TeamView from './TeamView';

export const dynamic = 'force-dynamic';

/**
 * ⚠️ requireManager() כאן היא בקרת הגישה.
 * הסתרת הפריט בתפריט היא נוחות בלבד — עובד שיקליד /team ידנית
 * יופנה לדשבורד מכאן, לא מה-UI.
 */
export default async function TeamPage() {
  const sess = await requireManager();
  const [team, perf, ent] = await Promise.all([
    listTeam(sess.orgId),
    teamPerformance(sess.orgId),
    getEntitlements(sess.orgId, { fresh: true }),
  ]);

  const seats = ent.features['users'];

  return (
    <TeamView
      me={{ userId: sess.userId, name: sess.userName }}
      team={team.map((m) => ({
        ...m,
        target: m.target ? Number(m.target) : null,
        lastLoginAt: m.lastLoginAt ? m.lastLoginAt.toISOString() : null,
      }))}
      perf={JSON.parse(JSON.stringify(perf))}
      seats={{ used: seats?.used ?? 0, limit: seats?.limit ?? null }}
      planName={ent.planName}
    />
  );
}
