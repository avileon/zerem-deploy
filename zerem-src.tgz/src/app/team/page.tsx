import { currentOrg, listTeam, teamPerformance } from '@/lib/queries';
import { PageHeader, Section, Chip, Avatar, Progress, ROLE_LABEL } from '@/components/ui';
import { ils, num } from '@/lib/israel';

export const dynamic = 'force-dynamic';

const PERMS: Record<string, string[]> = {
  OWNER: ['גישה מלאה', 'ניהול צוות', 'הגדרות API', 'נתונים פיננסיים', 'מחיקת נתונים'],
  ADMIN: ['ניהול צוות', 'כל הלידים', 'הגדרות API', 'דוחות'],
  SALES_REP: ['הלידים שלי', 'המשימות שלי', 'הצעות מחיר', 'גביית תשלום'],
  VIEWER: ['צפייה בלבד'],
};

export default async function TeamPage() {
  const org = await currentOrg();
  const [team, perf] = await Promise.all([listTeam(org.id), teamPerformance(org.id)]);

  return (
    <div className="p-4 lg:p-7">
      <PageHeader title="צוות והרשאות" subtitle={`${team.length} משתמשים · RBAC`}
        actions={<button className="btn btn-primary btn-sm">+ הזמן</button>} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="חברי צוות">
          <ul className="divide-y divide-slate-100">
            {team.map((m) => {
              const l = perf.leadsPer.find((x) => x.userId === m.userId);
              const t = perf.tasksPer.find((x) => x.userId === m.userId);
              const wonValue = Number(l?.wonValue ?? 0);
              const target = Number(m.target ?? 0);
              return (
                <li key={m.userId} className="px-4 py-3">
                  <div className="flex items-start gap-3">
                    <Avatar name={m.name} size={40} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">{m.name}</span>
                        <Chip tone={m.role === 'OWNER' ? 'violet' : m.role === 'ADMIN' ? 'teal' : 'sky'}>{ROLE_LABEL[m.role]}</Chip>
                      </div>
                      <div className="ltr mt-0.5 text-[11px] text-slate-400">{m.email}</div>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {PERMS[m.role].map((p) => <Chip key={p}>{p}</Chip>)}
                      </div>
                      {target > 0 && (
                        <div className="mt-2">
                          <div className="mb-1 flex justify-between text-[11px]">
                            <span className="text-slate-500">יעד חודשי</span>
                            <span className="num text-slate-700">{ils(wonValue)} / {ils(target)}</span>
                          </div>
                          <Progress value={wonValue} max={target} tone={wonValue >= target ? 'green' : 'teal'} />
                        </div>
                      )}
                    </div>
                    <div className="shrink-0 text-left text-[10px] text-slate-400">
                      <div className="num text-sm font-bold text-slate-700">{Number(l?.total ?? 0)}</div>
                      <div>לידים</div>
                      {Number(t?.overdue ?? 0) > 0 && (
                        <div className="mt-1 font-bold text-rose-600">{Number(t?.overdue)} באיחור</div>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </Section>

        <Section title="מטריצת הרשאות" pad>
          <table className="w-full text-xs">
            <thead>
              <tr className="text-slate-400">
                <th className="pb-2 text-right font-bold">יכולת</th>
                {['OWNER','ADMIN','SALES_REP','VIEWER'].map((r) => (
                  <th key={r} className="pb-2 text-center font-bold">{ROLE_LABEL[r]}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[
                ['צפייה בלידים שלי', 1,1,1,1],
                ['צפייה בכל הלידים', 1,1,0,1],
                ['יצירת הצעת מחיר', 1,1,1,0],
                ['גביית תשלום', 1,1,1,0],
                ['הנפקת חשבונית', 1,1,1,0],
                ['האצלת משימות', 1,1,1,0],
                ['ניהול צוות', 1,1,0,0],
                ['הגדרות אינטגרציה', 1,1,0,0],
                ['נתונים פיננסיים', 1,1,0,0],
                ['מחיקת נתונים', 1,0,0,0],
              ].map((row) => (
                <tr key={row[0] as string}>
                  <td className="py-1.5 text-slate-700">{row[0]}</td>
                  {row.slice(1).map((v, i) => (
                    <td key={i} className="py-1.5 text-center">
                      {v ? <span className="text-green-600">✓</span> : <span className="text-slate-200">—</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </Section>
      </div>
    </div>
  );
}
