'use client';
import Link from 'next/link';
import { useState } from 'react';
import { PageHeader, Section, Chip, Avatar, Progress, Empty, timeAgo } from '@/components/ui';
import { ils } from '@/lib/israel';

/* eslint-disable @typescript-eslint/no-explicit-any */

const PERMS = {
  MANAGER: ['כל הלידים והמשימות', 'ניהול צוות', 'חיוב ומנוי', 'אינטגרציות', 'דוחות'],
  EMPLOYEE: ['הלידים שלו', 'המשימות שלו', 'הצעות מחיר', 'גביית תשלום'],
} as const;

const USER_STATUS: Record<string, { label: string; tone: string }> = {
  PENDING: { label: 'טרם הפעיל', tone: 'sky' },
  ACTIVE: { label: 'פעיל', tone: 'green' },
  DISABLED: { label: 'מושבת', tone: 'rose' },
};

export default function TeamView({ me, team, perf, seats, planName }: {
  me: { userId: string; name: string };
  team: any[]; perf: any; seats: { used: number; limit: number | null }; planName: string;
}) {
  const [addOpen, setAddOpen] = useState(false);
  const [invite, setInvite] = useState<{ url: string; who: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const full = seats.limit !== null && seats.used >= seats.limit;

  async function act(body: unknown, key: string) {
    setBusy(key); setMsg(null);
    const r = await fetch('/api/team', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(null);
    if (!r.ok) setMsg(r.error);
    return r;
  }

  async function resend(userId: string, name: string, pending: boolean) {
    const r = await act({ action: 'resend', userId }, `r${userId}`);
    if (r.ok) setInvite({ url: r.inviteUrl, who: name });
    void pending;
  }

  async function remove(userId: string, name: string) {
    if (!confirm(`להסיר את ${name} מהצוות? הוא יתנתק מיד מכל המכשירים. הנתונים שלו נשמרים.`)) return;
    const r = await act({ action: 'remove', userId }, `x${userId}`);
    if (r.ok) location.reload();
  }

  return (
    <div className="p-4 lg:p-7">
      <PageHeader
        title="צוות"
        subtitle={`${seats.used}${seats.limit ? ` מתוך ${seats.limit}` : ''} משתמשים · חבילת ${planName}`}
        actions={
          <button onClick={() => setAddOpen(true)} disabled={full}
                  className={`btn btn-sm ${full ? 'btn-ghost' : 'btn-primary'}`}>
            + עובד
          </button>
        }
      />

      {msg && <div className="mb-3 rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{msg}</div>}

      {/* ── מכסת מושבים ── */}
      {seats.limit !== null && (
        <div className={`mb-4 rounded-2xl p-4 ${full ? 'bg-amber-50' : 'bg-slate-50'}`}>
          <div className="mb-1.5 flex items-baseline justify-between">
            <span className="text-[12px] font-bold text-slate-700">מושבים בחבילה</span>
            <span className="num text-[12px] text-slate-500">{seats.used} / {seats.limit}</span>
          </div>
          <Progress value={seats.used} max={seats.limit} tone={full ? 'rose' : seats.used / seats.limit > 0.7 ? 'amber' : 'teal'} />
          {full && (
            <div className="mt-2 flex flex-col gap-2 lg:flex-row lg:items-center">
              <div className="flex-1 text-[11px] text-amber-900">
                אין מקום למשתמש נוסף. אפשר לשדרג חבילה או להוסיף מושב בודד.
              </div>
              <Link href="/settings/billing" className="btn btn-primary btn-sm">שדרוג</Link>
            </div>
          )}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="חברי צוות" icon="👥">
          {team.length === 0 ? (
            <Empty icon="👥" title="אתה לבד כאן" hint="הוסף עובד כדי לחלק לידים ומשימות" />
          ) : (
            <div className="space-y-2">
              {team.map((m) => {
                const l = perf.leadsPer.find((x: any) => x.userId === m.userId);
                const t = perf.tasksPer.find((x: any) => x.userId === m.userId);
                const wonValue = Number(l?.wonValue ?? 0);
                const target = Number(m.target ?? 0);
                const us = USER_STATUS[m.status] ?? USER_STATUS.PENDING;
                const isMe = m.userId === me.userId;

                return (
                  <div key={m.userId} className="rounded-xl border border-slate-100 p-3">
                    <div className="flex items-start gap-3">
                      <Avatar name={m.name} size={36} />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[13px] font-bold text-slate-800">{m.name}</span>
                          <Chip tone={m.role === 'MANAGER' ? 'violet' : 'sky'}>
                            {m.role === 'MANAGER' ? 'מנהל' : 'עובד'}
                          </Chip>
                          <Chip tone={us.tone}>{us.label}</Chip>
                          {isMe && <Chip tone="teal">זה אתה</Chip>}
                        </div>
                        <div className="ltr mt-0.5 text-[10px] text-slate-400">{m.email}</div>
                        <div className="mt-1 text-[10px] text-slate-400">
                          {m.lastLoginAt ? `נכנס ${timeAgo(m.lastLoginAt)}` : 'טרם נכנס למערכת'}
                          {l && ` · ${l.total} לידים`}
                          {t && Number(t.open) > 0 && ` · ${t.open} משימות פתוחות`}
                        </div>
                      </div>
                    </div>

                    {target > 0 && (
                      <div className="mt-2.5">
                        <div className="mb-1 flex items-baseline justify-between text-[10px]">
                          <span className="text-slate-500">יעד חודשי</span>
                          <span className="num text-slate-600">{ils(wonValue)} / {ils(target)}</span>
                        </div>
                        <Progress value={wonValue} max={target} tone="teal" />
                      </div>
                    )}

                    {!isMe && (
                      <div className="mt-2.5 flex gap-1.5 border-t border-slate-50 pt-2.5">
                        <button onClick={() => resend(m.userId, m.name, m.status === 'PENDING')}
                                disabled={busy === `r${m.userId}`} className="btn btn-ghost btn-sm flex-1">
                          {busy === `r${m.userId}` ? '…' : m.status === 'PENDING' ? 'קישור הפעלה' : 'איפוס סיסמה'}
                        </button>
                        <button onClick={() => remove(m.userId, m.name)}
                                disabled={busy === `x${m.userId}`} className="btn btn-ghost btn-sm !text-rose-600">
                          הסרה
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Section>

        <div>
          <Section title="מה כל תפקיד רואה" icon="🔐">
            <div className="space-y-3">
              {(['MANAGER', 'EMPLOYEE'] as const).map((r) => (
                <div key={r} className="rounded-xl border border-slate-100 p-3">
                  <Chip tone={r === 'MANAGER' ? 'violet' : 'sky'}>
                    {r === 'MANAGER' ? 'מנהל' : 'עובד'}
                  </Chip>
                  <ul className="mt-2 space-y-1">
                    {PERMS[r].map((perm) => (
                      <li key={perm} className="flex items-start gap-1.5 text-[12px] text-slate-600">
                        <span className="mt-[2px] text-teal-600">✓</span>{perm}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-xl bg-slate-50 p-3 text-[10px] leading-relaxed text-slate-500">
              פתיחת עסקים, שינוי חבילות וגישה ללקוחות אחרים אינם תפקיד כאן —
              הם שייכים לצוות הפלטפורמה בלבד.
            </div>
          </Section>
        </div>
      </div>

      {addOpen && <AddSheet onClose={() => setAddOpen(false)}
                            onDone={(url, who) => { setAddOpen(false); setInvite({ url, who }); }} />}
      {invite && <InviteSheet invite={invite} onClose={() => { setInvite(null); location.reload(); }} />}
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-black/40 lg:items-center lg:justify-center" onClick={onClose}>
      <div className="safe-b w-full rounded-t-3xl bg-white p-5 lg:max-w-sm lg:rounded-3xl"
           onClick={(e) => e.stopPropagation()}>
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-slate-200 lg:hidden" />
        {children}
      </div>
    </div>
  );
}

function AddSheet({ onClose, onDone }: { onClose: () => void; onDone: (url: string, who: string) => void }) {
  const [f, setF] = useState({ name: '', email: '', phone: '', role: 'EMPLOYEE' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(null); setBusy(true);
    const r = await fetch('/api/team', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add', ...f }),
    }).then((x) => x.json()).catch(() => ({ ok: false, error: 'שגיאת רשת' }));
    setBusy(false);
    if (r.ok) onDone(r.inviteUrl, f.name);
    else setError(r.error);
  }

  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-bold text-slate-900">הוספת עובד</h3>
      <p className="mt-1 text-[12px] text-slate-500">
        תקבל קישור לשליחה. העובד קובע סיסמה בעצמו — אתה לא רואה אותה.
      </p>
      <form onSubmit={submit} className="mt-4 space-y-3">
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">שם מלא</span>
          <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required className="input" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">אימייל</span>
          <input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })}
                 required type="email" dir="ltr" className="input ltr" />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold text-slate-500">טלפון (לא חובה)</span>
          <input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })}
                 dir="ltr" className="input ltr" />
        </label>
        <div>
          <span className="mb-1 block text-[11px] font-bold text-slate-500">תפקיד</span>
          <div className="flex gap-1.5">
            {[['EMPLOYEE', 'עובד'], ['MANAGER', 'מנהל']].map(([k, l]) => (
              <button key={k} type="button" onClick={() => setF({ ...f, role: k })}
                className={`chip flex-1 justify-center px-2 py-1.5 ${
                  f.role === k ? 'bg-teal-700 text-white' : 'border border-slate-200 bg-white text-slate-600'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>
        {error && <div className="rounded-xl bg-rose-50 px-3 py-2 text-[12px] font-semibold text-rose-700">{error}</div>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn btn-ghost flex-1">ביטול</button>
          <button type="submit" disabled={busy} className="btn btn-primary flex-1">
            {busy ? 'מוסיף…' : 'הוספה'}
          </button>
        </div>
      </form>
    </Sheet>
  );
}

function InviteSheet({ invite, onClose }: { invite: { url: string; who: string }; onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  return (
    <Sheet onClose={onClose}>
      <h3 className="text-base font-bold text-slate-900">קישור עבור {invite.who}</h3>
      <div className="mt-3 rounded-xl bg-amber-50 p-3 text-[10px] leading-relaxed text-amber-800">
        ⚠️ הקישור מוצג פעם אחת בלבד ותקף 72 שעות. סגירה בלי העתקה מחייבת
        יצירת קישור חדש.
      </div>
      <div className="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-2.5">
        <div className="ltr break-all text-[10px] text-slate-600">{invite.url}</div>
      </div>
      <div className="mt-3 flex gap-2">
        <button onClick={() => { navigator.clipboard.writeText(invite.url); setCopied(true); }}
                className="btn btn-primary flex-1">{copied ? '✓ הועתק' : 'העתקה'}</button>
        <a href={`https://wa.me/?text=${encodeURIComponent(`הוספתי אותך לזרם. לקביעת סיסמה: ${invite.url}`)}`}
           target="_blank" rel="noreferrer" className="btn btn-ghost flex-1 !text-green-700">וואטסאפ</a>
      </div>
      <button onClick={onClose} className="btn btn-ghost mt-2 w-full">סגירה</button>
    </Sheet>
  );
}
