#!/bin/bash
# מחזור החיוב היומי — נקרא מ-/etc/cron.d/zerem-billing.
# הקריאה היא ל-localhost בתוך הקונטיינר: הנתיב לא נחשף לאינטרנט.
# משתמשים ב-node fetch ולא ב-wget/curl — התמונה של האפליקציה
# מבוססת node:alpine ואין בה wget. זה הפיל את הגרסה הראשונה.
set -euo pipefail
SECRET=$(grep '^CRON_SECRET=' /opt/zerem/.env | cut -d= -f2-)
docker exec -e U="http://localhost:3000/api/cron/billing" -e A="Bearer $SECRET" zerem-app \
  node -e 'fetch(process.env.U,{method:"POST",headers:{Authorization:process.env.A}})
    .then(r=>r.text()).then(t=>console.log(new Date().toISOString(),t))
    .catch(e=>console.log(new Date().toISOString(),"ERR",String(e)))'
