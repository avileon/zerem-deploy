#!/bin/sh
set -e
echo "→ ממתין ל-PostgreSQL…"
until pg_isready -h "${PGHOST:-db}" -U "${PGUSER:-postgres}" -q; do sleep 1; done
echo "→ מסנכרן סכמה…"
npx drizzle-kit push --force
SEEDED=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM organizations" 2>/dev/null || echo 0)
if [ "$SEEDED" = "0" ]; then echo "→ טוען נתוני דמו…"; npx tsx src/db/seed.ts; else echo "✓ נתונים קיימים"; fi
echo "→ זורע קטלוג גבייה…"
npx tsx src/db/seed-billing.ts || echo "⚠ זריעת הגבייה נכשלה — ממשיכים"
exec "$@"
