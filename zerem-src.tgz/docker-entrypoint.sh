#!/bin/sh
set -e
echo "→ ממתין ל-PostgreSQL…"
until pg_isready -h "${PGHOST:-db}" -U "${PGUSER:-postgres}" -q; do sleep 1; done
# ⚠️ המיגרציה חייבת לרוץ לפני ה-push: drizzle לא יודע להסיר ערכים
# מ-enum שנמצא בשימוש, וייכשל על שינוי התפקידים.
echo "→ מיגרציית אימות (לפני סנכרון)…"
npx tsx src/db/migrate-auth.ts || echo "⚠ מיגרציה נכשלה — ממשיכים"
echo "→ מסנכרן סכמה…"
npx drizzle-kit push --force
SEEDED=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM organizations" 2>/dev/null || echo 0)
if [ "$SEEDED" = "0" ]; then echo "→ טוען נתוני דמו…"; npx tsx src/db/seed.ts; else echo "✓ נתונים קיימים"; fi
echo "→ זורע קטלוג גבייה…"
npx tsx src/db/seed-billing.ts || echo "⚠ זריעת הגבייה נכשלה — ממשיכים"
echo "→ זורע אימות…"
npx tsx src/db/seed-auth.ts || echo "⚠ זריעת האימות נכשלה — ממשיכים"
exec "$@"
