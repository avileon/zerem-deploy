#!/bin/sh
set -e

echo "→ ממתין ל-PostgreSQL…"
until pg_isready -h "${PGHOST:-db}" -U "${PGUSER:-postgres}" -q; do sleep 1; done

# ⚠️ מיגרציית התפקידים חייבת לרוץ לפני המיגרציות הרגילות —
# היא ממירה enum ישן, ו-drizzle לא יודע לעשות את זה.
echo "→ מיגרציית אימות…"
npx tsx src/db/migrate-auth.ts || echo "⚠ מיגרציית אימות נכשלה — ממשיכים"

# ⚠️ מיגרציות, לא `push --force`.
# push משווה סכמות ומייצר DDL בזמן ריצה — הוא מוחק עמודות ששמן השתנה
# ואת הנתונים שבהן. כאן: קבצי SQL מגורסאות שרצים פעם אחת לפי הסדר.
# כישלון כאן עוצר את האתחול בכוונה.
echo "→ מיגרציות סכמה…"
npx tsx src/db/migrate.ts

# ── זריעה: רק בבסיס נתונים ריק. לעולם לא דורסת נתונים קיימים.
SEEDED=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM organizations" 2>/dev/null || echo 0)
if [ "$SEEDED" = "0" ]; then
  echo "→ בסיס נתונים ריק — טוען נתוני דמו…"
  npx tsx src/db/seed.ts || echo "⚠ זריעת דמו נכשלה"
else
  echo "✓ נתונים קיימים ($SEEDED ארגונים) — מדלג על זריעת דמו"
fi

# הקטלוג והאימות אידמפוטנטיים — בטוח להריץ בכל עליה
echo "→ מסנכרן קטלוג חבילות…"
npx tsx src/db/seed-billing.ts || echo "⚠ סנכרון קטלוג נכשל — ממשיכים"
echo "→ מוודא מנהל-על…"
npx tsx src/db/seed-auth.ts || echo "⚠ זריעת אימות נכשלה — ממשיכים"

exec "$@"
