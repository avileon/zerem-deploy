CREATE TYPE "public"."billing_interval" AS ENUM('MONTHLY', 'YEARLY');--> statement-breakpoint
CREATE TYPE "public"."billing_invoice_status" AS ENUM('DRAFT', 'OPEN', 'PAID', 'ZERO_RATED', 'FAILED', 'REFUNDED', 'VOID');--> statement-breakpoint
CREATE TYPE "public"."channel" AS ENUM('WHATSAPP', 'SMS', 'EMAIL', 'CALL', 'SYSTEM');--> statement-breakpoint
CREATE TYPE "public"."coupon_duration" AS ENUM('ONCE', 'REPEATING', 'FOREVER');--> statement-breakpoint
CREATE TYPE "public"."coupon_type" AS ENUM('PERCENT', 'FIXED', 'FREE_PERIODS', 'TRIAL_EXTEND');--> statement-breakpoint
CREATE TYPE "public"."doc_kind" AS ENUM('QUOTE', 'PROFORMA', 'TAX_INVOICE', 'RECEIPT', 'TAX_INVOICE_RECEIPT', 'CREDIT_NOTE');--> statement-breakpoint
CREATE TYPE "public"."doc_provider" AS ENUM('RIVHIT', 'CARDCOM', 'MANUAL');--> statement-breakpoint
CREATE TYPE "public"."invite_kind" AS ENUM('SET_PASSWORD', 'RESET_PASSWORD');--> statement-breakpoint
CREATE TYPE "public"."invoice_line_kind" AS ENUM('PLAN', 'ADDON', 'PRORATION', 'DISCOUNT', 'CREDIT');--> statement-breakpoint
CREATE TYPE "public"."lead_source" AS ENUM('WORDPRESS', 'META_LEAD_ADS', 'MANUAL', 'WHATSAPP', 'PHONE', 'REFERRAL', 'API', 'IMPORT');--> statement-breakpoint
CREATE TYPE "public"."lead_status" AS ENUM('NEW', 'CONTACTED', 'QUALIFIED', 'QUOTED', 'NEGOTIATION', 'WON', 'LOST');--> statement-breakpoint
CREATE TYPE "public"."msg_direction" AS ENUM('IN', 'OUT');--> statement-breakpoint
CREATE TYPE "public"."msg_status" AS ENUM('QUEUED', 'SENT', 'DELIVERED', 'READ', 'FAILED');--> statement-breakpoint
CREATE TYPE "public"."notif_channel" AS ENUM('PUSH', 'WHATSAPP', 'EMAIL', 'IN_APP');--> statement-breakpoint
CREATE TYPE "public"."payment_provider" AS ENUM('CARDCOM', 'ICREDIT', 'MANUAL', 'BANK_TRANSFER', 'BIT');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('PENDING', 'AUTHORIZED', 'PAID', 'FAILED', 'REFUNDED', 'CHARGEBACK');--> statement-breakpoint
CREATE TYPE "public"."pm_status" AS ENUM('VALID', 'EXPIRING', 'INVALID');--> statement-breakpoint
CREATE TYPE "public"."quote_status" AS ENUM('DRAFT', 'SENT', 'VIEWED', 'SIGNED', 'REJECTED', 'EXPIRED', 'PAID');--> statement-breakpoint
CREATE TYPE "public"."role" AS ENUM('MANAGER', 'EMPLOYEE');--> statement-breakpoint
CREATE TYPE "public"."session_kind" AS ENUM('TENANT', 'CONSOLE');--> statement-breakpoint
CREATE TYPE "public"."sub_item_kind" AS ENUM('PLAN', 'ADDON');--> statement-breakpoint
CREATE TYPE "public"."sub_status" AS ENUM('TRIALING', 'FREE', 'ACTIVE', 'PAST_DUE', 'CANCELING', 'SUSPENDED', 'CLOSED');--> statement-breakpoint
CREATE TYPE "public"."task_priority" AS ENUM('LOW', 'NORMAL', 'HIGH', 'URGENT');--> statement-breakpoint
CREATE TYPE "public"."task_status" AS ENUM('OPEN', 'IN_PROGRESS', 'DONE', 'CANCELLED');--> statement-breakpoint
CREATE TYPE "public"."user_status" AS ENUM('PENDING', 'ACTIVE', 'DISABLED');--> statement-breakpoint
CREATE TYPE "public"."webhook_dir" AS ENUM('IN', 'OUT');--> statement-breakpoint
CREATE TABLE "accounting_docs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"lead_id" uuid,
	"quote_id" uuid,
	"payment_id" uuid,
	"provider" "doc_provider" DEFAULT 'RIVHIT' NOT NULL,
	"kind" "doc_kind" NOT NULL,
	"external_type_code" integer,
	"document_number" varchar(32),
	"document_identity" varchar(64),
	"document_url" text,
	"amount_ils" numeric(12, 2) NOT NULL,
	"vat_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"allocation_number" varchar(32),
	"allocation_required" boolean DEFAULT false NOT NULL,
	"allocation_status" varchar(24),
	"allocation_error" text,
	"sent_to_customer_at" timestamp with time zone,
	"issued_at" timestamp with time zone DEFAULT now() NOT NULL,
	"raw_response" jsonb
);
--> statement-breakpoint
CREATE TABLE "activities" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"type" varchar(48) NOT NULL,
	"actor_id" uuid,
	"lead_id" uuid,
	"entity_type" varchar(32),
	"entity_id" uuid,
	"summary" text NOT NULL,
	"data" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"actor_id" uuid,
	"action" varchar(64) NOT NULL,
	"entity_type" varchar(32),
	"entity_id" uuid,
	"ip" varchar(45),
	"diff" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "billing_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid,
	"subscription_id" uuid,
	"type" varchar(48) NOT NULL,
	"payload" jsonb NOT NULL,
	"actor" varchar(64),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "billing_invoice_lines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"invoice_id" uuid NOT NULL,
	"description" text NOT NULL,
	"quantity" numeric(10, 2) DEFAULT '1' NOT NULL,
	"unit_ex_vat" numeric(12, 2) NOT NULL,
	"amount_ex_vat" numeric(12, 2) NOT NULL,
	"kind" "invoice_line_kind" DEFAULT 'PLAN' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "billing_invoices" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"subscription_id" uuid,
	"seq" integer DEFAULT 0 NOT NULL,
	"period_start" timestamp with time zone NOT NULL,
	"period_end" timestamp with time zone NOT NULL,
	"subtotal_ex_vat" numeric(12, 2) NOT NULL,
	"discount_ex_vat" numeric(12, 2) DEFAULT '0' NOT NULL,
	"vat_rate" numeric(5, 4) NOT NULL,
	"vat_amount" numeric(12, 2) NOT NULL,
	"total_inc_vat" numeric(12, 2) NOT NULL,
	"currency" varchar(3) DEFAULT 'ILS' NOT NULL,
	"status" "billing_invoice_status" DEFAULT 'OPEN' NOT NULL,
	"paid_at" timestamp with time zone,
	"cardcom_tran_id" varchar(32),
	"cardcom_doc_number" varchar(32),
	"cardcom_doc_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "billing_payment_methods" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"provider" "payment_provider" DEFAULT 'CARDCOM' NOT NULL,
	"token" text NOT NULL,
	"last4" varchar(4),
	"brand" varchar(24),
	"exp_month" integer,
	"exp_year" integer,
	"holder_name" text,
	"is_default" boolean DEFAULT true NOT NULL,
	"status" "pm_status" DEFAULT 'VALID' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "charge_attempts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"invoice_id" uuid NOT NULL,
	"attempt_no" integer DEFAULT 1 NOT NULL,
	"external_uniq_id" varchar(80) NOT NULL,
	"request_sent_at" timestamp with time zone DEFAULT now() NOT NULL,
	"response_code" integer,
	"response_text" text,
	"cardcom_tran_id" varchar(32),
	"succeeded" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "coupon_redemptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"coupon_id" uuid NOT NULL,
	"org_id" uuid NOT NULL,
	"subscription_id" uuid,
	"redeemed_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "coupons" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" varchar(40) NOT NULL,
	"type" "coupon_type" NOT NULL,
	"value" numeric(12, 2) NOT NULL,
	"duration" "coupon_duration" DEFAULT 'ONCE' NOT NULL,
	"duration_cycles" integer,
	"valid_from" timestamp with time zone,
	"valid_until" timestamp with time zone,
	"max_redemptions" integer,
	"redemption_count" integer DEFAULT 0 NOT NULL,
	"max_per_org" integer DEFAULT 1 NOT NULL,
	"applies_to_plans" jsonb,
	"applies_to_interval" "billing_interval",
	"first_time_only" boolean DEFAULT false NOT NULL,
	"min_amount_ex_vat" numeric(12, 2),
	"campaign" varchar(64),
	"note" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "integrations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"provider" varchar(32) NOT NULL,
	"enabled" boolean DEFAULT false NOT NULL,
	"credentials_enc" text,
	"config" jsonb,
	"status" varchar(32),
	"status_message" text,
	"last_checked_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "invitations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"kind" "invite_kind" DEFAULT 'SET_PASSWORD' NOT NULL,
	"token_hash" varchar(64) NOT NULL,
	"user_id" uuid,
	"admin_id" uuid,
	"email" text NOT NULL,
	"invited_by" text,
	"used_at" timestamp with time zone,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "leads" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"full_name" text NOT NULL,
	"phone" varchar(20) NOT NULL,
	"wa_chat_id" varchar(40),
	"email" text,
	"company_name" text,
	"vat_id" varchar(20),
	"address" text,
	"city" varchar(64),
	"notes" text,
	"status" "lead_status" DEFAULT 'NEW' NOT NULL,
	"source" "lead_source" DEFAULT 'MANUAL' NOT NULL,
	"owner_id" uuid,
	"tags" text[] DEFAULT '{}' NOT NULL,
	"estimated_value_ils" numeric(12, 2),
	"lost_reason" text,
	"utm_source" varchar(120),
	"utm_medium" varchar(120),
	"utm_campaign" varchar(200),
	"utm_term" varchar(200),
	"utm_content" varchar(200),
	"landing_page" text,
	"referrer" text,
	"gclid" varchar(200),
	"fbclid" varchar(200),
	"custom_fields" jsonb,
	"last_contact_at" timestamp with time zone,
	"won_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "login_attempts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"identifier" varchar(160) NOT NULL,
	"succeeded" boolean DEFAULT false NOT NULL,
	"ip" varchar(45),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "memberships" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"role" "role" DEFAULT 'EMPLOYEE' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"monthly_target_ils" numeric(12, 2)
);
--> statement-breakpoint
CREATE TABLE "message_templates" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"name" text NOT NULL,
	"body" text NOT NULL,
	"shortcut" varchar(24),
	"category" varchar(40),
	"use_count" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "messages" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"lead_id" uuid,
	"channel" "channel" DEFAULT 'WHATSAPP' NOT NULL,
	"direction" "msg_direction" NOT NULL,
	"external_id" varchar(64),
	"body" text,
	"media_url" text,
	"media_type" varchar(32),
	"status" "msg_status" DEFAULT 'QUEUED' NOT NULL,
	"error_message" text,
	"template_id" uuid,
	"author_id" uuid,
	"is_automated" boolean DEFAULT false NOT NULL,
	"sent_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"channel" "notif_channel" DEFAULT 'IN_APP' NOT NULL,
	"title" text NOT NULL,
	"body" text,
	"url" text,
	"read_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "org_subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"plan_id" varchar(32) NOT NULL,
	"interval" "billing_interval" DEFAULT 'MONTHLY' NOT NULL,
	"status" "sub_status" DEFAULT 'TRIALING' NOT NULL,
	"current_period_start" timestamp with time zone DEFAULT now() NOT NULL,
	"current_period_end" timestamp with time zone NOT NULL,
	"trial_ends_at" timestamp with time zone,
	"cancel_at_period_end" boolean DEFAULT false NOT NULL,
	"canceled_at" timestamp with time zone,
	"cancel_reason" text,
	"payment_method_id" uuid,
	"coupon_id" uuid,
	"coupon_cycles_left" integer,
	"dunning_attempt" integer DEFAULT 0 NOT NULL,
	"next_retry_at" timestamp with time zone,
	"billing_anchor_day" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "organizations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"slug" varchar(64) NOT NULL,
	"legal_name" text,
	"vat_id" varchar(20),
	"address" text,
	"city" varchar(64),
	"phone" varchar(20),
	"email" text,
	"logo_url" text,
	"brand_color" varchar(9) DEFAULT '#2563eb',
	"timezone" varchar(40) DEFAULT 'Asia/Jerusalem' NOT NULL,
	"currency" varchar(3) DEFAULT 'ILS' NOT NULL,
	"quote_valid_days" integer DEFAULT 14 NOT NULL,
	"quote_terms" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "organizations_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "otp_codes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"quote_id" uuid,
	"destination" varchar(64) NOT NULL,
	"code_hash" varchar(64) NOT NULL,
	"attempts" integer DEFAULT 0 NOT NULL,
	"consumed_at" timestamp with time zone,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "outgoing_webhooks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"name" text NOT NULL,
	"url" text NOT NULL,
	"secret" varchar(64) NOT NULL,
	"events" text[] DEFAULT '{}' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"failure_count" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"lead_id" uuid,
	"quote_id" uuid,
	"provider" "payment_provider" DEFAULT 'CARDCOM' NOT NULL,
	"status" "payment_status" DEFAULT 'PENDING' NOT NULL,
	"amount_ils" numeric(12, 2) NOT NULL,
	"installments" integer DEFAULT 1 NOT NULL,
	"low_profile_id" varchar(64),
	"pay_link_url" text,
	"transaction_id" varchar(64),
	"approval_number" varchar(32),
	"last4" varchar(4),
	"card_brand" varchar(24),
	"return_value" varchar(64),
	"card_token" varchar(64),
	"token_expiry" varchar(8),
	"error_code" varchar(16),
	"error_message" text,
	"raw_response" jsonb,
	"paid_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plan_entitlements" (
	"plan_id" varchar(32) NOT NULL,
	"feature_key" varchar(40) NOT NULL,
	"limit_value" integer,
	"is_enabled" boolean DEFAULT true NOT NULL,
	CONSTRAINT "plan_entitlements_plan_id_feature_key_pk" PRIMARY KEY("plan_id","feature_key")
);
--> statement-breakpoint
CREATE TABLE "plan_prices" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"plan_id" varchar(32) NOT NULL,
	"interval" "billing_interval" NOT NULL,
	"amount_ex_vat" numeric(12, 2) NOT NULL,
	"currency" varchar(3) DEFAULT 'ILS' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE "plans" (
	"id" varchar(32) PRIMARY KEY NOT NULL,
	"name_he" text NOT NULL,
	"tagline" text,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_public" boolean DEFAULT true NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "platform_admins" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"name" text NOT NULL,
	"password_hash" text,
	"status" "user_status" DEFAULT 'PENDING' NOT NULL,
	"is_owner" boolean DEFAULT false NOT NULL,
	"last_login_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "platform_admins_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"sku" varchar(64),
	"name" text NOT NULL,
	"description" text,
	"unit" varchar(24) DEFAULT 'יח׳' NOT NULL,
	"unit_price_ils" numeric(12, 2) NOT NULL,
	"cost_ils" numeric(12, 2),
	"vat_exempt" boolean DEFAULT false NOT NULL,
	"category" varchar(80),
	"active" boolean DEFAULT true NOT NULL,
	"external_id" varchar(64),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"endpoint" text NOT NULL,
	"p256dh" text NOT NULL,
	"auth" text NOT NULL,
	"user_agent" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "quote_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"quote_id" uuid NOT NULL,
	"product_id" uuid,
	"name" text NOT NULL,
	"description" text,
	"unit" varchar(24) DEFAULT 'יח׳' NOT NULL,
	"quantity" numeric(12, 3) DEFAULT '1' NOT NULL,
	"unit_price_ils" numeric(12, 2) NOT NULL,
	"discount_percent" numeric(5, 2) DEFAULT '0' NOT NULL,
	"vat_exempt" boolean DEFAULT false NOT NULL,
	"line_total_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "quote_signatures" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"quote_id" uuid NOT NULL,
	"signer_name" text NOT NULL,
	"signer_phone" varchar(20),
	"signer_email" text,
	"signature_image" text NOT NULL,
	"document_sha256" varchar(64) NOT NULL,
	"document_snapshot" jsonb NOT NULL,
	"otp_verified" boolean DEFAULT false NOT NULL,
	"otp_channel" "channel",
	"otp_verified_at" timestamp with time zone,
	"ip_address" varchar(45),
	"user_agent" text,
	"signed_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "quotes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"lead_id" uuid NOT NULL,
	"created_by_id" uuid,
	"number" integer NOT NULL,
	"title" text,
	"status" "quote_status" DEFAULT 'DRAFT' NOT NULL,
	"public_token" varchar(48) NOT NULL,
	"subtotal_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"discount_type" varchar(8) DEFAULT 'PERCENT' NOT NULL,
	"discount_value" numeric(12, 2) DEFAULT '0' NOT NULL,
	"discount_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"vat_rate" numeric(5, 4) DEFAULT '0.18' NOT NULL,
	"vat_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"total_ils" numeric(12, 2) DEFAULT '0' NOT NULL,
	"valid_until" timestamp with time zone,
	"notes" text,
	"terms" text,
	"sent_at" timestamp with time zone,
	"first_viewed_at" timestamp with time zone,
	"view_count" integer DEFAULT 0 NOT NULL,
	"signed_at" timestamp with time zone,
	"rejected_at" timestamp with time zone,
	"rejection_reason" text,
	"pdf_url" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "quotes_public_token_unique" UNIQUE("public_token")
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"kind" "session_kind" NOT NULL,
	"token_hash" varchar(64) NOT NULL,
	"user_id" uuid,
	"org_id" uuid,
	"admin_id" uuid,
	"impersonated_by_admin_id" uuid,
	"ip" varchar(45),
	"user_agent" text,
	"expires_at" timestamp with time zone NOT NULL,
	"revoked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subscription_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"subscription_id" uuid NOT NULL,
	"kind" "sub_item_kind" NOT NULL,
	"addon_key" varchar(40),
	"quantity" integer DEFAULT 1 NOT NULL,
	"unit_ex_vat" numeric(12, 2) NOT NULL,
	"added_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"lead_id" uuid NOT NULL,
	"name" text NOT NULL,
	"amount_ils" numeric(12, 2) NOT NULL,
	"interval_months" integer DEFAULT 1 NOT NULL,
	"card_token" varchar(64) NOT NULL,
	"token_expiry" varchar(8),
	"next_charge_at" timestamp with time zone NOT NULL,
	"last_charge_at" timestamp with time zone,
	"failure_count" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_assignments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"task_id" uuid NOT NULL,
	"from_user_id" uuid,
	"to_user_id" uuid NOT NULL,
	"by_user_id" uuid,
	"note" text,
	"notified_push" boolean DEFAULT false NOT NULL,
	"notified_whatsapp" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tasks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"title" text NOT NULL,
	"description" text,
	"status" "task_status" DEFAULT 'OPEN' NOT NULL,
	"priority" "task_priority" DEFAULT 'NORMAL' NOT NULL,
	"due_at" timestamp with time zone,
	"remind_at" timestamp with time zone,
	"reminded_at" timestamp with time zone,
	"lead_id" uuid,
	"assignee_id" uuid,
	"created_by_id" uuid,
	"board_order" integer DEFAULT 0 NOT NULL,
	"completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "usage_counters" (
	"org_id" uuid NOT NULL,
	"feature_key" varchar(40) NOT NULL,
	"period_start" varchar(10) NOT NULL,
	"used" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "usage_counters_org_id_feature_key_period_start_pk" PRIMARY KEY("org_id","feature_key","period_start")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"phone" varchar(20),
	"name" text NOT NULL,
	"avatar_url" text,
	"password_hash" text,
	"status" "user_status" DEFAULT 'PENDING' NOT NULL,
	"last_login_at" timestamp with time zone,
	"last_seen_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "vat_rates" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"rate" numeric(5, 4) NOT NULL,
	"effective_from" timestamp with time zone NOT NULL,
	"note" text
);
--> statement-breakpoint
CREATE TABLE "webhook_endpoints" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"name" text NOT NULL,
	"slug" varchar(48) NOT NULL,
	"secret" varchar(64) NOT NULL,
	"source" "lead_source" DEFAULT 'WORDPRESS' NOT NULL,
	"field_map" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"default_owner_id" uuid,
	"auto_create_task" boolean DEFAULT true NOT NULL,
	"task_template" text DEFAULT 'לחזור ללקוח {{full_name}}',
	"active" boolean DEFAULT true NOT NULL,
	"hit_count" integer DEFAULT 0 NOT NULL,
	"last_hit_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "webhook_endpoints_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "webhook_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid,
	"direction" "webhook_dir" NOT NULL,
	"endpoint_id" uuid,
	"provider" varchar(32),
	"event" varchar(64),
	"http_status" integer,
	"payload" jsonb,
	"response" jsonb,
	"error_message" text,
	"duration_ms" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "accounting_docs" ADD CONSTRAINT "accounting_docs_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "accounting_docs" ADD CONSTRAINT "accounting_docs_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "accounting_docs" ADD CONSTRAINT "accounting_docs_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "accounting_docs" ADD CONSTRAINT "accounting_docs_payment_id_payments_id_fk" FOREIGN KEY ("payment_id") REFERENCES "public"."payments"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activities" ADD CONSTRAINT "activities_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activities" ADD CONSTRAINT "activities_actor_id_users_id_fk" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activities" ADD CONSTRAINT "activities_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_actor_id_users_id_fk" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_events" ADD CONSTRAINT "billing_events_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_invoice_lines" ADD CONSTRAINT "billing_invoice_lines_invoice_id_billing_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."billing_invoices"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_invoices" ADD CONSTRAINT "billing_invoices_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_invoices" ADD CONSTRAINT "billing_invoices_subscription_id_org_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."org_subscriptions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "billing_payment_methods" ADD CONSTRAINT "billing_payment_methods_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "charge_attempts" ADD CONSTRAINT "charge_attempts_invoice_id_billing_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."billing_invoices"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_coupon_id_coupons_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_redemptions" ADD CONSTRAINT "coupon_redemptions_subscription_id_org_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."org_subscriptions"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "integrations" ADD CONSTRAINT "integrations_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_admin_id_platform_admins_id_fk" FOREIGN KEY ("admin_id") REFERENCES "public"."platform_admins"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leads" ADD CONSTRAINT "leads_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leads" ADD CONSTRAINT "leads_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "memberships" ADD CONSTRAINT "memberships_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "memberships" ADD CONSTRAINT "memberships_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "message_templates" ADD CONSTRAINT "message_templates_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "messages" ADD CONSTRAINT "messages_author_id_users_id_fk" FOREIGN KEY ("author_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "org_subscriptions" ADD CONSTRAINT "org_subscriptions_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "org_subscriptions" ADD CONSTRAINT "org_subscriptions_plan_id_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "otp_codes" ADD CONSTRAINT "otp_codes_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "otp_codes" ADD CONSTRAINT "otp_codes_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "outgoing_webhooks" ADD CONSTRAINT "outgoing_webhooks_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plan_entitlements" ADD CONSTRAINT "plan_entitlements_plan_id_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."plans"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "plan_prices" ADD CONSTRAINT "plan_prices_plan_id_plans_id_fk" FOREIGN KEY ("plan_id") REFERENCES "public"."plans"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "products" ADD CONSTRAINT "products_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD CONSTRAINT "push_subscriptions_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD CONSTRAINT "push_subscriptions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_signatures" ADD CONSTRAINT "quote_signatures_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_signatures" ADD CONSTRAINT "quote_signatures_quote_id_quotes_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quotes"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quotes" ADD CONSTRAINT "quotes_created_by_id_users_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_admin_id_platform_admins_id_fk" FOREIGN KEY ("admin_id") REFERENCES "public"."platform_admins"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_impersonated_by_admin_id_platform_admins_id_fk" FOREIGN KEY ("impersonated_by_admin_id") REFERENCES "public"."platform_admins"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscription_items" ADD CONSTRAINT "subscription_items_subscription_id_org_subscriptions_id_fk" FOREIGN KEY ("subscription_id") REFERENCES "public"."org_subscriptions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscriptions" ADD CONSTRAINT "subscriptions_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_assignments" ADD CONSTRAINT "task_assignments_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_assignments" ADD CONSTRAINT "task_assignments_task_id_tasks_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."tasks"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_assignments" ADD CONSTRAINT "task_assignments_from_user_id_users_id_fk" FOREIGN KEY ("from_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_assignments" ADD CONSTRAINT "task_assignments_to_user_id_users_id_fk" FOREIGN KEY ("to_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_assignments" ADD CONSTRAINT "task_assignments_by_user_id_users_id_fk" FOREIGN KEY ("by_user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_lead_id_leads_id_fk" FOREIGN KEY ("lead_id") REFERENCES "public"."leads"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_assignee_id_users_id_fk" FOREIGN KEY ("assignee_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "tasks" ADD CONSTRAINT "tasks_created_by_id_users_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "usage_counters" ADD CONSTRAINT "usage_counters_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_endpoints" ADD CONSTRAINT "webhook_endpoints_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_endpoints" ADD CONSTRAINT "webhook_endpoints_default_owner_id_users_id_fk" FOREIGN KEY ("default_owner_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "webhook_logs" ADD CONSTRAINT "webhook_logs_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "doc_lead_idx" ON "accounting_docs" USING btree ("lead_id");--> statement-breakpoint
CREATE UNIQUE INDEX "doc_payment_kind_uq" ON "accounting_docs" USING btree ("org_id","payment_id","kind");--> statement-breakpoint
CREATE INDEX "activity_lead_idx" ON "activities" USING btree ("org_id","lead_id","created_at");--> statement-breakpoint
CREATE INDEX "be_org_time_idx" ON "billing_events" USING btree ("org_id","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "inv_sub_period_uq" ON "billing_invoices" USING btree ("subscription_id","period_start");--> statement-breakpoint
CREATE INDEX "inv_org_idx" ON "billing_invoices" USING btree ("org_id","created_at");--> statement-breakpoint
CREATE INDEX "pm_org_idx" ON "billing_payment_methods" USING btree ("org_id","is_default");--> statement-breakpoint
CREATE UNIQUE INDEX "charge_uniq_uq" ON "charge_attempts" USING btree ("external_uniq_id");--> statement-breakpoint
CREATE UNIQUE INDEX "coupon_org_uq" ON "coupon_redemptions" USING btree ("coupon_id","org_id");--> statement-breakpoint
CREATE UNIQUE INDEX "coupon_code_uq" ON "coupons" USING btree ("code");--> statement-breakpoint
CREATE UNIQUE INDEX "integration_org_provider_uq" ON "integrations" USING btree ("org_id","provider");--> statement-breakpoint
CREATE UNIQUE INDEX "invite_token_uq" ON "invitations" USING btree ("token_hash");--> statement-breakpoint
CREATE UNIQUE INDEX "lead_org_phone_uq" ON "leads" USING btree ("org_id","phone");--> statement-breakpoint
CREATE INDEX "lead_board_idx" ON "leads" USING btree ("org_id","status","owner_id");--> statement-breakpoint
CREATE INDEX "lead_owner_idx" ON "leads" USING btree ("org_id","owner_id","updated_at");--> statement-breakpoint
CREATE INDEX "lead_email_idx" ON "leads" USING btree ("org_id","email");--> statement-breakpoint
CREATE INDEX "login_attempt_idx" ON "login_attempts" USING btree ("identifier","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "membership_org_user_uq" ON "memberships" USING btree ("org_id","user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "message_external_uq" ON "messages" USING btree ("org_id","external_id");--> statement-breakpoint
CREATE INDEX "message_lead_idx" ON "messages" USING btree ("lead_id","sent_at");--> statement-breakpoint
CREATE INDEX "notification_user_idx" ON "notifications" USING btree ("user_id","read_at","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "sub_org_live_uq" ON "org_subscriptions" USING btree ("org_id");--> statement-breakpoint
CREATE INDEX "sub_due_idx" ON "org_subscriptions" USING btree ("status","current_period_end");--> statement-breakpoint
CREATE INDEX "sub_retry_idx" ON "org_subscriptions" USING btree ("status","next_retry_at");--> statement-breakpoint
CREATE INDEX "otp_lookup_idx" ON "otp_codes" USING btree ("destination","expires_at");--> statement-breakpoint
CREATE UNIQUE INDEX "payment_txn_uq" ON "payments" USING btree ("org_id","transaction_id");--> statement-breakpoint
CREATE INDEX "payment_quote_idx" ON "payments" USING btree ("quote_id");--> statement-breakpoint
CREATE INDEX "payment_status_idx" ON "payments" USING btree ("org_id","status","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "plan_price_uq" ON "plan_prices" USING btree ("plan_id","interval");--> statement-breakpoint
CREATE INDEX "product_org_idx" ON "products" USING btree ("org_id","active");--> statement-breakpoint
CREATE UNIQUE INDEX "product_org_sku_uq" ON "products" USING btree ("org_id","sku");--> statement-breakpoint
CREATE UNIQUE INDEX "push_endpoint_uq" ON "push_subscriptions" USING btree ("endpoint");--> statement-breakpoint
CREATE INDEX "quote_item_idx" ON "quote_items" USING btree ("quote_id","sort_order");--> statement-breakpoint
CREATE UNIQUE INDEX "quote_signature_uq" ON "quote_signatures" USING btree ("quote_id");--> statement-breakpoint
CREATE UNIQUE INDEX "quote_org_number_uq" ON "quotes" USING btree ("org_id","number");--> statement-breakpoint
CREATE INDEX "quote_lead_idx" ON "quotes" USING btree ("lead_id");--> statement-breakpoint
CREATE INDEX "quote_status_idx" ON "quotes" USING btree ("org_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX "session_token_uq" ON "sessions" USING btree ("token_hash");--> statement-breakpoint
CREATE INDEX "session_user_idx" ON "sessions" USING btree ("user_id","expires_at");--> statement-breakpoint
CREATE INDEX "sub_item_sub_idx" ON "subscription_items" USING btree ("subscription_id");--> statement-breakpoint
CREATE INDEX "subscription_due_idx" ON "subscriptions" USING btree ("active","next_charge_at");--> statement-breakpoint
CREATE INDEX "task_assign_idx" ON "task_assignments" USING btree ("task_id","created_at");--> statement-breakpoint
CREATE INDEX "task_assignee_idx" ON "tasks" USING btree ("org_id","assignee_id","status","due_at");--> statement-breakpoint
CREATE INDEX "task_lead_idx" ON "tasks" USING btree ("lead_id");--> statement-breakpoint
CREATE INDEX "task_due_idx" ON "tasks" USING btree ("org_id","status","due_at");--> statement-breakpoint
CREATE INDEX "webhook_log_idx" ON "webhook_logs" USING btree ("org_id","created_at");