# זרם CRM — ארכיטקטורה

מענה ישיר לשתי הבקשות שבסוף ה-PRD: **סכמת בסיס הנתונים** ו**מבנה התיקיות**.
בנוסף — התיקונים שה-PRD פספס, בסעיף 5.

---

## 1. סכמת PostgreSQL — 25 טבלאות

### 1.1 מפת יחסים

```
organizations ─┬─ memberships ── users ── push_subscriptions
               │
               ├─ leads ─┬─ tasks ── task_assignments
               │         ├─ quotes ─┬─ quote_items ── products
               │         │          ├─ quote_signatures ── otp_codes
               │         │          └─ payments ── subscriptions
               │         ├─ messages ── message_templates
               │         ├─ accounting_docs   (payments → מסמך)
               │         └─ activities
               │
               ├─ integrations            (GREEN_API · CARDCOM · RIVHIT · FCM)
               ├─ webhook_endpoints       (קליטה נכנסת, מיפוי שדות)
               ├─ outgoing_webhooks       (Make · Zapier · Sheets)
               ├─ webhook_logs
               ├─ notifications
               └─ audit_logs

vat_rates   (גלובלי — לא שייך לארגון)
```

### 1.2 הטבלאות לפי תחום

| תחום | טבלאות |
|---|---|
| **דיירות והרשאות** | `organizations` · `users` · `memberships` · `push_subscriptions` |
| **CRM** | `leads` · `tasks` · `task_assignments` · `activities` |
| **מכירות** | `products` · `quotes` · `quote_items` · `quote_signatures` · `otp_codes` |
| **כסף** | `payments` · `subscriptions` · `accounting_docs` |
| **תקשורת** | `messages` · `message_templates` · `notifications` |
| **אינטגרציות** | `integrations` · `webhook_endpoints` · `outgoing_webhooks` · `webhook_logs` |
| **ציות** | `audit_logs` · `vat_rates` |

### 1.3 שבע החלטות התכן שמחזיקות את המערכת

**① `orgId` בכל טבלה עסקית + Row-Level Security**
```sql
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant ON leads USING (org_id = current_setting('app.org_id')::uuid);
-- בכל בקשה:  SET LOCAL app.org_id = '<uuid>';
```
בידוד בשכבת ה-DB, לא רק בקוד. באג ב-ORM לא חושף נתונים של דייר אחר.

**② הטלפון הוא מפתח הדדופליקציה**
```sql
CREATE UNIQUE INDEX lead_org_phone_uq ON leads (org_id, phone);
```
הטלפון נשמר **E.164 מנורמל בלבד**. `050-1234567`, `+972501234567`, `972-50-1234567`
כולם → `+972501234567`. בלי הנרמול, אותו לקוח ייווצר 3 פעמים מ-3 טפסים.
מימוש: `normalizePhone()` ב-`src/lib/israel.ts`.

**③ שיעור המע״מ נשמר על המסמך**
```sql
quotes.vat_rate numeric(5,4) NOT NULL   -- 0.1800
```
לא קבוע בקוד ולא נשלף בזמן צפייה. הצעה מדצמבר שהופכת לחשבונית בינואר חוצה
שינוי חוק — הסכום חייב להישאר כפי שהוצג ללקוח. טבלת `vat_rates` נותנת את
השיעור **לפי תאריך**.

**④ שורות ההצעה מנותקות מהקטלוג**
`quote_items` מעתיקה `name` / `unitPriceIls` מהמוצר ולא מקשרת אליו לוגית.
עדכון מחיר בקטלוג לא משנה הצעה שכבר נשלחה ללקוח.

**⑤ אידמפוטנטיות על כסף**
```sql
CREATE UNIQUE INDEX payment_txn_uq ON payments (org_id, transaction_id);
CREATE UNIQUE INDEX doc_payment_kind_uq ON accounting_docs (org_id, payment_id, kind);
```
הראשון: webhook שמגיע פעמיים לא יוצר שני תשלומים.
השני: מונע **כפל הנפקת חשבונית** — הבאג הקלאסי בשילוב Cardcom+ריווחית, וזו בעיית מס.

**⑥ החתימה היא ראיה, לא תמונה**
`quote_signatures` שומרת: ציור + `document_sha256` + `document_snapshot` (JSON מוקפא)
+ `otp_verified` + IP + User-Agent + חותמת זמן שרת.
זה מה שמעביר את החתימה מ"רגילה" ל"מאובטחת" לפי §3 לחוק חתימה אלקטרונית — בלי עלות של תעודות CA.

**⑦ ה-CRM אינו מנפיק חשבוניות**
`accounting_docs` **רושמת** מה שריווחית/Cardcom הנפיקו — `documentNumber`,
`documentUrl`, `allocationNumber`. הנפקה עצמאית של חשבונית מס אינה חוקית
ללא מערכת מאושרת. ה-CRM מייצר רק **הצעות מחיר** (לא מוסדרות).

### 1.4 אינדקסים קריטיים
```sql
CREATE UNIQUE INDEX lead_org_phone_uq       ON leads (org_id, phone);
CREATE UNIQUE INDEX payment_txn_uq          ON payments (org_id, transaction_id);
CREATE UNIQUE INDEX doc_payment_kind_uq     ON accounting_docs (org_id, payment_id, kind);
CREATE UNIQUE INDEX message_external_uq     ON messages (org_id, external_id);
CREATE UNIQUE INDEX quote_org_number_uq     ON quotes (org_id, number);
CREATE INDEX lead_board_idx    ON leads (org_id, status, owner_id);
CREATE INDEX task_assignee_idx ON tasks (org_id, assignee_id, status, due_at);
CREATE INDEX task_due_idx      ON tasks (org_id, status, due_at);
CREATE INDEX activity_lead_idx ON activities (org_id, lead_id, created_at DESC);
```

---

## 2. מבנה התיקיות

```
zerem/
├── public/
│   ├── manifest.webmanifest      # PWA — display:standalone, dir:rtl, shortcuts
│   ├── sw.js                     # Service Worker: network-first + Web Push
│   └── icon-{192,512,maskable}.png
│
├── drizzle/                      # מיגרציות שנוצרות אוטומטית
│
├── src/
│   ├── app/
│   │   ├── layout.tsx            # RTL, viewport-fit=cover, manifest
│   │   ├── globals.css           # design tokens, safe-area, יעדי מגע 44px
│   │   ├── page.tsx              # דשבורד
│   │   │
│   │   ├── leads/
│   │   │   ├── page.tsx          # שרת: שליפה
│   │   │   ├── LeadsView.tsx     # לקוח: רשימה (מובייל) / קנבן (דסקטופ)
│   │   │   └── [id]/page.tsx     # כרטיס לקוח 360°
│   │   ├── tasks/
│   │   │   ├── page.tsx
│   │   │   └── TasksView.tsx     # swipe-to-complete + גיליון האצלה
│   │   ├── quotes/
│   │   │   ├── page.tsx
│   │   │   └── new/QuoteBuilder.tsx   # מסך מפוצל: טופס | תצוגה חיה
│   │   │
│   │   ├── q/[token]/            # ← ציבורי. ללא מעטפת, ללא אימות.
│   │   │   ├── page.tsx
│   │   │   └── PublicQuote.tsx   # OTP → קנבס חתימה → תשלום
│   │   │
│   │   ├── payments/  catalog/  reports/  team/
│   │   ├── integrations/         # ספקים + מיפוי שדות + תבניות
│   │   ├── more/  notifications/  offline/
│   │   │
│   │   └── api/
│   │       ├── ingest/[slug]/route.ts       # אלמנטור · Gravity · WPForms · Meta
│   │       └── webhooks/
│   │           ├── cardcom/route.ts         # ping → GetLpResult → שרשרת
│   │           └── green-api/route.ts       # הודעות · סטטוסים · מצב חיבור
│   │
│   ├── components/
│   │   ├── Shell.tsx             # בר תחתון (מובייל) / סרגל צד (דסקטופ)
│   │   └── ui.tsx                # Chip · Stat · Section · Avatar · תוויות עברית
│   │
│   ├── db/
│   │   ├── schema.ts             # 25 טבלאות + enums + relations
│   │   ├── index.ts              # חיבור Drizzle
│   │   └── seed.ts               # נתוני דמו
│   │
│   └── lib/
│       ├── israel.ts             # ← מע״מ · מספר הקצאה · טלפונים · חישוב מסמך
│       ├── queries.ts            # שאילתות קריאה
│       └── integrations/
│           ├── green-api.ts
│           ├── cardcom.ts
│           └── rivhit.ts
│
├── drizzle.config.ts
└── ARCHITECTURE.md
```

**עקרון החלוקה:** `page.tsx` = Server Component ששולף נתונים.
`XxxView.tsx` = Client Component עם אינטראקטיביות. גבול אחד, ברור.

---

## 3. זרימת הקצה-לקצה (כפי שמומשה)

```
1. טופס אלמנטור  →  POST /api/ingest/{slug}
                     ├─ מיפוי שדות דינמי מה-DB
                     ├─ normalizePhone() → E.164
                     ├─ בדיקת כפילות לפי (org_id, phone)
                     ├─ שמירת UTM + gclid + fbclid + דף נחיתה
                     ├─ יצירת משימת מעקב (יעד: 30 דקות)
                     └─ Push לנציג
                     ↳ תמיד מחזיר 200 — טופס בוורדפרס לא יציג שגיאה ללקוח

2. נציג בנייד     →  /leads → כרטיס → "הצעה"
3. בונה הצעות     →  קטלוג → כמויות → הנחה → תצוגה חיה
                     ↳ אזהרת מספר הקצאה **לפני** השליחה אם הסכום חוצה סף
4. שליחה          →  Green API · כפתור מסוג url (לא quick-reply — ראה §5)
5. הלקוח פותח     →  /q/{token} → viewCount++ → התראה לנציג
6. אישור          →  OTP לוואטסאפ → קנבס חתימה → snapshot + SHA-256
7. תשלום          →  Cardcom LowProfile/Create → PayLink
8. Webhook        →  ping → **GetLpResult** → אמת → payments=PAID
                     → quotes=PAID → leads=WON
9. חשבונית        →  ריווחית Document.New → מספר הקצאה → PDF
10. שליחה         →  Green API sendFileByUrl → הלקוח מקבל בוואטסאפ
```

---

## 4. שכבת ההפשטה של הערוצים

```
        ┌─────────────────────────────┐
        │      ליבת המוצר             │
        └──────────────┬──────────────┘
                       │
     ┌─────────────────┼─────────────────┐
     │                 │                 │
┌────▼─────┐   ┌───────▼──────┐   ┌──────▼──────┐
│ Green API│   │   Cardcom    │   │   ריווחית    │
│ WhatsApp │   │   תשלומים    │   │  חשבונאות   │
└──────────┘   └──────────────┘   └─────────────┘
     ▲
     └── נתיב שדרוג: WhatsApp Cloud API הרשמי = מחלקה נוספת בלבד
```

---

## 5. מה ה-PRD פספס — והתיקונים שבוצעו

| # | ב-PRD | המצב בפועל | מה נעשה |
|---|---|---|---|
| 1 | "VAT (Israeli tax rate)" | **18%** מ-01.01.2025 (לא 17%). תקציב 2026 השאיר על 18% | `vat_rates` לפי תאריך + `vatRateAt()`; השיעור מוקפא על כל מסמך |
| 2 | לא הוזכר | **מספר הקצאה** — חשבונית מעל **₪5,000** (לפני מע״מ, מ-01.06.2026) בלי מספר ⇒ הקונה לא מקזז מע״מ תשומות | `requiresAllocationNumber()`; אזהרה בבונה ההצעות **לפני** השליחה; שדות `allocation_*` |
| 3 | "Green API for WhatsApp Web instance" | זהו חיבור **לא רשמי**. תנאי Meta אוסרים; המספר עלול להיחסם לצמיתות | אזהרה מפורשת במסך האינטגרציות; `delaySendMessagesMilliseconds`; התראה למנהל על `blocked`/`suspended`; ערוץ מופשט לשדרוג ל-Cloud API |
| 4 | "Pre-defined message templates" עם כפתורים | `sendButtons` הוצא משימוש. `sendInteractiveButtons` תומך רק ב-`url`/`call`/`copy` — **אין quick-reply עם payload** | כפתור "אישור הצעה" = `url` לקישור חתום ב-`/q/{token}` |
| 5 | "Webhook handler: update deal to Paid" | ל-Cardcom **אין חתימת HMAC**. גוף ה-webhook ניתן לזיוף | ה-webhook הוא ping בלבד → `GetLpResult` שרת-לשרת → רק לזה מאמינים |
| 6 | Cardcom + ריווחית שניהם | **שניהם מנפיקים חשבוניות** ⇒ כפל הנפקה = בעיית מס | ריווחית = מנפיק יחיד; ב-Cardcom לא נשלח אובייקט `Document`; unique index כגיבוי |
| 7 | לא הוזכר | `document_type` בריווחית **שונה בין חשבונות** ("305" הוא קוד מבנה-אחיד, לא ריווחית) | `Document.TypeList` בעת חיבור + `guessDocTypeMap()` + אישור המשתמש |
| 8 | לא הוזכר | `send_mail` בריווחית ברירת מחדל **true** — סביבת פיתוח תשלח מיילים ללקוחות אמיתיים | תמיד מועבר במפורש `send_mail: false` |
| 9 | "digital signature canvas" | חתימה מסחרית בישראל **אינה דורשת** חתימה מאושרת. השאלה היא ראייתית | OTP + SHA-256 + snapshot + IP/UA ⇒ רמת "מאובטחת" (§3) בלי תעודות |
| 10 | "Israeli Format Validation" | מספרי 1-800/1-700/1-599 **אין להם צורה בינלאומית** — אי אפשר לשלוח להם וואטסאפ | `normalizePhone()` מסווג `MOBILE`/`LANDLINE`/`VOIP`/`SERVICE` ודוחה שירות |

---

## 6. מה חסר ל-production

| נושא | מצב |
|---|---|
| אימות משתמשים (Auth.js) | לא מומש — האב-טיפוס רץ על ארגון/משתמש יחיד |
| RLS בפועל | הסכמה מוכנה; ה-policies לא הופעלו |
| הצפנת `credentials_enc` | השדה קיים; AES-256-GCM + KMS לא חוברו |
| תורים (BullMQ + Redis) | שליחות רצות סינכרונית; נדרש תור עם throttle לפי instance |
| ייצור PDF | התצוגה היא HTML; נדרש Puppeteer/`@react-pdf` לקובץ אמיתי |
| Web Push חי | ה-SW מוכן; חסרים מפתחות VAPID ורישום מנוי |
| קריאות API אמיתיות | הלקוחות כתובים ומוכנים; לא חוברו מפתחות חיים |
| בדיקות | אין. עדיפות ראשונה: `normalizePhone`, `calcTotals`, `requiresAllocationNumber` |

---

## 7. הרצה

```bash
createdb zerem
echo 'DATABASE_URL="postgres://postgres:postgres@127.0.0.1:5432/zerem"' > .env
npm install
npx drizzle-kit push --force
npx tsx src/db/seed.ts
npm run dev
```

בדיקת קליטת ליד:
```bash
curl -X POST localhost:3000/api/ingest/wp-contact-8f3a2c \
  -H 'Content-Type: application/json' \
  -d '{"form_fields[name]":"ישראל ישראלי","form_fields[phone]":"054-1234567"}'
```
שליחה חוזרת עם `+972541234567` תחזיר `duplicate: true`.
